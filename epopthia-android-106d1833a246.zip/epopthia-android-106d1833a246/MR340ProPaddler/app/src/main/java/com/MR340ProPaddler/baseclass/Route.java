package com.MR340ProPaddler.baseclass;

public class Route {

    public WayPoint[] wps;
    public CheckPoint[] cps;

    public Route()
    {
        wps = new WayPoint[0];
        cps = new CheckPoint[0];
    }
//    public Route(Route r0)
//    {
//        wps = new
//
//    }

}
