package com.MR340ProPaddler.utility;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.provider.Settings.Secure;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.widget.AppCompatDrawableManager;
import android.text.format.DateFormat;
import android.widget.Spinner;
import android.widget.Toast;

import com.MR340ProPaddler.ActivityMain;
import com.MR340ProPaddler.adapters.SpinnerAdapter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

@SuppressWarnings({"unused", "WeakerAccess"})
public class ClassUtility {

    private final static double hours_to_milliseconds = 3600000.0;
    private final static double days_to_hours = 24.0;

    public static long getCurrentMilliSeconds() {
        Date curr_date = new Date();
        return curr_date.getTime();
    }

    private static String getBackwardsCompatibleSimpleStringFormat(String myform) {
        String oform = myform;
        int apiLevel = Build.VERSION.SDK_INT;
        if (apiLevel <= 17) {
            oform = oform.replace('H', 'k'); //Historically on Android 'k' was interpreted as 'H',
        }
        return (oform);
    }

    public static Date getDate() {
        return (new Date());
    }

    public static Date getDate(long delta_ms) {
        long curr_date_ms = getDate().getTime() + delta_ms;// + delta_hours;
        Date date = new Date();
        date.setTime(curr_date_ms);
        return date;
    }

    public static Date getDate(Date date, long delta_ms) {
        long curr_date_ms = date.getTime() + delta_ms;// + delta_hours;
        date.setTime(curr_date_ms);
        return date;
    }


    public static String getCurrentTime()
    {
        Date curr_date = new Date();
        return (String) DateFormat.format("hh:mm", curr_date);
    }

    public static String convertSecondsToMinutesSeconds(double sec) {
        double min = sec / 60.0;
        double min_int = (int) min;
        double fsec = (min - min_int) * 60.0;
        if (fsec < 0) fsec = 0;
        return String.format("%02d:%02d", (int) min_int, (int) fsec);
    }

    public static String getRaceOwlTextTime(Date start_date, double delta_hours) {
        long curr_date = (long) (start_date.getTime() + (delta_hours * hours_to_milliseconds));// + delta_hours;
        return (String) DateFormat.format("EEE hh:mma", curr_date);
    }

    public static String getRaceOwlTextTime(Date curr_date) {
        return (String) DateFormat.format("EEE hh:mma", curr_date);
    }

    public static String TimeFromDate(Date start_date, double delta_hours) {
        long curr_date = (long) (start_date.getTime() + (delta_hours * hours_to_milliseconds));// + delta_hours;
        return (String) DateFormat.format("hh:mm:ss a", curr_date);
    }

    public static String dayTimeFromDateNoSec(Date start_date, double delta_hours) {
        long curr_date = (long) (start_date.getTime() + (delta_hours * hours_to_milliseconds));// + delta_hours;
        return (String) DateFormat.format("EEE hh:mm a", curr_date);
    }

    public static String today(int day_offset) {
        Date curr_date = new Date();
        long tmp = (long) (curr_date.getTime() + (day_offset * hours_to_milliseconds * days_to_hours));// + delta_hours;
        return (String) DateFormat.format("MM/dd/yyyy", tmp);
    }

    //    raceowl RACE dates use date format:
    //    2015-07-28T00:00:00
    public static String raceowl_today(int day_offset) {
        Date curr_date = new Date();
        long tmp = (long) (curr_date.getTime() + (day_offset * hours_to_milliseconds * days_to_hours));// + delta_hours;
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("yyyy-MM-ddTHH:mm:ss"), tmp);
    }

    //    raceowl location update use date format:
    //    
    public static String getDateStr(Date curr_date) {
        return (String) DateFormat.format("MM/dd/yyyy", curr_date);
    }

    public static String getTimeStr(Date curr_date) {
        return (String) DateFormat.format("hh:mm a", curr_date);
    }


    //    raceowl location update use date format:
    //    MMddyyyyHHmmss
    public static String raceowl_now() {
        Date curr_date;
        curr_date = new Date();
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"), curr_date);
    }

    public static String getNextHour() {
        Date curr_date;
        curr_date = new Date();
        int hour = getHour(curr_date) + 1;
        if (hour > 23) hour = 0;

        return (DateFormat.format("MMddyyyy", curr_date) + String.format("%02d%02d00", hour, 0));
    }

    public static String getCurrentTimezone() {

        TimeZone tz = TimeZone.getDefault();
        return (tz.getDisplayName());
    }
    //    raceowl location update use date format:
    //    MMddyyyyHHmmss
    public static String getRaceOwlNetTimeNow() {
        Date curr_date;
        curr_date = new Date();
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"), curr_date);
    }

    public static String getRaceOwlNetTime(long utcTime_ms) {
        Date curr_date = convertUTCtoDate(utcTime_ms);
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"), curr_date);
    }

    //    raceowl location update use date format:
    //    
    public static String getRaceOwlNetTime(Date curr_date) {
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"), curr_date);
    }

    //    raceowl location update use date format:
    //
    public static String getRaceOwlNetTime(Date curr_date, int hour_offset) {
        return (String.format("%s%02d0000", DateFormat.format("MMddyyyy", curr_date), hour_offset));
    }

    public static String removeWhiteSpace(String instr) {
        return (instr.replace(" ", "").trim());

    }


    //    raceowl location update use date format:
//      date_str in form of "MM/dd/yyyy"
//      time_str in form of "hh:mm a"
    public static String getRaceOwlNetTime(String date_str, String time_str) {
        Date date = new Date();
        String string_date = date_str + time_str;
         SimpleDateFormat format = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("MM/dd/yyyyhh:mm a"));
        try {
            date = format.parse(string_date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (getRaceOwlNetTime(date));

    }

    //    raceowl location update use date format:
    public static String getRaceOwlNetTime(String raceowl_time, int offset_hour) {
        String string_date = raceowl_time;
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"));
        try {
            long tmp = (long) (format.parse(string_date).getTime() + offset_hour * hours_to_milliseconds);
            string_date = DateFormat.format("MMddyyyyHHmmss", tmp).toString();

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (string_date);
    }


    public static String toRaceOwlTime(String raceowlnettime) {
        return (getRaceOwlTime(parseRaceOwlNetTime(raceowlnettime)));
    }

    public static String toRaceOwlNetTime(String raceowltime) {
        return (getRaceOwlNetTime(parseRaceOwlTime(raceowltime)));
    }


    //    raceowl location update use date format:
    //  // 2017-05-05T07:30:00
    public static String getRaceOwlTime(Date curr_date) {
        return (String) DateFormat.format(getBackwardsCompatibleSimpleStringFormat("yyyy-MM-ddTHH:mm:ss"), curr_date);
    }

    //    getRaceOwlTime
    public static String getRaceOwlTime(Date curr_date, int offset_hour) {
        String string_date;
        long tmp = (long) (curr_date.getTime() + offset_hour * hours_to_milliseconds);
        string_date = DateFormat.format("yyyy-MM-ddTHH:mm:ss", tmp).toString();
        return (string_date);
    }

    //    raceowl location update use date format:
    //    
    public static Date parseRaceOwlNetTime(String string_date) {
        Date date = new Date();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("MMddyyyyHHmmss"));  //MMddyyyyHHmmss
        try {
            date = format.parse(string_date);
            //System.out.println(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (date);
    }

    //    raceowl location update use date format:
    // 2017-05-05T07:30:00
    // "yyyy-MM-ddTHH:mm:ss"
    public static Date parseRaceOwlTime(String string_date) {
        Date date = new Date();

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("yyyy-MM-ddHH:mm:ss"));  //MMddyyyyHHmmss
        try {
            date = format.parse(string_date.replace("T", ""));
            //System.out.println(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (date);
    }


    public static String stringArrayToString(String[] tokens, String delimiter) {

        String ret = "";
        int tot = tokens.length;

        if (tot > 0) {
            ret = tokens[0];
        }
        for (int inx = 1; inx < tokens.length; inx++) {
            if (tokens[inx] != null) {
                ret = String.format("%s%s%s", ret, delimiter, tokens[inx]);
            }
        }
        return ret;
    }

  
    // ------------------------------------------------------------------------
    //	isInteger
    // ------------------------------------------------------------------------
    public static boolean isInteger(String str) {
        try {
            int test = Integer.parseInt(str);
            return true;
        } catch (NumberFormatException ignored) {
        }
        return false;
    }

    // ------------------------------------------------------------------------
    //	isInteger
    // ------------------------------------------------------------------------
    public static int toInteger(String str) {
        int test = 0;
        try {
            test = Integer.parseInt(str);
            return test;
        } catch (NumberFormatException ignored) {
        }
        return test;
    }

    // ------------------------------------------------------------------------
    //	isInteger
    // ------------------------------------------------------------------------
    public static int toInteger(String str, int defaultInt) {
        int test;
        try {
            test = Integer.parseInt(str);
        } catch (NumberFormatException ignored) {
            test = defaultInt;
        }
        return test;
    }
    // ------------------------------------------------------------------------
    //	toDouble
    // ------------------------------------------------------------------------
    public static double toDouble(String str, double defaultDouble) {
        double test;
        try {
            test = Double.parseDouble(str);
        } catch (NumberFormatException ignored) {
            test = defaultDouble;
        }
        return test;
    }


    // ------------------------------------------------------------------------
    //	isNumeric
    // ------------------------------------------------------------------------
    public static boolean isNumeric(String str) {
        try {
            double test = Double.parseDouble(str);
            return true;
        } catch (NumberFormatException ignored) {
        }
        return false;
    }

    // ------------------------------------------------------------------------
    //	VerifyInteger
    // ------------------------------------------------------------------------
    public static boolean VerifyInteger(String test_str, String variable_name, Context ctx) {
        boolean ret;
        String msg;
        if (isInteger(test_str)) {
            ret = true;
        } else {
            msg = String.format("Input Error: %s must be an integer!", variable_name);
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
            ret = false;
        }
        return ret;
    }


    public static long getSecondsFromDate(Date start_date) {
        long diffInSec = 100;
        Date curr_date = new Date();
        if (start_date != null) {
            long diffInMs = curr_date.getTime() - start_date.getTime();
            diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMs);
        }
        return (diffInSec);
    }

    public static long min(long n1, long n2) {
        return Math.min(n1, n2);
    }

    public static long max(long n1, long n2) {
        return Math.max(n1, n2);
    }

    // ------------------------------------------------------------------------
    //	addItemsOnSpinner
    // ------------------------------------------------------------------------
    public static void addItemsOnSpinner(Activity activity, String[]items, Spinner spinner, int initpos)
    {
        List<String> list = new ArrayList<>();
        Collections.addAll(list, items);
        SpinnerAdapter dataAdapter = new SpinnerAdapter(activity, android.R.layout.simple_spinner_item, android.R.id.text1, list, 0);

        spinner.setAdapter(dataAdapter);

        if (initpos >0 && initpos<items.length)
        {
            spinner.setSelection(initpos);
        }
    }

    public static int getIndex(String item, String[]items)
    {
        int index = -1;
        for (int i=0;i<items.length;i++) {
            if (items[i].equals(item)) {
                index = i;
                break;
            }
        }
        return (index);
    }

    //---------------------------------------------------------------------------
    // getConfirmDialog - generic are you sure dialog
    //---------------------------------------------------------------------------
    public static void getConfirmDialog(final Context mContext,
                                        final String title, final String msg,
                                        final String positiveBtnCaption, final String negativeBtnCaption,
                                        final boolean isCancelable, final boolean one_button, final ActivityMain.AlertModal target) {

        ((Activity) mContext).runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

            int imageResource = android.R.drawable.ic_dialog_alert;
            Drawable image = mContext.getResources().getDrawable(imageResource);

            builder.setTitle(title);
            builder.setMessage(msg);
            builder.setIcon(image);
            builder.setCancelable(false);
            builder.setPositiveButton(positiveBtnCaption,
                    (dialog, id) -> target.onButtonClicked(true));

            if (!one_button) {
                builder.setNegativeButton(negativeBtnCaption,
                        (dialog, id) -> target.onButtonClicked(false));
            }
            AlertDialog alert = builder.create();
            alert.setCancelable(isCancelable);
            alert.show();
            if (isCancelable) {
                alert.setOnCancelListener(arg0 -> target.onButtonClicked(false));
            }
        });

    }

    //---------------------------------------------------------------------------
    // convertStringToDate
    //---------------------------------------------------------------------------
    public static Date convertStringToDate(String date_string, String date_format)
    {
        Date date = new Date();
        //String dtStart = "2010-10-15T09:27:37Z";
        //"yyyy-MM-ddTHH:mm:ss"
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat(date_format));// "yyyy/MM/dd");
        try {
            date = format.parse(date_string);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (date);
    }

    //---------------------------------------------------------------------------
    // convertStringToDate
    //---------------------------------------------------------------------------
    public static boolean isDateValid(String date_string, String date_format)
    {
        Date date = new Date();
        boolean ret;

        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(date_format);
        try {
            format.parse(date_string);
            ret = true;
        } catch (ParseException e) {
            ret = false;
        }
        return (ret);
    }


    //---------------------------------------------------------------------------
    // cint - convert string to int
    //---------------------------------------------------------------------------
    public static int cint(String mystr) {
        int myNum = 0;
        try
        {
            myNum = Integer.parseInt(mystr);
        } catch (NumberFormatException nfe)
        {
            System.out.println("Could not parse " + nfe);
        }
        return (myNum);
    }


    //---------------------------------------------------------------------------
    // cint - convert string to int
    //---------------------------------------------------------------------------
    public static float cfloat(String mystr) {
        float myNum = 0;
        try
        {
            myNum = Float.parseFloat(mystr);
        } catch (NumberFormatException nfe)
        {
            System.out.println("Could not parse " + nfe);
        }
        return (myNum);
    }


    //---------------------------------------------------------------------------
    // getHour - get 24 hour
    //---------------------------------------------------------------------------
    public static int getHour(Date mydate)
    {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("HH:mm:ss"));
        String str = sdf.format(mydate);
        return (cint((str.split(":"))[0]));
    }

    //---------------------------------------------------------------------------
    // getHour - get minute
    //---------------------------------------------------------------------------
    public static int getMinute(Date mydate)
    {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat(getBackwardsCompatibleSimpleStringFormat("HH:mm:ss"));
        String str = sdf.format(mydate);
        return (cint((str.split(":"))[1]));
    }


    //---------------------------------------------------------------------------
    // isTimeMoreThanXMinutesAgo
    //---------------------------------------------------------------------------
    public static boolean isTimeMoreThanXMinutesAgo(Date test_time, long minutes) {
        Calendar date = Calendar.getInstance();
        long t = date.getTimeInMillis();
        Date thresh = new Date(t - (minutes * Const.minute_to_msec));
        return (test_time.before(thresh));
    }



    //---------------------------------------------------------------------------
    // convertUTCtoDate
    //---------------------------------------------------------------------------
    public static Date convertUTCtoDate(long milliSeconds)
    {
        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return new Date(milliSeconds);
    }
    //---------------------------------------------------------------------------
    // getBitmapFromVectorDrawable
    //---------------------------------------------------------------------------
    public static Bitmap getBitmapFromVectorDrawable(Context context, int drawableId)
    {
        @SuppressLint("RestrictedApi") Drawable drawable = AppCompatDrawableManager.get().getDrawable(context, drawableId);

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = (DrawableCompat.wrap(drawable)).mutate();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    //---------------------------------------------------------------------------
    // getUniqueID
    //---------------------------------------------------------------------------
    @SuppressLint("HardwareIds")
    public static String getUniqueID(Context ctx)
    {
        return (Secure.getString(ctx.getContentResolver(), Secure.ANDROID_ID));
    }

    //---------------------------------------------------------------------------
    // formatBoatNumber
    //---------------------------------------------------------------------------
    public static String formatBoatNumber(String boat_number)
    {
        String tmpboatnum = boat_number;
        if (isInteger(boat_number))
        {
            int tmpint = Integer.parseInt(boat_number);
            tmpboatnum = String.format("%04d", tmpint);

        }
        return (tmpboatnum);
    }


    //---------------------------------------------------------------------------
    // toSentenceCase
    //---------------------------------------------------------------------------
    public static String toSentenceCase(String instr)
    {
        String cap = instr;
        if (instr.length() > 1) {
            cap = instr.substring(0, 1).toUpperCase() + instr.substring(1);
        }
        return (cap);
    }

    //---------------------------------------------------------------------------
    // getAppVersionString
    //---------------------------------------------------------------------------
    public static  String getAppVersionString(Context context)
    {
        String ret = "";
        PackageManager manager =  context.getPackageManager();
        String name = context.getPackageName();
        PackageInfo info;
        try
        {
            info = manager.getPackageInfo(name,0);
            ret = info.versionName;
        }
        catch (PackageManager.NameNotFoundException e)
        {
            e.printStackTrace();
        }
        return (ret);
    }

    public static double getDeltaTimeSec(Date prev, Date curr)
    {
        double diffInSec;
        long diffInMs = curr.getTime() - prev.getTime();
        diffInSec = TimeUnit.MILLISECONDS.toSeconds(diffInMs);
        return (diffInSec);
    }

    public static String getApplicationName(Context context)
    {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : context.getString(stringId);
    }

   
  // ----------------------------------------------------------------------
    // sign
    // ----------------------------------------------------------------------
    static public double sign(double val) {
        if (val > 0) return 1.0;
        else return -1.0;
    }


    // ----------------------------------------------------------------------
    // calcElapsedTimeSec
    // ----------------------------------------------------------------------
    static double calcElapsedTimeSec(Date s0, Date s1) {
        long diff_ms = s1.getTime() - s0.getTime();
        return diff_ms / 1000.0;
    }
    public static Date toWholeHour(Date d, int beforeOrAfter) {
        Calendar c = new GregorianCalendar();
        c.setTime(d);
        c.add(Calendar.HOUR, beforeOrAfter);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

    public static Date toWholeMinute(Date d, int beforeOrAfter) {
        Calendar c = new GregorianCalendar();
        c.setTime(d);
        c.add(Calendar.MINUTE, beforeOrAfter);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTime();
    }

}
