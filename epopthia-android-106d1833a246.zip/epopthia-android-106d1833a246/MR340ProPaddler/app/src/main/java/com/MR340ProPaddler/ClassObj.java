package com.MR340ProPaddler;

public class ClassObj
{
	String rawobj;
	final float[] rivermile;
	public double[] lat_rad;
	public double[] lon_rad;
	
	
	ClassObj()
	{
		rawobj = "";
        rivermile = new float[2];
	}
}

