package com.MR340ProPaddler;

import com.MR340ProPaddler.baseclass.LatLngRad;
import com.MR340ProPaddler.utility.Const;

import static com.MR340ProPaddler.WayPointNav.*;
import static java.lang.Math.abs;
import static java.lang.Math.max;

class ClassSimulation {
	private static final double accuracy_m = 30.0 * Const.ft_to_m;
	private double sim_last_elapsed_time_sec;
	private double sim_last_river_mile;

	private final WayPointMission wp;

	// ----------------------------------------------------------------------
	// simulation constructor
	// ----------------------------------------------------------------------
	ClassSimulation()
	{
		wp = ActivityMain.wp; // get wp from main activity
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(false);
		sim_last_river_mile = 0;
	}

	// ----------------------------------------------------------------------
	// init
	// ----------------------------------------------------------------------
	void init(float speed_mph, float rivermile)
	{
		int curr_wp =  wp.getWayPointIndex(rivermile);
		wp.setWaypoint(curr_wp);

		double lat_deg = wp.getWaypointLatitude(curr_wp)*Const.rtd;
		double lon_deg = wp.getWaypointLongitude(curr_wp)*Const.rtd;
		double bearing_deg = wp.getWaypointBearing();
		double speed_mps = speed_mph * Const.mph_to_mps;

		wp.updateNav(lat_deg, lon_deg, speed_mps, bearing_deg, accuracy_m, System.currentTimeMillis());

		// update sim AppState
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(true);
		sim_last_river_mile = rivermile;
	}

	// ----------------------------------------------------------------------
	// init - secondary init used for settings restore
	// ----------------------------------------------------------------------
	void init(float speed_mph, double lat_deg, double lon_deg, double bearing_deg, int curr_wp)
	{
		wp.setWaypoint(curr_wp);

		double speed_mps = speed_mph * Const.mph_to_mps;

		wp.updateNav(lat_deg, lon_deg, speed_mps, bearing_deg, accuracy_m, System.currentTimeMillis());

		// update simulation AppState
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(true);
		sim_last_river_mile = WayPointMission.wps[WayPointMission.curr_wp_index].rivermile;
	}

	// ----------------------------------------------------------------------
	// cycle
	// ----------------------------------------------------------------------
	void cycle(double elapsed_time_s, double speed_mph)
	{
		double speed_mps = speed_mph * Const.mph_to_mps;

		double deltat_s = elapsed_time_s - sim_last_elapsed_time_sec;

		deltat_s = max(deltat_s,0);  	//forbid going backwards in time.
		double wpdir = wp.getWpDirection();

		double delta_mile = speed_mps * Const.m_to_mile * deltat_s;
		double new_rivermile = (-delta_mile*wpdir)  + sim_last_river_mile; //negative delta mile goes down river
		double wp_bearing_rad;

		//get closest wp; (this could be in front or behind the boat)
		int new_wp = wp.getWayPointIndex((float) new_rivermile);

		double rm_delta_mile = wpdir * (WayPointMission.wps[new_wp].rivermile - new_rivermile);

		//if rm_delta neg then boat is behind wp RM
		//if rm_delta positive then boat is behind wp RM
		if (rm_delta_mile < 0)
		{
			wp.setWaypoint(new_wp);
		}
		else
		{
			wp.setWaypoint(wp.getNextWP(new_wp));
		}

		//get the new current wp
		int curr_wp = wp.getCurrentWaypoint();

		//get the new delta to the new current waypoint
		rm_delta_mile = wp.getWpDirection() * (WayPointMission.wps[curr_wp].rivermile - new_rivermile);
		double rm_delta_ft = rm_delta_mile / Const.ft_to_mile;

		//bearing to next wp
		int prev_wp = wp.getPrevWP(curr_wp);
		wp_bearing_rad = LatLonToBearing(WayPointMission.wps[prev_wp].pt.latitude_rad, WayPointMission.wps[prev_wp].pt.longitude_rad,WayPointMission.wps[curr_wp].pt.latitude_rad,WayPointMission.wps[curr_wp].pt.longitude_rad);

		LatLngRad tempwp = RangeBearingToLatLon(WayPointMission.wps[curr_wp].pt.latitude_rad, WayPointMission.wps[curr_wp].pt.longitude_rad, wp_bearing_rad+Const.pi, abs(rm_delta_ft));

		wp.updateNav(tempwp.latitude_rad *Const.rtd, tempwp.longitude_rad *Const.rtd, speed_mps, wp_bearing_rad*Const.rtd, accuracy_m, System.currentTimeMillis());

		//update sim AppState
		sim_last_elapsed_time_sec = elapsed_time_s;
		sim_last_river_mile = new_rivermile;

	}
}
