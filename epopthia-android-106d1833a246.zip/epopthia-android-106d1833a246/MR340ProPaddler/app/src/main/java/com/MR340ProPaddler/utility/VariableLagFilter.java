package com.MR340ProPaddler.utility;

public class VariableLagFilter {
	
	private final double tau_s;
	private long last_init_ms;
	private long last_time_ms;
	private final double[] x = new double[2];
	private boolean init_init;
	
	public VariableLagFilter(double init_tau_s)
	{
		tau_s = init_tau_s;
		init_init = true;
	}
	
	public double step(double u, boolean init, long curr_time_ms)
	{
		double y;
		
		if (init_init) 
		{
			init = true;
			init_init = false;
		}

		if (init)
		{
			last_init_ms = curr_time_ms;
			last_time_ms = curr_time_ms;
			x[0] = u;
			x[1] = u;
			y = u;
		}
		else
		{
			double delta_init_s = (curr_time_ms - last_init_ms) / 1000.0;
			if (delta_init_s >= tau_s)
			{
				//output
				double deltat_s = (curr_time_ms - last_time_ms) / 1000.0;
				y = (deltat_s *(u+x[0]) - (deltat_s -2.0*tau_s)*x[1]) / (2.0*tau_s+ deltat_s);
				
				//AppState update
				x[0] = u;
				x[1] = y;
			}
			else
			{	
				y = u;
			}
			last_time_ms = curr_time_ms;
		}
				
		return (y);
	}
}
