package com.MR340ProPaddler.baseclass;

@SuppressWarnings({"WeakerAccess", "unused"})
public class GPSData
{
    public final LatLngTime ptt;
    public final double speed_mps;  //valid speed is >=0
    public final double bearing_rad;
    public final double accuracy_m; //valid accuracy is >=0

    public GPSData()
    {
        ptt = new LatLngTime();
        speed_mps = -1.0;
        bearing_rad = 0;
        accuracy_m = -1.0;
    }

    public GPSData(GPSData d0)
    {
        ptt = new LatLngTime(d0.ptt);
        speed_mps = d0.speed_mps;
        bearing_rad = d0.bearing_rad;
        accuracy_m = d0.accuracy_m;
    }

    public GPSData(LatLngRad pt1, double speed1_mps, double bearing1_rad, double accuracy1_m, long time1_ms)
    {
        ptt = new LatLngTime(pt1, time1_ms);
        speed_mps = speed1_mps;
        bearing_rad = bearing1_rad;
        accuracy_m = accuracy1_m;
    }
}
