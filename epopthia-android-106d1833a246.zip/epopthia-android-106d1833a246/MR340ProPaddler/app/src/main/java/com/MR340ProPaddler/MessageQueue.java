package com.MR340ProPaddler;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

class MessageQueue
{
    private final ArrayList<String> messages = new ArrayList<>();

    MessageQueue()
    {

    }

    public void add(String msg)
    {
        msg = msg.trim();
        if (msg.length() > 0) {
            messages.add((msg));
        }
        else
        {
            Log.e("MessageQueue:", "attempt to add 0 length message");
        }
    }

    void display(Context ctx, boolean screenOff)
    {
        if (!screenOff) {
            if (messages.size() > 0 && ctx != null) {
                int index = 0;
                String msg = messages.get(index);
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show();
                messages.remove(index);
            }
        }
        else
        {
            messages.clear();
        }
    }
}
