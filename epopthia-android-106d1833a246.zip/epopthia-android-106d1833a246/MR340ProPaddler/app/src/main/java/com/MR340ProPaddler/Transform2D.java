package com.MR340ProPaddler;

import android.graphics.Matrix;
import android.graphics.PointF;

import com.MR340ProPaddler.utility.Const;

public class Transform2D {

	private final Matrix a10 = new Matrix(); //boat to NE
	private final Matrix a02 = new Matrix(); //NE to track
	private final Matrix a23 = new Matrix(); //track to screen
	
	public final Matrix a13 = new Matrix(); //boat to screen

	public Transform2D(float[] scale, float[] offset)
	{
		// track to screen
		a23.postRotate(-90);
		a23.postScale(scale[0], scale[1]);
		a23.postTranslate(offset[0], offset[1]);		
	}

	// ------------------------------------------------------------------------
	// createBoatToScreen 
	// ------------------------------------------------------------------------
	public void createBoatToScreen(float bearing_rad, float track_rotation_rad, float north_ft, float east_ft)
	{
		// boat to NED
		a10.reset();
		a10.postRotate((float) (bearing_rad* Const.rtd));
		a10.postTranslate(north_ft, east_ft);

		// NED to track
		a02.reset();
		a02.postRotate((float) (track_rotation_rad*Const.rtd));
		a02.invert(a02);

		// boat to screen
		a13.reset();
		a13.set(a10);
		a13.postConcat(a02);
		a13.postConcat(a23);
	}
	
	// ------------------------------------------------------------------------
	// xformPoints
	// ------------------------------------------------------------------------
	public PointF[] xformPoints(PointF[] pts, Matrix A)
	{
		int num = pts.length;
		PointF[] xpts = new PointF[num];
				
		// place back into the point array
		for (int inx=0;inx<num;inx++)
		{
			float[] pt = new float[]{pts[inx].x,pts[inx].y};
			A.mapPoints(pt);
			xpts[inx] = new PointF(pt[0],pt[1]);
		}
		
		return xpts;
	}
	
}
