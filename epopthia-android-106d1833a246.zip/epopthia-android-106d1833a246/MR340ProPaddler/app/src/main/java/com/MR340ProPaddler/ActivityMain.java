package com.MR340ProPaddler;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.MR340ProPaddler.adapters.PagerAdapter;
import com.MR340ProPaddler.adapters.SpinnerAdapter;
import com.MR340ProPaddler.fragments.Frag00_summary;
import com.MR340ProPaddler.fragments.Frag01_nav;
import com.MR340ProPaddler.fragments.Frag02_tracking;
import com.MR340ProPaddler.fragments.Frag03_checkpointlog;
import com.MR340ProPaddler.fragments.Frag04_eta;
import com.MR340ProPaddler.fragments.Frag05_progress;
import com.MR340ProPaddler.fragments.Frag06_big_display;
import com.MR340ProPaddler.infrastructure.AppState;
import com.MR340ProPaddler.infrastructure.BatteryMonitor;
import com.MR340ProPaddler.infrastructure.NetworkMonitor;
import com.MR340ProPaddler.infrastructure.Settings;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

public class ActivityMain extends FragmentActivity {

    private Handler mMainTimerLoopHandle = null;
    private static int gps_watch_dog_count = 0;
    private final int min_gps_watch_dog_count = 40;
    private float avg_scale;
    private static boolean gps_disabled;
    private static final int MY_CHILD_ACTIVITY = 10;
    private long lastLocationTrackTime_ms = -1;
    private long lastStateUpdateTime_ms = -1;
    private Settings lastSettings = null;
    private AppState lastState = null;
    private Context mContext;
    private PowerManager.WakeLock mWakeLock;

    public static WayPointMission wp = null;
    private static BatteryMonitor battery = null;
    private static RaceOwlClient raceowl = null;
    private static ClassSimulation sim = null;
    private static Globals globals = null; // application globals
    private static ClassLog history = null;

    private BroadcastReceiver mScreenMonitor = null;
    private BroadcastReceiver mPositionUpdate = null;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        mContext = this;

        // Get the one and only instance of globals
        globals = Globals.getInstance();
        globals.appState.ctx = this;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpager_layout);

        //screen to remain on until turned off by user
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        //don't let the app snooze
        PowerManager pm = (PowerManager)this.getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"MR340Propaddler:");
            mWakeLock.acquire();
        }

        initialisePaging();

        //start GPS service
        startGPSService();

        //start speech service
        startTTSService();

        // monitor for screen off/on
        startScreenMonitor();

        //start battery monitor
        //get an instance of the battery monitor
        battery = BatteryMonitor.getInstance();
        startBatteryMonitor();

        // circular buffer for storing location data
        history = ClassLog.getInstance();
        lastSettings = new Settings(globals.settings);
        lastState = new AppState(globals.appState);

        avg_scale = (globals.settings.triggersPerMinute / (float) history.getBufferSize());

        // create instance of waypoint mission class
        wp = WayPointMission.getInstance();

        //init the race owl races
        raceowl = RaceOwlClient.getInstance();

        // new simulation class
        sim = new ClassSimulation();

        //force finding the closest WP
        wp.initialized = false;

        // Dialog if comm is turned on
        boolean oneOrMoreCommunicationModesEnabled = raceowl.getTrackingStatus() || globals.settings.enableAutoCheckin;
        if (oneOrMoreCommunicationModesEnabled
                && globals.appState.quickStartState == AppState.QuickStartState.disabled
                && !globals.appState.isSoftStart)
        {
            verifyCommEnable();
        }

        // start timed activities
        mMainTimerLoopHandle = new Handler(); //setup for timed updates
        startRepeatingTasks();

        // start one-time tasks
        startOneTimeTask();

        if (!hasPermissions(this, PERMISSIONS)) {
            // The request code used in ActivityCompat.requestPermissions()
            // and returned in the Activity's onRequestPermissionsResult()
            int PERMISSION_ALL = 1;
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        setStartupScreen();

    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void stopGPSService() {
        Log.d(globals.appState.appName, "stopGPSService");
        stopService(new Intent(this, LocationService.class));
        unregisterLocationReceiver();
    }

    private void startGPSService() {
        Log.d(globals.appState.appName, "startGPSService");

        //start GPS service
        Intent gps_service = new Intent(this, LocationService.class);
        long gps_update_time;
        if (isNavScreen(globals.settings.startup_screen_idx)) {
            gps_update_time = globals.settings.gpsFastUpdatePeriod_sec;
        } else {
            gps_update_time = globals.settings.gpsSlowUpdatePeriod_sec;
        }
        gps_service.putExtra("update_rate_ms", gps_update_time * 1000);

        ContextCompat.startForegroundService(this.getApplicationContext(), gps_service);

        registerLocationReceiver();

    }

    @Override
    protected void onDestroy() {

        mWakeLock.release();

        stopGPSService();

        stopTTSService();

        stopRepeatingTasks();

        globals.saveAllSettings(this);

        stopBatteryMonitor();

        stopScreenMonitor();

        super.onDestroy();
    }

    private void initialisePaging() {
        List<Fragment> fragments = new Vector<>();
        fragments.add(Fragment.instantiate(this, Frag00_summary.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag01_nav.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag02_tracking.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag03_checkpointlog.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag04_eta.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag05_progress.class.getName()));
        fragments.add(Fragment.instantiate(this, Frag06_big_display.class.getName()));
        PagerAdapter mPagerAdapter;
        mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
        ViewPager pager = findViewById(R.id.viewpager);
        pager.setAdapter(mPagerAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu); //your file name
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            lastSettings = new Settings(globals.settings);
            lastState = new AppState(globals.appState);
            //startActivityForResult(new Intent(this, ActivitySettings.class));
            Intent intent = new Intent(this, ActivitySettings.class);
            startActivityForResult(intent, MY_CHILD_ACTIVITY);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == MY_CHILD_ACTIVITY) {
            if (resultCode == Activity.RESULT_OK) {
                processSettingsChanges();
            }
        }
    }

    // ------------------------------------------------------------------------
    //	processSettingsChanges
    // ------------------------------------------------------------------------
    private void processSettingsChanges() {
        boolean reset = false;

        //GPS update rate
        if (globals.settings.gpsSlowUpdatePeriod_sec != lastSettings.gpsSlowUpdatePeriod_sec) {
            setBestGPSUpdateRate(getCurrentScreen(), true);
        }
        //GPS update nav rate
        if (globals.settings.gpsFastUpdatePeriod_sec != lastSettings.gpsFastUpdatePeriod_sec) {
            setBestGPSUpdateRate(getCurrentScreen(), true);
        }

        //switch speed basis
        if (globals.settings.location_based_speed && !lastSettings.location_based_speed) {
            wp.reset_speed_update_count(wp.min_speed_update_count);
        }

        //reset the planner upcoming_races
        if (globals.settings.reset_planner) //reset the plan
        {
            wp.resetCheckPointRestTime();
            globals.settings.reset_planner = false;
        }

        //update the planned rest times if the plan is not frozen
        if (!globals.settings.freeze_baseline_plan) {
            wp.updatePlanRestTime();
        }
        //race owl
        if (lastSettings.RaceEventID != globals.settings.RaceEventID) {
            raceowl.setRaceEvent(globals.settings.RaceEventID);
            reset = true;

        }
        if (!lastState.enableSimulation && globals.appState.enableSimulation) //trans into sim
        {
            Log.d(globals.appState.appName, "simulation enabled");
            wp.reset_speed_update_count(wp.min_speed_update_count);
            sim.init(globals.settings.sim_speed_mph, globals.settings.sim_init_rivermile);
            reset = true;
        }
        else if (lastState.enableSimulation && !globals.appState.enableSimulation) //trans out of sim
        {
            Log.d(globals.appState.appName, "simulation disabled");
            wp.reset_speed_update_count(wp.min_speed_update_count);
            reset = true;
        }

        if (globals.appState.enableSimulation && (lastSettings.sim_init_rivermile != globals.settings.sim_init_rivermile)) //jump to new location
        {
            wp.reset_speed_update_count(wp.min_speed_update_count);
            sim.init(globals.settings.sim_speed_mph, globals.settings.sim_init_rivermile);
        }

        //determine waypoint direction from start and stop waypoints
        double tmp_delta_mile = wp.getCheckpointRiverMile(globals.settings.finishCheckpointIndex) - wp.getCheckpointRiverMile(globals.settings.startCheckpointIndex);
        globals.settings.waypoint_reverse = tmp_delta_mile > 0;
        if (lastSettings.waypoint_reverse != globals.settings.waypoint_reverse) //reverse waypoints
        {
            reset = true;
        }

        //reset the start and stop checkpoints
        if (globals.settings.startCheckpointIndex != lastSettings.startCheckpointIndex
                || globals.settings.finishCheckpointIndex != lastSettings.finishCheckpointIndex
                || globals.settings.waypoint_reverse != lastSettings.waypoint_reverse) {
            //validate the start/stop checkpoints
            if (!wp.validateStartStop()) {
                reset = true;
            }
        }

        if (!lastSettings.startDate.equals(globals.settings.startDate) && isGoodGpsWatchdog(globals.appState.enableSimulation, false)) //new start time
        {
            reset = true;
        }

        //set counter log to -1, this will force an immediate log entry
        if (lastSettings.logging_delta_min > globals.settings.logging_delta_min) {
            mLogger.run();
        }

        if (lastSettings.audioStatusUpdatePeriod_min != globals.settings.audioStatusUpdatePeriod_min) {
            doAudioStatusNow();
        }


        if ((lastSettings.desired_finish_hr != globals.settings.desired_finish_hr) &&
                (lastSettings.desired_speed_mph != globals.settings.desired_speed_mph)) {
            //unable to set both finish and speed
            globals.appState.useDesiredFinishHr = true;
            Toast.makeText(this, "Unable to simultaneously set desired finish and speed. Using desired finish.", Toast.LENGTH_LONG).show();
            wp.calcSpeedOrHourGoal();
        } else if ((lastSettings.desired_finish_hr != globals.settings.desired_finish_hr)) {
            globals.appState.useDesiredFinishHr = true;
            wp.calcSpeedOrHourGoal();
        } else if ((lastSettings.desired_speed_mph != globals.settings.desired_speed_mph)) {
            globals.appState.useDesiredFinishHr = false;
            wp.calcSpeedOrHourGoal();
        }

        if (reset) {
            getConfirmDialog(mContext, "Confirm Reset", "Actions will reset event history. Continue?", "Yes", "No", false, false, value -> {
                if (value) {
                    resetAll();
                } else {
                    globals.settings = new Settings(lastSettings);
                }
            });
        }

        //write globals to non-volatile
        globals.saveAllSettings(mContext);
    }

    // ------------------------------------------------------------------------
    // resetAll - reset checkpoints, logs
    // ------------------------------------------------------------------------
    private void resetAll() {

        broadcastGPSRateUpdate(10);

        //export log file
        ExportLogFile();

        //average history
        history.Reset();

        //force finding the closest WP
        wp.initialized = false;
        wp.resetCurrentPosition();


        // clear wp arrival times
        wp.ClearActualCheckpointArrivalTimes();

        // delete the log file
        ClassFileIO fio = new ClassFileIO(this);
        fio.deleteLog();

        //reset the total miles
        ResetTotalMiles();

        //clear sms log
        WayPointMission.sms_log.clear();
        fio.deleteTextLog();

        globals.appState.forceReset = false;

        globals.locations.clear();
        globals.checkPointCycles.clear();
        globals.racerStates.clear();

        wp.setNearestCheckpointIndex(3 * Const.sec_to_ms);


        setBestGPSUpdateRate(globals.settings.startup_screen_idx, !globals.appState.screenOff);
        broadcastGPSRateUpdate(0);


    }

    // ------------------------------------------------------------------------
    //	ResetTotalMiles
    // ------------------------------------------------------------------------
    private void ResetTotalMiles() {
        //reset total miles
        globals.settings.tot_mile_last_lat_rad = 0.0;
        globals.settings.tot_mile_last_lon_rad = 0.0;
        globals.settings.tot_mile = (float) 0.0;

        //reset river miles
        globals.settings.start_river_mile = (float) wp.getRiverMile();
    }

    @SuppressWarnings("SameParameterValue")
    private void resetGpsWatchdog(int count) {
        gps_watch_dog_count = count;

    }

    // ------------------------------------------------------------------------
    //	isGoodGpsWatchdog
    // ------------------------------------------------------------------------
    public static boolean isGoodGpsWatchdog(boolean is_simulation, boolean decrement) {
        if (is_simulation) return (true);

        if (decrement) gps_watch_dog_count--;

        if (gps_watch_dog_count <= 0) {
            gps_watch_dog_count = 0;
            return (false);
        } else {
            return (true);
        }
    }

    // ------------------------------------------------------------------------
    //	registerLocationReceiver
    // ------------------------------------------------------------------------
    private void registerLocationReceiver() {
        final IntentFilter theFilter = new IntentFilter();

        theFilter.addAction("MR340_LOCATION");

        mPositionUpdate = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String strAction = intent.getAction();

                if (strAction != null && strAction.equals("MR340_LOCATION")) {

                    gps_disabled = intent.getBooleanExtra("gpsDisabled", false);
                    if (!gps_disabled) {
                        double lat = intent.getDoubleExtra("Latitude", 0.0);
                        double lon = intent.getDoubleExtra("Longitude", 0.0);
                        float speed = intent.getFloatExtra("Speed", (float) 0.0);
                        float bearing = intent.getFloatExtra("Bearing", (float) 0.0);
                        long time = intent.getLongExtra("Time", 0);
                        float accuracy = intent.getFloatExtra("Accuracy", (float) 0.0);
                        resetGpsWatchdog(min_gps_watch_dog_count);

                        updateLocation(lat, lon, speed, bearing, time, accuracy);
                        globals.appState.gpsDisableWarningDisplayed = false;
                    } else {
                        if (!globals.appState.enableSimulation && !globals.appState.gpsDisableWarningDisplayed) {
                            promptForGPS();
                        }
                    }
                }
            }
        };

        this.registerReceiver(mPositionUpdate, theFilter);
    }

    //---------------------------------------------------------------------------
    // unregisterLocationReceiver
    //---------------------------------------------------------------------------
    private void unregisterLocationReceiver() {
        int apiLevel = Build.VERSION.SDK_INT;

        if (apiLevel >= 7) {
            try {
                this.unregisterReceiver(mPositionUpdate);
            } catch (IllegalArgumentException e) {
                mPositionUpdate = null;
            }
        } else {
            this.unregisterReceiver(mPositionUpdate);
            mPositionUpdate = null;
        }
    }

    //---------------------------------------------------------------------------
    // updateLocation
    //---------------------------------------------------------------------------
    private void updateLocation(double lat_deg, double lon_deg, float speed_mps, float bearing_deg, long time_ms, float accuracy_m) {
        if (!globals.appState.enableSimulation)
        {
//            Log.d(globals.appState.appName, "updateLocation");
            wp.updateNav(lat_deg, lon_deg, speed_mps, bearing_deg, accuracy_m, time_ms);

            if (globals.appState.screenOff)
            {
                //mMainTimerLoopHandle.removeCallbacks(runMainTimerEvent);
                mMainTimerLoopHandle.postDelayed(runMainTimerEvent, Const.prime_deltat_ms);   // X second between raceowl_status updates
            }
        }
    }

    //---------------------------------------------------------------------------
    // mLogger
    //---------------------------------------------------------------------------
    private final Runnable mLogger = new Runnable() {
        @Override
        public void run() {

            //Toast.makeText(	   	 mContext ,"mLogger repeatable" , Toast.LENGTH_LONG).show();
            long startTime = System.currentTimeMillis();
            updateLog();
            long delay = (long) (1000 * 60 * globals.settings.logging_delta_min) - (System.currentTimeMillis() - startTime);
            if (delay < 0) {
                delay = 0;
            }
            mMainTimerLoopHandle.removeCallbacks(mLogger);
            mMainTimerLoopHandle.postDelayed(mLogger, delay);
        }
    };



//    long referenceTime_ms = System.currentTimeMillis();
//    long countMainTimer = 0;
    //---------------------------------------------------------------------------
    // runMainTimerEvent
    //---------------------------------------------------------------------------
    private final Runnable runMainTimerEvent = new Runnable() {
        @Override
        public void run() {

            mMainTimerLoopHandle.removeCallbacks(runMainTimerEvent);
            //update the context
            globals.appState.ctx = getApplication().getApplicationContext();

            //process periodic events
            processPeriodicEvents();

            //display a message from the queue
            globals.messages.display(globals.appState.ctx, globals.appState.screenOff);
            //setup the next call to the status checker

            mMainTimerLoopHandle.postDelayed(runMainTimerEvent, Const.prime_deltat_ms);
        }
    };

    //---------------------------------------------------------------------------
    // doAudioStatusNow
    //---------------------------------------------------------------------------
    private void doAudioStatusNow() {
        mAudioStatus.run();
    }

    //---------------------------------------------------------------------------
    // mAudioStatus
    //---------------------------------------------------------------------------
    private final Runnable mAudioStatus = new Runnable() {
        @Override
        public void run() {

            //Toast.makeText(	   	 mContext ,"main repeatable" , Toast.LENGTH_LONG).show();
            if (globals.settings.enableAudibleStatus) {
                wp.audibleStatus();
            }
            long delay = (long) globals.settings.audioStatusUpdatePeriod_min * 1000 * 60;
            mMainTimerLoopHandle.removeCallbacks(mAudioStatus);
            mMainTimerLoopHandle.postDelayed(mAudioStatus, delay);
        }
    };

    //---------------------------------------------------------------------------
    // mStartupDialog
    //---------------------------------------------------------------------------
    private final Runnable mStartupDialog = new Runnable() {
        @Override
        public void run() {

            // make really sure we are online or not
            globals.appState.isOnline = NetworkMonitor.isNetworkAvailable(getApplicationContext());

            boolean tryAgain = false;

            // on startup if we have a network available we want to update the race listing
            if  (globals.appState.isOnline)
            {
                if (!globals.appState.racesInitializing && !globals.appState.racesInitialized) {
                    raceowl.updateRaces();
                    tryAgain = true;
                }
            }
            else {
                // check for valid race
                boolean validRaceUpdate = raceowl.isValidRaceUpdate(globals.settings.lastRaceUpdateDate);
                boolean validRaceEvent = raceowl.isRaceEventRacing(globals.settings.RaceEventID);
                Log.d(globals.appState.appName, String.format("startup dialog selected: validRaceUpdate = %b, validRaceEvent = %b", validRaceUpdate, validRaceEvent));

                if (validRaceUpdate && validRaceEvent) {
                    globals.appState.racesInitialized = true;  //the network is gone but - allow for bypass of start screen, as we have valid downloads
                } else {
                    globals.appState.racesInitialized = false;
                    globals.appState.quickStartState =  AppState.QuickStartState.armed;
                }

                // we need a network as the races are invalid and we are offline, try 3 times to resolve then give up
                if (!globals.appState.racesInitialized && globals.appState.racesInitializedRetryCount > 0) {
                    if (!globals.appState.isOnline) {
                        promptForNetwork();
                        // gui exit will trigger a try again
                        globals.appState.racesInitializedRetryCount--; //give up
                    }
                }
            }

            // if all good, then show the startup dialog
            if (globals.appState.racesInitialized) {
                if (globals.appState.quickStartState == AppState.QuickStartState.armed)
                    showQuickStartDialog(mContext);
            }
            else
            {
                tryAgain = true;
            }


            if (tryAgain )
            {
                // setup a loop to check again
                mMainTimerLoopHandle.removeCallbacks(mStartupDialog);
                mMainTimerLoopHandle.postDelayed(mStartupDialog, 4 * Const.sec_to_ms);
            }
        }
    };



    //---------------------------------------------------------------------------
    // promptForNetwork
    //---------------------------------------------------------------------------
    private void promptForNetwork() {
        ClassUtility.getConfirmDialog(mContext, "Warning: No Network!", "Unable to communicate with RaceOwl. A network connection is required during application initialization.", "Retry", "Cancel", false, false, value -> {
            //globals.gpsDisableWarningDisplayed = true;
            if (value) {
                raceowl.updateRaces();
            } else {
                globals.settings.lastRaceUpdateDate = ClassUtility.getDate();
            }

            mMainTimerLoopHandle.postDelayed(mStartupDialog, 2 * Const.sec_to_ms);
        });
    }

    //---------------------------------------------------------------------------
    // startOneTimeTask
    //---------------------------------------------------------------------------
    private void startOneTimeTask() {
        int start_delay_ms = 0;
        if (raceowl.getRaceCount() <= 0) {
            start_delay_ms = 3 * Const.sec_to_ms;
        }
        mMainTimerLoopHandle.removeCallbacks(mStartupDialog);
        mMainTimerLoopHandle.postDelayed(mStartupDialog, start_delay_ms);
    }

    //---------------------------------------------------------------------------
    // startRepeatingTasks
    //---------------------------------------------------------------------------
    private void startRepeatingTasks() {
        Log.d(globals.appState.appName, "Start Repeating Tasks");
        runMainTimerEvent.run();
        mLogger.run();
        mAudioStatus.run();
    }

    //---------------------------------------------------------------------------
    // stopRepeatingTasks
    //---------------------------------------------------------------------------
    private void stopRepeatingTasks() {

        Log.d(globals.appState.appName, "Stop Repeating Tasks");
        mMainTimerLoopHandle.removeCallbacks(runMainTimerEvent);
        mMainTimerLoopHandle.removeCallbacks(mLogger);
        mMainTimerLoopHandle.removeCallbacks(mAudioStatus);
        mMainTimerLoopHandle.removeCallbacks(mStartupDialog);
    }

    // ------------------------------------------------------------------------
    //	processPeriodicEvents
    // ------------------------------------------------------------------------
    private int counter_sim = -1;
    private int counter_avg = -1;

    private void processPeriodicEvents() {

        // update the elapsed time
        double elapsed_time_s = wp.calcElapsedTimeSec();


        // determine if we are Online or not
        globals.appState.isOnline = NetworkMonitor.isNetworkAvailable(getApplicationContext());

        long currSystemTime_ms = System.currentTimeMillis();
        double deltaLocationTimeMin = lastLocationTrackTime_ms < 0 ? 0 : (currSystemTime_ms - lastLocationTrackTime_ms) * Const.ms_to_min;
        double deltaStateTimeMin = lastStateUpdateTime_ms < 0 ? 0 : (currSystemTime_ms - lastStateUpdateTime_ms) * Const.ms_to_min;

        // update the simulation
        if (globals.appState.enableSimulation) {
            counter_sim++;
            if (counter_sim == 0 || counter_sim >= 1) {
                counter_sim = 0;
                //sim.cycle(max(elapsed_time_s, 0.0), globals.globals.sim_speed_mph);
                sim.cycle(elapsed_time_s, globals.settings.sim_speed_mph);
            }
        }

        if (elapsed_time_s >= 0) {

            ClassLogData log = new ClassLogData();

            // update circular log buffer
            log.lat_rad = wp.getLatitude();
            log.lon_rad = wp.getLongitude();
            log.elapsed_time_hr = (float) (wp.getElapsedTimeSec(false) / 3600);
            log.speed_mph = (float) wp.getSpeed();
            log.track_mph = (float) wp.getTrackSpeed();
            log.rivermile = (float) wp.getRiverMile();
            log.totalmile = wp.getTotalMiles();

            // save average
            counter_avg++;
            if (counter_avg == 0 || counter_avg >= globals.settings.average_base_min * avg_scale) {
                counter_avg = 0;
                history.addLogItem(log);
            }

            // if audio is enabled
            if (globals.settings.enableAudibleWarningTrack) {
                wp.decrementAudioCounter();         //enforces a delta time between audio so as to not squash
                wp.AudibleCrossTrackWarning();
            }

            if (raceowl != null) {
                boolean sendLocationDone = false;

                // if this is TRACKING
                if (raceowl.getTrackingStatus()) {
                    RacerState s0 = RacerState.recentRacerState();

                    // decrement counter
                    globals.settings.counterLocationTracking--;  //called every second (prime delta t)

                    if (globals.settings.counterLocationTracking <= 0 || deltaLocationTimeMin > raceowl.deltaLocationTrackingMin)
                    {
                        lastLocationTrackTime_ms = currSystemTime_ms;

                        Log.d(globals.appState.appName, String.format("Location send timer expired. Date = %s", ClassUtility.getDate()));

                        globals.settings.counterLocationTracking = (int) (raceowl.deltaLocationTrackingMin * globals.settings.triggersPerMinute);
                        if (!Location.addLocation(globals.locations, s0)) {
                            {
                                globals.messages.add("The current location is not valid. Unable to add it to the send queue. Do you have GPS location enabled?");
                            }

                            // check queues and send
                            raceowl.sendLocation();
                            sendLocationDone = true;
                        }
                    }
                }

                globals.settings.counterStateUpdate--;  //called every prime delta t
                if (globals.settings.counterStateUpdate <= 0 || deltaStateTimeMin > raceowl.deltaStateUpdateMin) {

                    lastStateUpdateTime_ms = currSystemTime_ms;

                    //reset counter
                    globals.settings.counterStateUpdate = (int) (raceowl.deltaStateUpdateMin * globals.settings.triggersPerMinute);

                    // check queues
                    if (!sendLocationDone) {
                        raceowl.sendLocation();
                    }
                    raceowl.sendCheckpoint();
                }
            }

            if (globals.appState.forceReset) {
                resetAll();
            }
        }
    }

    // ------------------------------------------------------------------------
    //	showQuickStartDialog
    // ------------------------------------------------------------------------
    private void showQuickStartDialog(final Context application_context)
    {

        //don't show a dialog if the app is closing
        if (this.isFinishing() || globals.appState.isSoftStart) {
            return;
        }

        final Dialog myDialog = new Dialog(application_context);

        myDialog.setContentView(R.layout.dialog_race_select);
        myDialog.setTitle("Quick Setup:");
        myDialog.setCancelable(false);

        final Spinner race_spinner2 = myDialog.findViewById(R.id.raceowl_races2);
        final Spinner app_mode = myDialog.findViewById(R.id.app_mode);
        final EditText race_number = myDialog.findViewById(R.id.racer_number2);
        final CheckBox cb_no_quick_settings = myDialog.findViewById(R.id.no_quick_settings);
        final CheckBox cb_go_upstream = myDialog.findViewById(R.id.go_upstream);

        Button ok_button = myDialog.findViewById(R.id.ok_button);

        //Fill spinner
        int idx = raceowl.getRaceIdx(raceowl.getCurrentRaceEventID());
        if (idx < 0 || globals.settings.RaceEventID < 0) idx = raceowl.get340RaceIdx(); // find 340 idx if no valid race is selected

        addItemsOnSpinner(raceowl.getRaceList(), race_spinner2, idx);

        //set racer number
        race_number.setText(globals.settings.boat_number);

        //Fill spinner
        ArrayList<String> tmp = new ArrayList<>();
        tmp.add("Manual");
        tmp.add("Auto");
        idx = globals.settings.app_auto_config_mode == 1 ? 1 : 0;
        addItemsOnSpinner(tmp, app_mode, idx);

        ok_button.setOnClickListener(v -> {

            boolean dismissDialog = true;

            int idx1 = race_spinner2.getSelectedItemPosition();
            int race_event_id = raceowl.getRaceEventID(idx1);

            String tmpStr = race_number.getText().toString();
            if (ClassUtility.VerifyInteger(tmpStr, "Racer Number", application_context)) {
                globals.settings.boat_number = tmpStr;// ClassUtility.toInteger(tmpStr);
            }
            else
            {
                dismissDialog = false;
            }

            raceowl.setRaceEvent(race_event_id);

            globals.settings.app_auto_config_mode = app_mode.getSelectedItemPosition();

            //quick globals
            globals.settings.enableQuickSettings = !cb_no_quick_settings.isChecked();

            if (cb_go_upstream.isChecked() != globals.settings.waypoint_reverse) {

                globals.settings.waypoint_reverse = cb_go_upstream.isChecked();
                globals.appState.forceReset = true;
            }

            //go upstream if specified
            int min_idx = Math.min(globals.settings.finishCheckpointIndex, globals.settings.startCheckpointIndex);
            int max_idx = Math.max(globals.settings.finishCheckpointIndex, globals.settings.startCheckpointIndex);
            if (globals.settings.waypoint_reverse) {
                globals.settings.startCheckpointIndex = max_idx;
                globals.settings.finishCheckpointIndex = min_idx;
            } else {
                globals.settings.startCheckpointIndex = min_idx;
                globals.settings.finishCheckpointIndex = max_idx;
            }

            // auto
            if (globals.settings.app_auto_config_mode == 1) {
                if (race_event_id != -1) {
                    // query for division start
                    globals.appState.setRaceStartTime = true;
                    raceowl.getIndividualStatus(race_event_id, globals.settings.boat_number);

                    // apply auto mode globals
                    globals.setAutoModeSettings();

                    //turn tracking on
                    raceowl.setTrackingState(RaceOwlClient.TrackingState.TRACKING);
                } else  // no race selected
                {

                    raceowl.setTrackingState(RaceOwlClient.TrackingState.DISABLED);
                    promptForNewDate();
                }
            }

            //raceowl.setTrackingState(globals.globals.trackingState);
            if (dismissDialog) {
                raceowl.isUpdateRaces = true;
                globals.appState.quickStartState = AppState.QuickStartState.displayed;
                myDialog.dismiss();
            }
        });


        myDialog.show();
    }


    //---------------------------------------------------------------------------
    // promptForNewDate
    //---------------------------------------------------------------------------
    private void promptForNewDate ()
    {
        ClassUtility.getConfirmDialog(mContext, "Warning: No Race Selected", "Set start time to now and reset globals?", "Yes", "No", false, false, value -> {
            //globals.gpsDisableWarningDisplayed = true;
            if (value) {
                globals.settings.setStartDate(ClassUtility.toWholeMinute(ClassUtility.getDate(), 0));
                globals.appState.forceReset = true;
            }
        });
    }


    //---------------------------------------------------------------------------
    // AlertModal - generic are you sure dialog
    //---------------------------------------------------------------------------
    public interface AlertModal {
        void onButtonClicked(boolean value);
    }

    //---------------------------------------------------------------------------
    // getConfirmDialog - generic are you sure dialog
    //---------------------------------------------------------------------------
    @SuppressWarnings("SameParameterValue")
    private static void getConfirmDialog ( final Context mContext,
                                           final String title, final String msg,
                                           final String positiveBtnCaption, final String negativeBtnCaption,
                                           final boolean isCancelable, final boolean one_button, final AlertModal target)
    {

        ((Activity) mContext).runOnUiThread(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

            int imageResource = android.R.drawable.ic_dialog_alert;
            Drawable image = mContext.getResources().getDrawable(imageResource);

            builder.setTitle(title);
            builder.setMessage(msg);
            builder.setIcon(image);
            builder.setCancelable(false);
            builder.setPositiveButton(positiveBtnCaption,
                    (dialog, id) -> target.onButtonClicked(true));

            if (!one_button) {
                builder.setNegativeButton(negativeBtnCaption,
                        (dialog, id) -> target.onButtonClicked(false));
            }
            AlertDialog alert = builder.create();
            alert.setCancelable(isCancelable);
            alert.show();
            if (isCancelable) {
                alert.setOnCancelListener(arg0 -> target.onButtonClicked(false));
            }
        });

    }

    //---------------------------------------------------------------------------
    // verifyCommEnable
    //---------------------------------------------------------------------------
    private void verifyCommEnable ()
    {
        getConfirmDialog(mContext, "Confirm Communications", "One or more communications are enabled (Auto-checkpoint texting, Crew eta texting, or raceowl tracking). Retain enabled communications?", "Yes", "No", false, false, value -> {
            if (!value) {
                globals.settings.enableAutoCheckin = false; //auto_cp_text
                raceowl.setTrackingState(RaceOwlClient.TrackingState.STOPPED);
            }
        });
    }

    //---------------------------------------------------------------------------
    // promptForGPS
    //---------------------------------------------------------------------------
    private void promptForGPS ()
    {
        getConfirmDialog(mContext, "Warning: GPS DISABLED!", "Standalone GPS is required for normal operation! Please enable or switch to simulation mode", "Ok", "No", false, true, value -> globals.appState.gpsDisableWarningDisplayed = true);
    }


    //---------------------------------------------------------------------------
    // onSaveInstanceState
    //---------------------------------------------------------------------------
    @Override
    public void onSaveInstanceState (Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);
        globals.appState.isSoftStart = true;
    }

    //---------------------------------------------------------------------------
    // onBackPressed
    //---------------------------------------------------------------------------
    @Override
    public void onBackPressed () {
        wp.max_speed_mph = 0.0;
        globals.appState.enableSimulation = false;
        globals.appState.isSoftStart = false;
        globals.appState.quickStartState = globals.settings.enableQuickSettings ? AppState.QuickStartState.armed : AppState.QuickStartState.disabled;
        super.onBackPressed();
    }

    //---------------------------------------------------------------------------
    // broadcastGPSRateUpdate
    //---------------------------------------------------------------------------
    private void broadcastGPSRateUpdate ( long new_gps_rate)
    {
        Intent i = new Intent("MR340_GPS_CONTROL");
        i.putExtra("update_rate_ms", new_gps_rate);
        sendBroadcast(i);
    }


    //---------------------------------------------------------------------------
    // Screen monitor
    //---------------------------------------------------------------------------
    private void startScreenMonitor ()
    {
        Log.d(globals.appState.appName, "startScreenMonitor");

        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_SCREEN_ON);
        intentFilter.addAction(Intent.ACTION_SCREEN_OFF);

        mScreenMonitor = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String strAction = intent.getAction();
                assert strAction != null;
                if (strAction.equals(Intent.ACTION_SCREEN_OFF)) {

                    setBestGPSUpdateRate(-1, false);
                    Log.d(globals.appState.appName, Intent.ACTION_SCREEN_OFF);
                    globals.appState.screenOff = true;
                    //wp.sayText("screen off");
                } else if (strAction.equals(Intent.ACTION_SCREEN_ON)) {
                    setBestGPSUpdateRate(getCurrentScreen(), true);
                    Log.d(globals.appState.appName, Intent.ACTION_SCREEN_ON);
                    globals.appState.screenOff = false;
                    //wp.sayText("screen on");
                }
            }
        };

        registerReceiver(mScreenMonitor, intentFilter);
    }

    private void stopScreenMonitor ()
    {
        Log.d(globals.appState.appName, "stopScreenMonitor");

        if (mScreenMonitor != null) unregisterReceiver(mScreenMonitor);
    }


    //---------------------------------------------------------------------------
    // isNavScreen
    //---------------------------------------------------------------------------
    private boolean isNavScreen ( int screen_idx)
    {
        boolean ret;
        switch (screen_idx) {
            case 0:
            case 1:
            case 6:
                ret = true;
                break;
            default:
                ret = false;
        }
        return (ret);
    }

    //---------------------------------------------------------------------------
    // getCurrentScreen
    //---------------------------------------------------------------------------
    private int getCurrentScreen ()
    {
        int ret;
        ViewPager pager = findViewById(R.id.viewpager);
        ret = pager.getCurrentItem();
        return (ret);
    }

    //---------------------------------------------------------------------------
    // manageScreenTransition - save startup and set GPS rate
    //---------------------------------------------------------------------------
    public void manageScreenTransition ()
    {
        // last screen
        int lastStartupScreen = globals.settings.startup_screen_idx;
        int currentScreen = getCurrentScreen();

        // update
        if (currentScreen != lastStartupScreen) {
            if (isNavScreen(currentScreen) != isNavScreen(lastStartupScreen)) {
                setBestGPSUpdateRate(currentScreen, true);
            }
            globals.settings.startup_screen_idx = currentScreen;
        }
    }


    //---------------------------------------------------------------------------
    // getBestGPSUpdateRate
    //---------------------------------------------------------------------------
    private void setBestGPSUpdateRate ( int screen_idx, boolean screen_on)
    {
        // tracking is the minimum value
        long rate_s = (long) (raceowl.locationUpdatePeriod_min * 60.0 / 2.0);

        // logging
        rate_s = ClassUtility.min((long) (globals.settings.logging_delta_min * 60.0), rate_s);

        // audio
        if (globals.settings.enableAudibleStatus) {
            rate_s = ClassUtility.min((long) (globals.settings.audioStatusUpdatePeriod_min * 60.0 / 2.0), rate_s);
        }

        // channel updates -> need fast rate
        if (globals.settings.enableAudibleWarningTrack) {
            rate_s = ClassUtility.min(globals.settings.gpsFastUpdatePeriod_sec, rate_s);
        }

        if (screen_on) {
            if (isNavScreen(screen_idx)) {
                rate_s = ClassUtility.min(globals.settings.gpsFastUpdatePeriod_sec, rate_s);
            } else {
                rate_s = ClassUtility.min(globals.settings.gpsSlowUpdatePeriod_sec, rate_s);
            }
        }

        //broadcast the new GPS rate message
        broadcastGPSRateUpdate(rate_s * 1000);

    }


    //---------------------------------------------------------------------------
    // setStartupScreen
    //---------------------------------------------------------------------------
    private void setStartupScreen ()
    {
        ViewPager pager = findViewById(R.id.viewpager);
        try {
            pager.setCurrentItem(globals.settings.startup_screen_idx);
        } catch (Exception e) {
            pager.setCurrentItem(0);
        }
    }

    //---------------------------------------------------------------------------
    // updateLog
    //---------------------------------------------------------------------------
    private void updateLog ()
    {

        double lat_rad = wp.getLatitude();
        double lon_rad = wp.getLongitude();
        double elapsed_time_s = wp.getElapsedTimeSec(false);

        // if logging is enabled
        if (elapsed_time_s >= 0 && globals.settings.logging_delta_min > 0 && lat_rad != 0.0 && lon_rad != 0.0) {
            Log.d(globals.appState.appName, "updatelog");

            ClassLogData log = new ClassLogData();

            // update circular log buffer
            log.lat_rad = lat_rad;
            log.lon_rad = lon_rad;
            log.elapsed_time_hr = (float) (elapsed_time_s / 3600);
            log.speed_mph = (float) wp.getSpeed();
            log.track_mph = (float) wp.getTrackSpeed();
            log.rivermile = (float) wp.getRiverMile();
            log.totalmile = wp.getTotalMiles();

            log.avg_speed_mph = (float) wp.getAvgSpeed();
            log.avg_track_mph = (float) wp.getAvgTrackSpeed();

            //write log event
            ClassFileIO fio = new ClassFileIO(mContext);
            String msg = fio.getLogLineStr(log, true, false);
            fio.appendToFile(msg, ClassFileIO.mylogfile);
        }
    }


    public void toggleAudioStatus()
    {
        wp.toggleAudioStatus2();
        setBestGPSUpdateRate(getCurrentScreen(), true);
    }

    //---------------------------------------------------------------------------
    // toggleChannelAudioWarning
    //---------------------------------------------------------------------------
    public void toggleChannelAudioWarning ()
    {
        wp.toggleAudioWarningTrack();
        setBestGPSUpdateRate(getCurrentScreen(), true);
    }

    //---------------------------------------------------------------------------
    // stopTTSService
    //---------------------------------------------------------------------------
    private void stopTTSService ()
    {
        Log.d(globals.appState.appName, "stopTTSService");

        stopService(new Intent(mContext, TextToSpeechService.class));
    }

    private void startTTSService ()
    {
        Log.d(globals.appState.appName, "startTTSService");
        Intent ttsService = new Intent(getApplication().getApplicationContext(), TextToSpeechService.class);
        ContextCompat.startForegroundService(this.getApplicationContext(), ttsService);
    }

    //---------------------------------------------------------------------------
    // Battery monitor
    //---------------------------------------------------------------------------
    private void startBatteryMonitor ()
    {
        Log.d(globals.appState.appName, "startBatteryMonitor");
        registerReceiver(battery, battery.getIntentFilter());
    }

    private void stopBatteryMonitor ()
    {
        Log.d(globals.appState.appName, "stopBatteryMonitor");
        if (battery!=null) unregisterReceiver(battery);
    }

    // ------------------------------------------------------------------------
    //	addItemsOnSpinner
    // ------------------------------------------------------------------------
    private void addItemsOnSpinner (ArrayList < String > list, Spinner spinner,int initPosition)
    {
        SpinnerAdapter dataAdapter = new SpinnerAdapter(mContext, android.R.layout.simple_spinner_item, android.R.id.text1, list, 0);
        spinner.setAdapter(dataAdapter);
        if (initPosition > 0 && initPosition < list.size()) {
            spinner.setSelection(initPosition);
        }
    }

    // ------------------------------------------------------------------------
    //	ExportLogFile
    // ------------------------------------------------------------------------
    private void ExportLogFile ()
    {

        Date export_date = globals.settings.lastStartDate;
        String fileName = globals.settings.dateToText(export_date);
        fileName = fileName.replace('\\', '_');
        fileName = fileName.replace('/', '_');
        fileName = fileName.replace(':', '_');
        fileName = fileName.replace(',', '_');

        boolean ret;
        ClassFileIO fio = new ClassFileIO(mContext);

        ClassLogData[] log_items = fio.readLog(ClassFileIO.mylogfile);

        if (log_items != null && log_items.length > 0) {
            //save log file to a csv

            String fileName1 = fileName + ".csv";
            ret = fio.writeLog(fileName1, log_items, "mr340pro");


            //save log file to a kml
            if (ret) {
                String fileName2 = fileName + ".kml";
                ret = fio.writeKML("mr340pro", fileName2, log_items);

            }

            if (ret) {
                Toast.makeText(getApplicationContext(), fileName + " export success", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Unable to write Log file (No log or SD card missing)", Toast.LENGTH_LONG).show();
            }

        }
    }

    private final String[] PERMISSIONS = {
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
    };

    // ------------------------------------------------------------------------
    //	hasPermissions
    // ------------------------------------------------------------------------
    private static boolean hasPermissions (Context context, String...permissions){
        if (context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
}
