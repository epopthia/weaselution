package com.MR340ProPaddler.infrastructure;
// --------------------------------------------------

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

// Created by sm403c on 5/10/2016.

//final String KEY_ITEM = "item"; // parent node

//        XMLParser parser = new XMLParser();
//        Document doc = parser.getDomElement(spot_xml); // getting DOM element
//        if (doc!=null) {
//            NodeList nl = doc.getElementsByTagName(KEY_ITEM);
//        }

// looping through all item nodes <item>
//        for (int i = 0; i < nl.getLength(); i++) {
//            // creating new HashMap
//            HashMap<String, String> map = new HashMap<String, String>();
//            Element e = (Element) nl.item(i);
//            // adding each child node to HashMap key => value
//            map.put(KEY_ID, parser.getValue(e, KEY_ID));
//            // adding HashList to ArrayList
//            menuItems.add(map);
//        }


// --------------------------------------------------
class XMLParser
{


    public static boolean isXml(String xml)
    {
        boolean ret = xml.charAt(0) == '<';
        return (ret);
    }

// --Commented out by Inspection START (12/29/18, 6:57 AM):
//    public Document getDomElement(String xml){
//        Document doc;
//        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        try {
//
//            DocumentBuilder db = dbf.newDocumentBuilder();
//
//            InputSource is = new InputSource();
//            is.setCharacterStream(new StringReader(xml));
//            doc = db.parse(is);
//
//        } catch (ParserConfigurationException | IOException | SAXException e) {
//            Log.e("Error: ", e.getMessage());
//            return null;
//        }
//        // return DOM
//        return doc;
//    }
// --Commented out by Inspection STOP (12/29/18, 6:57 AM)

    public String getValue(Element item, String str)
    {
        NodeList n = item.getElementsByTagName(str);
        return this.getElementValue(n.item(0));
    }

    private String getElementValue(Node elem) {
        Node child;
        if( elem != null){
            if (elem.hasChildNodes()){
                for( child = elem.getFirstChild(); child != null; child = child.getNextSibling() ){
                    if( child.getNodeType() == Node.TEXT_NODE  ){
                        return child.getNodeValue();
                    }
                }
            }
        }
        return "";
    }
}


