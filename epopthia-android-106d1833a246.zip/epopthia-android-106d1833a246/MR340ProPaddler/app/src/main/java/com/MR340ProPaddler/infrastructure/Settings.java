package com.MR340ProPaddler.infrastructure;

import android.annotation.SuppressLint;
import android.net.ParseException;
import android.text.format.DateFormat;

import com.MR340ProPaddler.RaceOwlClient;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;

import java.text.SimpleDateFormat;
import java.util.Date;

@SuppressLint("SimpleDateFormat")
public class Settings {

	public boolean enableAudibleStatus; // true to enable audible status updates
	public boolean enableAudibleStatusNoWords; // true to speak numbers only, no words
	public boolean enableAudibleWarningTrack; // true to enable audible ping for warning track
	public boolean displayCheckpointsOnly;
	public boolean displayCycledCheckpoints;
	public boolean enable_high_contrast_color;
	public boolean enableQuickSettings; 			//true to show quick settings dialog
	public boolean enableAutoCheckin;
	public boolean freeze_baseline_plan;
	public boolean freeze_zoom; //freeze_zoom
	public boolean location_based_speed;
	public boolean reset_planner; //not saved
	public boolean waypoint_reverse; // true to go upstream instead of down
	public Date lastRaceUpdateDate;
	public Date lastStartDate;
	public Date startDate;
	public Date lastQuickSettingsDate;
	public double tot_mile_last_lat_rad;
	public double tot_mile_last_lon_rad;
	public final int[] display_idx;
	public float crosstrack_warning;
	public float default_checkpoint_rest_hr;
	public float defaultSleepHr;
	public float desired_finish_hr;
	public float desired_speed_mph;
	public float logging_delta_min;
	public float m_boat_scale;
	public final float max_zoom;
	public final float min_zoom;
	public float sim_init_rivermile;
	public float sim_speed_mph;
	public float start_river_mile;
	public float tot_mile;
	public final float triggersPerMinute;
	public float zoom;
	public int app_auto_config_mode;  				//0 = manual, 1 = auto
	public int audioStatusUpdatePeriod_min;
	public int average_base_min;
	public int base_line_width;
	public int counterLocationTracking;
	public int counterStateUpdate;
	public int division_RaceEventID;  // race ID that was used to find the division lookup
	public int gpsFastUpdatePeriod_sec;
	public int gpsSlowUpdatePeriod_sec;
	public int line_width;
	public int nav_origin; //boat,trak,or river
	public int RaceEventID;  //raceowl selected race
	public int sleep1_cp_idx;
	public int sleep2_cp_idx;
	public int sleep3_cp_idx;
	public int selectedProgress;

	public int startCheckpointIndex;
	public int finishCheckpointIndex;

	public int startup_screen_idx;

	public RaceOwlClient.TrackingState trackingState; // current state of tracking
	public boolean trackingEnabled; //tracking disabled (does not matter what the user or device capability is)
	public boolean trackingActive;  //user desires to track


	public final String authorizationCode;
	public String boat_number;
	public String checkpoint_selected;
	public String division_selected;
	public final String phone_number;
	public String version;

	public Settings()
	{
		selectedProgress = 0;
		app_auto_config_mode = 1;
		audioStatusUpdatePeriod_min = 4;
		authorizationCode = "";
		average_base_min = 45;
		base_line_width = 2;
		boat_number = "";
		checkpoint_selected = "";
		counterLocationTracking = 0;
		counterStateUpdate = 0;
		crosstrack_warning = 60;
		default_checkpoint_rest_hr = (float) 0.5;
		defaultSleepHr = 3;
		desired_finish_hr = 85;
		desired_speed_mph = 6;
		display_idx = new int[] {2,6,7,9,1};
		displayCheckpointsOnly = true;
		displayCycledCheckpoints = false;
		division_RaceEventID = -1;
		division_selected = "";
		enable_high_contrast_color = false;
		enableAudibleStatus = false;
		enableAudibleStatusNoWords = false;
		enableAudibleWarningTrack = false;
		enableAutoCheckin = false;
		enableQuickSettings = true;
		finishCheckpointIndex = -1;
		freeze_baseline_plan = false;
		freeze_zoom = false;
		gpsFastUpdatePeriod_sec = 2;
		gpsSlowUpdatePeriod_sec = 30;
		lastQuickSettingsDate = ClassUtility.getDate(-10000);
		lastRaceUpdateDate = ClassUtility.getDate(-10000);
		lastStartDate = ClassUtility.getDate(-10000);
		line_width = 2;
		location_based_speed = false;
		logging_delta_min = 4;
		m_boat_scale = 2;
		max_zoom = (float) 60;
		min_zoom = (float) 0.01;
		nav_origin = 0;
		phone_number = "";
		RaceEventID = -1;
		reset_planner = false;
		sim_init_rivermile = 367;
		sim_speed_mph = 6;
		sleep1_cp_idx = -1;
		sleep2_cp_idx = -1;
		sleep3_cp_idx = -1;
		start_river_mile = 0;
		startCheckpointIndex = -1;
		startDate = new Date();
		startup_screen_idx = 0;
		tot_mile = 0;
		tot_mile_last_lat_rad = 0;
		tot_mile_last_lon_rad = 0;

		trackingState = RaceOwlClient.TrackingState.STOPPED;
		trackingActive = false;
		trackingEnabled = true;

		triggersPerMinute = (float) (60.0);
		version = "";
		waypoint_reverse = false;
		zoom = 1;
	}

	public Settings(Settings src)
	{
		selectedProgress = src.selectedProgress;
		app_auto_config_mode = src.app_auto_config_mode;
		audioStatusUpdatePeriod_min = src.audioStatusUpdatePeriod_min;
		authorizationCode = src.authorizationCode;
		average_base_min = src.average_base_min;
		base_line_width = src.base_line_width;
		boat_number = src.boat_number;
		checkpoint_selected = src.checkpoint_selected;
		counterLocationTracking = src.counterLocationTracking;
		counterStateUpdate = src.counterStateUpdate;
		crosstrack_warning = src.crosstrack_warning;
		default_checkpoint_rest_hr = src.default_checkpoint_rest_hr;
		defaultSleepHr = src.defaultSleepHr;
		desired_finish_hr = src.desired_finish_hr;
		desired_speed_mph = src.desired_speed_mph;
		display_idx = src.display_idx;
		displayCheckpointsOnly = src.displayCheckpointsOnly;
		displayCycledCheckpoints = src.displayCycledCheckpoints;
		division_RaceEventID = src.division_RaceEventID;
		division_selected = src.division_selected;
		enable_high_contrast_color = src.enable_high_contrast_color;
		enableAudibleStatus = src.enableAudibleStatus;
		enableAudibleStatusNoWords = src.enableAudibleStatusNoWords;
		enableAudibleWarningTrack = src.enableAudibleWarningTrack;
		enableAutoCheckin = src.enableAutoCheckin;
		enableQuickSettings = src.enableQuickSettings;
		trackingEnabled = src.trackingEnabled;
		trackingActive = src.trackingActive;
		finishCheckpointIndex = src.finishCheckpointIndex;
		freeze_baseline_plan = src.freeze_baseline_plan;
		freeze_zoom = src.freeze_zoom;
		gpsFastUpdatePeriod_sec = src.gpsFastUpdatePeriod_sec;
		gpsSlowUpdatePeriod_sec = src.gpsSlowUpdatePeriod_sec;
		lastQuickSettingsDate = src.lastQuickSettingsDate;
		lastRaceUpdateDate = src.lastRaceUpdateDate;
		lastStartDate = src.lastStartDate;
		line_width = src.line_width;
		location_based_speed = src.location_based_speed;
		logging_delta_min = src.logging_delta_min;
		m_boat_scale = src.m_boat_scale;
		max_zoom = src.max_zoom;
		min_zoom = src.min_zoom;
		nav_origin = src.nav_origin;
		phone_number = src.phone_number;
		RaceEventID = src.RaceEventID;
		reset_planner = src.reset_planner;
		sim_init_rivermile = src.sim_init_rivermile;
		sim_speed_mph = src.sim_speed_mph;
		sleep1_cp_idx = src.sleep1_cp_idx;
		sleep2_cp_idx = src.sleep2_cp_idx;
		sleep3_cp_idx = src.sleep3_cp_idx;
		start_river_mile = src.start_river_mile;
		startCheckpointIndex = src.startCheckpointIndex;
		startDate = src.startDate;
		startup_screen_idx = src.startup_screen_idx;
		tot_mile = src.tot_mile;
		tot_mile_last_lat_rad = src.tot_mile_last_lat_rad;
		tot_mile_last_lon_rad = src.tot_mile_last_lon_rad;
		trackingState = src.trackingState;
		triggersPerMinute = src.triggersPerMinute;
		version = src.version;
		waypoint_reverse = src.waypoint_reverse;
		zoom = src.zoom;
	}

	public String getCurrentDateTime()
	{
		SimpleDateFormat sdf = new SimpleDateFormat(Const.start_date_format);
		return sdf.format(new Date());
	}

	public Date textToDate(String dtStart) throws java.text.ParseException
	{
		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat(Const.start_date_format);
		try
		{
			date = format.parse(dtStart);
			//System.out.println(date);
		}
		catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return date;
	}

	public String dateToText(Date date)
	{
		return DateFormat.format(Const.start_date_format, date).toString();
	}

	public void setStartDate(Date startDate)
	{
		lastStartDate = this.startDate;
		this.startDate = startDate;
	}

}