package com.MR340ProPaddler.baseclass;

import com.MR340ProPaddler.WayPointNav;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;

import org.json.JSONException;
import org.json.JSONObject;

@SuppressWarnings("WeakerAccess")
public class CheckPoint
{
	public boolean isCheckpoint;
	public boolean isSupported;
	public final boolean text_out;  //true if texted out
	public boolean valid;
	public boolean visible;
	public final double dr_next_rad;
	public final double dr_past_rad;
	public double offset_ft;  //river mile offset from nearest track waypoint - used to pin point the checkpoint
	public double prev_cp_dist_ft;
	public double rivermile;
	public final float MilesToNext;
	public final LatLngRad pt;
	public final WayPoint.Type type;
	public int closest_wp_index;
	public int Order;
	public RangeBearing rb;
	public String CutOff;
	public String Name;
	public String TakeoutSide;
	public Vector3D ur;

	public CheckPoint()
	{
		closest_wp_index = 0;
		CutOff  = "";
		dr_past_rad = -1.0;  //-1 is invalid
        dr_next_rad = -1.0;
		isCheckpoint = false;
		isSupported = false;
		MilesToNext = (float) 0.0;
		Name = "";
		offset_ft = 0.0;  //river mile offset from nearest track waypoint - used to pin point the checkpoint
		Order = 0;
		prev_cp_dist_ft = 0.0;
		pt = new LatLngRad(0.0,0.0);
		rb = new RangeBearing();
		rivermile = 0.0;
		TakeoutSide = "";
		text_out = false;
		type = WayPoint.Type.checkpoint;
		ur = new Vector3D();
		valid = false;
		visible = true;
	}
    public CheckPoint(CheckPoint cp)
    {
        closest_wp_index = cp.closest_wp_index;
        CutOff = cp.CutOff;
        dr_next_rad = cp.dr_next_rad;
        dr_past_rad = cp.dr_past_rad;
        isCheckpoint = cp.isCheckpoint;
        isSupported = cp.isSupported;
        MilesToNext = cp.MilesToNext;
        Name = cp.Name;
        offset_ft = cp.offset_ft;
        Order = cp.Order;
        prev_cp_dist_ft = cp.prev_cp_dist_ft;
        pt = new LatLngRad(cp.pt);
        rb = new RangeBearing();
        rivermile = cp.rivermile;
        TakeoutSide = cp.TakeoutSide;
        text_out = cp.text_out;
        type = cp.type;
        ur =  WayPointNav.ComputeUnitRadialVector(cp.pt.latitude_rad, cp.pt.longitude_rad);
        valid = cp.valid;
        visible = cp.visible;

    }

    public CheckPoint(CheckPoint cp0, CheckPoint cp1)
    {
        this(cp1);
        rb = new RangeBearing(cp0.pt, cp1.pt);
    }

    public CheckPoint(JSONObject item)
    {
        this();
        try {
            CutOff = item.getString("CutOff");
            Name = item.getString("Name");
            Order = item.getInt("Order");
            TakeoutSide = item.getString("TakeoutSide");
            String gps_deg = item.getString("GPS");
            String[] toks = gps_deg.split(",");
            if (toks.length == 2) {
                if (ClassUtility.isNumeric(toks[0])) {
                    pt.latitude_rad = Double.parseDouble(toks[0]) * Const.dtr;
                    pt.longitude_rad = Double.parseDouble(toks[1]) * Const.dtr;
                }
            }
            ur =  WayPointNav.ComputeUnitRadialVector(pt.latitude_rad, pt.longitude_rad);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}