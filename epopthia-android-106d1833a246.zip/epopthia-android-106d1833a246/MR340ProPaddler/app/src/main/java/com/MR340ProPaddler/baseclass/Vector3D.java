package com.MR340ProPaddler.baseclass;

public class Vector3D
{
    public final double[] v ;


    public Vector3D()
    {
        v = new double[3];
    }
    public Vector3D(double[] i)
    {
        v = i;
    }
    public Vector3D(Vector3D v0)
    {
        v = new double[]{v0.v[0],v0.v[1],v0.v[2]};
    }
}
