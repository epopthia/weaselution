package com.MR340ProPaddler.baseclass;


import com.MR340ProPaddler.PathSegment;
import com.MR340ProPaddler.RacerState;
import com.MR340ProPaddler.utility.Const;

import static com.MR340ProPaddler.RacerState.checkpoint_radius_dr_rad;
import static com.MR340ProPaddler.baseclass.RangeBearing.calcDeltaAngle;
import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.StrictMath.abs;

@SuppressWarnings("WeakerAccess")
public class RouteRelative {

    public int waypoint_index;
    public int checkpoint_index;

    public double waypoint_frac;

    public boolean at_checkpoint;       // true if the racer is considered at a checkpoint. this is typically 500ft in distance before and 500ft after the geolocation point
    public double checkpoint_frac;      // fraction that represents the downtrack position of a racer between 2 checkpoints. <0 behind checkpoint 1,
    // 0 = at checkpoint 1, between 0 and 1 = between cp 1 and 2,  1 = at checkpoint 2, > 1 ahead of cp 2
    public double checkpoint_value;      // a checkpoint_index + checkpoint_frac = a combined overall checkpoint AppState representation value
    public double race_completion_frac;

    public double dr_cp0_to_cp1_rad;      //arc length from past checkpoint to current checkpoint
    public double dt_dr_cp0_to_pt_rad;    //downtrack arc length from past checkpoint to current position
    public double ct_dr_cp0_to_pt_rad;    //crosstrack arc length from past checkpoint to current position
    public double dt_dr_pt_to_cp1_rad;    //downtrack arc length from current location to current checkpoint


    //constructor
    public RouteRelative() {
        waypoint_index = -1;                //init to an invalid number for index
        checkpoint_index = -1;              //init to an invalid number for index
        at_checkpoint = false;
        race_completion_frac = 0.0;
        waypoint_frac = Const.large;        //init to a large number since we are checking for them to be between 0 and 1
        checkpoint_frac = Const.large;      //init to a large number since we are checking for them to be between 0 and 1
        dr_cp0_to_cp1_rad = Const.two_pi;      //init to a large number since we are checking for them to be very small
        dt_dr_cp0_to_pt_rad = Const.two_pi;    //init to a large number since we are checking for them to be very small
        dt_dr_pt_to_cp1_rad = Const.two_pi;
        ct_dr_cp0_to_pt_rad = Const.two_pi;    //init to a large number since we are checking for them to be very small
        checkpoint_value = 0.0;
    }

    public RouteRelative(RouteRelative s0) {
        waypoint_index = s0.waypoint_index;
        checkpoint_index = s0.checkpoint_index;
        at_checkpoint = s0.at_checkpoint;
        race_completion_frac = s0.race_completion_frac;
        waypoint_frac = s0.waypoint_frac;
        checkpoint_frac = s0.checkpoint_frac;
        checkpoint_value = s0.checkpoint_value;
        dr_cp0_to_cp1_rad = s0.dr_cp0_to_cp1_rad;
        dt_dr_cp0_to_pt_rad = s0.dt_dr_cp0_to_pt_rad;
        dt_dr_pt_to_cp1_rad = s0.dt_dr_pt_to_cp1_rad;
        ct_dr_cp0_to_pt_rad = s0.ct_dr_cp0_to_pt_rad;
    }

    //----------------------------------------------------------------------------------------------
    // RouteRelative
    //----------------------------------------------------------------------------------------------
    public RouteRelative(Vector3D ur_cp0, Vector3D ur_cp1, Vector3D ur_test_point) {
        this();

        //verify inputs
        if ((ur_cp0 != null) && (ur_cp1 != null) && (ur_test_point != null)) {

            Vector3D un = calcUnitNormalVector(ur_cp0, ur_cp1);
            Vector3D ut = VectorCross3D(ur_cp0, un);

            dr_cp0_to_cp1_rad = VectorDot3D(ur_cp1, ut);                    //arc from p0 to p1
            dt_dr_cp0_to_pt_rad = VectorDot3D(ur_test_point, ut);           //downtrack arc from p0 to tp
            dt_dr_pt_to_cp1_rad = dr_cp0_to_cp1_rad - dt_dr_cp0_to_pt_rad;  //downtrack arc from tp to p1

            ct_dr_cp0_to_pt_rad = VectorDot3D(un, ur_test_point);           //crosstrack arc from cp0-cp1 to tp


            // find distance along the own_path regardless of how far off the own_path laterally we are
            // this allows for an estimate of closeness to checkpoint regardless of the own_path the route
            // takes between checkpoints.

            // TODO: verify that dr_cp0_to_cp1_rad is not zero. this can be accomplished at CP verification during route creation
            dr_cp0_to_cp1_rad = abs(dr_cp0_to_cp1_rad) > Const.min_point_dist_rad ? dr_cp0_to_cp1_rad : Const.min_point_dist_rad;
            checkpoint_frac = dt_dr_cp0_to_pt_rad / dr_cp0_to_cp1_rad;


            // default this to false - not at a checkpoint
            at_checkpoint = false;

            // if crosstrack and downtrack are within the checkpoint radius then signal we are at a checkpoint
            if (abs(ct_dr_cp0_to_pt_rad) < checkpoint_radius_dr_rad) {

                //we are close to the start point
                if (abs(dt_dr_cp0_to_pt_rad) < checkpoint_radius_dr_rad) {
                    at_checkpoint = true;
                }
                // we are close to the end of the cp segment
                else if (abs(dr_cp0_to_cp1_rad - dt_dr_cp0_to_pt_rad) < checkpoint_radius_dr_rad) {
                    at_checkpoint = true;
                }
            }
        }
    }

    // ----------------------------------------------------------------------
    //  calcCheckPointRelative
    //	Given Lat/lon, last AppState and route, propagate the racer AppState
    // ----------------------------------------------------------------------
    private static RouteRelative calcCheckPointRelative(PathSegment own_path, RacerState s0, Route route) {
        int start_cp = s0 != null && s0.route_relative.checkpoint_index > 0 ? s0.route_relative.checkpoint_index : 1; //select start of route if init

        RouteRelative s1 = s0 != null ? new RouteRelative(s0.route_relative) : new RouteRelative();

        if (route.cps.length > 1) {
            //scan checkpoint list and populate the crosstrack and progress fractions for each checkpoint
            for (int inx = start_cp; inx < route.cps.length; inx++) {
                if (route.cps[inx].ur == null)
                    route.cps[inx].ur = calcUnitRadialVector(route.cps[inx].pt.latitude_rad, route.cps[inx].pt.longitude_rad);

                RouteRelative tmp = new RouteRelative(route.cps[inx - 1].ur, route.cps[inx].ur, own_path.ur);
                tmp.checkpoint_index = inx;
                // TODO: need checkpoint cycle check to pick the first un-cycled checkpoint to account for race courses that reverse the route
                // we found a checkpoint
                if (tmp.at_checkpoint && tmp.checkpoint_frac < 0.5) {
                    s1 = new RouteRelative(tmp);
                    break;
                }
                // we are parallel to a checkpoint, the route could be circular or reversed
                else if (tmp.checkpoint_frac >= 0 && tmp.checkpoint_frac < 1.0) {
                    if (inx == start_cp) {
                        s1 = new RouteRelative(tmp);
                        break;
                    }
                    //another match was found, and the cross track is small
                    else if (tmp.ct_dr_cp0_to_pt_rad < checkpoint_radius_dr_rad) {
                        // check if the bearing is good
                        if (own_path.rb.bearing_rad <= Const.two_pi && calcDeltaAngle(route.cps[inx].rb.bearing_rad, own_path.rb.bearing_rad) < Const.pi_over_2) {
                            s1 = new RouteRelative(tmp);
                            break;  //conclusive, exit loop
                        } else if (s1.checkpoint_index != start_cp && s1.ct_dr_cp0_to_pt_rad > tmp.ct_dr_cp0_to_pt_rad) {
                            s1 = new RouteRelative(tmp);
                            //note: not conclusive, keep loop going
                        } else {
                            s1 = new RouteRelative(tmp);
                        }
                    }
                    //another match was found, this may be a circular or reversed course. so check that bearing is in range and valid
                    else if (own_path.rb.bearing_rad <= Const.two_pi && calcDeltaAngle(route.cps[inx].rb.bearing_rad, own_path.rb.bearing_rad) < Const.pi_over_2) {
                        s1 = new RouteRelative(tmp);
                        break;
                    }
                }
                // we are no where near the route segment. pick the point that we left the course (ie the last AppState)
                else if (start_cp == tmp.checkpoint_index) {
                    s1 = new RouteRelative(tmp);
                }
            }
        }

        s1.checkpoint_value = s1.checkpoint_index - 1 + s1.checkpoint_frac;  // checkpoint we are going to subtract 1 to make 0 base, add the fraction between cpN and cpN+1
        return (s1);
    }


    // ----------------------------------------------------------------------
    //  RouteRelative
    //	Given Lat/lon, last AppState and route, propagate the racer AppState
    // ----------------------------------------------------------------------
    public RouteRelative(PathSegment own_path, RacerState s0, Route route) {
        // start from where we where last
        this(s0.route_relative);

        //TODO: waypoint process

        // checkpoint relative process
        RouteRelative s1 = calcCheckPointRelative(own_path, s0, route);

        waypoint_index = s1.waypoint_index;
        checkpoint_index = s1.checkpoint_index;
        at_checkpoint = s1.at_checkpoint;
        race_completion_frac = s1.race_completion_frac;
        waypoint_frac = s1.waypoint_frac;
        checkpoint_frac = s1.checkpoint_frac;
        checkpoint_value = s1.checkpoint_value;
        ct_dr_cp0_to_pt_rad = s1.ct_dr_cp0_to_pt_rad;
        dr_cp0_to_cp1_rad = s1.dr_cp0_to_cp1_rad;
        dt_dr_cp0_to_pt_rad = s1.dt_dr_cp0_to_pt_rad;
        dt_dr_pt_to_cp1_rad = s1.dt_dr_pt_to_cp1_rad;
    }

    //------------------------------------------------------------------------------
    //Function:         VectorCross3D
    //Description:      3D cross product  a X b
    //arguments:        A   - Vector3D source  0
    //                  B   - Vector3D source  1
    //Return value:     cross_prod_out
    //------------------------------------------------------------------------------
    private static Vector3D VectorCross3D(Vector3D a, Vector3D b) {
        Vector3D cross_prod_out = new Vector3D();
        cross_prod_out.v[0] = a.v[1] * b.v[2] - a.v[2] * b.v[1];
        cross_prod_out.v[1] = a.v[2] * b.v[0] - a.v[0] * b.v[2];
        cross_prod_out.v[2] = a.v[0] * b.v[1] - a.v[1] * b.v[0];
        return (cross_prod_out);
    }


    //-----------------------------------------------------------------------------
    //function:         VectorDot3D
    //description:      Compute the dot product between 2 vectors A.B = C
    //arguments:        A   - Vector3D source  0
    //                  B   - Vector3D source  1
    //return:           dot product
    //-----------------------------------------------------------------------------
    private static double VectorDot3D(Vector3D a, Vector3D b) {
        double dp = 0.0;
        for (int inx = 0; inx < 3; inx++) {
            dp += (a.v[inx] * b.v[inx]);
        }
        return (dp);
    }


    //-----------------------------------------------------------------------------
    //function:      calcUnitNormalVector
    //description:
    //arguments:     Vector3D ur1, Vector3D ur2
    //return:        un
    //-----------------------------------------------------------------------------
    private static Vector3D calcUnitNormalVector(Vector3D ur1, Vector3D ur2) {
        Vector3D un1 = new Vector3D();

        //Compute Unit Normal Vector via the cross product
        un1.v[0] = ur2.v[1] * ur1.v[2] - ur2.v[2] * ur1.v[1];
        un1.v[1] = ur2.v[2] * ur1.v[0] - ur2.v[0] * ur1.v[2];
        un1.v[2] = ur2.v[0] * ur1.v[1] - ur2.v[1] * ur1.v[0];

        //Normalize Vector
        return (normalizeVector(un1));
    }

    //-----------------------------------------------------------------------------
    //function:      normalizeVector
    //description:
    //arguments:
    //return:        v_out
    //-----------------------------------------------------------------------------
    private static Vector3D normalizeVector(Vector3D v_in) {

        Vector3D v_out = new Vector3D();
        double mag_v_in_sq;
        double Normalize_Vector_1_1;
        double check_val_out;
        int i;

        mag_v_in_sq = 0.0;
        for (i = 0; i < 3; i++) {
            mag_v_in_sq += v_in.v[i] * v_in.v[i];
        }
        Normalize_Vector_1_1 = sqrt(mag_v_in_sq);

        check_val_out = Normalize_Vector_1_1;

        if ((Math.abs(Normalize_Vector_1_1) < 1.0E-008)) {
            check_val_out = 1.0E-008;
        }

        //normalize
        for (i = 0; i < 3; i++) {
            v_out.v[i] = v_in.v[i] / check_val_out;
        }

        return (v_out);
    }


    //-----------------------------------------------------------------------------
    //function:      calcUnitRadialVector
    //description:   Given a Lat/lon compute the unit radial Vector3D
    //arguments:     double latitude_rad, double longitude_rad, double ur.v[3]
    //return:        ur
    //-----------------------------------------------------------------------------
    private static Vector3D calcUnitRadialVector(double latitude_rad, double longitude_rad) {

        Vector3D ur = new Vector3D();

        double sin_lat = sin(latitude_rad);
        double sin_lon = sin(longitude_rad);
        double cos_lat = cos(latitude_rad);
        double cos_lon = cos(longitude_rad);
        double radial_magnitude = sqrt(1.0 - Const.gd_two_e2_minus_e4 * sin_lat * sin_lat);

        ur.v[0] = cos_lat * cos_lon / radial_magnitude;
        ur.v[1] = cos_lat * sin_lon / radial_magnitude;
        ur.v[2] = (1.0 - Const.gd_e2) * sin_lat / radial_magnitude;

        return (ur);
    }


    //-----------------------------------------------------------------------------
    //function:      ComputeUnitTangentialVector
    //description:   Compute Unit Tangential Vector
    //arguments:     double un[3] ,double ur.v[3] ,double ut[3]
    //return:        un
    //-----------------------------------------------------------------------------
    public static Vector3D calcUnitTangentialVector(Vector3D un, Vector3D ur) {
        return (VectorCross3D(un, ur));
    }

    //-----------------------------------------------------------------------------
    //function:      DistBetweenWaypoints
    //description:   Calculate the distance between waypoints in feet
    //arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
    //return:        distance_ft
    //-----------------------------------------------------------------------------
    public static double distBetweenPoints(LatLngRad p1, LatLngRad p2) {
        Vector3D ur1 = calcUnitRadialVector(p1.latitude_rad, p1.longitude_rad);
        Vector3D ur2 = calcUnitRadialVector(p2.latitude_rad, p2.longitude_rad);
        Vector3D un = calcUnitNormalVector(ur1, ur2);
        Vector3D ut = calcUnitTangentialVector(un, ur2);

        return (VectorDot3D(ur1, ut));
    }

    //---------------------------------------------------------------------------
    // getNearestCheckpoint
    // set the current checkpoint to the closest to location
    //---------------------------------------------------------------------------
    public static CheckPoint getNearestCheckpoint(RacerState s0, Route route) {

        CheckPoint nearCheckPoint = null;
        double mindr = 0;

        for (CheckPoint cp : route.cps) {
            if (nearCheckPoint != null)
            {
                double dr = distBetweenPoints(s0.ptt.pt, cp.pt);
                if (dr < mindr)
                {
                    nearCheckPoint = cp;
                    mindr = distBetweenPoints(s0.ptt.pt, cp.pt);
                }
            } else {
                nearCheckPoint = cp;
                mindr = distBetweenPoints(s0.ptt.pt, cp.pt);
            }
        }

        return (nearCheckPoint);


    }
}