package com.MR340ProPaddler.baseclass;
import java.util.Arrays;
import java.util.Comparator;

@SuppressWarnings("unused")
public class WayPoint
{
	public enum Type
	{
		startpoint,
		checkpoint,
		waypoint,
		stoppoint
	}

	public LatLngRad pt;
	public double rivermile;
	private Type type;
	private String label;
	private final int order;

	public boolean valid;
	public WayPoint()
	{
		label = "";
		order = 0;
		pt = new LatLngRad(0,0);
		rivermile = 0.0;
		type = Type.waypoint;
		int id = 0;
		valid = false;
	}

	WayPoint(double lat_rad, double lon_rad)
	{
        this();
		pt = new LatLngRad(lat_rad,lon_rad);
	}

	WayPoint(CheckPoint cp)
	{
	    this();
		label = cp.Name;
		pt = cp.pt;
		type = cp.type;
	}

	// ---------------------------------------------------------------------------------------------
	// sortWaypoints
	// set location in array to be the same as the specified waypoint Order
	// ---------------------------------------------------------------------------------------------
	static void sortWaypoints(WayPoint[] wps)
	{
		Arrays.sort(wps,new WayPointItemComparator());
	}

	// ---------------------------------------------------------------------------------------------
	// WayPointItemComparator
	// compare waypoint item
	// ---------------------------------------------------------------------------------------------
	static private class WayPointItemComparator implements Comparator<WayPoint>
	{
		public int compare(WayPoint left, WayPoint right)
		{
			return Integer.compare(left.order, right.order);
		}
	}

}
