package com.MR340ProPaddler.adapters;

import java.util.List;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class SpinnerAdapter extends ArrayAdapter<String>
{
	public SpinnerAdapter(Context context, int resource, int textViewResourceId, List<String> list, int selected) 
	{
		super(context, resource, textViewResourceId, list);
		setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	}


	@NonNull
	@Override
	public View getView(int position, View convertView, @NonNull ViewGroup parent)
	{
		TextView tv;
		tv = (TextView) super.getView(position, convertView, parent);
		tv.setTextColor(Color.WHITE);
		tv.setBackgroundColor(Color.BLACK);
		tv.setTypeface(Typeface.SANS_SERIF);
		tv.setTextSize(40f);
		tv.setGravity(Gravity.CENTER);

		return tv;
	}
}
   
