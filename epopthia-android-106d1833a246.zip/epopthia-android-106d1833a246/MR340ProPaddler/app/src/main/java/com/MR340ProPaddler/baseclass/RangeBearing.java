package com.MR340ProPaddler.baseclass;

import com.MR340ProPaddler.utility.Const;

import static java.lang.Math.atan2;
import static java.lang.Math.cos;
import static java.lang.Math.min;
import static java.lang.Math.pow;

@SuppressWarnings({"unused", "WeakerAccess"})
public class RangeBearing {

    public final double range_m;
    public double bearing_rad;

    public RangeBearing()
    {
        range_m = 0.0;
        bearing_rad = Const.large; //invalid heading
    }

    public RangeBearing(double inRange_m, double inBearing_rad)
    {
        range_m = inRange_m;
        bearing_rad = inBearing_rad;
    }
	
    public RangeBearing(RangeBearing item0)
    {
        range_m = item0.range_m;
        bearing_rad = item0.bearing_rad;
    }

    public RangeBearing(double from_lat_rad, double from_lon_rad, double to_lat_rad, double to_lon_rad)
    {
        this(new LatLngRad(from_lat_rad, from_lon_rad), new LatLngRad(to_lat_rad, to_lon_rad));
    }

    //-----------------------------------------------------------------------------
    // RangeBearing
    //-----------------------------------------------------------------------------
    public RangeBearing(LatLngRad pt0,  LatLngRad pt1)
    {
        double delta_n_m = (pt1.latitude_rad-pt0.latitude_rad)*Const.earth_a_m;
        double delta_e_m = (pt1.longitude_rad-pt0.longitude_rad)*Const.earth_a_m*cos(pt0.latitude_rad);
        range_m = pow((delta_n_m*delta_n_m + delta_e_m*delta_e_m),0.5);
        bearing_rad = atan2(delta_e_m,delta_n_m);
        bearing_rad = limit_angle_rad(bearing_rad);
    }

    //-----------------------------------------------------------------------------
    //	limit_angle_rad
    //	limit angle between 0 and 360 deg
    //-----------------------------------------------------------------------------
    private static double limit_angle_rad(double loc_bearing_rad)
    {
        double lim_bearing_rad = loc_bearing_rad;

        if (loc_bearing_rad<0.0)
        {
            lim_bearing_rad+= Const.two_pi;
        }
        else if (loc_bearing_rad>= Const.two_pi)
        {
            lim_bearing_rad-= Const.two_pi;
        }
        return (lim_bearing_rad);

    }

    //-----------------------------------------------------------------------------
    //	calcDeltaAngle
    //-----------------------------------------------------------------------------
    public static double calcDeltaAngle(double a0_rad, double a1_rad)
    {
        double delta_rad = a1_rad - a0_rad;
        return (min(Const.two_pi - delta_rad, delta_rad));
    }

}
