package com.MR340ProPaddler;

import java.util.ArrayList;

class ClassObjIndex {
	
	final ArrayList<Integer> objs;
	
	ClassObjIndex()
	{
		objs = new ArrayList<>();
	}

}
