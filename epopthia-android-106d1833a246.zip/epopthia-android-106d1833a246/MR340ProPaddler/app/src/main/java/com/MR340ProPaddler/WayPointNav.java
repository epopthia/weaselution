package com.MR340ProPaddler;

import static java.lang.Math.*;
import android.graphics.PointF;

import com.MR340ProPaddler.baseclass.CheckPoint;
import com.MR340ProPaddler.baseclass.LatLngRad;
import com.MR340ProPaddler.baseclass.Vector3D;
import com.MR340ProPaddler.utility.Const;


// this is a library function, therefore don't warn on unused methods
@SuppressWarnings({"unused", "WeakerAccess"})

public  class WayPointNav
{
	
	//-----------------------------------------------------------------------------
	// class variables

	public static class matrix
	{
		public  final double[][] v ;
		matrix()
		{
			v = new double[3][3];
		}
		matrix(double[][] i)
		{
			v = i;
		}
	}


	public static class vector2D
	{
		public  final double[] v ;
		vector2D()
		{
			v = new double[2];
		}
		vector2D(double[] i)
		{
			v = i;
		}
	}
	
	public static double ref_lat_rad;
	public static double ref_lon_rad;
	public static double range_ft;
	public static double bearing_rad;

	//-----------------------------------------------------------------------------
	//  ne_to_latlon
	//  Procedure to convert from North and East distances in feet to latitude_rad and
	//  longitude_rad in radians.  This assumes _a reference latitude_rad and longitude_rad.
	//-----------------------------------------------------------------------------
	public static LatLngRad ne_to_latlon(double north, double east, double ref_lat_rad, double ref_lon_rad, double latitude, double longitude)
	{
		final double Re_ft = 2.09256463254593E+07;
		return (new LatLngRad(ref_lat_rad + north / Re_ft, ref_lon_rad + east / (Re_ft * cos(ref_lat_rad))));
	}
	
	//------------------------------------------------------------------------------
	//Function:       VectorCross3D
	//Description:    3D cross product  a X b
	//Arguments:      a
	//              b
	//              cross_prod_out
	//Return value:   cross_prod_out
	//------------------------------------------------------------------------------
	public static Vector3D VectorCross3D(Vector3D a, Vector3D b)
	{
		Vector3D cross_prod_out = new Vector3D();
		cross_prod_out.v[0] = a.v[1]*b.v[2] - a.v[2]*b.v[1];
		cross_prod_out.v[1] = a.v[2]*b.v[0] - a.v[0]*b.v[2];
		cross_prod_out.v[2] = a.v[0]*b.v[1] - a.v[1]*b.v[0];
		return(cross_prod_out);
	}

	//------------------------------------------------------------------------------
	//Function:       VectorNorm3D
	//Description:    Function to compute a norm of a 3D Vector3D
	//Arguments:      a
	//Return value:   norm
	//------------------------------------------------------------------------------
	public static  double VectorNorm3D(Vector3D a)
	{
		return sqrt(a.v[0]*a.v[0] + a.v[1]*a.v[1] + a.v[2]*a.v[2]);
	}

	//-----------------------------------------------------------------------------
	//function:      VectorDot3D
	//description:   Compute the dot product between 2 vectors A.B = C
	//arguments:     A   - Vector3D source  0
	//              B   - Vector3D source  1
	//return:        dot product
	//-----------------------------------------------------------------------------
	public static  double VectorDot3D(Vector3D a, Vector3D b)
	{
		double dp = 0.0;
		for (int inx=0;inx<3;inx++)
		{
		    dp+=(a.v[inx]*b.v[inx]);
		}
		return(dp);
	}
	//-----------------------------------------------------------------------------
	//function:      VectorDot2D
	//description:   Compute the dot product between 2 vectors A.B = C
	//arguments:     A   - Vector3D source  0
	//              B   - Vector3D source  1
	//return:        dot product
	//-----------------------------------------------------------------------------
	public static  double VectorDot2D(vector2D a, vector2D b)
	{
		int inx;
		double dp;
		for (dp=0.0,inx=0;inx<2;inx++)
		{
		    dp+=(a.v[inx]*b.v[inx]);
		}
		return(dp);
	}

	//------------------------------------------------------------------------------
	//Function:       VectorNorm3D
	//Description:    Function to compute a norm of a 3D Vector3D
	//Arguments:      a
	//Return value:   norm
	//------------------------------------------------------------------------------
	public static  double VectorNorm2D(vector2D a)
	{
		return sqrt(a.v[0]*a.v[0] + a.v[1]*a.v[1]);
	}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitRadialVector
	//description:   Given a Lat/lon compute the unit radial Vector3D
	//arguments:     double latitude_rad, double longitude_rad, double ur.v[3]
	//return:        ur
	//-----------------------------------------------------------------------------
	public static Vector3D ComputeUnitRadialVector(double latitude_rad, double longitude_rad)
	{
		
		Vector3D ur = new Vector3D();

		double sin_lat;
		double sin_lon;
		double cos_lat;
		double cos_lon;
		double radial_magnitude;
		
		sin_lat = sin(latitude_rad);
		sin_lon = sin(longitude_rad);
		cos_lat = cos(latitude_rad);
		cos_lon = cos(longitude_rad);
		radial_magnitude = sqrt(1.0 - Const.gd_two_e2_minus_e4*sin_lat*sin_lat);
		
		ur.v[0] = cos_lat*cos_lon/radial_magnitude;
		ur.v[1] = cos_lat*sin_lon/radial_magnitude;
		ur.v[2] = (1.0 - Const.gd_e2)*sin_lat/radial_magnitude;
		
		return (ur);
	}

	//-----------------------------------------------------------------------------
	//function:      NormalizeVector
	//description:
	//arguments:
	//return:        v_out
	//-----------------------------------------------------------------------------
	public static Vector3D NormalizeVector(Vector3D v_in)
	{
		
		Vector3D v_out = new Vector3D();
		double mag_v_in_sq;
		double Normalize_Vector_1_1;
		double check_val_out;
		int i;
	
		mag_v_in_sq = 0.0;
		for (i=0; i<3; i++) 
		{
			mag_v_in_sq += v_in.v[i]*v_in.v[i];
		}
		Normalize_Vector_1_1 = sqrt(mag_v_in_sq);
		
		check_val_out = Normalize_Vector_1_1;
		
		if ((abs(Normalize_Vector_1_1) < 1.0E-008)) 
		{
			check_val_out = 1.0E-008;
		}
		
		//normalize
		for (i=0; i<3; i++) 
		{
			v_out.v[i] = v_in.v[i]/check_val_out;
		}
		
		return(v_out);
	}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitNormalVector
	//description:
	//arguments:     double ur1[3] ,double ur2[3]
	//return:        un
	//-----------------------------------------------------------------------------
	public static Vector3D ComputeUnitNormalVector(Vector3D ur1 , Vector3D ur2)
	{
		Vector3D un1 = new Vector3D();
		
		//Compute Unit Normal Vector via the cross product
		un1.v[0] = ur2.v[1]*ur1.v[2] - ur2.v[2]*ur1.v[1];
		un1.v[1] = ur2.v[2]*ur1.v[0] - ur2.v[0]*ur1.v[2];
		un1.v[2] = ur2.v[0]*ur1.v[1] - ur2.v[1]*ur1.v[0];
		
		//Normalize Vector
		return (NormalizeVector(un1));
		
	}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitTangentialVector
	//description:   Compute Unit Tangential Vector
	//arguments:     double un[3] ,double ur.v[3] ,double ut[3]
	//return:        un
	//-----------------------------------------------------------------------------
	public static Vector3D ComputeUnitTangentialVector(Vector3D un , Vector3D ur)
	{
		return (VectorCross3D(un, ur));
	}

	//-----------------------------------------------------------------------------
	// function:      RangeBearingToLatLon
	// description:   Convert range and bearing data to Lat and lon
	// arguments:     latitude_rad - reference Lat
	//					longitude_rad - reference lon
	//					heading_rad - bearing rel. to true north from ref location
	//					double distance_ft - dist(ft)
	//					double *latitude_out
	//					double *longitude_out
	// return:        latitude_out and longitude_out thru argument pointers
	//-----------------------------------------------------------------------------
	public static  LatLngRad RangeBearingToLatLon(double latitude_rad, double longitude_rad, double heading_rad, double distance_ft)
	{
		
		double lat_rad, hdg_rad, dist_rad, clat_in, slat_in;
		double chdg_in, shdg_in, cdist_in, sdist_in, slat_out, lat_out_rad;
		double clat_out, delta_longitude, sdlong;
		double eps = 1.0e-14;
		double Re_ft = Const.earth_a_ft; // 2.09256463254593E+07;
		

	
		lat_rad  = latitude_rad;
		hdg_rad  = heading_rad;
		dist_rad = distance_ft / Re_ft;
		clat_in  = cos( lat_rad );
		slat_in  = sin( lat_rad );
		chdg_in  = cos( hdg_rad );
		shdg_in  = sin( hdg_rad );
		cdist_in = cos( dist_rad );
		sdist_in = sin( dist_rad );
	
		slat_out     = slat_in * cdist_in + clat_in * sdist_in * chdg_in;
		lat_out_rad  = asin( slat_out );
		clat_out     = cos( lat_out_rad );
	
		if ( abs(clat_out) < eps ) //divide by zero protection
			delta_longitude = 0.0;
		else
		{
			sdlong          = ( sdist_in * shdg_in ) / clat_out;
			delta_longitude = asin( sdlong );
		}
		
		return(new LatLngRad(lat_out_rad, longitude_rad + delta_longitude));
	  
	}
	
	//-----------------------------------------------------------------------------
	// function:      	LatLonToRangeBearing
	// description:   	Convert Lat lon and ref Lat lon to range and bearing data to Lat and lon
	// arguments:     	from_lat_rad - reference Lat
	//                	from_lon_rad - reference lon
	//					to_lat_rad
	//					to_lon_rad	
	//                  bearing_rad - bearing rel. to true north from ref location
	//                  range_ft - dist(ft)
	//-----------------------------------------------------------------------------
    public static  void LatLonToRangeBearing(double to_lat_rad, double to_lon_rad, double from_lat_rad, double from_lon_rad)
    {
        double delta_n_ft = (from_lat_rad-to_lat_rad)*Const.earth_a_ft;
        double delta_e_ft = (from_lon_rad-to_lon_rad)*Const.earth_a_ft*cos(to_lat_rad);
        range_ft = pow((delta_n_ft*delta_n_ft + delta_e_ft*delta_e_ft),0.5);
        bearing_rad = atan2(delta_e_ft,delta_n_ft);
        bearing_rad = limit_angle_rad(bearing_rad);
    }

	
	//-----------------------------------------------------------------------------
	// function:      	LatLonToRange
	// description:   	Convert Lat lon and ref Lat lon to range
	// arguments:     	from_lat_rad - reference Lat
	//                	from_lon_rad - reference lon
	//					to_lat_rad
	//					to_lon_rad	
	//                  range_ft - dist(ft)
	//-----------------------------------------------------------------------------
    public static  double LatLonToRange(double from_lat_rad, double from_lon_rad, double to_lat_rad, double to_lon_rad)
    {
    	double ret_ft;
        double delta_n_ft = (from_lat_rad-to_lat_rad)*Const.earth_a_ft;
        double delta_e_ft = (from_lon_rad-to_lon_rad)*Const.earth_a_ft*cos(to_lat_rad);
        ret_ft = pow((delta_n_ft*delta_n_ft + delta_e_ft*delta_e_ft),0.5);
        return (ret_ft);
    }

    //-----------------------------------------------------------------------------
	// function:      	LatLonToBearing
	// description:   	Convert Lat lon and ref Lat lon bearing data to Lat and lon
	// arguments:     	from_lat_rad - reference Lat
	//                	from_lon_rad - reference lon
	//					to_lat_rad
	//					to_lon_rad	
	//                  bearing_rad - bearing rel. to true north from ref location (from 0 to 360)
	//-----------------------------------------------------------------------------
    public static double LatLonToBearing(double from_lat_rad, double from_lon_rad, double to_lat_rad, double to_lon_rad)
    {
        
        double delta_n_ft = (to_lat_rad-from_lat_rad)*Const.earth_a_ft;
        double delta_e_ft = (to_lon_rad-from_lon_rad)*Const.earth_a_ft*cos(from_lat_rad);
        double loc_bearing_rad = atan2(delta_e_ft,delta_n_ft);
        loc_bearing_rad = limit_angle_rad(loc_bearing_rad);
        return (loc_bearing_rad);
   }
    
	//-----------------------------------------------------------------------------
    //	limit_angle_rad
    //	limit angle between 0 and 360 deg
	//-----------------------------------------------------------------------------
    public static  double limit_angle_rad(double loc_bearing_rad)
    {
    	double lim_bearing_rad = loc_bearing_rad;
    	
        if (loc_bearing_rad<0.0)
        {
        	lim_bearing_rad+= Const.two_pi;
        }
        else if (loc_bearing_rad>= Const.two_pi)
        {
        	lim_bearing_rad-= Const.two_pi;
        }
        return (lim_bearing_rad);
    	
    }
	//-----------------------------------------------------------------------------
	//function:      DistBetweenWaypoints
	//description:   Calculate the distance between waypoints in feet
	//arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	//return:        distance_ft
	//-----------------------------------------------------------------------------
	public  static double DistBetweenWaypoints(double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	{
		double distance_ft;

		Vector3D ur1 = ComputeUnitRadialVector(lat1_rad, lon1_rad);
		Vector3D ur2 = ComputeUnitRadialVector(lat2_rad, lon2_rad);
		Vector3D un = ComputeUnitNormalVector(ur1 ,ur2);
		Vector3D ut = ComputeUnitTangentialVector(un, ur2);
		distance_ft = VectorDot3D(ur1, ut) * Const.earth_a_ft;
		
		return(distance_ft);
	}

	//-----------------------------------------------------------------------------
	// function:      DistToWayPoint
	// description:   Calculate the distance from currentPosition to curr_wp
	//				  along the path from past_wp to curr_wp
	// arguments:     LatLngRad past_wp, LatLngRad curr_wp, LatLngRad currentPosition)
	// return:        distance_ft
	//-----------------------------------------------------------------------------
	public static  double DistToWayPoint(LatLngRad past_wp, LatLngRad curr_wp, LatLngRad curr_pos)
	{
		// unit radials
		Vector3D ur_curr_pos = ComputeUnitRadialVector(curr_pos.latitude_rad, curr_pos.longitude_rad);
		Vector3D ur_past_wp = ComputeUnitRadialVector(past_wp.latitude_rad, past_wp.longitude_rad);
		Vector3D ur_curr_wp = ComputeUnitRadialVector(curr_wp.latitude_rad, curr_wp.longitude_rad);

		// unit normal prev to curr LatLngRad
		Vector3D un_past_curr_wp = ComputeUnitNormalVector(ur_past_wp,ur_curr_wp);
		
		// unit tangential prev to curr
		Vector3D ut_past_curr_wp = ComputeUnitTangentialVector(un_past_curr_wp, ur_curr_wp);

        return(VectorDot3D(ut_past_curr_wp, ur_curr_pos) * Const.earth_a_ft);
	}


	//-----------------------------------------------------------------------------
	// function:      calcDownTrackPerc
	// description:   Calculate the current down track %
	// arguments:     LatLngRad past_wp, LatLngRad curr_wp, LatLngRad currentPosition
	// return:        down track
	//-----------------------------------------------------------------------------
	public static  double calcDownTrackPerc(LatLngRad past_wp, LatLngRad curr_wp, LatLngRad curr_pos)
	{
		double perc = 1.0;

		// unit radials
		Vector3D ur_past_wp = ComputeUnitRadialVector(past_wp.latitude_rad, past_wp.longitude_rad);
		Vector3D ur_curr_wp = ComputeUnitRadialVector(curr_wp.latitude_rad, curr_wp.longitude_rad);
		// unit normal prev to curr LatLngRad
		Vector3D un_past_curr_wp = ComputeUnitNormalVector(ur_past_wp,ur_curr_wp);
		// unit normal prev to curr LatLngRad
		Vector3D ut_past_curr_rad = ComputeUnitTangentialVector(ur_past_wp, un_past_curr_wp);

		double rdist = VectorDot3D(ur_curr_wp, ut_past_curr_rad) * Const.earth_a_ft;

		Vector3D ur_curr_pos = ComputeUnitRadialVector(curr_pos.latitude_rad, curr_pos.longitude_rad);

//		if (Math.abs(rdist) > 1e-16) {
		double cdist = VectorDot3D(ur_curr_pos, ut_past_curr_rad) * Const.earth_a_ft ;

		if (Math.abs(rdist) > 0.0)
		{
			perc = cdist/rdist;
		}

		return(perc);
	}
	
	//-----------------------------------------------------------------------------
	// function:      CrossTrack
	// description:   Calculate the current cross track error
	// arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	// return:        cross_track_err_ft
	//-----------------------------------------------------------------------------
	public static  double CrossTrack(LatLngRad past_wp, LatLngRad curr_wp, LatLngRad curr_pos)
	{
		// unit radials
		Vector3D ur_curr_pos = ComputeUnitRadialVector(curr_pos.latitude_rad, curr_pos.longitude_rad);
		Vector3D ur_past_wp = ComputeUnitRadialVector(past_wp.latitude_rad, past_wp.longitude_rad);
		Vector3D ur_curr_wp = ComputeUnitRadialVector(curr_wp.latitude_rad, curr_wp.longitude_rad);

		// unit normal prev to curr LatLngRad
		Vector3D un_past_curr_wp = ComputeUnitNormalVector(ur_past_wp,ur_curr_wp);
		
		// cross track component
        return(VectorDot3D(un_past_curr_wp, ur_curr_pos) * Const.earth_a_ft);
	}

	//-----------------------------------------------------------------------------
	// setReferenceLatLon
	//-----------------------------------------------------------------------------
	public static  void setReferenceLatLon(double lat_rad, double lon_rad)
	{
		ref_lat_rad = lat_rad;
		ref_lon_rad = lon_rad;
	}
	
	
	//-----------------------------------------------------------------------------
	//function:      getNorthFt
	//description:   Return north component in ft. (note reference Lat lon must be set)
	//arguments:     lat_rad
	//               lon_rad
	//return:        north_ft
	//-----------------------------------------------------------------------------
	public static  double getNorthFt(double lat_rad)
	{
		return(Const.earth_a_ft * (lat_rad-ref_lat_rad));
	}
	
	
	//-----------------------------------------------------------------------------
	//function:      getEastFt
	//description:   getEastFt east component in ft. (note reference Lat lon must be set)
	//arguments:     lat_rad
	//               lon_rad
	//return:        north_ft
	//-----------------------------------------------------------------------------
	public static  double getEastFt(double lon_rad)
	{
		return(Const.earth_a_ft * cos(ref_lat_rad) *(lon_rad-ref_lon_rad));
	}
	
	
	//-----------------------------------------------------------------------------
	//  getWayPoints
	//	
	//	Convert a Lat/long into a pixel location
	//-----------------------------------------------------------------------------
	public static void getWayPoints(double[] past_wp_latlon, double[] curr_wp_latlon, double warning_offset_ft, double rotation_angle_rad, float[] scale, float[] offset, PointF[] pts)
	{
		double dist_estimate_ft;

		double x = Const.earth_a_ft * cos(ref_lat_rad) *(curr_wp_latlon[1]-ref_lon_rad); //east
		double y = Const.earth_a_ft * (curr_wp_latlon[0]-ref_lat_rad); //north
		double x0 = Const.earth_a_ft * cos(ref_lat_rad) *(past_wp_latlon[1]-ref_lon_rad); //east
		double y0 = Const.earth_a_ft * (past_wp_latlon[0]-ref_lat_rad); //north

		//dist_estimate_ft = DistBetweenWaypoints(past_wp_latlon[0], past_wp_latlon[1], curr_wp_latlon[0], curr_wp_latlon[1]);

		double st = sin(rotation_angle_rad);
		double ct = cos(rotation_angle_rad);
		pts[0].x = (int) (((x*ct - y*st) * scale[0])+offset[0]);
		pts[0].y = (int) (offset[1]-((x*st + y*ct) * scale[1]));
		
		//disabled if warning_offset_ft==0
		if (warning_offset_ft>0)
		{
			//xy curr
			Vector3D currv= new Vector3D(new double[]{x,y,0});
			
			//xy past
			Vector3D pastv= new Vector3D();
			pastv.v[0] = x0; //Const.earth_a_ft * cos(ref_lat_rad) *(past_wp_latlon[1]-ref_lon_rad); //east
			pastv.v[1] = y0; //Const.earth_a_ft * (past_wp_latlon[0]-ref_lat_rad); //north
			pastv.v[2] = 0;
			
			Vector3D[] wt = getWarningTrackOffset(pastv, currv, warning_offset_ft);
			
			double x1 = wt[0].v[0];
			double y1 = wt[0].v[1];
			pts[1].x = (int) (((x1*ct - y1*st) * scale[0])+offset[0]);
			pts[1].y = (int) (offset[1]- ((x1*st + y1*ct) * scale[1]));
		
			//pt[2]= 90deg offset warning track.
			x1 = wt[1].v[0];
			y1 = wt[1].v[1];
			pts[2].x = (int) (((x1*ct - y1*st) * scale[0])+offset[0]);
			pts[2].y = (int) (offset[1]- ((x1*st + y1*ct) * scale[1]));
		}

    }

	//-----------------------------------------------------------------------------
	//  calcOffsetWayPoint
	//-----------------------------------------------------------------------------
	public static  LatLngRad calcOffsetWayPoint(LatLngRad pastwp, LatLngRad currwp, double offset_ft)
	{
		Vector3D pv = latLonToEastNorth(pastwp.latitude_rad, pastwp.longitude_rad);
		Vector3D cv = latLonToEastNorth(currwp.latitude_rad, currwp.longitude_rad);
		Vector3D ov = getOffsetVector(pv, cv, offset_ft);
		return eastNorthToLatLon(ov.v[0], ov.v[1]);
	}

	//-----------------------------------------------------------------------------
	//  latLonToEastNorth
	//-----------------------------------------------------------------------------
	public static Vector3D latLonToEastNorth(double lat_rad, double lon_rad)
	{
		return (new Vector3D(new double[]{
				Const.earth_a_ft * cos(ref_lat_rad) *(lon_rad-ref_lon_rad), //east
				Const.earth_a_ft * (lat_rad-ref_lat_rad), //north
				0.0}));
	}

	//-----------------------------------------------------------------------------
	//  getOffsetVector
	//-----------------------------------------------------------------------------
	public static Vector3D getOffsetVector(Vector3D pastv, Vector3D currv, double offset_ft)
	{
		Vector3D ret;
		
		//get unit Vector3D between past and curr wp
		Vector3D past_currv = VectorDifference(currv, pastv);
		
		//perform 3D cross product
		Vector3D z = new Vector3D(new double[]{0,0,1});
		Vector3D un_curr = VectorCross3D(z,NormalizeVector(past_currv));
		ret = VectorAdd(VectorMultiply(un_curr,offset_ft),currv);
		
		return (ret);
	}

	//-----------------------------------------------------------------------------
	//  getWarningTrackOffset
	//-----------------------------------------------------------------------------
	public static  Vector3D[] getWarningTrackOffset(Vector3D pastv, Vector3D currv, double warning_offset_ft)
	{
		Vector3D[] ret = new Vector3D[2];
		
		//get unit Vector3D between past and curr wp
		Vector3D past_currv = VectorDifference(currv, pastv);
		
		//perform 3D cross product
		Vector3D z = new Vector3D(new double[]{0,0,1});
		Vector3D un_curr = VectorCross3D(z,NormalizeVector(past_currv));

		ret[0] = VectorAdd(VectorMultiply(un_curr,warning_offset_ft),currv);
		ret[1] = VectorAdd(VectorMultiply(un_curr,-warning_offset_ft),currv);
		
		return (ret);
	}
	
	//-----------------------------------------------------------------------------
	//  pointToLatLon
	//-----------------------------------------------------------------------------
	public static  LatLngRad pointToLatLon(PointF xy, double rotation_angle_rad, double[] scale, double[] offset)
	{
		//xy to enu0 
		double e0 = (xy.x - offset[0])/scale[0];
		double n0 = (offset[1] - xy.y)/scale[1];
		
		//enu0 to enu1 
		double st = sin(-rotation_angle_rad);
		double ct = cos(-rotation_angle_rad);
		double e1 = e0*ct - n0*st;
		double n1 = e0*st + n0*ct;
		
		//east/north to Lat/lon

        return eastNorthToLatLon(e1, n1);
	}


	
	//-----------------------------------------------------------------------------
	//  pointToLatLon
	//-----------------------------------------------------------------------------
	public static  LatLngRad eastNorthToLatLon(double east_ft, double north_ft)
	{
		LatLngRad ret = new LatLngRad();

		//east/north to Lat/lon
		ret.longitude_rad = east_ft/Const.earth_a_ft/cos(ref_lat_rad) + ref_lon_rad;
		ret.latitude_rad = north_ft/Const.earth_a_ft + ref_lat_rad;
		
		return ret;
	}

 	//---------------------------------------------------------------------------
	// getCheckpointMarkers
	//---------------------------------------------------------------------------
	public static  void getCheckpointMarkers(CheckPoint cp, LatLngRad cpwp0, LatLngRad cpwp1, double in_out_buffer_ft, double rotation_angle_rad, float[] scale, float[] offset, PointF[] pts)
	{
		// XY of checkpoint
		//double x = Const.earth_a_ft * cos(ref_lat_rad) *(cp.longitude_rad-ref_lon_rad); //east
		//double y = Const.earth_a_ft * (cp.latitude_rad-ref_lat_rad); //north

		//xy curr
		//Vector3D cpv= new Vector3D(new double[]{x,y,0});

		//wp0 Vector3D
		double xwp0 = Const.earth_a_ft * cos(ref_lat_rad) *(cpwp0.longitude_rad -ref_lon_rad); //east
		double ywp0 = Const.earth_a_ft * (cpwp0.latitude_rad -ref_lat_rad); //north
		Vector3D wpv0= new Vector3D(new double[]{xwp0,ywp0,0});

		//wp1 Vector3D
		double xwp1 = Const.earth_a_ft * cos(ref_lat_rad) *(cpwp1.longitude_rad -ref_lon_rad); //east
		double ywp1 = Const.earth_a_ft * (cpwp1.latitude_rad -ref_lat_rad); //north
		Vector3D wpv1= new Vector3D(new double[]{xwp1,ywp1,0});

		//get unit Vector3D between wpv and cpv
		Vector3D utv = NormalizeVector(VectorDifference(wpv1, wpv0));

		Vector3D z = new Vector3D(new double[]{0,0,1});
		Vector3D unv = VectorCross3D(z,NormalizeVector(utv));

		Vector3D tmp1 = VectorAdd(VectorMultiply(utv,-cp.offset_ft - in_out_buffer_ft),wpv1);
		double river_half_width = Const.mile_to_feet;
		Vector3D p1 = VectorAdd(VectorMultiply(unv, river_half_width),tmp1);
		Vector3D p2 = VectorAdd(VectorMultiply(unv,-river_half_width),tmp1);

		tmp1 = VectorAdd(VectorMultiply(utv,-cp.offset_ft+in_out_buffer_ft),wpv1);
		Vector3D p3 = VectorAdd(VectorMultiply(unv, river_half_width),tmp1);
		Vector3D p4 = VectorAdd(VectorMultiply(unv,-river_half_width),tmp1);

		double st = sin(rotation_angle_rad);
		double ct = cos(rotation_angle_rad);

		pts[0].x = (int) (((p1.v[0]*ct - p1.v[1]*st) * scale[0])+offset[0]);
		pts[0].y = (int) (offset[1]-((p1.v[0]*st + p1.v[1]*ct) * scale[1]));

		pts[1].x = (int) (((p2.v[0]*ct - p2.v[1]*st) * scale[0])+offset[0]);
		pts[1].y = (int) (offset[1]-((p2.v[0]*st + p2.v[1]*ct) * scale[1]));

		pts[2].x = (int) (((p3.v[0]*ct - p3.v[1]*st) * scale[0])+offset[0]);
		pts[2].y = (int) (offset[1]-((p3.v[0]*st + p3.v[1]*ct) * scale[1]));

		pts[3].x = (int) (((p4.v[0]*ct - p4.v[1]*st) * scale[0])+offset[0]);
		pts[3].y = (int) (offset[1]-((p4.v[0]*st + p4.v[1]*ct) * scale[1]));
	}

	//-----------------------------------------------------------------------------
	//  getPoint
	//-----------------------------------------------------------------------------
	public static  PointF getPoint(double latitude_rad, double longitude_rad, double rotation_angle_rad, float[] scale, float[] offset)
	{
		PointF pts = new PointF();
		getPoint(latitude_rad, longitude_rad, rotation_angle_rad, scale, offset, pts);
		return pts;
	}

	//-----------------------------------------------------------------------------
	//  getPoint
	//-----------------------------------------------------------------------------
	public static  void getPoint(double latitude_rad, double longitude_rad, double rotation_angle_rad, float[] scale, float[] offset, PointF pts)
	{
		double x = Const.earth_a_ft * cos(ref_lat_rad) *(longitude_rad-ref_lon_rad); //east
		double y = Const.earth_a_ft * (latitude_rad-ref_lat_rad); //north
		double st = sin(rotation_angle_rad);
		double ct = cos(rotation_angle_rad);
		pts.x = (int) (((x*ct - y*st) * scale[0]) + offset[0]);
		pts.y = (int) (offset[1] - ((x*st + y*ct) * scale[1]));
	}

	//-----------------------------------------------------------------------------
	//  getNorthEast
	//-----------------------------------------------------------------------------
	public static  double[] getNorthEast(double latitude_rad, double longitude_rad)
	{
		double x = Const.earth_a_ft * (latitude_rad-ref_lat_rad); //north
		double y = Const.earth_a_ft * cos(ref_lat_rad) *(longitude_rad-ref_lon_rad); //east
		return (new double[]{x,y});
	}

	//-----------------------------------------------------------------------------
	//  getNorthEast
	//-----------------------------------------------------------------------------
	public static  void getNorthEast(double latitude_rad, double longitude_rad, float[] pts ) 
	{
		pts[0] = (float) (Const.earth_a_ft * (latitude_rad-ref_lat_rad)); //north
		pts[1] = (float) (Const.earth_a_ft * cos(ref_lat_rad) *(longitude_rad-ref_lon_rad)); //east
	}
	
	//-----------------------------------------------------------------------------
	//  getPoint
	//	
	//	Convert a Lat/long into a pixel location
	//-----------------------------------------------------------------------------
	public static  void getPoint(double lat_rad, double lon_rad, double rotation_angle_rad, double scale, PointF ret)
	{
		double x = Const.earth_a_ft * cos(ref_lat_rad) *(lon_rad-ref_lon_rad); //east
		double y = Const.earth_a_ft * (lat_rad-ref_lat_rad); //north
		double st = sin(rotation_angle_rad);
		double ct = cos(rotation_angle_rad);
		ret.x = (int) ((x*ct - y*st) * scale);
		ret.y = (int) ((x*st + y*ct) * scale);
	}
	//-----------------------------------------------------------------------------
	//  get2DCoordinateXformMatrix
	//	
	//	create a 2D coordinate tranform matrix (A). upper left 2x2 is the rotation matrix
	//  upper right 2X1 is the translation. lower right 1X1 is a scale factor
	//-----------------------------------------------------------------------------
	public static  Double[][] get2DCoordinateXformMatrix(double rotation_angle_rad, double [] offset,  double scale)
	{
		
		Double[][] A = new Double[3][3];
		 
		// scale factor
		A[2][2] = scale;
		
		// offset Vector3D
		A[2][0] = offset[0];
		A[2][1] = offset[1];
		
		// rotation matrix
		double st = sin(rotation_angle_rad);
		double ct = cos(rotation_angle_rad);

		A[0][0] = ct;
		A[0][1] = -st;

		A[1][0] = st;
		A[1][1] = ct;
		
		return A;
	}


	//------------------------------------------------------------------------------
	//Function:       getAngle
	//Description:    Get angle between 2 vectors
	//Arguments:      a
	//              b
	//Return value:   cross_prod_out
	//------------------------------------------------------------------------------
	public static  double getAngle(vector2D a, vector2D b)
	{
		return acos(VectorDot2D(a,b)/VectorNorm2D(a)/VectorNorm2D(b));
	}
	
	//------------------------------------------------------------------------------
	// Function:       VectorDifference
	// Description:    compute a-b
	//------------------------------------------------------------------------------
	public static Vector3D VectorDifference(Vector3D a, Vector3D b)
	{
		Vector3D ret = new Vector3D();
		for (int inx=0;inx<a.v.length;inx++)
		{
			ret.v[inx] = a.v[inx] - b.v[inx];
		}
		return ret;
	}
	//------------------------------------------------------------------------------
	// Function:       VectorDifference
	// Description:    compute a+b
	//------------------------------------------------------------------------------
	public static Vector3D VectorAdd(Vector3D a, Vector3D b)
	{
		Vector3D ret = new Vector3D();
		for (int inx=0;inx<a.v.length;inx++)
		{
			ret.v[inx] = a.v[inx] + b.v[inx];
		}
		return ret;
	}

	//------------------------------------------------------------------------------
	// Function:       VectorMultiply
	// Description:    compute a*b
	//------------------------------------------------------------------------------
	public static Vector3D VectorMultiply(Vector3D a, double b)
	{
		Vector3D ret = new Vector3D();
		for (int inx=0;inx<a.v.length;inx++)
		{
			ret.v[inx] = a.v[inx] * b;
		}
		return ret;
	}

	//------------------------------------------------------------------------------
	// Function:       getProjectionMatrix
	// Description:    The orthogonal projection can be represented by a projection matrix.
	// To project a Vector3D onto the unit Vector3D a = (ax, ay, az), it would need to be multiplied
	// with this projection matrix:
	//------------------------------------------------------------------------------
	public static  matrix getProjectionMatrix(Vector3D v)
	{
		matrix ret = new matrix();

		Vector3D u = NormalizeVector(v);

		ret.v[0][0] = u.v[0] * u.v[0];
		ret.v[0][1] = u.v[0] * u.v[1];
		ret.v[0][2] = u.v[0] * u.v[2];

		ret.v[1][0] = u.v[1] * u.v[0];
		ret.v[1][1] = u.v[1] * u.v[1];
		ret.v[1][2] = u.v[1] * u.v[2];

		ret.v[1][0] = u.v[2] * u.v[0];
		ret.v[1][1] = u.v[2] * u.v[1];
		ret.v[1][2] = u.v[2] * u.v[2];

		return (ret);

	}



}


