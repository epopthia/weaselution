package com.MR340ProPaddler.infrastructure;

import android.app.Application;
import android.os.Environment;
//import android.support.multidex.MultiDex;
import android.util.Log;

import com.MR340ProPaddler.ClassLog;
import com.MR340ProPaddler.Globals;
import com.MR340ProPaddler.RaceOwlClient;
import com.MR340ProPaddler.WayPointMission;

import java.io.File;

@SuppressWarnings({"unused"})
public class Startup extends Application {


    public Startup() {
        // this method fires only once per application start.
        // getApplicationContext returns null here

    }

    @Override
    public void onCreate() {
        super.onCreate();


        Log.d("MR340ProPaddler", "Constructor fired");
        // this method fires once as well as constructor
        // but also application has context here

        // Get the one and only instance of globals
        Globals globals = Globals.getInstance(this.getApplicationContext());

        RaceOwlClient raceowl = RaceOwlClient.getInstance();

        WayPointMission wp = WayPointMission.getInstance();

        ClassLog history = ClassLog.getInstance();

        // set startup globals
    //    globals.gpsDisableWarningDisplayed = false;

        // race update needs to be accessed at least once
        if (raceowl.getRaceCount() <= 0)
        {
            globals.appState.racesInitialized = false;
        }

        // verify the output directory
        verifyOutputDirectory();

    }

    // ---------------------------------------------------------------------------------------------
    // verifyOutputDirectory
    // ---------------------------------------------------------------------------------------------
    private void verifyOutputDirectory()
    {
        File folder = new File(Environment.getExternalStorageDirectory() + File.separator + "mr340pro");
        if (!folder.exists())
        {
            boolean success = folder.mkdirs();

//            TODO: react to this
//            if (!success)
//            {
//                toast
//
//            }
        }
    }

}