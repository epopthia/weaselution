package com.MR340ProPaddler;

//import java.util.Date;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.MR340ProPaddler.baseclass.CheckPoint;
import com.MR340ProPaddler.baseclass.CheckPointCycle;
import com.MR340ProPaddler.baseclass.CheckPointTime;
import com.MR340ProPaddler.baseclass.Route;
import com.MR340ProPaddler.baseclass.WayPoint;
import com.MR340ProPaddler.infrastructure.AppState;
import com.MR340ProPaddler.infrastructure.Settings;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import static android.preference.PreferenceManager.getDefaultSharedPreferences;

public class Globals {

    private static Globals objGlobals;

    //private final SharedPreferences preferences;

    // preferences
    public Settings settings;
    ArrayList<RacerState> racerStates;
    public ArrayList<Location> locations;
    ArrayList<RaceOwlAPI.RaceEvent> raceowlRaceList;
    public ArrayList<CheckPointCycle> checkPointCycles;
    ArrayList<RaceOwlClient.RaceDivisions>  divisions;

    public ArrayList<CheckPointTime> checkPointTimes;


    public final Route route;


    final MessageQueue messages;
    public final AppState appState;
    final int maxRacerState = 2;

    // seek bar constants
    final float seekbar_base_line_width_scale = 1;
    final float seekbar_base_line_width_offset = 1;
    final String seekbar_base_line_width_format = "Graphics baseline width (%1.0f pixel)";


    //settings.seekbar_gps_update_rate_scale, settings.seekbar_gps_update_rate_offset, tv, settings.seekbar_gps_update_rate_format, null);
    final int[] seekbar_gps_update_rate_values = new int[]{1,2,5,10,15,30,60,90,2*60,5*60,10*60};
    final float seekbar_gps_update_rate_scale = 1;
    final float seekbar_gps_update_rate_offset = 0;
    final String seekbar_gps_update_rate_format = "GPS status update time (%1.0f sec/update)";
    final String seekbar_gps_nav_update_rate_format = "GPS NAV update time (%1.0f sec/update)";


    final float seekbar_logging_delta_min_scale = (float) 0.25;
    final float seekbar_logging_delta_min_offset = 0;
    final String seekbar_logging_delta_min_format = "Logging time (%1.2f minute/log entry)";
    final String seekbar_logging_delta_min_disabled = "Logging (disabled)";

    final float seekbar_audio_status_min_scale = 3;
    final float seekbar_audio_status_min_offset = 1;
    final String seekbar_audio_status_min_format = "Audio status time (%1.0f minute/status)";

    final float seekbar_crosstrack_warning_scale = 20;
    final float seekbar_crosstrack_warning_offset = 0;
    final String seekbar_crosstrack_warning_format = "Crosstrack warning (%1.0f ft)";
    final String seekbar_crosstrack_warning_disabled = "Crosstrack warning (disabled)";

    final float seekbar_m_boat_scale_scale = (float) 0.5;
    final float seekbar_m_boat_scale_offset = 1;
    final String seekbar_m_boat_scale_format = "Boat icon scale (%1.1f)";

    final float seekbar_average_base_min_scale = 5;
    final float seekbar_average_base_min_offset = 5;
    final String seekbar_average_base_min_format = "Averaging basis (%1.0f minute)";


    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized Globals getInstance(Context app_context)
    {
        if(objGlobals == null)
        {
            objGlobals = new Globals(app_context);
        }
        return objGlobals;
    }
    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized Globals getInstance(Context app_context, boolean forceNew)
    {
        if(objGlobals == null || forceNew)
        {
            objGlobals = new Globals(app_context);
        }
        return objGlobals;
    }

    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized Globals getInstance()
    {
        return objGlobals;
    }

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------
    private Globals(Context context) {

        settings = new Settings();
        messages = new MessageQueue();
        appState = new AppState(context);
        route  = new Route();

        racerStates = new ArrayList<>();
        locations = new ArrayList<>();
        raceowlRaceList = new ArrayList<>();
        checkPointCycles = new ArrayList<>();
        divisions = new ArrayList<>();
        checkPointTimes = new ArrayList<>();

        loadAllSettings(context);

        // if we have dismissed the quickstart then restore it after some time has passed
        if (!settings.enableQuickSettings)
        {
            if (ClassUtility.getDeltaTimeSec(settings.lastQuickSettingsDate, new Date()) > 10 * Const.day_to_sec)
            {
                settings.lastQuickSettingsDate = new Date();
                settings.enableQuickSettings = true;
            }
        }
        else
        {
            settings.lastQuickSettingsDate = new Date();
        }

        //set quick start State
        appState.quickStartState = settings.enableQuickSettings ? AppState.QuickStartState.armed : AppState.QuickStartState.disabled;

        Log.d(appState.appName, String.format("settings.enableQuickSettings = %b, appState.quickStartState = %s", settings.enableQuickSettings, appState.quickStartState.name()));

        // always update the following
        //settings.phone_number = ClassUtility.getCellPhoneNumber(context, true);
        settings.version = ClassUtility.getAppVersionString(context);
    }

    // ----------------------------------------------------------------------
    // setAutoModeSettings
    // ----------------------------------------------------------------------
    void setAutoModeSettings()
    {
        WayPointMission wp = WayPointMission.getInstance();
        setDefaultStartStop(route.cps);
        wp.setNearestCheckpointIndex(3 * Const.sec_to_ms);
        settings.startup_screen_idx = 0;
        settings.average_base_min = 45;
        settings.line_width = 2;
        settings.nav_origin = 0;
        settings.zoom = 1;
        settings.crosstrack_warning = 60;
        settings.m_boat_scale = 2;
        settings.displayCheckpointsOnly = true;
        settings.displayCycledCheckpoints = false;
        settings.enableAudibleWarningTrack = false;
        settings.enableAudibleStatus =  true;
        settings.tot_mile = 0;
        settings.tot_mile_last_lat_rad = 0;
        settings.tot_mile_last_lon_rad  = 0;
        settings.audioStatusUpdatePeriod_min = 4;
        settings.gpsSlowUpdatePeriod_sec =  30;
        settings.gpsFastUpdatePeriod_sec =  2;
        settings.trackingEnabled = true;
        settings.enableAutoCheckin = true;
        settings.trackingActive = true;

    }



    // ----------------------------------------------------------------------
    // setDefaultStartStop
    // ----------------------------------------------------------------------
    void setDefaultStartStop(CheckPoint[] cps)
    {
        int first_cp_idx = 0;
        for (int inx=0;inx<route.cps.length;inx++) {
            if (route.cps[inx].isCheckpoint) {
                first_cp_idx = inx;
                break;
            }
        }

        int last_cp_idx = route.cps.length - 1;
        for (int inx=route.cps.length-1;inx>=0;inx--) {
            if (route.cps[inx].isCheckpoint) {
                last_cp_idx = inx;
                break;
            }
        }

        if (settings.waypoint_reverse) {
            settings.startCheckpointIndex = last_cp_idx;
            settings.finishCheckpointIndex = first_cp_idx;
        } else {
            settings.startCheckpointIndex = first_cp_idx;
            settings.finishCheckpointIndex = last_cp_idx;
        }

    }


    // ----------------------------------------------------------------------
    // loadAllSettings from json file
    // ----------------------------------------------------------------------
    private void loadAllSettings(Context app_context)
    {
        SharedPreferences preferences = getDefaultSharedPreferences(app_context);

        Gson gson = new GsonBuilder().serializeNulls().create();

        //Settings
        String json = preferences.getString("settings", "");
        Type collectionType = new TypeToken<Settings>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            try {
                settings = gson.fromJson(json, collectionType);
            }
            catch (Exception e)
            {
                settings = new Settings();
//                Log.e(objGlobals.appState.appName, "loadAllSettings failure", e);
            }
        }

        json = preferences.getString("checkPointCycles", "");
        collectionType = new TypeToken<ArrayList<CheckPointCycle>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            try {
                checkPointCycles = gson.fromJson(json, collectionType);
            }
            catch (Exception e)
            {
                checkPointCycles = new ArrayList<>();
                Log.e(objGlobals.appState.appName, "loadAllSettings checkPointCycles failure", e);
            }
        }



        json = preferences.getString("raceowlRaceList", "");
        collectionType = new TypeToken<ArrayList<RaceOwlAPI.RaceEvent>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            try {
                raceowlRaceList = gson.fromJson(json, collectionType);
            }
            catch (Exception e)
            {
                raceowlRaceList = new ArrayList<>();
                Log.e(objGlobals.appState.appName, "loadAllSettings raceowlRaceList failure", e);
            }


        }
        json = preferences.getString("divisions", "");
        collectionType = new TypeToken<ArrayList<RaceOwlClient.RaceDivisions>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            divisions = gson.fromJson(json, collectionType);
        }

        json = preferences.getString("locations", "");

        collectionType = new TypeToken<ArrayList<Location>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            try {
                locations = gson.fromJson(json, collectionType);
            }
            catch (Exception e)
            {
                locations = new ArrayList<>();
                Log.e(objGlobals.appState.appName, "loadAllSettings locations failure", e);
            }
        }
        json = preferences.getString("racerStates", "");
        collectionType = new TypeToken<ArrayList<RacerState>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            try {
                racerStates = gson.fromJson(json, collectionType);
            }
            catch (Exception e)
            {
                racerStates = new ArrayList<>();
                Log.e(objGlobals.appState.appName, "loadAllSettings racerStates failure", e);
            }

        }
        json = preferences.getString("checkPointTimes", "");
        collectionType = new TypeToken<ArrayList<CheckPointTime>>(){}.getType();
        if (Objects.requireNonNull(json).length() > 0)
        {
            checkPointTimes = gson.fromJson(json, collectionType);
        }

        //print information
        Log.d(appState.appName, "Settings Restored:");
        Log.d(appState.appName, "------------------");
        Log.d(appState.appName, String.format("race count = %d", this.raceowlRaceList.size()));
        Log.d(appState.appName, String.format("checkPointCycles count = %d", this.checkPointCycles.size()));
        Log.d(appState.appName, String.format("checkPointTimes count = %d", this.checkPointTimes.size()));
        Log.d(appState.appName, String.format("locations count = %d", this.locations.size()));
        Log.d(appState.appName, String.format("racerStates count = %d", this.racerStates.size()));
        Log.d(appState.appName, String.format("divisions count = %d", this.divisions.size()));


        Log.d(appState.appName, "");
    }

    // ----------------------------------------------------------------------
    // saveAllSettings to json file
    //FIX me!
    // ----------------------------------------------------------------------
    void saveAllSettings(Context app_context) {
        SharedPreferences preferences = getDefaultSharedPreferences(app_context);
        SharedPreferences.Editor editor = preferences.edit();
        Gson gson = new Gson();
        try {
            String json = gson.toJson(settings);
            editor.putString("settings", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed settings to JSON:");
        }

        try {
            String json = gson.toJson(raceowlRaceList);
            editor.putString("raceowlRaceList", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed raceowlRaceList to JSON:");
        }


        try {
            String json = gson.toJson(checkPointCycles);
            editor.putString("checkPointCycles", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed checkPointCycles to JSON:");
        }

        try {
            String json = gson.toJson(checkPointTimes);
            editor.putString("checkPointTimes", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed checkPointTimes to JSON:");
        }


        try {
            String json = gson.toJson(divisions);
            editor.putString("divisions", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed divisions to JSON:");
        }

        try {
            String json = gson.toJson(locations);
            editor.putString("locations", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed locations to JSON:");
        }

        try {
            String json = gson.toJson(racerStates);
            editor.putString("racerStates", json);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            Log.e("RaceOwl", "Could not save malformed racerStates to JSON:");
        }

        editor.apply();

    }

    private void putDouble(
            final SharedPreferences.Editor edit, final String key,
            final double value) {
        edit.putLong(key, Double.doubleToRawLongBits(value));
    }

    @SuppressWarnings("SameParameterValue")
    private double getDouble(final SharedPreferences prefs, final String key, final double defaultValue) {
        return Double.longBitsToDouble(prefs.getLong(key,
                Double.doubleToLongBits(defaultValue)));
    }
    // ---------------------------------------------------------------------------------------------
    // clearCheckpoints
    // ---------------------------------------------------------------------------------------------
    void clearCheckpoints()
    {
        route.cps = new CheckPoint[0];
    }

    boolean isInvalidCheckpoint(int idx)
    {
        return (route.cps == null || route.cps.length <= idx);
    }

    // ---------------------------------------------------------------------------------------------
    // getCheckpointNames
    // ---------------------------------------------------------------------------------------------
    ArrayList<String> getCheckpointNames()
    {
        ArrayList<String> ret = new ArrayList<>();
        for (CheckPoint cp:route.cps)
        {
//            if (cp.isCheckpoint || cp.isSupported) {
            ret.add(cp.Name);
//            }
        }
        return (ret);
    }



    public void clearCheckpointsLog() {
        checkPointCycles.clear();
    }

    void checkPointCyclesAdd(CheckPointCycle cpc) {
        cpc.MessageID = checkPointCycles.size();
        checkPointCycles.add(cpc);
    }

    // ---------------------------------------------------------------------------------------------
    // clearWaypoints
    // ---------------------------------------------------------------------------------------------
    void clearWaypoints()
    {
        route.wps = new WayPoint[0];
    }


}
