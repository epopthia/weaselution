package com.MR340ProPaddler.fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.MR340ProPaddler.ActivityMain;
import com.MR340ProPaddler.Globals;
import com.MR340ProPaddler.R;
import com.MR340ProPaddler.WayPointMission;
import com.MR340ProPaddler.utility.Const;

import java.util.Objects;

public class Frag00_summary extends Fragment
{
	private View v = null;
	private Handler mHandler;
    private Globals globals;
    private WayPointMission wp;
    // --Commented out by Inspection (1/4/19, 3:08 PM):MenuItem menu;

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{

        setHasOptionsMenu(true);

   	    if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);

		//get waypoint
		wp = WayPointMission.getInstance();

		//get view
		v = inflater.inflate(R.layout.frag01_summary, container, false);
		v.setKeepScreenOn(true);


		// if fragment is visible then update
	    if (getUserVisibleHint())
	    {
	    	update();
        }
		return v;
	}

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
    {
        menu.add(0, 0, 0, "Reset Statistics");
        menu.add(0, 1, 0, "Toggle Channel Audio ");
        menu.add(0,2,0,"Toggle Status Audio ");
        menu.add(0,3,0,"Toggle High Contrast");

        super.onCreateOptionsMenu(menu, inflater);
    }


    @Override
	public void onAttach(Context context) {
		super.onAttach(context);
		globals = Globals.getInstance();
		globals.appState.ctx = context;
	}


	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
	    super.setUserVisibleHint(isVisibleToUser);
	    if (isVisibleToUser && v!=null)
	    {
            ((ActivityMain)Objects.requireNonNull(getActivity())).manageScreenTransition();
	    	update();
	    }
	}

	// graphicsRefresh for AppState screen
	private void graphicsRefresh()
	{
		int my_color = Color.RED;

		if (globals.settings.enable_high_contrast_color)
		{
			my_color = Color.WHITE;
		}

		//set text color
		setTextColor(my_color);

	}
	@Override
	public void onResume()
	{
		graphicsRefresh();

		if (globals.appState.enableSimulation)
		{
	   	    //start timed activities
	        mHandler = new Handler(); //setup for timed updates
	   	    startRepeatingTask();
		}
		else
		{
			registerBroadcastReceiver();
		}

		update();
		super.onResume();
	}

	@Override
	public void onPause()
	{
		//sim mode
		if (globals.appState.enableSimulation)
		{
			stopRepeatingTask();
		}
		else
		{
			unregisterReceiver();
		}
		super.onPause();
	}

	private BroadcastReceiver mPositionUpdate = null;

	private void registerBroadcastReceiver()
	{
	    final IntentFilter theFilter = new IntentFilter();

	    theFilter.addAction("MR340_LOCATION");

	    mPositionUpdate = new BroadcastReceiver()
	    {
	        @Override
	        public void onReceive(Context context, Intent intent) {
	            String strAction = intent.getAction();

				assert strAction != null;
				if (strAction.equals("MR340_LOCATION"))
	            {
	            	update();
	            }
	        }
	    };

	    Objects.requireNonNull(getActivity()).registerReceiver(mPositionUpdate, theFilter);
	}



	//---------------------------------------------------------------------------
	// unregisterReceiver
	//---------------------------------------------------------------------------
	private void unregisterReceiver() {
	    int apiLevel = Build.VERSION.SDK_INT;

	    if (apiLevel >= 7) {
	        try {
	            Objects.requireNonNull(getActivity()).unregisterReceiver(mPositionUpdate);
	        }
	        catch (IllegalArgumentException e) {
	            mPositionUpdate = null;
	        }
	    }
	    else {
	    	Objects.requireNonNull(getActivity()).unregisterReceiver(mPositionUpdate);
	        mPositionUpdate = null;
	    }
	}
	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	private void startRepeatingTask()
	{
		mStatusChecker.run();
	}

	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
    private void stopRepeatingTask()
    {
	    mHandler.removeCallbacks(mStatusChecker);
	}

	//---------------------------------------------------------------------------
	// mStatusChecker
	//---------------------------------------------------------------------------
	private final Runnable mStatusChecker = new Runnable()
	{
	    @Override
	    public void run()
	    {
			//Toast.makeText(getActivity() ,String.format("Status") , Toast.LENGTH_LONG).show();
        	update();
			mHandler.removeCallbacks(mStatusChecker);
	    	mHandler.postDelayed(mStatusChecker, Const.prime_deltat_ms);
	    }
	};


	//---------------------------------------------------------------------------
	// mStatusChecker
	//---------------------------------------------------------------------------
	private void setTextColor(int color)
	{
		TextView t1 = v.findViewById(R.id.text_Bearing_Err);
		if (t1==null) return;

		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_crosstrack);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_max);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_speed);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_AvgSpd);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_Plan);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_Track);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_avgTrack);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_gps);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_totalmile);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_rivermile);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_efficient);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_elapsed_time);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_estimated_finish_time);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_checkpoints);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_eta);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_dist);
		t1.setTextColor(color);

	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{

		TextView t1 = v.findViewById(R.id.speed_mph);

		if (t1==null) return;  //pop out of update if screen not drawn

		TextView t2 = v.findViewById(R.id.avg_speed_mph);
		TextView t3 = v.findViewById(R.id.crosstrack);
		TextView t4 = v.findViewById(R.id.rivermile);
		t1.setText(String.format("%1.1f",wp.getSpeed()));
		t2.setText(String.format("%1.1f",wp.getAvgSpeed()));
		t3.setText(String.format("%1.0f",wp.getCrossTrack()));
		t4.setText(String.format("%1.1f",wp.getRiverMile()));

		t4 = v.findViewById(R.id.totalmile);
		t4.setText(String.format("%1.1f",wp.getTotalMiles()));

		TextView track = v.findViewById(R.id.trackspeed_mph);
		double tmp = wp.getTrackSpeed();

		track.setText(String.format("%1.1f",tmp));


		TextView t7 = v.findViewById(R.id.gpsaccuracy);
		t7.setText(String.format("%1.1f",wp.getAccuracy()));

		track = v.findViewById(R.id.avg_trackspeed_mph);
		tmp = wp.getAvgTrackSpeed();
		track.setText(String.format("%1.1f",tmp));

		t7 = v.findViewById(R.id.efficiency);
		t7.setText(String.format("%1.0f",wp.getEfficiency()*100));

		int idx = wp.getNextCheckPointIndex(0.0,true);
		TextView t6 = v.findViewById(R.id.next_checkpoint);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 0)));
		t6 = v.findViewById(R.id.next_checkpoint_eta);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 1)));
		t6 = v.findViewById(R.id.next_checkpoint_dist);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 2)));

		idx = wp.getSelectedCheckpointIndex();
		t6 = v.findViewById(R.id.selected_checkpoint);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 0)));
		t6 = v.findViewById(R.id.selected_checkpoint_eta);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 1)));
		t6 = v.findViewById(R.id.selected_checkpoint_dist);
		t6.setText(String.format("%s",wp.getCheckpointItem(idx, 2)));

		idx = wp.getFinalCheckpoint();
		TextView t8 = v.findViewById(R.id.finish_checkpoint);
		t8.setText(String.format("%s",wp.getCheckpointItem(idx,0)));
		t8 = v.findViewById(R.id.finish_checkpoint_eta);
		t8.setText(String.format("%s",wp.getCheckpointItem(idx,1)));
		t8 = v.findViewById(R.id.finish_checkpoint_dist);
		t8.setText(String.format("%s",wp.getCheckpointItem(idx,2)));

		TextView t9 = v.findViewById(R.id.elapsed_time);
		t9.setText(String.format("%s", wp.getElapsedTimeHourStr()));

		TextView tv10 = v.findViewById(R.id.estimated_finish_time);
		tv10.setText(String.format("%s",wp.getEstimatedFinishHourStr()));

		t9 = v.findViewById(R.id.plan_speed_mph);
		t9.setText(String.format("%s", wp.getPlanSpeedStr()));

		t9 = v.findViewById(R.id.max_speed_mph);
		t9.setText(String.format("%1.1f", wp.getMaxSpeed()));

	    tv10 = v.findViewById(R.id.bearing_err);
	    tv10.setText(String.format("%1.0f",wp.getBearingError()));

		graphicsRefresh();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		boolean ret = true;
		int idx = item.getItemId();
	    switch (idx)
	    {
	        case 0:
				wp.ResetStatistics();
	        	break;
	        case 1:
				((ActivityMain)Objects.requireNonNull(getActivity())).toggleChannelAudioWarning();
				break;
			case 2:
				((ActivityMain)Objects.requireNonNull(getActivity())).toggleAudioStatus();
				break;
	        case 3:
	        	globals.settings.enable_high_contrast_color = !globals.settings.enable_high_contrast_color;
	        	break;
	        default:
	            ret = super.onOptionsItemSelected(item);
	    }
    	update();
        return ret;
    }

}
