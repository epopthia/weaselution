package com.MR340ProPaddler;

class ClassLogData
{
	public double lat_rad;
	double lon_rad;
	float elapsed_time_hr;
	float speed_mph;
	float track_mph;
	public float rivermile;
	float totalmile;
	float avg_speed_mph;
	float avg_track_mph;
	
	static final int log_time_col = 0;
	static final int log_speed_col = 1; 	// for history buffer
	static final int log_track_col = 2;
	static final int log_avg_speed_col = 3;
	static final int log_avg_track_col = 4;
	static final int log_rivermile_col = 5;
	static final int log_totalmile_col = 6;
	static final int log_lat_col = 7;
	static final int log_lon_col = 8;
	
	
	ClassLogData()
	{
		elapsed_time_hr = (float) 0.0;
		rivermile = (float) 0.0;
		totalmile = (float) 0.0;
		lat_rad = 0.0;
		lon_rad = 0.0;
		speed_mph = (float) 0.0;
		track_mph = (float) 0.0;
		avg_speed_mph = (float) 0.0;
		avg_track_mph = (float) 0.0;
	}
}
