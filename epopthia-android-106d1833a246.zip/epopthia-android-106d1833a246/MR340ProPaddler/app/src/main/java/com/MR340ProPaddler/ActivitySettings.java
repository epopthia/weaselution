package com.MR340ProPaddler;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.ParseException;
import java.util.ArrayList;


public class ActivitySettings extends Activity
{

	//Button raceowl_btn;
	private Context mContext;
	private boolean reset_planner;

	private Globals globals;
	private RaceOwlClient raceowl;


	private Spinner race_spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		mContext = this;

		globals = Globals.getInstance();
		raceowl = RaceOwlClient.getInstance();

		setContentView(R.layout.activity_settings);

		reset_planner = false;

		Button settings_button_ok = this.findViewById(R.id.settings_button_ok);
		settings_button_ok.setOnClickListener(v -> setResults());

		Button settingsForceRaceUpdate = this.findViewById(R.id.forceRaceOwlRaceUpdate_button);
		settingsForceRaceUpdate.setOnClickListener(v -> raceowl.updateRaces());


		Button planning_btn = this.findViewById(R.id.reset_planner_button);

		planning_btn.setOnClickListener(v -> {

			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage("Apply rest times. This will remove any fine adjustments to rest time. Are you sure?").setPositiveButton("Yes", dialogResetPlannerClickListener)
					.setNegativeButton("No", dialogResetPlannerClickListener).show();

		});

		Button reset_btn = this.findViewById(R.id.restore_defaults_button);
		reset_btn.setOnClickListener(v -> {

			AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
			builder.setMessage("Restore default globals. Are you sure?").setPositiveButton("Yes", dialogRestoreDefaultsClickListener)
					.setNegativeButton("No", dialogRestoreDefaultsClickListener).show();

		});

		race_spinner = this.findViewById(R.id.raceowl_races);
		race_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> arg0, View v, int position, long id) {
				raceowl.getRaceEventID(race_spinner.getSelectedItemPosition());
			}
			public void onNothingSelected(AdapterView<?> arg0) {
				Toast.makeText(mContext, "no race selected", Toast.LENGTH_LONG).show();
			}
		});


		Button set_date_time = this.findViewById(R.id.start_date_time_button);
		set_date_time.setOnClickListener(v -> DateTimeDialog(mContext));

		//crosstrack_warning
		SeekBar seekBar_crosstrack_warning = this.findViewById(R.id.seekbar_crosstrack_warning);
		seekBar_crosstrack_warning.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = progress* globals.seekbar_crosstrack_warning_scale + globals.seekbar_crosstrack_warning_offset;
				TextView tx = findViewById(R.id.crosstrack_warning);
				if (val>0)
				{
					tx.setText(String.format(globals.seekbar_crosstrack_warning_format, val));
				}
				else
				{
					tx.setText(globals.seekbar_crosstrack_warning_disabled);
				}
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//m_boat_scale
		SeekBar seekBar_m_boat_scale = this.findViewById(R.id.seekbar_m_boat_scale);
		seekBar_m_boat_scale.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = progress* globals.seekbar_m_boat_scale_scale + globals.seekbar_m_boat_scale_offset;
				TextView tx = findViewById(R.id.m_boat_scale);
				tx.setText(String.format(globals.seekbar_m_boat_scale_format, val));
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//seekbar_base_line_width
		SeekBar seekBar_line_width = this.findViewById(R.id.seekbar_base_line_width);
		seekBar_line_width.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = (progress* globals.seekbar_base_line_width_scale + globals.seekbar_base_line_width_offset);
				TextView tx = findViewById(R.id.base_line_width);
				tx.setText(String.format(globals.seekbar_base_line_width_format,val));
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//seekbar_audio_status_min
		SeekBar seekBar_audio_status_min = this.findViewById(R.id.seekbar_audio_status_min);
		seekBar_audio_status_min.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = (progress* globals.seekbar_audio_status_min_scale + globals.seekbar_audio_status_min_offset);
				TextView tx = findViewById(R.id.audio_status_min);
				tx.setText(String.format(globals.seekbar_audio_status_min_format, val));
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//seekbar_gps_update_rate
		SeekBar seekBar_gps_update_rate = this.findViewById(R.id.seekbar_gps_update_rate);
		seekBar_gps_update_rate.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = (progress* globals.seekbar_gps_update_rate_scale + globals.seekbar_gps_update_rate_offset);
				TextView tx = findViewById(R.id.gps_update_rate);

				int val_idx = (int) val;
				if (val_idx< globals.seekbar_gps_update_rate_values.length) {
					tx.setText(String.format(globals.seekbar_gps_update_rate_format, (float) globals.seekbar_gps_update_rate_values[val_idx]));
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//seekbar_gps_nav_update_rate
		SeekBar seekBar_gps_nav_update_rate = this.findViewById(R.id.seekbar_gps_nav_update_rate);
		seekBar_gps_nav_update_rate.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = (progress* globals.seekbar_gps_update_rate_scale + globals.seekbar_gps_update_rate_offset);
				TextView tx = findViewById(R.id.gps_nav_update_rate);

				int val_idx = (int) val;
				if (val_idx< globals.seekbar_gps_update_rate_values.length) {
					tx.setText(String.format(globals.seekbar_gps_nav_update_rate_format, (float) globals.seekbar_gps_update_rate_values[val_idx]));
				}
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});


		//logging_delta_min
		SeekBar seekBar_logging_delta_min = this.findViewById(R.id.seekbar_logging_delta_min);
		seekBar_logging_delta_min.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = progress* globals.seekbar_logging_delta_min_scale + globals.seekbar_logging_delta_min_offset;
				TextView tx = findViewById(R.id.logging_delta_min);
				if (val>0)
				{
					tx.setText(String.format(globals.seekbar_logging_delta_min_format, val));
				}
				else
				{
					tx.setText(globals.seekbar_logging_delta_min_disabled);
				}
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});


		SeekBar seekbar_average_base_min = this.findViewById(R.id.seekbar_average_base_min);
		seekbar_average_base_min.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				//convert to actual value from progress
				float val = progress* globals.seekbar_average_base_min_scale + globals.seekbar_average_base_min_offset;
				TextView tx = findViewById(R.id.average_base_min);
				tx.setText(String.format(globals.seekbar_average_base_min_format, val));
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}

			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		Button export_log_button = this.findViewById(R.id.export_log_button);
		export_log_button.setOnClickListener(v -> {
			TextView et = findViewById(R.id.start_date);
			String fname = et.getText().toString();
			fname = fname.replace('\\', '_');
			fname = fname.replace('/', '_');
			fname = fname.replace(':', '_');
			fname = fname.replace(',', '_');

			boolean success = ExportLogFile(fname);
			if (success) {
				Toast.makeText(mContext, fname + " export success", Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(mContext, "Unable to write Log file (No log or SD card missing)", Toast.LENGTH_LONG).show();
			}
		});


		initSettings();

	}
//
//    /**
//     * Method gets triggered when Register button is clicked
//     *
//     * @param view
//     */
////    public void registerUser(View view)
////    {
////        RaceOwlRestClient raceowl = new RaceOwlRestClient();
////        raceowl.getRaces(view);
////    }


	//---------------------------------------------------------------------------
	// initSettings
	//---------------------------------------------------------------------------
	private void initSettings()
	{

//			Bundle b = myintent.getExtras();

		CheckBox cb = findViewById(R.id.sim_enable);
		cb.setChecked(globals.appState.enableSimulation);


		EditText et = findViewById(R.id.sim_speed_mph);
		et.setText(String.format("%f",globals.settings.sim_speed_mph));

		et = findViewById(R.id.sim_init_rivermile);
		et.setText(String.format("%f",globals.settings.sim_init_rivermile));

		et = findViewById(R.id.boat_number);
		et.setText(String.format("%s",globals.settings.boat_number));


		TextView tv = findViewById(R.id.start_date);
		tv.setText(globals.settings.dateToText(globals.settings.startDate));

		SeekBar sb = findViewById(R.id.seekbar_base_line_width);
		tv = findViewById(R.id.base_line_width);
		setSeekBarValue(sb, (float) (globals.settings.base_line_width), globals.seekbar_base_line_width_scale, globals.seekbar_base_line_width_offset, tv, globals.seekbar_base_line_width_format, null,false);

		sb = findViewById(R.id.seekbar_audio_status_min);
		tv = findViewById(R.id.audio_status_min);
		setSeekBarValue(sb, (float) (globals.settings.audioStatusUpdatePeriod_min), globals.seekbar_audio_status_min_scale, globals.seekbar_audio_status_min_offset, tv, globals.seekbar_audio_status_min_format, null, false);


		//gps update rate
		sb = findViewById(R.id.seekbar_gps_update_rate);
		tv = findViewById(R.id.gps_update_rate);
		int update_rate_sec = globals.settings.gpsSlowUpdatePeriod_sec;
		int update_rate_val = 0;
		for (int knx = 0; knx< globals.seekbar_gps_update_rate_values.length; knx++)
		{
			if (globals.seekbar_gps_update_rate_values[knx]==update_rate_sec)
			{
				update_rate_val = knx;
				break;
			}
		}
		String nav_update_str = String.format(globals.seekbar_gps_update_rate_format,(float) globals.seekbar_gps_update_rate_values[update_rate_val]);
		setSeekBarValue(sb, (float) (update_rate_val), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset, tv, nav_update_str, nav_update_str,true);

		//gps nav update rate
		sb = findViewById(R.id.seekbar_gps_nav_update_rate);
		tv = findViewById(R.id.gps_nav_update_rate);
		update_rate_sec = globals.settings.gpsFastUpdatePeriod_sec;
		update_rate_val = 0;
		for (int knx = 0; knx< globals.seekbar_gps_update_rate_values.length; knx++)
		{
			if (globals.seekbar_gps_update_rate_values[knx]==update_rate_sec)
			{
				update_rate_val = knx;
				break;
			}
		}
		nav_update_str = String.format(globals.seekbar_gps_nav_update_rate_format,(float) globals.seekbar_gps_update_rate_values[update_rate_val]);
		setSeekBarValue(sb, (float) (update_rate_val), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset, tv, nav_update_str, nav_update_str,true);

		// raceowl
		RaceOwlClient raceowl = RaceOwlClient.getInstance();
		ArrayList<String> races = raceowl.getRaceList();
		Spinner race_spinner = findViewById(R.id.raceowl_races);

		int RaceEventID = globals.settings.RaceEventID;
		int idx = raceowl.getRaceIdx(RaceEventID);
		UIUtil.addItemsOnSpinner(this, races, race_spinner, idx);

		int start_idx = globals.settings.startCheckpointIndex;

		ArrayList<String> checkpoints =  globals.getCheckpointNames();

		Spinner spinner1 = findViewById(R.id.spinner1);
		UIUtil.addItemsOnSpinner(this, checkpoints, spinner1, start_idx);

		int end_idx = globals.settings.finishCheckpointIndex;
		Spinner spinner2 = findViewById(R.id.spinner2);
		UIUtil.addItemsOnSpinner(this, checkpoints, spinner2, end_idx);

		cb = findViewById(R.id.location_based_speed);
		cb.setChecked(globals.settings.location_based_speed);

		cb = findViewById(R.id.freeze_zoom);
		cb.setChecked(globals.settings.freeze_zoom);

		cb = findViewById(R.id.enable_quick_settings);
		cb.setChecked(globals.settings.enableQuickSettings);

		cb = findViewById(R.id.freeze_baseline_plan);
		cb.setChecked(globals.settings.freeze_baseline_plan);

		cb = findViewById(R.id.audible_status_nowords);
		cb.setChecked(globals.settings.enableAudibleStatusNoWords);


		sb = findViewById(R.id.seekbar_logging_delta_min);
		tv = findViewById(R.id.logging_delta_min);
		float myfloat = globals.settings.logging_delta_min;
		setSeekBarValue(sb, myfloat, globals.seekbar_logging_delta_min_scale, globals.seekbar_logging_delta_min_offset, tv, globals.seekbar_logging_delta_min_format, globals.seekbar_logging_delta_min_disabled,false);

		sb = findViewById(R.id.seekbar_average_base_min);
		tv = findViewById(R.id.average_base_min);
		myfloat = (float) globals.settings.average_base_min;
		setSeekBarValue(sb, myfloat, globals.seekbar_average_base_min_scale, globals.seekbar_average_base_min_offset, tv, globals.seekbar_average_base_min_format, null,false);

		sb = findViewById(R.id.seekbar_crosstrack_warning);
		tv = findViewById(R.id.crosstrack_warning);
		myfloat = globals.settings.crosstrack_warning;
		setSeekBarValue(sb, myfloat, globals.seekbar_crosstrack_warning_scale, globals.seekbar_crosstrack_warning_offset, tv, globals.seekbar_crosstrack_warning_format, globals.seekbar_crosstrack_warning_disabled,false);

		sb = findViewById(R.id.seekbar_m_boat_scale);
		tv = findViewById(R.id.m_boat_scale);
		myfloat = globals.settings.m_boat_scale;
		setSeekBarValue(sb, myfloat, globals.seekbar_m_boat_scale_scale, globals.seekbar_m_boat_scale_offset, tv, globals.seekbar_m_boat_scale_format, null, false);


		et = findViewById(R.id.desired_finish_hr);
		et.setText(String.format("%1.2f",globals.settings.desired_finish_hr));

		et = findViewById(R.id.desired_speed_mph);
		et.setText(String.format("%1.1f",globals.settings.desired_speed_mph));

		et = findViewById(R.id.default_checkpoint_rest_hr);
		et.setText(String.format("%1.2f",globals.settings.default_checkpoint_rest_hr));

		et = findViewById(R.id.default_sleep_hr);
		et.setText(String.format("%1.1f",globals.settings.defaultSleepHr));

		idx = globals.settings.sleep1_cp_idx;
		spinner1 = findViewById(R.id.sleep1_cp_idx_dd);
		UIUtil.addItemsOnSpinnerWithNone(this, checkpoints, spinner1, idx);
		idx = globals.settings.sleep2_cp_idx;
		spinner1 = findViewById(R.id.sleep2_cp_idx_dd);
		UIUtil.addItemsOnSpinnerWithNone(this, checkpoints, spinner1, idx);
		idx = globals.settings.sleep3_cp_idx;
		spinner1 = findViewById(R.id.sleep3_cp_idx_dd);
		UIUtil.addItemsOnSpinnerWithNone(this, checkpoints, spinner1, idx);
	}



	private void setResults()
	{

		Intent resultIntent = getIntent();
		String tmpstr;
		String variable_name;

		CheckBox cb = findViewById(R.id.sim_enable);
		globals.appState.enableSimulation =  cb.isChecked();

		int val = (int) getSeekBarValue((SeekBar) findViewById(R.id.seekbar_base_line_width), globals.seekbar_base_line_width_scale, globals.seekbar_base_line_width_offset);
		globals.settings.base_line_width =  val;

		val = (int) getSeekBarValue((SeekBar) findViewById(R.id.seekbar_audio_status_min), globals.seekbar_audio_status_min_scale, globals.seekbar_audio_status_min_offset);
		globals.settings.audioStatusUpdatePeriod_min = val;

		int val_idx = (int) getSeekBarValue((SeekBar) findViewById(R.id.seekbar_gps_update_rate), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset);
		val = globals.seekbar_gps_update_rate_values[val_idx];
		globals.settings.gpsSlowUpdatePeriod_sec = val;

		val_idx = (int) getSeekBarValue((SeekBar) findViewById(R.id.seekbar_gps_nav_update_rate), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset);
		val = globals.seekbar_gps_update_rate_values[val_idx];
		globals.settings.gpsFastUpdatePeriod_sec = val;

		EditText et = findViewById(R.id.sim_speed_mph);
		variable_name = "sim_speed_mph";
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.sim_speed_mph =  Float.parseFloat(tmpstr);


		et = findViewById(R.id.sim_init_rivermile);
		variable_name = "sim_init_rivermile";
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.sim_init_rivermile =  Float.parseFloat(tmpstr);

		et = findViewById(R.id.boat_number);
		variable_name = "boat_number";
		tmpstr = et.getText().toString();
		if (VerifyInteger(tmpstr, variable_name)) globals.settings.boat_number = tmpstr;

		TextView tv = findViewById(R.id.start_date);
		//globals.settings.startDate =

		try {
			globals.settings.setStartDate(globals.settings.textToDate(tv.getText().toString()));
        } catch (ParseException e) {
            e.printStackTrace();
        }


		Spinner spinner1 = findViewById(R.id.spinner1);
		globals.settings.startCheckpointIndex = spinner1.getSelectedItemPosition();

		Spinner spinner2 = findViewById(R.id.spinner2);
		globals.settings.finishCheckpointIndex =  spinner2.getSelectedItemPosition();

		cb = findViewById(R.id.location_based_speed);
		globals.settings.location_based_speed =  cb.isChecked();

		cb = findViewById(R.id.freeze_zoom);
		globals.settings.freeze_zoom =  cb.isChecked();

		cb = findViewById(R.id.enable_quick_settings);
		globals.settings.enableQuickSettings =  cb.isChecked();

		cb = findViewById(R.id.freeze_baseline_plan);
		globals.settings.freeze_baseline_plan =  cb.isChecked();

		cb = findViewById(R.id.audible_status_nowords);
		globals.settings.enableAudibleStatusNoWords =  cb.isChecked();


		globals.settings.reset_planner =  reset_planner;


		float myfloat = getSeekBarValue((SeekBar) findViewById(R.id.seekbar_logging_delta_min), globals.seekbar_logging_delta_min_scale, globals.seekbar_logging_delta_min_offset);
		globals.settings.logging_delta_min =  myfloat;

		myfloat = getSeekBarValue((SeekBar) findViewById(R.id.seekbar_average_base_min), globals.seekbar_average_base_min_scale, globals.seekbar_average_base_min_offset);
		globals.settings.average_base_min = (int) myfloat;

		myfloat = getSeekBarValue((SeekBar) findViewById(R.id.seekbar_crosstrack_warning), globals.seekbar_crosstrack_warning_scale, globals.seekbar_crosstrack_warning_offset);
		globals.settings.crosstrack_warning  =  myfloat;

		myfloat = getSeekBarValue((SeekBar) findViewById(R.id.seekbar_m_boat_scale), globals.seekbar_m_boat_scale_scale, globals.seekbar_m_boat_scale_offset);
		globals.settings.m_boat_scale =  myfloat;

		et = findViewById(R.id.desired_finish_hr);
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.desired_finish_hr = Float.parseFloat(tmpstr);

		et = findViewById(R.id.desired_speed_mph);
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.desired_speed_mph = Float.parseFloat(tmpstr);

		et = findViewById(R.id.default_checkpoint_rest_hr);
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.default_checkpoint_rest_hr =  Float.parseFloat(tmpstr);

		et = findViewById(R.id.default_sleep_hr);
		tmpstr = et.getText().toString();
		if (VerifyNumeric(tmpstr, variable_name)) globals.settings.defaultSleepHr = Float.parseFloat(tmpstr);

		spinner1 = findViewById(R.id.sleep1_cp_idx_dd);
		globals.settings.sleep1_cp_idx =  spinner1.getSelectedItemPosition();

		spinner1 = findViewById(R.id.sleep2_cp_idx_dd);
		globals.settings.sleep2_cp_idx =  spinner1.getSelectedItemPosition();

		spinner1 = findViewById(R.id.sleep3_cp_idx_dd);
		globals.settings.sleep3_cp_idx =  spinner1.getSelectedItemPosition();

		spinner1 = findViewById(R.id.raceowl_races);
		RaceOwlClient raceowl = RaceOwlClient.getInstance();
		globals.settings.RaceEventID =  raceowl.getRaceEventID(spinner1.getSelectedItemPosition());

        setResult(Activity.RESULT_OK, resultIntent);
        finish();

	}


	// ------------------------------------------------------------------------
	//	DateTimeDialog
	// ------------------------------------------------------------------------
	private void DateTimeDialog(final Context activity)
	{

		final Dialog myDialog = new Dialog(activity);
		myDialog.setContentView(R.layout.dialog_date_time);
		myDialog.setTitle("Select start time");
		myDialog.setCancelable(true);

		Button ok_button = myDialog.findViewById(R.id.ok_button);
		ok_button.setOnClickListener(v -> {

			final TimePicker timepicker= myDialog.findViewById(R.id.timePicker1);
			final DatePicker datepicker= myDialog.findViewById(R.id.datePicker1);

			String mytime = String.format("%02d:%02d:00", timepicker.getCurrentHour(),timepicker.getCurrentMinute());
			String mydate = String.format("%04d/%02d/%02d", datepicker.getYear(),datepicker.getMonth()+1,datepicker.getDayOfMonth());

			TextView et = findViewById(R.id.start_date);
			et.setText(String.format("%s,%s", mydate, mytime));

			myDialog.dismiss();

		});

		Button cancel_button = myDialog.findViewById(R.id.cancel_button);
		cancel_button.setOnClickListener(v -> myDialog.dismiss());
		myDialog.show();
	}

	// ------------------------------------------------------------------------
	//	ExportLogFile
	// ------------------------------------------------------------------------
	private boolean ExportLogFile(String fname)
	{
		boolean ret = false;
		ClassFileIO fio = new ClassFileIO(this);

		ClassLogData[] log_items = fio.readLog(ClassFileIO.mylogfile);

		if (log_items!=null)

		{
			//save log file to a csv

			String fname1 = fname + ".csv";
			ret = fio.writeLog(fname1, log_items, "mr340pro");

			//save log file to a kml
			if (ret)
			{
				String fname2 = fname + ".kml";
				ret = fio.writeKML("mr340pro", fname2, log_items);
			}
		}
		return ret;
	}


	// ------------------------------------------------------------------------
	//	setSeekBarValue
	//	format like "base line width (%1.0f pixels)"
	// ------------------------------------------------------------------------
	private void setSeekBarValue(SeekBar seekbar, float val, float scale, float offset, TextView tx, String format, String static_string, boolean force_static_string)
	{
		int sval = (int) ((val-offset)/scale);
		seekbar.setProgress(sval);

		if (tx!=null)
		{
			if ((val<=0 && static_string!=null) || force_static_string)
			{
				tx.setText(static_string);
			}
			else
			{
				tx.setText(String.format(format , val));
			}
		}

	}

	// ------------------------------------------------------------------------
	//	getSeekBarValue
	// ------------------------------------------------------------------------
	private float getSeekBarValue(SeekBar seekbar, float scale, float offset)
	{
		return (((float) seekbar.getProgress() * scale + offset));
	}


	// ------------------------------------------------------------------------
	//	Are you sure dialog
	// ------------------------------------------------------------------------
	private final DialogInterface.OnClickListener dialogRestoreDefaultsClickListener = (dialog, which) -> {
		if (which == DialogInterface.BUTTON_POSITIVE) {
			restoreSettingsDefaults();

		}
	};

	// ------------------------------------------------------------------------
	//	Are you sure dialog
	// ------------------------------------------------------------------------
	private final DialogInterface.OnClickListener dialogResetPlannerClickListener = new DialogInterface.OnClickListener()
	{
		@Override
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
				case DialogInterface.BUTTON_POSITIVE:
					reset_planner = true;
					break;

				case DialogInterface.BUTTON_NEGATIVE:
					reset_planner = false;
					break;
			}
		}
	};

	// ------------------------------------------------------------------------
	//	isNumeric
	// ------------------------------------------------------------------------
	private boolean isNumeric(String str)
	{
		try
		{
			Double.parseDouble(str);
			return true;
		} catch (NumberFormatException ignored) {}
		return false;
	}

	// ------------------------------------------------------------------------
	//	isInteger
	// ------------------------------------------------------------------------
	private boolean isInteger(String str)
	{
		try
		{
			Integer.parseInt(str);
			return true;
		} catch (NumberFormatException ignored) {}
		return false;
	}
	// ------------------------------------------------------------------------
	//	VerifyNumeric
	// ------------------------------------------------------------------------
	private boolean VerifyNumeric(String test_str, String variable_name)
	{
		boolean ret;
		String msg;
		if (isNumeric(test_str))
		{
			ret = true;
		}
		else
		{
			msg = String.format("Input Error: %s must be a number! Please re-enter.", variable_name);
			Toast.makeText(mContext ,msg , Toast.LENGTH_LONG).show();
			ret = false;
		}
		return ret;
	}


	// ------------------------------------------------------------------------
	//	VerifyInteger
	// ------------------------------------------------------------------------
	private boolean VerifyInteger(String test_str, String variable_name)
	{
		boolean ret;
		String msg;
		if (isInteger(test_str))
		{
			ret = true;
		}
		else
		{
			msg = String.format("Input Error: %s must be an integer! Please re-enter.", variable_name);
			Toast.makeText(mContext ,msg , Toast.LENGTH_LONG).show();
			ret = false;
		}
		return ret;
	}


	//---------------------------------------------------------------------------
	// restoreSettingsDefaults
	//---------------------------------------------------------------------------
	private void restoreSettingsDefaults()
	{

		TextView tv;
		CheckBox cb;
		SeekBar sb;

		sb = findViewById(R.id.seekbar_base_line_width);
		tv = findViewById(R.id.base_line_width);
		setSeekBarValue(sb, (float) 2, globals.seekbar_base_line_width_scale, globals.seekbar_base_line_width_offset, tv, globals.seekbar_base_line_width_format, null,false);

		sb = findViewById(R.id.seekbar_audio_status_min);
		tv = findViewById(R.id.audio_status_min);
		setSeekBarValue(sb, (float) 10, globals.seekbar_audio_status_min_scale, globals.seekbar_audio_status_min_offset, tv, globals.seekbar_audio_status_min_format, null,false);

		//gps update rate
		sb = findViewById(R.id.seekbar_gps_update_rate);
		tv = findViewById(R.id.gps_update_rate);
		//new int[]{1,2,5,10,15,30,60,90,2*60,5*60,10*60};
		int update_rate_sec = 15;


		int update_rate_val = 0;
		for (int knx = 0; knx< globals.seekbar_gps_update_rate_values.length; knx++)
		{
			if (globals.seekbar_gps_update_rate_values[knx]==update_rate_sec)
			{
				update_rate_val = knx;
				break;
			}
		}
		String nav_update_str = String.format(globals.seekbar_gps_update_rate_format,(float) globals.seekbar_gps_update_rate_values[update_rate_val]);
		setSeekBarValue(sb, (float) (update_rate_val), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset, tv, nav_update_str, nav_update_str,true);

		//gps nav update rate
		sb = findViewById(R.id.seekbar_gps_nav_update_rate);
		tv = findViewById(R.id.gps_nav_update_rate);
		update_rate_sec = 2;
		update_rate_val = 0;
		for (int knx = 0; knx< globals.seekbar_gps_update_rate_values.length; knx++)
		{
			if (globals.seekbar_gps_update_rate_values[knx]==update_rate_sec)
			{
				update_rate_val = knx;
				break;
			}
		}
		nav_update_str = String.format(globals.seekbar_gps_nav_update_rate_format,(float) globals.seekbar_gps_update_rate_values[update_rate_val]);
		setSeekBarValue(sb, (float) (update_rate_val), globals.seekbar_gps_update_rate_scale, globals.seekbar_gps_update_rate_offset, tv, nav_update_str, nav_update_str,true);

		cb = findViewById(R.id.location_based_speed);
		cb.setChecked(false);

		cb = findViewById(R.id.freeze_zoom);
		cb.setChecked(false);

		cb = findViewById(R.id.enable_quick_settings);
		cb.setChecked(true);

		sb = findViewById(R.id.seekbar_logging_delta_min);
		tv = findViewById(R.id.logging_delta_min);
		float myfloat = 5;
		setSeekBarValue(sb, myfloat, globals.seekbar_logging_delta_min_scale, globals.seekbar_logging_delta_min_offset, tv, globals.seekbar_logging_delta_min_format, globals.seekbar_logging_delta_min_disabled,false);

		sb = findViewById(R.id.seekbar_average_base_min);
		tv = findViewById(R.id.average_base_min);
		myfloat = 30;
		setSeekBarValue(sb, myfloat, globals.seekbar_average_base_min_scale, globals.seekbar_average_base_min_offset, tv, globals.seekbar_average_base_min_format, null,false);

		sb = findViewById(R.id.seekbar_crosstrack_warning);
		tv = findViewById(R.id.crosstrack_warning);
		myfloat = 60;
		setSeekBarValue(sb, myfloat, globals.seekbar_crosstrack_warning_scale, globals.seekbar_crosstrack_warning_offset, tv, globals.seekbar_crosstrack_warning_format, globals.seekbar_crosstrack_warning_disabled,false);

		sb = findViewById(R.id.seekbar_m_boat_scale);
		tv = findViewById(R.id.m_boat_scale);
		myfloat = 2;
		setSeekBarValue(sb, myfloat, globals.seekbar_m_boat_scale_scale, globals.seekbar_m_boat_scale_offset, tv, globals.seekbar_m_boat_scale_format, null, false);

		//turn on crew texting
		//turn on auto checkpoint
		//globals.globals.enableAudibleStatus = true;

	}

}
