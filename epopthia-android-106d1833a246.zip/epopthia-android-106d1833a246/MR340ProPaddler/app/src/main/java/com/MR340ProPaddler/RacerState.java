package com.MR340ProPaddler;

import android.annotation.SuppressLint;

import com.MR340ProPaddler.baseclass.LatLng;
import com.MR340ProPaddler.baseclass.LatLngTime;
import com.MR340ProPaddler.baseclass.PointHistory;
import com.MR340ProPaddler.baseclass.RouteRelative;
import com.MR340ProPaddler.utility.Const;
import com.MR340ProPaddler.baseclass.GPSData;
import com.MR340ProPaddler.baseclass.LatLngRad;
import com.MR340ProPaddler.baseclass.Route;
import com.MR340ProPaddler.utility.ClassUtility;

import java.util.Date;

import static com.MR340ProPaddler.utility.Const.maxSpeedLimit_mps;
import static com.MR340ProPaddler.utility.Const.minSpeedLimit_mps;
import static java.lang.Math.floor;
import static java.lang.Math.max;
import static java.lang.Math.min;
import static java.lang.Math.sqrt;


@SuppressWarnings("WeakerAccess")
public class RacerState {


    //private class for use in storage of checkpoint data
    public static class CheckPointHistory
    {
        public final PointHistory in;
        public final PointHistory out;
        CheckPointHistory()
        {
            in = new PointHistory();
            out = new PointHistory();
        }
    }

    // information
    public int event_id;
    public String racer_id;
    // current data
    public LatLngTime ptt;          // location and time of that location fix
    public double speed_mps;
    public final double accuracy_m;

    // defined by self history
    public double avg_speed_mps;
    public double max_speed_mps;
    public double total_dist_m;
    public PathSegment own_path;
    public Date referenceDate;

    // data relative to the race route_relative
    public final RouteRelative route_relative;
    public final CheckPointHistory[] cp_history;  //history of checkpoints that have been cycled


    //constants needed for AppState update
    private static final double tauSec = 15.0 * Const.minute_to_sec; //time constant for average speed calc. allow tauSec * delta speed change per update
    public static final double checkpoint_radius_dr_rad = 300 / Const.earth_a_ft; // radius under which we are considered at a checkpoint

    //constructor
    public RacerState()
    {
        accuracy_m = 0;
        avg_speed_mps = 0.0;
        cp_history = new CheckPointHistory[0];
        event_id = -1;
        max_speed_mps = 0.0;
        ptt = new LatLngTime();
        own_path = new PathSegment(ptt);
        racer_id = "";
        route_relative = new RouteRelative();
        speed_mps = 0.0;
        total_dist_m = 0.0;
        referenceDate =  new Date();
    }

    public RacerState(LatLngRad point, double speed_mps0, Date _time, Route route, int event_id0, String racer_id0)
    {
        this();
        event_id = event_id0;
        ptt =  new LatLngTime(point.latitude_rad, point.longitude_rad, _time.getTime());
        own_path = new PathSegment(ptt);
        racer_id = racer_id0;
//        route_relative = propagateRouteProgress(this, null, route);
        speed_mps = speed_mps0;
    }

    public RacerState(LatLng point, double speed_mps, Date _time, Route route, int event_id0, String racer_id0)
    {
        this(new LatLngRad(point), speed_mps, _time, route, event_id0, racer_id0);
    }

    public RacerState(RacerState s0)
    {
        accuracy_m = s0.accuracy_m;
        avg_speed_mps = s0.avg_speed_mps;
        cp_history = new CheckPointHistory[s0.cp_history.length];
        System.arraycopy(s0.cp_history,0,cp_history,0,s0.cp_history.length);
        event_id = s0.event_id;
        max_speed_mps = s0.max_speed_mps;
        own_path = new PathSegment(s0.own_path);
        ptt = new LatLngTime(s0.ptt);
        racer_id = s0.racer_id;
        route_relative = new RouteRelative(s0.route_relative);
        speed_mps = s0.speed_mps;
        total_dist_m = s0.total_dist_m;
        referenceDate = s0.referenceDate;
    }

    //----------------------------------------------------------------------------------------------
    // RacerState
    // main constructor for RacerState.
    //----------------------------------------------------------------------------------------------
    public RacerState(GPSData loc1, RacerState s0, Route route)
    {
        this(s0);

        //information
        racer_id = s0.racer_id;
        event_id = s0.event_id;

        //current AppState
        // current position
        ptt = new LatLngTime(loc1.ptt);

        // past relative data
        own_path = new PathSegment(loc1.ptt, s0.ptt, s0.own_path);

        speed_mps = calcSpeed(s0,this, loc1);

        // average speed update
        avg_speed_mps = calcAvgSpeed(s0, this);

        max_speed_mps = calcMaxSpeed(s0, this);

        total_dist_m =  calcTotalDistance(s0, this);

        // get position relative to the route
  //      route_relative = propagateRouteProgress(this, s0, route);

        // check for any checkpoint cycling
//        cp_history = processCheckpointCycle(this, s0, route);

    }


    // ----------------------------------------------------------------------
    //  calcTotalDistance
    // ----------------------------------------------------------------------
    private static double calcTotalDistance(RacerState s0, RacerState s1)
    {
        double delta_m = sqrt(s1.own_path.deltaEast_m * s1.own_path.deltaEast_m +  s1.own_path.deltaNorth_m * s1.own_path.deltaNorth_m);
        return (s0.total_dist_m + delta_m);
    }

    //----------------------------------------------------------------------------------------------
    // calcSpeed
    //----------------------------------------------------------------------------------------------
    private static double calcSpeed(RacerState s0, RacerState s1, GPSData loc1)
    {
        double speed_mps;

        // current speed update from GPS is preferred
        if (loc1.speed_mps >= 0)
        {
            speed_mps = loc1.speed_mps;
        }
        // use the location based speed if not valid GPS based is provided
        else {
            speed_mps = s1.own_path.speedLocationBase_mps;
        }

        // limit max speed (this is typically produced when you hyperspace from one lat/lon
        // to another, ie you turned off the phone on location 1 and then back on in location 2)
        speed_mps = speed_mps < maxSpeedLimit_mps ? speed_mps : s0.speed_mps;

        return (speed_mps);
    }


    //----------------------------------------------------------------------------------------------
    // calcAvgSpeed
    //----------------------------------------------------------------------------------------------
    private static double calcAvgSpeed(RacerState s0, RacerState s1)
    {
        //retain last speed by default, overwrite if conditions warrant
        double avg_speed_mps = s0.avg_speed_mps < minSpeedLimit_mps ? s1.speed_mps : s0.avg_speed_mps;

        if (s1.own_path.deltaT_ms > 0)
        {
            double localTauSec = Math.min(Math.max(getElapsedTimeSec(s0), 10), tauSec);

            double deltat_s = s1.own_path.deltaT_ms * Const.ms_to_sec;
            double tauSecLim =  Math.max(Math.min(localTauSec, deltat_s * 2.0), 0.0);
            tauSecLim = tauSecLim/localTauSec;

            // if the speed is too slow, then we are going to assume that the racer is STOPPED and not
            // include the speed estimate in the moving average.
            if (s1.speed_mps >= minSpeedLimit_mps) {
                // speed is a moving average
                avg_speed_mps = s0.avg_speed_mps + tauSecLim * (s1.speed_mps - s0.avg_speed_mps);
            }
        }

        return (avg_speed_mps);
    }

    //----------------------------------------------------------------------------------------------
    // calcMaxSpeed
    //----------------------------------------------------------------------------------------------
    private static double calcMaxSpeed(RacerState last_state, RacerState new_state)
    {
        //retain last speed by default, overwrite if conditions warrant
        double max_speed_mps = last_state.max_speed_mps;

        if (new_state.speed_mps >= last_state.max_speed_mps)
        {
            max_speed_mps = new_state.speed_mps;

        }
        return (max_speed_mps);
    }

    // ----------------------------------------------------------------------
    //  propagateRouteProgress
    //	Given Lat/lon, last AppState and route, propagate the racer AppState
    // ----------------------------------------------------------------------
    private static RouteRelative propagateRouteProgress(RacerState s1_partial, RacerState s0, Route route)
    {
        RouteRelative s1;

        if (s0!=null) {
            s1 = new RouteRelative(s1_partial.own_path, s0, route);
        }
        else
        {
            s1 = new RouteRelative();
        }
        return s1;
    }


    // ---------------------------------------------------------------------------------------------
    // verifyAverageSpeed
    // ---------------------------------------------------------------------------------------------
    private static boolean verifyAverageSpeed(double avg_speed_mps)
    {
        boolean ret = true;

        if (avg_speed_mps < minSpeedLimit_mps)
        {
            ret = false;
        }
        else if (avg_speed_mps > maxSpeedLimit_mps)
        {
            ret = false;
        }
        return (ret);
    }


    // ---------------------------------------------------------------------------------------------
    // estimateCheckpointTime
    // return UTC time for estimate of when the racer enters or exits a checkpoint
    // NOTE: inputs are assumed defined
    // returns 0 if no estimate is possible
    // ---------------------------------------------------------------------------------------------
    private static long estimateCheckpointTime(RacerState state, long utc_limit, boolean look_forward)
    {
        long utc = 0;

        double dist_rad;

        if (verifyAverageSpeed(state.avg_speed_mps))
        {
            dist_rad = look_forward ? state.route_relative.dt_dr_pt_to_cp1_rad : -state.route_relative.dt_dr_cp0_to_pt_rad;
            double dist_m = dist_rad * Const.earth_a_m;
            long deltat_s = (long) (dist_m / state.avg_speed_mps);
            utc = state.ptt.utc_time_ms + deltat_s * Const.sec_to_ms;
            utc = look_forward && utc_limit > 0 ? min(utc,utc_limit) : max(utc,utc_limit);
        }

        return (utc);

    }


    //----------------------------------------------------------------------------------------------
    //Receive new position data
    //----------------------------------------------------------------------------------------------
    private CheckPointHistory[] processCheckpointCycle(RacerState s1, RacerState s0, Route route)
    {

        CheckPointHistory[] cps = new CheckPointHistory[0];

        // -----------------------------------------------------------------------------------------
        // Verify inputs
        // verify route exists
        if (route.cps == null)
        {
            return (cps);
        }
        // verify current racer AppState checkpoint is valid in context of the current route, return if invalid
        int s1idx = (int) floor(s1.route_relative.checkpoint_value);
        if (!(s1idx >=0 && s1idx < route.cps.length))
        {
            return (cps);
        }

        // verify last racer AppState checkpoint is valid in context of the current route, if invalid continue
        int s0idx = (int) floor(s0.route_relative.checkpoint_value);
        boolean valid_s0idx = s0idx >= 0 && s0idx < route.cps.length;


        // -----------------------------------------------------------------------------------------
        // initialize the checkpoint history
        if (s1.cp_history.length != route.cps.length)
        {
            cps = new CheckPointHistory[route.cps.length];
            for(int i=0; i < cps.length; i++){
                cps[i] = new CheckPointHistory();
            }
        }
        else {
            cps = s1.cp_history;
        }

        // -----------------------------------------------------------------------------------------
        // Find cycled checkpoints


        // -----------------------------------------------------------------------------------------
        // check for entering a checkpoint

        // at a checkpoint and entry has not been recorded
        if (s1.route_relative.at_checkpoint && (cps[s1idx].in.state == PointHistory.PointHistoryState.unknown))
        {
            cps[s1idx].in.state = PointHistory.PointHistoryState.cycled;
            long utc_in_time_ms = s1.ptt.utc_time_ms; //default to no look ahead logic
            // with prior racer AppState
            if (valid_s0idx)
            {
                long utc_limit = max(cps[s1idx].out.state != PointHistory.PointHistoryState.unknown ? cps[s1idx].out.time : 0, s1.ptt.utc_time_ms);
                long utc_time_ms = estimateCheckpointTime(s0, utc_limit, true);
                if (utc_time_ms > 0)
                {
                    utc_in_time_ms = utc_time_ms;
                }
            }
            cps[s1idx].in.time = utc_in_time_ms;
        }
        // checkpoint is between consecutive gps readings and has not been recorded
        else if (valid_s0idx && (s1idx>s0idx) && (cps[s1idx].in.state == PointHistory.PointHistoryState.unknown))
        {
            // with prior racer AppState
            long utc_limit = cps[s1idx].out.state != PointHistory.PointHistoryState.unknown ? cps[s1idx].out.time : 0;
            long utc_time_ms = estimateCheckpointTime(s0, utc_limit, true);
            if (utc_time_ms > 0)
            {
                cps[s1idx].in.state = PointHistory.PointHistoryState.cycled;
                cps[s1idx].in.time = utc_time_ms;
            }
        }

        // -----------------------------------------------------------------------------------------
        // check for exiting a checkpoint
        // checkpoint is behind us and has not been recorded
        if (!s1.route_relative.at_checkpoint && (cps[s1idx].out.state == PointHistory.PointHistoryState.unknown))
        {
            cps[s1idx].out.state = PointHistory.PointHistoryState.cycled;

            long utc_in_time_ms = s1.ptt.utc_time_ms; //default to no look back logic
            // with prior racer AppState
            long utc_limit = cps[s1idx].in.state != PointHistory.PointHistoryState.unknown ? cps[s1idx].in.time : 0;
            long utc_time_ms = estimateCheckpointTime(s1, utc_limit, false);
            if (utc_time_ms > 0)
            {
                utc_in_time_ms = utc_time_ms;
            }
            cps[s1idx].out.time = utc_in_time_ms;
        }

        return (cps);

    }


    // ----------------------------------------------------------------------
    //  updateState
    //	Update the Navigation AppState
    // ----------------------------------------------------------------------
    public static void updateState(RacerState state)
    {
        long time_ms = state.ptt.utc_time_ms;
        updateState(state.ptt.pt.latitude_rad * Const.rtd, state.ptt.pt.longitude_rad * Const.rtd,
                state.speed_mps, state.own_path.rb.bearing_rad * Const.rtd, state.accuracy_m, time_ms);
    }

    // ----------------------------------------------------------------------
    //  updateState
    //	Update the geo-position AppState of the racer
    // ----------------------------------------------------------------------
    public static RacerState updateState(double lat_deg, double lon_deg, double speed_mps, double actual_bearing_deg, double accuracy_m, long time_ms)
    {

        Globals globals = Globals.getInstance();

        Date curr_date = new Date();

        // ----------------------------------------------------------------------
        // Update the racer AppState

        //update the AppState, get the last saved or init a new location
        RacerState s0 = globals.racerStates.size() > 0 ? recentRacerState(): new RacerState( new LatLng(lat_deg, lon_deg), speed_mps, curr_date, globals.route, globals.settings.RaceEventID, globals.settings.boat_number);

        // get the current location
        GPSData loc = new GPSData(new LatLngRad(lat_deg * Const.dtr, lon_deg * Const.dtr), speed_mps, actual_bearing_deg * Const.dtr, accuracy_m, time_ms);

        // update to the new AppState
        RacerState s1 = new RacerState(loc, s0, globals.route);

        // add the racer AppState
        pushRacerState(s1);

        return(s1);


    }


    // ---------------------------------------------------------------------------------------------
    //     getRecentRacerState() - return the best estimate of the racer's AppState
    // ---------------------------------------------------------------------------------------------
    public static  RacerState recentRacerState()
    {
        Globals globals = Globals.getInstance();

        int count = globals.racerStates.size();
        RacerState ret;
        if (count > 0)
        {
            ret = new RacerState(globals.racerStates.get(count-1));
        }
        else
        {
            ret = new RacerState(new LatLngRad(), 0.0, new Date(), globals.route, globals.settings.RaceEventID, globals.settings.boat_number);
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // pushRacerState
    // ---------------------------------------------------------------------------------------------
    public static  void pushRacerState(RacerState s0)
    {
        Globals globals = Globals.getInstance();

        globals.racerStates.add(s0);
        if (globals.racerStates.size() > globals.maxRacerState)
        {
            globals.racerStates.remove(0);
        }
    }

    //---------------------------------------------------------------------------
    // resetSpeeds
    //---------------------------------------------------------------------------
    public static void resetSpeeds()
    {
        RacerState s1 = recentRacerState();
        s1.avg_speed_mps = s1.speed_mps;
        s1.max_speed_mps = s1.speed_mps;
        pushRacerState(s1);
    }

    public static void resetTimeAndMiles()
    {
        RacerState s1 = recentRacerState();
        s1.referenceDate = new Date();
        s1.total_dist_m = 0.0;
        pushRacerState(s1);
    }

    // ----------------------------------------------------------------------
    //	getElapsedTimeHourStr
    // ----------------------------------------------------------------------
    public static String getElapsedTimeHourStr(RacerState s1) {
        return (convertSecToHourStr(getElapsedTimeSec(s1)));
    }

    // ----------------------------------------------------------------------
    // convertSecToHourStr
    // ----------------------------------------------------------------------
    @SuppressLint("DefaultLocale")
    private static String convertSecToHourStr(double sec) {
        String ret;
        double sgn = ClassUtility.sign(sec);
        double hours = sec * sgn * Const.sec_to_hour;
        double hours_int = floor(hours);
        double minutes = (hours - hours_int) * 60.0;
        ret = String.format("%02.0f:%02.0f", hours_int, minutes);
        if (sgn < 0) ret = "-" + ret;
        return ret;
    }

    // ----------------------------------------------------------------------
    // getElapsedTime - return number of seconds since start time
    // ----------------------------------------------------------------------
    private static double getElapsedTimeSec(RacerState s0)
    {
        return ClassUtility.getDeltaTimeSec(s0.referenceDate, new Date());
    }


}
