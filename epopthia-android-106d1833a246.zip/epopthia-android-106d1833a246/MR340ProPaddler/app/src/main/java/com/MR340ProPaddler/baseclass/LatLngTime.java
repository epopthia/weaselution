package com.MR340ProPaddler.baseclass;



import java.util.Calendar;

@SuppressWarnings("WeakerAccess")
public class LatLngTime
{
    public final LatLngRad pt;
    public final long utc_time_ms;  //the number of milliseconds between a specified date and midnight of January 1, 1970,

    public LatLngTime()
    {
        pt = new LatLngRad();
        utc_time_ms = 0;
    }
    public LatLngTime(double lat_rad, double lng_rad, long utc_time1_ms)
    {
        pt = new LatLngRad(lat_rad,lng_rad);
        utc_time_ms = utc_time1_ms;
    }
    public LatLngTime(LatLng pt0)
    {
        this(new LatLngRad(pt0));
    }

    public LatLngTime(LatLngRad pt0) {

        pt = new LatLngRad(pt0);
        Calendar c = Calendar.getInstance();
        int utcOffset = c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET);
        utc_time_ms = c.getTimeInMillis() + utcOffset;
    }

    public LatLngTime(LatLngRad pt0, long pt0_time_ms) {

        pt = new LatLngRad(pt0);
        utc_time_ms = pt0_time_ms;
    }

    public LatLngTime(LatLngTime pt0) {
        pt = new LatLngRad(pt0.pt);
        utc_time_ms = pt0.utc_time_ms;
    }
}
