package com.MR340ProPaddler.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CheckpointEtaAdapter extends ArrayAdapter<String>
{
	private int mSelected;

	public CheckpointEtaAdapter(Context context, ArrayList<String> listarray, int selected)
	{
		super(context, android.R.layout.simple_list_item_1, android.R.id.text1, listarray);
		if (selected>(listarray.size()-1))
		{
			selected = 0;
		}
		mSelected = selected;
	}

	@NonNull
	@Override
	public View getView(int position, View convertView, @NonNull ViewGroup parent)
	{
		TextView tv;
		tv = (TextView) super.getView(position, convertView, parent);

		if (position!= mSelected)
		{
			tv.setBackgroundColor(Color.BLACK);
		}
		else
		{
			tv.setBackgroundColor(Color.BLUE);
		}
		tv.setTextColor(Color.WHITE);
		tv.setTypeface(Typeface.MONOSPACE);
		tv.setTextSize(20f);

		return tv;
	}

	public void updateSelected(int selected)
	{
		mSelected = selected;
	}
}
   
