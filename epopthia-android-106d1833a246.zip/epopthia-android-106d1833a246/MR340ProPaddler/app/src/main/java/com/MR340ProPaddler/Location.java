package com.MR340ProPaddler;

import android.util.Log;

import com.MR340ProPaddler.baseclass.LatLng;
import com.MR340ProPaddler.baseclass.LatLngTime;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;

import java.util.ArrayList;
import java.util.Date;

public class Location {

    final double AvgSpeed_mph;
    public final LatLngTime llt;
    Date lastAttemptToSend;
    int MessageID;
    private boolean acknowledged;

    Location(double Lat_deg, double Lon_deg)
    {
        llt = new LatLngTime(new LatLng(Lat_deg, Lon_deg));
        AvgSpeed_mph = 0.0;
        MessageID = -1;
        lastAttemptToSend = ClassUtility.getDate(-100 * Const.hour_to_ms); //set the last send far enough in the past to be out of the way
        acknowledged = false;
    }

    private Location(RacerState rs0)
    {
        llt = new LatLngTime(rs0.ptt);
        AvgSpeed_mph = rs0.avg_speed_mps * Const.mps_to_mph;
        MessageID = -1;
        lastAttemptToSend = ClassUtility.getDate(-100 * Const.hour_to_ms); //set the last send far enough in the past to be out of the way
        acknowledged = false;
    }


    // ---------------------------------------------------------------------------------------------
    // isValidLocation
    // ---------------------------------------------------------------------------------------------
    private static boolean isValidLocation(Location loc)
    {
        boolean retcode = !(Math.abs(loc.llt.pt.latitude_rad) < Const.epsilon);

        if (retcode && Math.abs(loc.llt.pt.longitude_rad) < Const.epsilon)
        {
            retcode = false;
        }
        return(retcode);
    }


    // ---------------------------------------------------------------------------------------------
    // addLocation (locations are sent to RaceOwl
    // ---------------------------------------------------------------------------------------------
    public static boolean addLocation(ArrayList<Location> locs0, RacerState racerState) {
        boolean success = false;
        if (racerState != null) {
            Location item = new Location(racerState);
            if (Location.isValidLocation(item)) {
                item.MessageID = locs0.size();
                locs0.add(item);
                Log.d("MR340ProPaddler", String.format("Location added. MessageID = %s", item.MessageID));
                success = true;
            }
        }
        return (success);
    }
    // ---------------------------------------------------------------------------------------------
    // getLocationsWaitingForSend
    // ---------------------------------------------------------------------------------------------
    public static int getLocationsWaitingForSendCount(ArrayList<Location> locs0)
    {
        int count = 0;
        for (Location loc : locs0) {
            if (!loc.acknowledged) {
                count++;
            }
        }
        return (count);
    }

    // ---------------------------------------------------------------------------------------------
    // getFirstLocationsForSend
    // ---------------------------------------------------------------------------------------------
    static Location getFirstLocationsForSend(ArrayList<Location> locs0)
    {
        for (Location loc : locs0) {
            if (!loc.acknowledged) {
                return loc;
            }
        }
        return(null);
    }
    // ---------------------------------------------------------------------------------------------
    // setLocationAcknowledged
    // ---------------------------------------------------------------------------------------------
    static void setLocationAcknowledged(ArrayList<Location> locs0, int id)
    {
        if (id >=0 && id < locs0.size())
        {
            Location tmp = locs0.get(id);
            tmp.acknowledged = true;
            locs0.set(id, tmp);
        }
    }
}
