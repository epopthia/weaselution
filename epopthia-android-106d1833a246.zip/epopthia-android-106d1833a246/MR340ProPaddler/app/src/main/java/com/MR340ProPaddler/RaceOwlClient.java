package com.MR340ProPaddler;

//import android.annotation.SuppressLint;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.ParseException;
import android.util.Log;

import com.MR340ProPaddler.baseclass.CheckPoint;
import com.MR340ProPaddler.baseclass.CheckPointCycle;
import com.MR340ProPaddler.baseclass.LatLngRad;
import com.MR340ProPaddler.baseclass.PointHistory;
import com.MR340ProPaddler.baseclass.RouteRelative;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

import static com.MR340ProPaddler.RaceOwlClient.TrackingState.DISABLED;
import static com.MR340ProPaddler.baseclass.CheckPointCycle.CheckPointCycleStatus.acknowledged;
import static com.MR340ProPaddler.baseclass.CheckPointCycle.CheckPointCycleStatus.pending;
import static com.MR340ProPaddler.baseclass.CheckPointCycle.CheckPointCycleStatus.rejected;
import static com.MR340ProPaddler.baseclass.CheckPointCycle.CheckPointCycleStatus.sent;
import static com.MR340ProPaddler.utility.ClassUtility.parseRaceOwlTime;

// --------------------------------------------------
// Created by sm403c on 2/21/2015.
// --------------------------------------------------
public class RaceOwlClient {

    // singleton implementation
    private static RaceOwlClient objRaceOwlRestClient;

    // list of all sent checkpoints
    private final ArrayList<RaceStandings> standings = new ArrayList<>();

    // Create the hash map on the beginning
    private final WeakHashMap<String, Integer> standings_lookup = new WeakHashMap<>();

    //private final ArrayList<Route> racetracks = new ArrayList<>();

    private final Globals globals;

    private final WayPointMission wp;

    //  private int loc_messageID;  //used to identify what positions have been updated to RaceOwl

    boolean isUpdateRaces;

    // update location every X minutes
    public final float locationUpdatePeriod_min = (float) 5;

    // send queue check
    final float data_send_delta_min = (float) 0.5;


    // ---------------------------------------------------------------------------------------------
    // getInstance
    // ---------------------------------------------------------------------------------------------
    public static synchronized RaceOwlClient getInstance()
    {
        if (objRaceOwlRestClient == null) {
            objRaceOwlRestClient = new RaceOwlClient();
        }
        return objRaceOwlRestClient;
    }

    // ---------------------------------------------------------------------------------------------
    // RaceOwlRestClient constructor
    // ---------------------------------------------------------------------------------------------
    private RaceOwlClient()
    {
        WeakHashMap<String, RaceStandings> standings = new WeakHashMap<>();

        // net message count
        net_message_count = 0;

        // get a instance of globals
        globals = Globals.getInstance();

        // get a instance of waypoint mission
        wp = WayPointMission.getInstance();

        // restore races, checkpoints, and divisions - race choices are restored from stored strings
        // we need to avoid an unintentional reset during a race
        verifyEventDataSync();

        // update races from RaceOwl
        updateRaces();

        // update minimum version
        min_version = "";
        version_invalid = false;
        version_state = 0;  // try min version request

        getMinMobileVersion();

        // set flag to trigger gui to refresh races
        isUpdateRaces = true;
    }


    static class ApiCommControl{
        Boolean pending;
        final Date next_send_enable_date;

        @SuppressWarnings("SameParameterValue")
        ApiCommControl(int delta_ms)
        {
            pending = true;
            next_send_enable_date = ClassUtility.getDate(delta_ms);
        }
        Boolean isSendDisabled()
        {
            boolean ret = pending && ClassUtility.getDate().before(next_send_enable_date);
            return (ret);
        }
    }

    //TrackingState track_state;

    private String statusMessage;

    private String min_version;
    private long net_message_count;

    private Boolean version_invalid;
    private int version_state;

    //public boolean TRACKING;

    // update location every X minutes
    final float deltaLocationTrackingMin = (float) 5;

    // send queue check
    final float deltaStateUpdateMin = 5 * (float) Const.sec_to_min;



    public enum TrackingState
    {
        DISABLED,               // initial appState - cannot be changed except by restart
        STOPPED,                // race is valid and this is a tracked device (not TRACKING here but able to if user selects)
        TRACKING_OFFLINE,       // device is being tracked but no network
        TRACKING,               // device is being tracked
        REJECT,                 // device is tracked, but raceowl rejected the location
        NETERROR               // device is tracked, but an unknown error occur
    }


    static class RaceOwlResponse{
        Boolean RaceOwlResponse;
        Boolean Success;
        int MessageID;
        String Response;
    }

    static class RaceDivisions
    {
        String DivisionName;
        int DivisionID;
        String StartTime;

        static RaceDivisions getDivision(List<RaceDivisions> div_list, int id)
        {
            RaceDivisions ret = null;
            for(RaceDivisions div: div_list)
            {
                if (div.DivisionID == id)
                {
                    ret = div;
                    break;
                }
            }
            return (ret);
        }
    }

    public static class RaceStandings
    {
        // from raceowl API
        String BoatNumber;
        final LatLngRad pt;
        Date LocationTime;
        int CheckPoint;
        String CheckPointState;
        Date CheckPointTime;
        int DivisionID;
        int PlaceDivision;
        int PlaceOverall;
        float AvgSpeed_mph;

        // local class fields
        Date last_update_time;
        float perc_complete;

        RaceStandings()
        {
            pt = new LatLngRad();
        }
    }


    // ---------------------------------------------------------------------------------------------
    // getRaceEventName
    // ---------------------------------------------------------------------------------------------
    public String getRaceEventName(int eventid)
    {
        String ret = "";
        for (int inx = 0; inx< globals.raceowlRaceList.size(); inx++)
        {
            RaceOwlAPI.RaceEvent item = globals.raceowlRaceList.get(inx);
            if (eventid == item.RaceEventID)
            {
                ret = item.RaceName;
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceEventIdByName
    // ---------------------------------------------------------------------------------------------
    private int getRaceEventIdByName(String racecode)
    {
        int ret = -1;
        for (int inx = 0; inx< globals.raceowlRaceList.size(); inx++)
        {
            RaceOwlAPI.RaceEvent item = globals.raceowlRaceList.get(inx);
            //String race_str = getRaceNameWithDates(item);
            if (racecode.equals(item.RaceCode))
            {
                ret = item.RaceEventID;
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // verifyEventDataSync
    // ---------------------------------------------------------------------------------------------
    private void verifyEventDataSync()
    {

        if (globals.settings.division_RaceEventID != globals.settings.RaceEventID)
        {
            getDivisions(globals.settings.RaceEventID);
        }
    }


    private ApiCommControl updateRacesControl = null;

    // ---------------------------------------------------------------------------------------------
    // updateRaces
    // http://v3.raceowl.com/api/RaceEvents/?OldEventFilter=12/01/2015
    // ---------------------------------------------------------------------------------------------
    void updateRaces() {


        if (!globals.appState.isOnline) return;

        globals.appState.racesInitializing = true;

        // send control, don't allow multiple requests for the same information until timeout
        if (updateRacesControl != null && updateRacesControl.isSendDisabled()) return;  //request is pending and has not timed out
        updateRacesControl = new ApiCommControl(10 * Const.sec_to_ms);

        //form request string
        String url = Const.RaceEventUrl + "/api/RaceEvents" + "?OldEventFilter=" + ClassUtility.today(-30);

        net_message_count++;

        Log.d(globals.appState.appName, String.format("RaceEvents: msg=%d", net_message_count ));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, null, new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {

                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                parseRaceEvents(response_str);

                // save the update for off-line
                globals.settings.lastRaceUpdateDate = ClassUtility.getDate();

                globals.appState.racesInitialized = true;

                // update the TRACKING appState (this will verify validity)
                setTrackingState(globals.settings.trackingState);

                // trigger a gui update
                isUpdateRaces = true;

                globals.messages.add("Update races success");

                if (updateRacesControl != null) updateRacesControl.pending = false;
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                // unable to get valid response from race owl, restore any saved races
                verifyEventDataSync();
                globals.appState.racesInitializing = false;

                globals.messages.add("RaceOwl update failure - restored previous races");
            }
        });
    }



    // ---------------------------------------------------------------------------------------------
    // upsertRaceEvent
    // ---------------------------------------------------------------------------------------------
    private void upsertRaceEvent(RaceOwlAPI.RaceEvent RaceEvent)
    {
        if (RaceEvent.RaceEventID > 0) {
            //does the event exist in the list already?
            int idx = getRaceIdx(RaceEvent.RaceCode);
            if (idx < 0) {
                //add the event
                globals.raceowlRaceList.add(RaceEvent);
            } else {
                globals.raceowlRaceList.set(idx, RaceEvent);
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // parseRaceEvents
    // ---------------------------------------------------------------------------------------------
    private void parseRaceEvents(String json_response) {
        // clear the race list
        globals.raceowlRaceList.clear();

        // add non-query races (eg none)
        addStandardRaceChoices();

        try {
            JSONArray items = new JSONArray(json_response);
            for (int i = 0; i < items.length(); i++) {
                RaceOwlAPI.RaceEvent race = new RaceOwlAPI.RaceEvent();

                JSONObject item = items.getJSONObject(i);

                race.RaceName = item.getString("RaceName");
                race.RaceEventID = item.getInt("RaceEventID");
                race.CheckpointTextNumber = item.getString("CheckpointTextNumber");
                race.LocationTextNumber = item.getString("LocationTextNumber");
                race.RaceEventDesc = item.getString("RaceEventDesc");
                race.RaceCode = item.getString("RaceCode");
                race.StartDate = item.getString("StartDate");  //raceowl time
                race.EndDate = item.getString("EndDate");    //raceowl time
                race.RaceEventToken = item.getString("RaceEventToken");
                race.RaceID = item.getInt("RaceID");
                race.IsMiles = item.getBoolean("IsMiles");

                // add the item to the array of globals.raceowlRaceList (IF THIS IS A 340 race!)
                if (race.RaceCode.toLowerCase().contains("340")) {
                    upsertRaceEvent(race);
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    // ---------------------------------------------------------------------------------------------
    // getCurrentRaceEventID
    // ---------------------------------------------------------------------------------------------
    int getCurrentRaceEventID()
    {
        return (globals.settings.RaceEventID);
    }


    // ---------------------------------------------------------------------------------------------
    // getRaceList
    // ---------------------------------------------------------------------------------------------
    ArrayList<String> getRaceList() {
        //make sure that Lat and lon are correct length
        ArrayList<String> lines = new ArrayList<>();
        String race_str;
        for (int inx = 0; inx < globals.raceowlRaceList.size(); inx++) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(inx);
            race_str = getRaceNameWithDates(race);
            lines.add(race_str);
        }
        return (lines);
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceNameWithDates
    // ---------------------------------------------------------------------------------------------
    private String getRaceNameWithDates(RaceOwlAPI.RaceEvent race)
    {
        String race_str;
        if (race.StartDate.length() > 0) {
            String[] toks = race.StartDate.split("T");
            race_str = race.RaceCode + ":" + toks[0] + "(" + race.RaceName + ")";
        } else {
            race_str = race.RaceCode;
        }

        return (race_str);

    }

    // ---------------------------------------------------------------------------------------------
    // getRaceCount
    public int getRaceCount()
    {
        return (globals.raceowlRaceList.size());
    }


    // ---------------------------------------------------------------------------------------------
    // get340RaceIdx
    // ---------------------------------------------------------------------------------------------
    int get340RaceIdx()
    {
        int idx = 0;
        int inx;
        // search races
        for (inx = 0; inx < globals.raceowlRaceList.size(); inx++) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(inx);
            if (race.RaceCode.contains("MR340")) {
                idx = inx;
                break;
            }
        }
        if (inx >= globals.raceowlRaceList.size()) {
            idx = -1;
        }
        return (idx);
    }
    // ---------------------------------------------------------------------------------------------
    // getRaceIdx
    // search the race events and return the index of if the array item having a matching raceeventid
    // note: a return of index < 0 (indicates that no matching races have been found
    // ---------------------------------------------------------------------------------------------
    int getRaceIdx(int RaceEventID) {
        int idx = 0;
        int inx;
        // search races
        for (inx = 0; inx < globals.raceowlRaceList.size(); inx++) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(inx);
            if (race.RaceEventID == RaceEventID) {
                idx = inx;
                break;
            }
        }
        if (inx >= globals.raceowlRaceList.size()) {
            idx = -1;
        }

        return (idx);
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceIdx
    // search the race events and return the index of if the array item having a matching raceeventid
    // note: a return of index < 0 (indicates that no matching races have been found
    // ---------------------------------------------------------------------------------------------
    private int getRaceIdx(String RaceCode) {
        int idx = 0;
        int inx;
        // search races
        for (inx = 0; inx < globals.raceowlRaceList.size(); inx++) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(inx);
            if (race.RaceCode.equals(RaceCode)) {
                idx = inx;
                break;
            }
        }
        if (inx >= globals.raceowlRaceList.size()) {
            idx = -1;
        }

        return (idx);
    }


    // ---------------------------------------------------------------------------------------------
    // getRaceItem
    // search the race events and return the index of if the array item having a matching raceeventid
    // ---------------------------------------------------------------------------------------------
    public RaceOwlAPI.RaceEvent getRaceItem(int RaceEventID) {
        RaceOwlAPI.RaceEvent retrace = null;

        // search races
        for (int inx = 0; inx < globals.raceowlRaceList.size(); inx++) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(inx);
            if (race.RaceEventID == RaceEventID) {
                retrace = race;
                break;
            }
        }

        if (retrace == null && globals.raceowlRaceList.size() > 0)  // no race found, the race stored race is no longer valid, so pick the first from the list (none)
        {
            RaceOwlAPI.RaceEvent race  = globals.raceowlRaceList.get(0);
            setRaceEvent(race.RaceEventID);
            retrace = race;
        }
        return (retrace);
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceEventID
    // ---------------------------------------------------------------------------------------------
    int getRaceEventID(int idx) {
        int RaceEventID = -1;
        // return the raceeventid given a list index
        if (idx < globals.raceowlRaceList.size() && idx >= 0)
        {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(idx);
            RaceEventID = race.RaceEventID;
        }
        return (RaceEventID);
    }

    // ---------------------------------------------------------------------------------------------
    // setRaceEvent
    // ---------------------------------------------------------------------------------------------
    private void setRaceEvent(String racecode)
    {
        setRaceEvent(getRaceEventIdByName(racecode));
    }

    // ---------------------------------------------------------------------------------------------
    // setRaceEvent
    // ---------------------------------------------------------------------------------------------
    void setRaceEvent(int raceeventid)
    {

        boolean reset = globals.settings.RaceEventID != raceeventid && raceeventid != 0; //none race will not reset

        globals.settings.RaceEventID = raceeventid;

        boolean raceEventValid = isRaceEventValid(globals.settings.RaceEventID, false);

        // clear tracks/state on a new race
        if (raceEventValid && reset) {
            clearLocations();
            globals.racerStates.clear();

        }

        // stop tracking if we are reset or invalid
        if (!raceEventValid || reset)
        {
            setTrackingState(RaceOwlClient.TrackingState.STOPPED);
        }

        //checkpoints
        if (raceEventValid && (reset || globals.route.cps.length <= 0)) {
            globals.clearCheckpointsLog();
        }

        if (raceEventValid && (reset || globals.divisions.size() <= 0)) {
            getDivisions(globals.settings.RaceEventID); // update divisions
        }

        // send broadcast so GUI can update to new selection
        Intent intent = new Intent(Const.RACEOWL_RACE_SELECT);
        globals.appState.ctx.sendBroadcast(intent);
    }


    // ---------------------------------------------------------------------------------------------
    // isValidRaceUpdate
    // ---------------------------------------------------------------------------------------------
    boolean isValidRaceUpdate(Date lastUpdate)
    {
        boolean ret = false;
        //verify inputs
        if (lastUpdate != null && globals.raceowlRaceList.size() > 0) {
            //is within a week
            Date currDate;
            currDate = new Date();

            // 604800000 => 7 days
            Date minDate = new Date(currDate.getTime() - 604800000L);
            if (lastUpdate.after(minDate)) {
                ret = true;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // isRaceEventRacing
    // return TRUE if the selected race event is currently valid
    // ---------------------------------------------------------------------------------------------
    boolean isRaceEventRacing(int RaceEventID) {

        boolean isRacing = isRaceEventValid(RaceEventID, true);

        if (isRacing)
        {
            // lookup the index based on the selected race idx
            int idx = getRaceIdx(RaceEventID);

            // get the race
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(idx);

            if (!race.RaceCode.equals("none")) {   // allow none
                Date startDate = parseRaceOwlTime(race.StartDate);
                Date endDate = parseRaceOwlTime(race.EndDate);
                Date now = new Date();
                if (!(now.after(startDate) && now.before((endDate)))) {
                    isRacing = false;
                }
            }
        }
        return (isRacing);
    }


    // ---------------------------------------------------------------------------------------------
    // isRaceEventValid
    // return TRUE if the selected race event is currently valid
    // ---------------------------------------------------------------------------------------------
    public boolean isRaceEventValid(int RaceEventID, boolean allowNone) {
        boolean retcode = true;

        // lookup the index based on the selected race idx
        int idx = getRaceIdx(RaceEventID);

        // if there is no race that matches the raceevent
        if (idx < 0) {
            return (false);  // jump out early if no matching
        }

        // get the race
        RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(idx);

        // mark not valid if none is selected
        if (race.RaceCode.equals("none") && !allowNone)
        {
            retcode = false;
        }

        return (retcode);
    }

    // ---------------------------------------------------------------------------------------------
    // ItemComparator
    // compare item
    // ---------------------------------------------------------------------------------------------
    private static class ItemComparator implements Comparator<RaceOwlAPI.RaceEvent> {
        public int compare(RaceOwlAPI.RaceEvent left, RaceOwlAPI.RaceEvent right) {
            return left.StartDate.compareTo(right.StartDate);
        }
    }


    // ---------------------------------------------------------------------------------------------
    // sendLocation
    // ---------------------------------------------------------------------------------------------
    public void sendLocation() {

        if (globals.appState.isOnline) {
            Location loc =  Location.getFirstLocationsForSend(globals.locations);
            if (loc != null)
            {
                if (ClassUtility.getSecondsFromDate(loc.lastAttemptToSend) > 15) {

                    loc.lastAttemptToSend = ClassUtility.getDate();
                    globals.locations.set(loc.MessageID, loc);
                    updatePositionToRaceowl(loc);
                }
            }
        }
        else
        {
            setTrackingState(RaceOwlClient.TrackingState.TRACKING_OFFLINE);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // sendCheckpoint
    // ---------------------------------------------------------------------------------------------
    public void sendCheckpoint()
    {
        if (CheckPointCycle.getCheckPointCyclesWaitingForSendCount(globals.checkPointCycles) > 0) // there is something to send
        {
            //get top location from list
            CheckPointCycle item = CheckPointCycle.getFirstCheckPointCyclesForSend(globals.checkPointCycles);
            if (ClassUtility.getSecondsFromDate(item != null ? item.lastAttemptToSend : null) > 15)
            {
                assert item != null;
                if (item.MessageID >=0 && item.MessageID < globals.checkPointCycles.size()) {
                    Objects.requireNonNull(item).lastAttemptToSend = ClassUtility.getDate();
                    globals.checkPointCycles.set(item.MessageID, item);
                    updateCheckpointToRaceowl(item);
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // getCheckpointIndexByName
    // ---------------------------------------------------------------------------------------------
    private int getCheckpointIndexByName(String checkpoint)
    {
        int ret = -1;
        for (int inx = 0; inx<globals.route.cps.length; inx++)
        {
            if (globals.route.cps[inx].Name.equalsIgnoreCase(checkpoint))
            {
                ret = inx;
                break;
            }
        }

        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getCheckpointIndexByMessageID
    // ---------------------------------------------------------------------------------------------
    private int getCheckpointIndexByMessageID(int messageID) {
        int ret =-1;
        for (CheckPointCycle _item : globals.checkPointCycles)
        {
            if (_item.MessageID == messageID)
            {
                ret = globals.checkPointCycles.indexOf(_item);
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // makeCheckPointCycle
    // ---------------------------------------------------------------------------------------------
    private CheckPointCycle makeCheckPointCycle(String boat, String checkpoint, Date cp_time, String status)
    {
        CheckPointCycle cpc = new CheckPointCycle();
        cpc.Authorization = globals.settings.authorizationCode;
        cpc.BoatNumber = boat;
        cpc.Checkpoint = checkpoint;
        cpc.locationTime = cp_time;
        cpc.TextLocationTime = ClassUtility.getRaceOwlTextTime(cp_time);
        cpc.NetLocationTime  = ClassUtility.getRaceOwlNetTime(cp_time);
        cpc.RaceEventID = globals.settings.RaceEventID;
        cpc.Status = status;
        cpc.raceowl_status = pending;
        cpc.checkpoint_index = getCheckpointIndexByName(checkpoint);
        return(cpc);
    }

    // ---------------------------------------------------------------------------------------------
    // updatePositionToRaceowl - note, function assumes we are online
    // ---------------------------------------------------------------------------------------------
    private void updatePositionToRaceowl(Location loc)
    {
        //format the request
        RaceOwlAPI.RaceEvent race = getRaceItem(globals.settings.RaceEventID);
        String url = Const.RaceEventUrl + "/api/RaceTeamLocation1";

        RaceOwlAPI.RaceTeamLocationRequest request = new RaceOwlAPI.RaceTeamLocationRequest();

        request.BoatNumber = globals.settings.boat_number;
        request.RaceEventID = race.RaceEventID;
        request.AvgSpeed = loc.AvgSpeed_mph;
        request.Latitude =  loc.llt.pt.latitude_rad * Const.rtd;
        request.Longitude = loc.llt.pt.longitude_rad * Const.rtd;
        request.LocationTime = ClassUtility.getRaceOwlNetTime(loc.llt.utc_time_ms);
        request.Phone = globals.settings.phone_number;
        request.uid = globals.appState.uid;
        request.MessageID = loc.MessageID;

        //send the request
        net_message_count++;
        Log.d(globals.appState.appName, String.format("location update: time=%s, que=%d, msg=%d)", ClassUtility.getRaceOwlNetTime(loc.llt.utc_time_ms), globals.locations.size(),net_message_count));

        Gson gson = new Gson();
        String json = gson.toJson(request);

        JSONObject obj;
        StringEntity entity = null;
        try {

            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Throwable t) {
            Log.e("RaceOwl", "Could not parse malformed JSON: \"" + json + "\"");
        }

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlAPI.RaceTeamLocationResponse resp = parseRaceTeamLocationResponse(response_str);
                if (resp.Success)
                {
                    Log.d(globals.appState.appName, String.format("Location success. MessageID = %s", resp.MessageID));
                    setTrackingState(TrackingState.TRACKING);

                }
                else
                {
                    globals.messages.add(resp.Response);
                    Log.d(globals.appState.appName, String.format("Location fail. MessageID = %s (%s)", resp.MessageID, resp.Response));
                    setTrackingState(TrackingState.REJECT);
                }

                //post the next location
                Location.setLocationAcknowledged(globals.locations, resp.MessageID);  //Raceowl sent success, mark location as ak even if there was some issue
                sendLocation(); // send the next message
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    sendLocation(); //post the next location
                }
                setTrackingState(TrackingState.NETERROR);
            }
        });
    }

    //---------------------------------------------------------------------------
    // parseRaceTeamLocationResponse
    //---------------------------------------------------------------------------
    private RaceOwlAPI.RaceTeamLocationResponse parseRaceTeamLocationResponse(String json)
    {
        RaceOwlAPI.RaceTeamLocationResponse resp = new RaceOwlAPI.RaceTeamLocationResponse();
        try {
            Gson gson = new Gson();
            Type collectionType = new TypeToken<RaceOwlAPI.RaceTeamLocationResponse>() {
            }.getType();
            if (json.length() > 0) {
                resp = gson.fromJson(json, collectionType);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return (resp);
    }


    // ---------------------------------------------------------------------------------------------
    // addStandardRaceChoices - add races such as 'none' to the race choice listing
    // ---------------------------------------------------------------------------------------------
    private void addStandardRaceChoices() {

        // add a 'none' event
        RaceOwlAPI.RaceEvent race = new RaceOwlAPI.RaceEvent();
        race.RaceName = "none";
        race.RaceEventID = -1;
        race.CheckpointTextNumber = "";
        race.LocationTextNumber = "";
        race.RaceCode = "none";
        race.StartDate = "";
        race.EndDate = "";
        race.RaceEventDesc = "";
        race.RaceEventToken = "";
        race.RaceID = -1;
        // add the item to the array of globals.raceowlRaceList
        globals.raceowlRaceList.add(race);
    }

    // ---------------------------------------------------------------------------------------------
    // getMinMobileVersion
    // ---------------------------------------------------------------------------------------------
    private void getMinMobileVersion() {


        if (!globals.appState.isOnline) return;

        version_state = 1;  //request version

        //form request string
        String url = Const.RaceEventUrl + "/api/GetMobileVersion";

        net_message_count++;
        Log.d(globals.appState.appName, String.format("GetMobileVersion: msg=%d", net_message_count ));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                // called when response HTTP raceowl_status is "200 OK"
                //response_str = "success " + response_str;
                min_version = new String(response);
                min_version = min_version.replace("\"", "");
                verifyMinAppVersion();
                //globals.messages.add(response_str);
                version_state = 2;  //success, ready for display
            }

            @SuppressLint("DefaultLocale")
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {

                String response_str;
                if (errorResponse!=null) {
                    response_str = new String(errorResponse);
                }
                else
                {
                    response_str = "RaceOwl website returned NULL for GetMobileVersion";
                }
                //response_str = "fail " + response_str;
                min_version = "";
                version_state = 0;  //retry the request
                version_state_retry_count++;
                response_str += String.format("(retry %d of 3)", version_state_retry_count);
                if (version_state_retry_count >= 3)
                {
                    version_state = 3; //version failed
                }
                globals.messages.add(response_str);
            }
        });
    }
    private int version_state_retry_count = 0;

    // ---------------------------------------------------------------------------------------------
    // getTrackingStatus
    // ---------------------------------------------------------------------------------------------
    public boolean getTrackingStatus()
    {
        boolean tracking;
        switch (globals.settings.trackingState)
        {
            case TRACKING:
            case TRACKING_OFFLINE:
            case REJECT:
            case NETERROR:
                tracking = true;
                break;
            default:
                tracking = false;
                break;
        }
        return (tracking);

    }

    // ---------------------------------------------------------------------------------------------
    // getTrackingStatusMessage
    // ---------------------------------------------------------------------------------------------
    public String getTrackingStatusMessage()
    {
        switch (globals.settings.trackingState) {
            case DISABLED:
                statusMessage = "DISABLED (non racer)";
                break;
            case STOPPED:
                statusMessage = "STOPPED";
                break;
            case TRACKING:
                statusMessage = "TRACKING";
                break;
            case TRACKING_OFFLINE:
                statusMessage = "TRACKING (pending network)";
                break;
            case REJECT:
                statusMessage = "ERROR (RaceOwl Rejected)";
                break;
            case NETERROR:
                statusMessage = "ERROR (Network data error)";
                break;


        }
        return (statusMessage);
    }

    // ---------------------------------------------------------------------------------------------
    // clearLocations
    // ---------------------------------------------------------------------------------------------
    public void clearLocations()
    {
        globals.locations.clear();
    }


    private String getSelectedCheckpoint()
    {
        return(globals.settings.checkpoint_selected);
    }

    private String getCheckpointName(int idx)
    {
        String ret = "";
        if (idx >=0 && idx <globals.route.cps.length)
        {
            ret = globals.route.cps[idx].Name;
        }
        return (ret);
    }


    public String getCurrentCheckpoint()
    {
        RacerState rs = RacerState.recentRacerState();
        if (rs.route_relative!=null) {
            int idx = rs.route_relative.at_checkpoint ? rs.route_relative.checkpoint_index - 1 : rs.route_relative.checkpoint_index;
            return (getCheckpointName(idx));
        }
        else
        {
            return(getSelectedCheckpoint());
        }
    }


    // ---------------------------------------------------------------------------------------------
    // setCurrentCheckpoint
    // ---------------------------------------------------------------------------------------------
    private void setCurrentCheckpoint(String checkpointString)
    {
        globals.settings.checkpoint_selected = checkpointString;
    }


    // ---------------------------------------------------------------------------------------------
    // getCheckpointPhone
    // ---------------------------------------------------------------------------------------------
    public String getCheckpointPhone(int eventID) {
        String ret = "";
        int idx = getRaceIdx(eventID);
        if (idx >= 0) {
            RaceOwlAPI.RaceEvent race = globals.raceowlRaceList.get(idx);
            ret = race.CheckpointTextNumber;
        }
        return ret;
    }

    // ---------------------------------------------------------------------------------------------
    // parseCheckpoints
    // ---------------------------------------------------------------------------------------------
    private void parseCheckpoints(String json_response) {

        // clear the race list
        ArrayList<CheckPoint> lcps = new ArrayList<>();

        try
        {
            JSONArray items = new JSONArray(json_response);
            for (int inx = 0; inx < items.length(); inx++)
            {
                JSONObject item = items.getJSONObject(inx);
                CheckPoint cp = new CheckPoint(item);
                if (inx > 0)
                {
                    cp = new CheckPoint(lcps.get(lcps.size()-1),cp);
                }
                // add the item to the array of globals.raceowlRaceList
                lcps.add(cp);
            }

            // save parsed checkpoints to the mission plan
            //TODO: simplify, shift calcs to constructor
            wp.setCheckpoints(wp.updateCheckpoints(lcps.toArray(new CheckPoint[0])));

            if (globals.appState.isOnline) {
                globals.messages.add("Checkpoints updated");
            }

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    //---------------------------------------------------------------------------
    // getCheckpointMessage
    //---------------------------------------------------------------------------
    public String getCheckpointMessage(CheckPointCycle cpc)
    {
        return (String.format("%s %s %s %s", cpc.BoatNumber, cpc.Checkpoint, cpc.TextLocationTime, cpc.Status));
    }

    //---------------------------------------------------------------------------
    // verifySuccessSpotJSON - return true if xml from SPOT contains
    //---------------------------------------------------------------------------
    private boolean verifySuccessSpotJSON(String spot_json)
    {
        boolean ret;
        JSONObject item;
        JSONObject feed;
        try
        {
            item = new JSONObject(spot_json);
            feed = item.getJSONObject("response").getJSONObject("feedResponse").getJSONObject("feeds").getJSONObject("feed");
            String id = feed.getString("id");
            globals.messages.add("Verified " + id);
            ret = true;

        } catch (JSONException e)
        {
            globals.messages.add("Spot Verify Fail");
            ret = false;
        }
        return (ret);
    }



    // ---------------------------------------------------------------------------------------------
    // RaceTeamCheckpoint
    //
    // example:
    //        params:
    //        BoatNumber
    //        RaceEventID
    //        LocationTime   (format like 01012016201743)
    //        Status = IN|OUT|DNF
    //        Authorization = authorization password supplied to those able to update.
    //        Checkpoint = checkpoint Name
    // ---------------------------------------------------------------------------------------------
    private void updateCheckpointToRaceowl(CheckPointCycle cpc)
    {
        if (!globals.appState.isOnline) return;

        // form request string
        String url = Const.RaceEventUrl + "/api/RaceTeamCheckpoint";
        RequestParams params = new RequestParams();
        params.put("BoatNumber", cpc.BoatNumber);
        params.put("RaceEventID", cpc.RaceEventID);
        params.put("PhoneNumber", globals.settings.phone_number);
        params.put("LocationTime", cpc.NetLocationTime);
        params.put("Status", cpc.Status);
        params.put("Checkpoint",cpc.Checkpoint);
        if (cpc.Authorization.length()>0)
        {
            params.put("Authorization", cpc.Authorization);
        }
        params.put("MessageID", cpc.MessageID);


        net_message_count++;
        Log.d(globals.appState.appName, String.format("RaceTeamCheckpoint: boat=%s, que=%d, msg=%d", cpc.BoatNumber, globals.checkPointCycles.size(), net_message_count ));

        CheckPointCycle.setCheckpointRaceOwlStatus(globals.checkPointCycles, cpc.MessageID, sent, false);

        String msg = String.format("%s %s", cpc.Checkpoint, cpc.Status);
        globals.messages.add(msg);
        if (globals.settings.enableAudibleStatus)
        {
            wp.sayLine(msg);
        }

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, params, new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlResponse resp = verifyRaceOwlResponse(response_str);
                if (resp.RaceOwlResponse)
                {
                    if (resp.Success)
                    {
                        CheckPointCycle.setCheckpointRaceOwlStatus(globals.checkPointCycles,resp.MessageID, acknowledged, true);
                    }
                    else
                    {
                        CheckPointCycle.setCheckpointRaceOwlStatus(globals.checkPointCycles, resp.MessageID, rejected, true);
                        globals.messages.add(response_str);
                    }
                }
                sendCheckpoint();
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("updateCheckpointToRaceowl fail: " + response_str);
                    sendCheckpoint();
                }
            }
        });
    }

    //---------------------------------------------------------------------------
    // parseLocationJson - return RaceOwlResponse
    //---------------------------------------------------------------------------
    private RaceOwlResponse verifyRaceOwlResponse(String json)
    {
        RaceOwlResponse resp = new RaceOwlResponse();
        resp.Success = false;
        resp.RaceOwlResponse = false;
        JSONObject item;
        try
        {
            item = new JSONObject(json);

            //TODO make more generic to accept null for message ID
            resp.MessageID = Integer.parseInt(item.getString("MessageID"));
            resp.RaceOwlResponse = true;
            resp.Response = item.getString("Response");
            resp.Success = item.getBoolean("Success");

        } catch (JSONException e)
        {
            //globals.messages.add(e.toString());
        }
        return (resp);
    }

    //---------------------------------------------------------------------------
    // setTrackingState TRACKING appState machine
    //---------------------------------------------------------------------------
    public void setTrackingState(TrackingState state)
    {
        RaceOwlClient.TrackingState current = globals.settings.trackingState;

        // check that we are allowed to transition to tracking
        boolean notTracking;
        switch (current)
        {
            case DISABLED:
            case STOPPED:
                notTracking = true;
                break;
            default:
                notTracking = false;
                break;
        }

        if (!isRaceEventValid(globals.settings.RaceEventID, false))
        {
            if (!notTracking)
            {
                globals.messages.add("Selected race is not valid, tracking set to stopped");

            }
            globals.settings.trackingActive = false;
            state = TrackingState.STOPPED;
        }

        boolean requestToTrack;
        switch(state) {
            case TRACKING_OFFLINE:
            case TRACKING:
            case REJECT:
            case NETERROR:
                requestToTrack = true;
                break;
            default:
                requestToTrack = false;
                break;
        }

        boolean allowTransition = !requestToTrack || (globals.settings.trackingActive && globals.settings.trackingEnabled);

        if (allowTransition)
        {
                globals.settings.trackingState = state;
        }
    }

    private void verifyMinAppVersion()
    {
        //min version been populated?
        if (min_version.length() > 0)
        {
//            globals.messages.add(min_version);

            //globals version
            float app_version = 0;
            float ret_min_version = 0;
            if (ClassUtility.isNumeric(globals.settings.version))
            {
                app_version = Float.parseFloat(globals.settings.version);
                //              globals.messages.add(String.format("%2.1f",app_version));
            }
            if (ClassUtility.isNumeric(min_version))
            {
                ret_min_version = Float.parseFloat(min_version);
            }

            if (ret_min_version > app_version && app_version > 0)
            {
                version_invalid = true;
                globals.messages.add("version invalid");
            }
            else
            {
                version_invalid = false;
                //   globals.messages.add("version good");
            }
        }
    }

    public static String getCheckPointCycleStatusText(CheckPointCycle.CheckPointCycleStatus status)
    {
        String retstr;
        switch (status)
        {
            case pending:
                retstr = "pending network";
                break;
            case sent:
                retstr = "sent";
                break;
            case acknowledged:
                retstr = "acknowledged";
                break;
            case rejected:
                retstr = "rejected";
                break;
            default:
                retstr = "unknown";
                break;
        }

        return (retstr);
    }


    public static int getCheckPointCycleStatusColor(CheckPointCycle.CheckPointCycleStatus status)
    {
        int return_color;
        switch (status)
        {
            case pending:
                return_color = Color.MAGENTA;
                break;
            case sent:
                return_color = Color.argb(255,255,100,100);///0xFFA500;  // orange
                break;
            case acknowledged:
                return_color = Color.GREEN;
                break;
            case rejected:
                return_color = Color.RED;
                break;
            default:
                return_color = Color.BLACK;
                break;
        }

        return (return_color);
    }


    //---------------------------------------------------------------------------
    // getCheckpointCycle
    //---------------------------------------------------------------------------
    public CheckPointCycle getCheckpointCycle(int idx)
    {
        CheckPointCycle item = new CheckPointCycle();
        if (idx>=0 && idx<globals.checkPointCycles.size())
        {
            item = globals.checkPointCycles.get(idx);
        }
        return (item);
    }

    //---------------------------------------------------------------------------
    // isSimilarCheckpoint
    //---------------------------------------------------------------------------
    public Boolean isSimilarCheckpoint(CheckPointCycle cp)
    {
        boolean ret = false;

        final int size = globals.checkPointCycles.size();
        for (int i = 0; i < size; i++)
        {
            CheckPointCycle item = globals.checkPointCycles.get(i);
            if (item.RaceEventID == cp.RaceEventID &&
                    (item.BoatNumber).equals(cp.BoatNumber) &&
                    (item.Checkpoint).equals(cp.Checkpoint) &&
                    (item.Status).equals(cp.Status))
            {
                ret = true;
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getDivisions
    // http://v3.raceowl.com/api/RaceEvents/?OldEventFilter=12/01/2015
    // ---------------------------------------------------------------------------------------------
    private void getDivisions(int race_event_id)
    {
        if (!globals.appState.isOnline) return;

        //form request string
        String url = Const.RaceEventUrl + "/api/RaceDivisions";
        url += "?RaceEventID=" + race_event_id;

        globals.settings.division_RaceEventID = race_event_id;


        net_message_count++;
        Log.d(globals.appState.appName, String.format("RaceDivisions: msg=%d", net_message_count ));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, null, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response) {
                String response_str = new String(response);
                parseDivisions(response_str);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e) {
                // unable to get valid response from race owl, restore any saved races
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    response_str = "fail " + response_str;
                    globals.messages.add(response_str);
                }
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // parseDivisions
    // ---------------------------------------------------------------------------------------------
    private void parseDivisions(String json_response) {

        if (json_response==null) return;
        if (json_response.length()==0) return;

        // clear the divisions
        globals.divisions.clear();

        try
        {
            JSONArray items = new JSONArray(json_response);
            for (int i = 0; i < items.length(); i++)
            {
                RaceDivisions div = new RaceDivisions();

                JSONObject item = items.getJSONObject(i);
                div.DivisionID = item.getInt("DivisionID");
                div.DivisionName = item.getString("DivisionName");
                div.StartTime = item.getString("StartTime");

                // add the item to the array of globals.raceowlRaceList
                globals.divisions.add(div);
            }
            if (globals.appState.isOnline) {
                globals.messages.add("Divisions updated");
            }

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceStandings
    // http://v3.raceowl.com/api/RaceEvents/?OldEventFilter=12/01/2015
    // ---------------------------------------------------------------------------------------------
    public void getRaceStandings(int race_event_id, int DivisionID, int start, int count)
    {
        if (!globals.appState.isOnline) return;

        //form request string
        String url = Const.RaceEventUrl + "/api/racestandings";

        RequestParams params = new RequestParams();
        params.put("RaceEventID", race_event_id);
        params.put("DivisionID", DivisionID);
        params.put("StartPosition", start);
        params.put("Count", count);


        net_message_count++;
        Log.d(globals.appState.appName, String.format("racestandings: DivisionID=%d", DivisionID));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, params, new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                parseRaceStandings(response_str);

            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("getRaceStandings fail: " + response_str);
                    //sendCheckpoint();
                }
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // getIndividualStatus
    // ---------------------------------------------------------------------------------------------
    void getIndividualStatus(int raceEventId, String BoatNumber)
    {
        if (!globals.appState.isOnline) return;

        //form request string
        String url = Const.RaceEventUrl + "/api/IndividualStatus";

        RequestParams params = new RequestParams();
        params.put("RaceEventID", raceEventId);
        params.put("BoatNumber", BoatNumber);

        net_message_count++;
        Log.d(globals.appState.appName, String.format("IndividualStatus: BoatNumber=%s", BoatNumber));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, params, new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                parseIndividualStatus(response_str);
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("getIndividualStatus fail, is this a registered racer? reference RaceOwl Response:" +  response_str );
                    sendCheckpoint();
                }
            }
        });
    }


    // ---------------------------------------------------------------------------------------------
    // getDivisionIndexByName
    // ---------------------------------------------------------------------------------------------
    public int getDivisionIndexByName(String division)
    {
        int ret = 0;
        if (division != null )
        {
            for (int inx = 0; inx < globals.divisions.size(); inx++) {
                RaceDivisions item = globals.divisions.get(inx);
                if (division.equals(item.DivisionName)) {
                    ret = inx;
                    break;
                }
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getDivisionIdByName
    // ---------------------------------------------------------------------------------------------
    private int getDivisionIdByName(String division)
    {
        int ret = -1;
        for (int inx = 0; inx< globals.divisions.size(); inx++)
        {
            RaceDivisions  item = globals.divisions.get(inx);
            if (division.equals(item.DivisionName))
            {
                ret = item.DivisionID;
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getDivisionNames
    // ---------------------------------------------------------------------------------------------
    public String[] getDivisionNames()
    {
        ArrayList<String> names = new ArrayList<>();
        for (RaceDivisions item : globals.divisions) {
            names.add(item.DivisionName);
        }
        return (names.toArray(new String[0]));
    }


    // ---------------------------------------------------------------------------------------------
    // setCurrectDivision
    // ---------------------------------------------------------------------------------------------
    public void setCurrectDivision(int idx)
    {
        if (idx >=0 && idx < globals.divisions.size()) {
            globals.settings.division_selected = globals.divisions.get(idx).DivisionName;
        }

    }

    // ---------------------------------------------------------------------------------------------
    // loadFakeRaceResults
    // ---------------------------------------------------------------------------------------------
    private void loadFakeRaceResults()
    {
        clearStandings();
        for (int inx=0;inx<10;inx++)
        {
            RaceStandings item = new RaceStandings();
            item.BoatNumber = String.format("%04d",inx);
            item.PlaceDivision = inx + 1;


            updateStandings(item);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // parseRaceStandings
    // ---------------------------------------------------------------------------------------------
    private void parseRaceStandings(String json_response) {

        try {
            JSONArray items = new JSONArray(json_response);
            for (int i = 0; i < items.length(); i++) {

                JSONObject item = items.getJSONObject(i);

                RaceStandings race_standing = new RaceStandings();

                race_standing.BoatNumber = item.getString("id");
                race_standing.pt.latitude_rad = item.getDouble("lat") * Const.dtr;
                race_standing.pt.longitude_rad = item.getDouble("lng") * Const.dtr;
                race_standing.LocationTime = ClassUtility.parseRaceOwlNetTime(item.getString("t"));
                race_standing.AvgSpeed_mph = (float) item.getDouble("v");
                race_standing.DivisionID = item.getInt("div");
                race_standing.PlaceDivision = item.getInt("dp");
                race_standing.PlaceOverall = item.getInt("op");

                //calculated
                race_standing.last_update_time = ClassUtility.getDate();
                race_standing.perc_complete = wp.getPercentComplete(race_standing.pt);

                // add the item to the standings
                updateStandings(race_standing);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }



    // ---------------------------------------------------------------------------------------------
    // parseIndividualStatus
    // ---------------------------------------------------------------------------------------------
    private void parseIndividualStatus(String json_response) {

        try {

            JSONObject item = new JSONObject(json_response);
            RaceStandings standing = new RaceStandings();
            standing.CheckPoint = item.getInt("cp");
            standing.CheckPointState = item.getString("cpx");
            standing.CheckPointTime = ClassUtility.parseRaceOwlNetTime(item.getString("cpt"));
            standing.BoatNumber = item.getString("id");
            standing.pt.latitude_rad = item.getDouble("lat") * Const.dtr;
            standing.pt.longitude_rad = item.getDouble("lng") * Const.dtr;
            standing.LocationTime = ClassUtility.parseRaceOwlNetTime(item.getString("t"));
            standing.AvgSpeed_mph = (float) item.getDouble("v");
            standing.DivisionID = item.getInt("div");
            standing.PlaceDivision = item.getInt("dp");
            standing.PlaceOverall = item.getInt("op");
            standing.last_update_time = ClassUtility.getDate();

            // add the item to the array of globals.raceowlRaceList
            updateStandings(standing);

            // proPaddler auto mode required to obtain the start time for the race
            int testNumber = ClassUtility.toInteger(globals.settings.boat_number, -1);
            int refNumber = ClassUtility.toInteger(standing.BoatNumber, -2);
            if (globals.appState.setRaceStartTime && testNumber == refNumber)
            {
                RaceDivisions div = RaceDivisions.getDivision(globals.divisions, standing.DivisionID);
                if (div != null) {
                    globals.settings.setStartDate(parseRaceOwlTime(div.StartTime));
                    globals.appState.setRaceStartTime = false;
                    if (globals.settings.lastStartDate != globals.settings.startDate || ClassUtility.getDate().before(globals.settings.startDate)) {
                        globals.appState.forceReset = true;
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    // ---------------------------------------------------------------------------------------------
    // updateStandings
    // ---------------------------------------------------------------------------------------------
    private float estimateCurrentSpeed(RaceStandings prev, RaceStandings curr)
    {
        float speed_mph;

        // distance traveled
        double dist_ft = WayPointNav.DistBetweenWaypoints(prev.pt.latitude_rad, prev.pt.longitude_rad, curr.pt.latitude_rad, curr.pt.longitude_rad);

        // time to travel
        double time_sec = ClassUtility.getDeltaTimeSec(prev.LocationTime, curr.LocationTime);

        // curr speed
        if (time_sec > 0) {
            double curr_fps = dist_ft/time_sec;
            speed_mph = (float) (curr_fps * Const.fps_to_mph);
            // limits
            speed_mph = Math.min(speed_mph,15);
            // 1st order filter with previous
            if (prev.AvgSpeed_mph > 0)
            {
                speed_mph =  (float) (prev.AvgSpeed_mph + 0.25 * (speed_mph - prev.AvgSpeed_mph));
            }
        }
        else  //use previous
        {
            speed_mph = prev.AvgSpeed_mph;

        }
        return (speed_mph);
    }


    // ---------------------------------------------------------------------------------------------
    // updateStandings
    // ---------------------------------------------------------------------------------------------
    private void updateStandings(RaceStandings standing)
    {
        Integer idx = standings_lookup.get(standing.BoatNumber);
        if (idx == null) {
            standings.add(standing);
            standings_lookup.put(standing.BoatNumber, standings.size() - 1);
        }
        else
        {
            // if AvgSpeed_mph is available from RaceOwl, then it should be the more accurate so use it
            // otherwise make an estimate based on the location update
            if (standing.AvgSpeed_mph <=0) {
                RaceStandings last = standings.get(idx);
                standing.AvgSpeed_mph = estimateCurrentSpeed(last, standing);
            }
            standings.set(idx,standing);
        }
    }

    // ---------------------------------------------------------------------------------------------
    // clearStandings
    // ---------------------------------------------------------------------------------------------
    private void clearStandings()
    {
        standings_lookup.clear();
        standings.clear();
    }


    // ---------------------------------------------------------------------------------------------
    // RaceStandings
    // ---------------------------------------------------------------------------------------------
    public RaceStandings getStandings(String id)
    {
        RaceStandings item = new RaceStandings();
        Integer idx = standings_lookup.get(id);
        if (idx != null) {
            item = standings.get(idx);
        }
        return item;
    }

    // ---------------------------------------------------------------------------------------------
    // register
    // ---------------------------------------------------------------------------------------------
    public void register(RaceOwlAPI.RegisterData register_data)
    {
        if (!globals.appState.isOnline)
        {
            Log.d(globals.appState.appName, "register - not online");
            return;
        }


        //form request string
        String url = Const.RaceEventUrl + "/api/Register";

        Gson gson = new Gson();
        String json = gson.toJson(register_data);

        JSONObject obj;
        StringEntity entity = null;
        try {

            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

        } catch (Throwable t) {
            Log.e("RaceOwl", "Could not parse malformed JSON: \"" + json + "\"");
        }

        net_message_count++;
        Log.d(globals.appState.appName, String.format("Register: last Name=%s", register_data.LastName));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);

                RaceOwlAPI.RegisterResponse resp = new RaceOwlAPI.RegisterResponse();
                JSONObject item;
                try
                {
                    item = new JSONObject(response_str);
                    resp.Response = item.getString("Response");
                    resp.Success = item.getBoolean("Success");

                } catch (JSONException e)
                {
                    //globals.messages.add(e.toString());
                }
                if (resp.Success)
                {
                    globals.messages.add("Register success");
                }
                else
                {
                    globals.messages.add(response_str);
                }
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("register fail: " + response_str);
                }
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // createEvent
    // ---------------------------------------------------------------------------------------------
    public void createEvent(final RaceOwlAPI.RaceEvent race_event)
    {
        // are we online
        if (!globals.appState.isOnline)
        {
            Log.d(globals.appState.appName, "createEvent - not online");
            return;
        }


        //form request string
        String url = Const.RaceEventUrl + "/api/UpsertRaceEvent";

        // populate string for checkpoints
        ArrayList<RaceOwlAPI.UploadCheckpoint> lcps = getRaceOwlCheckpoints(globals.route.cps);
        Gson gsonobj = new Gson();
        String checkpoints_json = gsonobj.toJson(lcps);


        net_message_count++;
        Log.d(globals.appState.appName, String.format("New event: %s", race_event.RaceName));

        AsyncHttpClient client = new AsyncHttpClient();

        RaceOwlAPI.UpsertRaceEvent newevent = new RaceOwlAPI.UpsertRaceEvent();
        newevent.RaceEventID = 0;
        newevent.Description = race_event.RaceEventDesc;
        newevent.RaceDate =  ClassUtility.toRaceOwlNetTime(race_event.StartDate);
        newevent.TimeZone = ClassUtility.getCurrentTimezone();
        newevent.IsMiles = race_event.IsMiles;
        newevent.RaceName = race_event.RaceName;
        newevent.RaceCode = race_event.RaceCode;
        newevent.CheckpointTextNumber = race_event.CheckpointTextNumber;
        newevent.UID = globals.appState.uid;
        newevent.AndroidCheckpointJson1 = checkpoints_json;

        Gson gson = new Gson();
        String json = gson.toJson(newevent);

        JSONObject obj;
        StringEntity entity = null;
        try {
            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            Log.d(globals.appState.appName, obj.toString());

        } catch (Throwable t) {
            Log.e(globals.appState.appName, "Could not parse malformed JSON: \"" + json + "\"");
        }

        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlResponseCreateEvent resp = parseCreateEvent(response_str);
                if (resp.Success)
                {
                    globals.messages.add("New Event success");
                    RaceOwlAPI.RaceEvent race_event2 = new RaceOwlAPI.RaceEvent(race_event);
                    race_event2.RaceEventID = resp.RaceEventID;
                    upsertRaceEvent(race_event2);
                }
                else
                {
                    globals.messages.add(response_str);
                }
                setRaceEvent(race_event.RaceCode);


            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("createEvent fail: " + response_str);
                }
            }
        });
    }



    static class RaceOwlResponseCreateEvent{
        String Response;
        Boolean Success;
        int RaceEventID;
        int[] CheckpointIDs;
        int  DivisionID;

        RaceOwlResponseCreateEvent()
        {
            Response = "";
            Success = false;
            RaceEventID = 0;
            CheckpointIDs = new int[0];
            DivisionID = 0;
        }
    }


    //---------------------------------------------------------------------------
    // parseCreateEvent
    //---------------------------------------------------------------------------
    private RaceOwlResponseCreateEvent parseCreateEvent(String json)
    {

        // json = "{\"Response\":\"\",\"Success\":true,\"RaceEventId\":1074,\"DivisionID\":1287,\"CheckpointIDs\":[309,310,311,312,313,314,315,316,317,318]}";

        RaceOwlResponseCreateEvent resp = new RaceOwlResponseCreateEvent();
        JSONObject item;
        try
        {
            item = new JSONObject(json);
            resp.Success = item.getBoolean("Success");
            resp.Response = item.getString("Response");
            if (resp.Success) {
                resp.RaceEventID = Integer.parseInt(item.getString("RaceEventId"));
                resp.DivisionID = Integer.parseInt(item.getString("DivisionID"));
                JSONArray jsonarray = item.getJSONArray("CheckpointIDs");
                resp.CheckpointIDs = new int[jsonarray.length()];
                for (int i = 0; i < jsonarray.length(); i++)
                {
                    resp.CheckpointIDs[i] = jsonarray.getInt(i);
                }
            }
        }
        catch (JSONException e)
        {
            globals.messages.add(e.toString());
        }
        return (resp);
    }


    // ---------------------------------------------------------------------------------------------
    // getDivisionName
    // ---------------------------------------------------------------------------------------------
    public String getDivisionName(int div_id)
    {
        String ret = "";
        for (int inx = 0; inx < globals.divisions.size(); inx++)
        {
            RaceDivisions item = globals.divisions.get(inx);
            if (item.DivisionID==div_id) {
                ret = item.DivisionName;
                break;
            }
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getCurrentDivisionID
    // ---------------------------------------------------------------------------------------------
    public int getCurrentDivisionID()
    {
        return ( getDivisionIdByName(globals.settings.division_selected));
    }

    // ---------------------------------------------------------------------------------------------
    // getCurrentShortRacename
    // ---------------------------------------------------------------------------------------------
    String getCurrentShortRacename()
    {
        String ret = "";
        RaceOwlAPI.RaceEvent item = getRaceItem(globals.settings.RaceEventID);
        if (item != null)
        {
            if (item.RaceCode.length() > 10)
            {
                ret = item.RaceCode.substring(0,10) + "...";
            }
            else
            {
                ret = item.RaceCode;
            }
        }
        return (ret);
    }


    // ---------------------------------------------------------------------------------------------
    // sendCheckPoints
    // ---------------------------------------------------------------------------------------------
    public void sendCheckPoints()
    {
        if (!globals.appState.isOnline) return;

        //form request string
        String url = Const.RaceEventUrl + "/api/SetCheckPoints";

        RequestParams params = new RequestParams();
        params.put("RaceEventID",globals.settings.RaceEventID);
        params.put("Checkpoints",wp.getCheckPoints());


        net_message_count++;
        Log.d(globals.appState.appName, String.format("New checkpoints: %s", "checkpoints"));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(url, params, new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlResponse resp = verifyRaceOwlResponse(response_str);
                if (resp.RaceOwlResponse)
                {
                    if (resp.Success)
                    {
                        globals.messages.add("New Event success");
                    }
                    else
                    {
                        globals.messages.add(response_str);
                    }
                }
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("sendCheckPoints fail: " + response_str);
                    sendCheckpoint();
                }
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // getRaceOwlCheckpoints
    // ---------------------------------------------------------------------------------------------
    private ArrayList<RaceOwlAPI.UploadCheckpoint> getRaceOwlCheckpoints(CheckPoint[] lcps)
    {
        ArrayList<RaceOwlAPI.UploadCheckpoint> rocps = new ArrayList<>();
        for (CheckPoint cp: lcps)
        {
            rocps.add(new RaceOwlAPI.UploadCheckpoint(cp));
        }
        return (rocps);
    }

    // ---------------------------------------------------------------------------------------------
    // sendFeedback
    // ---------------------------------------------------------------------------------------------
    public void sendFeedback(RaceOwlAPI.FeedbackData feedbackData)
    {
        if (!globals.appState.isOnline)
        {
            Log.d(globals.appState.appName, "sendFeedback - not online");
            return;
        }

        //form request string
        String url = Const.RaceEventUrl + "/api/FeedBack";

        Gson gson = new Gson();
        String json = gson.toJson(feedbackData);

        JSONObject obj;
        StringEntity entity = null;
        try {

            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

        } catch (Throwable t) {
            Log.e("RaceOwl", "Could not parse malformed JSON: \"" + json + "\"");
        }

        net_message_count++;
        Log.d(globals.appState.appName, String.format("FeedBack: Name=%s", feedbackData.Name  ));

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                //String response_str = new String(response);
                RaceOwlAPI.FeedbackResponse resp = new RaceOwlAPI.FeedbackResponse();
                resp.Success = true;
                globals.messages.add("Feedback success");
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("Feedback fail: " + response_str);
                }
            }
        });
    }

    // ---------------------------------------------------------------------------------------------
    // uploadCheckpoints
    // ---------------------------------------------------------------------------------------------
    public void uploadCheckpoints()
    {
        // are we online
        if (!globals.appState.isOnline)
        {
            Log.d(globals.appState.appName, "uploadCheckpoints - not online");
            return;
        }


        // populate string for checkpoints
        ArrayList<RaceOwlAPI.UploadCheckpoint> lcps = getRaceOwlCheckpoints(wp.getCheckPoints());
        Gson gsonobj = new Gson();
        String checkpoints_json = gsonobj.toJson(lcps);

        RaceOwlAPI.ApiUpsertCheckpoints api = new RaceOwlAPI.ApiUpsertCheckpoints();
        api.RaceEventID = globals.settings.RaceEventID;
        api.UID = globals.appState.uid;
        api.AndroidCheckpointJson1 = checkpoints_json;

        net_message_count++;
        Log.d(globals.appState.appName, "uploadCheckpoints");

        // form the net message for post
        Gson gson = new Gson();
        String json = gson.toJson(api);
        JSONObject obj;
        StringEntity entity = null;
        try {
            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
            Log.d(globals.appState.appName, obj.toString());
        } catch (Throwable t) {
            Log.e(globals.appState.appName, "Could not parse malformed JSON: \"" + json + "\"");
        }

        //form request string
        String url = Const.RaceEventUrl + "/api/uploadCheckpoints";
        AsyncHttpClient client = new AsyncHttpClient();
        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlAPI.UploadCheckpointModel[] lcps = parseUploadCheckpoints(response_str);

            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {

                    String response_str = new String(errorResponse);
                    globals.messages.add("uploadCheckpoints fail: " + response_str);
                }
            }
        });
    }

    //---------------------------------------------------------------------------
    // parseUploadCheckpoints
    //---------------------------------------------------------------------------
    private RaceOwlAPI.UploadCheckpointModel[] parseUploadCheckpoints(String json)
    {
        RaceOwlAPI.UploadCheckpointModel[] resp = new RaceOwlAPI.UploadCheckpointModel[0];
        try {
            Gson gson = new Gson();
            Type collectionType = new TypeToken<RaceOwlAPI.UploadCheckpointModel[]>() {
            }.getType();
            if (json.length() > 0) {
                resp = gson.fromJson(json, collectionType);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return (resp);
    }

    // ---------------------------------------------------------------------------------------------
    // apiTrackerRegistration
    //
    //    sample tracker values
    //    spot = 0HR9GhUtvA0FvflNqsscx5KPi9G2CopuQ
    //    inreach = BobHines
    // ---------------------------------------------------------------------------------------------
    public void apiTrackerRegistration(RaceOwlAPI.TrackerRegistration tracker)
    {
        // are we online
        if (!globals.appState.isOnline)
        {
            Log.d(globals.appState.appName, "apiTrackerRegistration - not online");
            return;
        }

        //format the net command
        RaceOwlAPI.RaceEvent race = getRaceItem(globals.settings.RaceEventID);
        String url = Const.RaceEventUrl + "/api/TrackerRegistration";

        //send the net command
        net_message_count++;
        Log.d(globals.appState.appName, "TrackerRegistration");

        Gson gson = new Gson();
        String json = gson.toJson(tracker);

        JSONObject obj;
        StringEntity entity = null;
        try {

            obj = new JSONObject(json);
            entity = new StringEntity(obj.toString());
            entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        } catch (Throwable t) {
            Log.e("RaceOwl", "Could not parse malformed JSON: \"" + json + "\"");
        }

        AsyncHttpClient client = new AsyncHttpClient();
        client.post(globals.appState.ctx, url, entity, "application/json", new AsyncHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] response)
            {
                // called when response HTTP raceowl_status is "200 OK"
                String response_str = new String(response);
                RaceOwlAPI.ApiReturnMessage resp = parseApiReturnMessage(response_str);
                globals.messages.add(resp.Response);
            }
            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] errorResponse, Throwable e)
            {
                if (errorResponse != null) {
                    String response_str = new String(errorResponse);
                    globals.messages.add("apiTrackerRegistration fail: " + response_str);
                }
            }
        });
    }

    //---------------------------------------------------------------------------
    // parseRaceTeamLocationResponse
    //---------------------------------------------------------------------------
    private RaceOwlAPI.ApiReturnMessage parseApiReturnMessage(String json)
    {
        RaceOwlAPI.ApiReturnMessage resp = new RaceOwlAPI.ApiReturnMessage();
        try {
            Gson gson = new Gson();
            Type collectionType = new TypeToken<RaceOwlAPI.ApiReturnMessage>() {
            }.getType();
            if (json.length() > 0) {
                resp = gson.fromJson(json, collectionType);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return (resp);
    }

    // ---------------------------------------------------------------------------------------------
    // getCheckPointNameByIndex
    // ---------------------------------------------------------------------------------------------
    private  String getCheckPointNameByIndex(int idx)
    {
        String ret = "";

        // get a instance of globals
        if (idx >=0 && idx<globals.route.cps.length)
        {
            ret = globals.route.cps[idx].Name;
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // sendAutoCheckpoint
    // ---------------------------------------------------------------------------------------------
    void sendAutoCheckpoint()
    {

        RacerState s0  = RacerState.recentRacerState();

        // verify checkpoints
        if (s0.cp_history == null) return;

        for (int inx=0;inx<s0.cp_history.length;inx++)
        {
            if (globals.route.cps[inx].isCheckpoint) {
                if (s0.cp_history[inx].in.state == PointHistory.PointHistoryState.cycled) {
                    String cpname = getCheckPointNameByIndex(inx);
                    CheckPointCycle cpc = makeCheckPointCycle(s0.racer_id, cpname, ClassUtility.convertUTCtoDate(s0.cp_history[inx].in.time), "in");
                    CheckPointCycle.addCheckPointCycle(globals.checkPointCycles, cpc);
                    s0.cp_history[inx].in.state = PointHistory.PointHistoryState.sent;
                }
                if (s0.cp_history[inx].out.state == PointHistory.PointHistoryState.cycled) {
                    String cpname = getCheckPointNameByIndex(inx);
                    CheckPointCycle cpc = makeCheckPointCycle(s0.racer_id, cpname, ClassUtility.convertUTCtoDate(s0.cp_history[inx].out.time), "out");
                    CheckPointCycle.addCheckPointCycle(globals.checkPointCycles, cpc);
                    s0.cp_history[inx].out.state = PointHistory.PointHistoryState.sent;
                }
            }
        }
        RacerState.pushRacerState(s0);

        //send queued current checkpoints
        sendCheckpoint();

    }

    //---------------------------------------------------------------------------
    // setCurrectCheckpointNear
    // set the current checkpoint to the closest to location
    //---------------------------------------------------------------------------
    public void setCurrectCheckpointNear()
    {
        RacerState s0 = RacerState.recentRacerState();
        CheckPoint nearcp = RouteRelative.getNearestCheckpoint(s0,globals.route);
        if (nearcp != null) {
            setCurrentCheckpoint(nearcp.Name);
        }
    }

    private Date textToDate(String dtStart) throws java.text.ParseException
    {
        Date date = new Date();
        @SuppressLint("SimpleDateFormat") SimpleDateFormat format = new SimpleDateFormat(Const.start_date_format);
        try
        {
            date = format.parse(dtStart);
            //System.out.println(date);
        }
        catch (ParseException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return date;
    }


}
