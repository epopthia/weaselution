package com.MR340ProPaddler;

import android.content.Context;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@SuppressWarnings("unused")
public
class UIUtil {

	// ------------------------------------------------------------------------
	//	addItemsOnListView
	// ------------------------------------------------------------------------
	public static void addItemsOnListView(Context ctx, String[] items, ListView listview, int initial_position)
	{
		final ArrayList<String> list = new ArrayList<>();
		Collections.addAll(list, items);
		final ArrayAdapter<String> adapter = new ArrayAdapter<>(ctx, android.R.layout.simple_list_item_checked, list);
		listview.setAdapter(adapter);
		listview.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
		listview.setSelection(initial_position);
		listview.setItemChecked(initial_position,true);
	}


	// ------------------------------------------------------------------------
	//	addItemsOnSpinner (with init pos setting)
	// ------------------------------------------------------------------------
	static void addItemsOnSpinner(Context ctx, ArrayList<String> items, Spinner spinner, int initpos)
	{
		List<String> list = new ArrayList<>(items);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(dataAdapter);

		if (initpos >0 && initpos<items.size())
		{
			spinner.setSelection(initpos,false);
		}
	}

	// ------------------------------------------------------------------------
	//	addItemsOnSpinner (with init pos setting)
	// ------------------------------------------------------------------------
	static void addItemsOnSpinner(Context ctx, String[] items, Spinner spinner, int initpos)
	{
		List<String> list = new ArrayList<>();
		Collections.addAll(list, items);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(dataAdapter);

		if (initpos >0 && initpos<items.length)
		{
			spinner.setSelection(initpos,false);
		}
	}

	// ------------------------------------------------------------------------
	//	addItemsOnSpinner (without init pos setting)
	// ------------------------------------------------------------------------
	public static void addItemsOnSpinner(Context ctx, String[] items, Spinner spinner)
	{
		List<String> list = new ArrayList<>();
		Collections.addAll(list, items);
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(dataAdapter);
	}

	// ------------------------------------------------------------------------
	//	setSpinnerSelectionWithoutCallingListener
	// ------------------------------------------------------------------------
	public static void setSpinnerSelectionWithoutCallingListener(final Spinner spinner, final int selection)
	{
		final OnItemSelectedListener l = spinner.getOnItemSelectedListener();
		spinner.setOnItemSelectedListener(null);
		spinner.post(() -> {
            spinner.setSelection(selection);
            spinner.post(() -> spinner.setOnItemSelectedListener(l));
        });
	}
	// ------------------------------------------------------------------------
	// addItemsOnSpinnerWithNone
	// ------------------------------------------------------------------------
	static void addItemsOnSpinnerWithNone(Context ctx, String[] items, Spinner spinner, int initpos)
	{
		List<String> list = new ArrayList<>();
		Collections.addAll(list, items);
		list.add("none");

		ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(dataAdapter);

		if (initpos >0 && initpos<items.length+1)
		{
			spinner.setSelection(initpos);
		}
		else
		{
			spinner.setSelection(items.length);
		}
	}
	// ------------------------------------------------------------------------
	// addItemsOnSpinnerWithNone
	// ------------------------------------------------------------------------
	static void addItemsOnSpinnerWithNone(Context ctx, ArrayList<String> items, Spinner spinner, int initpos)
	{
		ArrayList<String> list = new ArrayList<>(items);
		list.add("none");

		ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(dataAdapter);

		if (initpos >0 && initpos<items.size()+1)
		{
			spinner.setSelection(initpos);
		}
		else
		{
			spinner.setSelection(items.size());
		}
	}
}
