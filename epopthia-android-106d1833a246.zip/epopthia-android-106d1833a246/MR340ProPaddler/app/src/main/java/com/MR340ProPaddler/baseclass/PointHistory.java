package com.MR340ProPaddler.baseclass;
import java.util.Date;

public class PointHistory
{
    public enum PointHistoryState
    {
        unknown,
        cycled,
        sent,
    }
    private final int index;
    public long time;
    public PointHistoryState state;

    public PointHistory()
    {
        index = -1; //invalid number for init
        time = new Date().getTime();
        state = PointHistoryState.unknown;
    }

    public PointHistory(PointHistory item)
    {
        index = item.index;
        time = item.time;
        state = item.state;
    }

    public PointHistory(int index0, long time0, PointHistoryState state0)
    {
        index = index0;
        time = time0;
        state = state0;
    }
}
