package com.MR340ProPaddler.fragments;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.MR340ProPaddler.ActivityMain;
import com.MR340ProPaddler.Globals;
import com.MR340ProPaddler.R;
import com.MR340ProPaddler.WayPointMission;
import com.MR340ProPaddler.adapters.CheckpointEtaAdapter;
import com.MR340ProPaddler.utility.ClassUtility;
import com.MR340ProPaddler.utility.Const;

import java.util.ArrayList;
import java.util.Objects;

public class Frag04_eta extends Fragment
{
	private View v = null;
	private final ArrayList<String> checkpointListArray = new ArrayList<>();
	private CheckpointEtaAdapter adapter = null; //= new CheckpointAdapter(getActivity(), android.R.layout.simple_list_item_1, android.R.id.text1, checkpointListArray, 0);
	private Handler mHandler;
	private WayPointMission wp = null;
	private Globals globals = null;
	
	private int list_array_count;
	
	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		setHasOptionsMenu(true);

		if (container == null) 
		{
	        return null;
	    }
		super.onCreate(savedInstanceState);
			
	    v=inflater.inflate(R.layout.frag04_eta, container, false);
	    
	    wp = WayPointMission.getInstance();

		mHandler = new Handler(); //setup for timed updates
	    
	    // if fragment is visible then update
	    if (getUserVisibleHint())
	    {
	    	update();
	    }
	    
	    list_array_count = 0;

	    return v;
	}

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        globals = Globals.getInstance();
        globals.appState.ctx = context;
    }

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) 
	{
	    super.setUserVisibleHint(isVisibleToUser);
	    if (isVisibleToUser && v!=null) 
	    { 
            ((ActivityMain)Objects.requireNonNull(getActivity())).manageScreenTransition();
            //Toast.makeText(getActivity() ,String.format("Visible") , Toast.LENGTH_LONG).show();
	    	update();	
	    }
	}
	
    @Override
    public void onPause() 
    {
		//Toast.makeText(getActivity() ,String.format("onPause") , Toast.LENGTH_LONG).show();    		
    	stopRepeatingTask();
        super.onPause();
    }

    @Override
	public void onResume() 
    {
		//Toast.makeText(getActivity() ,String.format("OnResume") , Toast.LENGTH_LONG).show();    		
    	boolean ret = update();
    	
   	    //start status check
   	    startRepeatingTask();

    	if (!ret)
    	{
			Toast.makeText(getActivity() , "Invalid checkpoint list", Toast.LENGTH_LONG).show();
    	}
        super.onResume();
    }
    
	private final Runnable mStatusChecker = new Runnable()
	{
	    @Override 
	    public void run() 
	    {
			//Toast.makeText(getActivity() ,String.format("Checkpoint") , Toast.LENGTH_LONG).show();    		

	    	updateStatus(); //this function can change value of mInterval.
			mHandler.removeCallbacks(mStatusChecker);
	    	mHandler.postDelayed(mStatusChecker, Const.prime_deltat_ms);
	    }
	};
	
	private void startRepeatingTask() 
	{
		mStatusChecker.run(); 
	}

    private void stopRepeatingTask()
    {
	    mHandler.removeCallbacks(mStatusChecker);
	}
    
	// ----------------------------------------------------------------------
    // update list view with current status
	// ----------------------------------------------------------------------
	private void updateStatus()
	{
		if (checkpointListArray.size()>0)
		{
			//update the list values with current information
			wp.getCheckpointStatus(checkpointListArray);

		}
		if (adapter!=null)
		{
			//Toast.makeText(getActivity() ,String.format("LA = %d",checkpointListArray.size()) , Toast.LENGTH_LONG).show();

			int pos = wp.getCheckpointIndextoMapped(WayPointMission.selected_cp_index);	
			if (pos>=0)
			{
				adapter.updateSelected(pos);
			}
			adapter.notifyDataSetChanged();

		}
	}

	// ----------------------------------------------------------------------
	// RestDialog
	// ----------------------------------------------------------------------
	private void RestDialog(final Context activity, final int cp_idx)
	{

        final Dialog myDialog = new Dialog(activity);
        
        try 
        {
        	Objects.requireNonNull(getActivity()).requestWindowFeature(Window.FEATURE_NO_TITLE );
        	
        } 
        catch (Exception e) 
        {
		    e.printStackTrace();
        }
        
        myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        myDialog.setContentView(R.layout.dialog_rest_time);
        myDialog.setTitle("");
        myDialog.setCancelable(true);
        
        TextView rest_text = myDialog.findViewById(R.id.rest_hr);
        SeekBar seekbar = myDialog.findViewById(R.id.seekBar1);
               
        double rest = globals.checkPointTimes.get(cp_idx).rest_hr;
        seekbar.setProgress((int) (rest*10));
    	rest_text.setText(String.format("%1.1f",rest));

    	seekbar.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
	    {
	    	
			@Override
	        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
	        {
		        EditText rest_text = myDialog.findViewById(R.id.rest_hr);
	        	String txt = String.format("%3.1f",progress/10.0);
	        	rest_text.setText(txt);
	        }

			@Override
			public void onStartTrackingTouch(SeekBar arg0) 
			{
			}

			@Override
			public void onStopTrackingTouch(SeekBar arg0) 
			{
			}
	    });

        Button ok_button = myDialog.findViewById(R.id.ok_button);
        ok_button.setOnClickListener(v -> {
            TextView rest_text1 = myDialog.findViewById(R.id.rest_hr);
            String testStr = rest_text1.getText().toString();
            globals.checkPointTimes.get(cp_idx).rest_hr = ClassUtility.toDouble(testStr, globals.checkPointTimes.get(cp_idx).rest_hr);
            if (!globals.settings.freeze_baseline_plan) globals.checkPointTimes.get(cp_idx).plan_rest_hr = globals.checkPointTimes.get(cp_idx).rest_hr;
            myDialog.dismiss();
           updateStatus();
        });

        Button cancel_button = myDialog.findViewById(R.id.cancel_button);
        cancel_button.setOnClickListener(v -> myDialog.dismiss());
        myDialog.show();
    }
	

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private boolean update()
	{
    	// Get ListView object from xml
		ListView listView = v.findViewById(R.id.listView1);
		if (listView ==null)
		{
			return (false);  //pop out of update if screen not drawn
		}
						
		// Defined Array values to show in ListView
   	    wp.getCheckpointStatus(checkpointListArray);
   	 
   	    // setup an adapter to display the upcoming_races
   	    if (adapter==null || list_array_count!= checkpointListArray.size())
   	    {
   	    	listView.setAdapter(null); 

   	    	//Toast.makeText(getActivity() ,String.format("Init") , Toast.LENGTH_LONG).show();    		
   	    	
   			adapter = new CheckpointEtaAdapter(getActivity(), checkpointListArray, 0);
   			
   			list_array_count = checkpointListArray.size();
   			
   	    	listView.setAdapter(adapter); 
   	    	
   	   	    // ListView RaceEvent Click Listener
   	   	    listView.setOnItemClickListener((parent, view, position, id) -> {
                          int wpIdx = wp.getMappedCheckpointIndex(position);
                          if (wpIdx>=0)
                          {
                         WayPointMission.selected_cp_index = wpIdx;
                         adapter.updateSelected(position);
                          }
                          updateStatus();

               });
   	   	    
   	   	    // Long listview click listener
   	   	    listView.setOnItemLongClickListener((arg0, arg1, pos, id) -> {
                    int wpIdx = wp.getMappedCheckpointIndex(pos);
                    if (wpIdx>=0)
                    {
                     WayPointMission.selected_cp_index = wpIdx;
                     RestDialog(getActivity(), wpIdx);
                    }
                    updateStatus();

                    return true;
                });
   	    }
   	 
   	    //move to next check point in list
   	    int cpIdx;
   	    if (wp.isValidCPIndex(WayPointMission.selected_cp_index))
   	    {
   	    	cpIdx = WayPointMission.selected_cp_index;
   	    }
   	    else
   	    {
   	    	cpIdx = wp.getNextCheckPointIndex(0.1,true);
   	    }
   	    
   	    int idx = wp.getCheckpointIndextoMapped(cpIdx);
   	    
   	    if (idx>=0) 
    	{
   	    	listView.setSelection(idx);
   	    	adapter.updateSelected(idx);
    	} 
   	    adapter.notifyDataSetChanged();
 
   	    return(true);
	}

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) 
	{
		menu.add(0, 0, 0, "Toggle Checkpoints Only");
    }
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
        int idx = item.getItemId();
		if (idx == 0) {
			globals.settings.displayCheckpointsOnly = !globals.settings.displayCheckpointsOnly;
		} else {
			super.onOptionsItemSelected(item);
		}
		return update();
	}

}
