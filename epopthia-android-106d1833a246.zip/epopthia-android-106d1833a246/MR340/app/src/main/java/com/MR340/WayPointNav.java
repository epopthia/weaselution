package com.MR340;

import static java.lang.Math.*;

public class WayPointNav 
{

	
	private double earth_a_ft = 20925646.325459316;

	public class vector
	{
		public double[] v ;
		vector()
		{
			v = new double[3];
		}
	}
	
	
	//-----------------------------------------------------------------------------
	//  ne_to_latlon
	//  Procedure to convert from North and East distances in feet to latitude and
	//  longitude in radians.  This assumes _a reference latitude and longitude.
	//-----------------------------------------------------------------------------
	public WayPoint ne_to_latlon(double north, double east, double ref_lat_rad, double ref_lon_rad, double latitude, double longitude)
	{
		WayPoint wp_out = new WayPoint();
	    double Re_ft = 2.09256463254593E+07;
	    wp_out.latitude  = ref_lat_rad + north / Re_ft;
	    wp_out.longitude = ref_lon_rad + east / (Re_ft * cos(ref_lat_rad));
	    return (wp_out);
	}
	
	//------------------------------------------------------------------------------
	//Function:       VectorCross3D
	//Description:    3D cross product  a X b
	//Arguments:      a
	//              b
	//              cross_prod_out
	//Return value:   cross_prod_out
	//------------------------------------------------------------------------------
	public vector VectorCross3D(vector a, vector b)
	{
		vector cross_prod_out = new vector();
		cross_prod_out.v[0] = a.v[1]*b.v[2] - a.v[2]*b.v[1];
		cross_prod_out.v[1] = a.v[2]*b.v[0] - a.v[0]*b.v[2];
		cross_prod_out.v[2] = a.v[0]*b.v[1] - a.v[1]*b.v[0];
		return(cross_prod_out);
	}

	//------------------------------------------------------------------------------
	//Function:       VectorNorm3D
	//Description:    Function to compute a norm of a 3D vector
	//Arguments:      a
	//Return value:   norm
	//------------------------------------------------------------------------------
	public double VectorNorm3D(vector a)
	{
		return sqrt(a.v[0]*a.v[0] + a.v[1]*a.v[1] + a.v[2]*a.v[2]);
	}

	//-----------------------------------------------------------------------------
	//function:      VectorDot3D
	//description:   Compute the dot product between 2 vectors A.B = C
	//arguments:     A   - vector source  0
	//              B   - vector source  1
	//return:        dot product
	//-----------------------------------------------------------------------------
	public double VectorDot3D(vector a, vector b)
	{
		int inx;
		double dp = 0;
		for (dp=0.0,inx=0;inx<3;inx++)
		{
		    dp+=(a.v[inx]*b.v[inx]);
		}
		return(dp);
	}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitRadialVector
	//description:   Given a lat/lon compute the unit radial vector
	//arguments:     double latitude_rad, double longitude_rad, double ur.v[3]
	//return:        ur
	//-----------------------------------------------------------------------------
	public vector ComputeUnitRadialVector(double latitude_rad, double longitude_rad)
	{
		double gd_e2 = 0.00669437999013;
	 	double gd_two_e2_minus_e4 = 0.013343945256807746;
		
		double sin_lat;
		double sin_lon;
		double cos_lat;
		double cos_lon;
		double two_e2_minus_e4_1;
		double radial_magnitude;
		
		vector ur = new vector();
		
		//Sine( u )
		sin_lat = sin(latitude_rad);
		sin_lon = sin(longitude_rad);
		//Cosine( u )
		cos_lat = cos(latitude_rad);
		cos_lon = cos(longitude_rad);
		two_e2_minus_e4_1 = 1.0 - gd_two_e2_minus_e4*sin_lat*sin_lat;
		//Square Root
		radial_magnitude = sqrt(two_e2_minus_e4_1);
		
		ur.v[0] = cos_lat*cos_lon/radial_magnitude;
		ur.v[1] = cos_lat*sin_lon/radial_magnitude;
		ur.v[2] = (1.0 - gd_e2)*sin_lat/radial_magnitude;
		
		return (ur);
	}

//-----------------------------------------------------------------------------
//function:      NormalizeVector
//description:
//arguments:
//return:        v_out
//-----------------------------------------------------------------------------
public vector NormalizeVector(vector v_in)
{
	
	vector v_out = new vector();
	double mag_v_in_sq;
	double Normalize_Vector_1_1;
	double check_val_out;
	int i;

	mag_v_in_sq = 0.0;
	for (i=0; i<3; i++) 
	{
		mag_v_in_sq += v_in.v[i]*v_in.v[i];
	}
	Normalize_Vector_1_1 = sqrt(mag_v_in_sq);
	
	check_val_out = Normalize_Vector_1_1;
	
	if ((abs(Normalize_Vector_1_1) < 1.0E-008)) 
	{
		check_val_out = 1.0E-008;
	}
	
	//normalize
	for (i=0; i<3; i++) 
	{
		v_out.v[i] = v_in.v[i]/check_val_out;
	}
	
	return(v_out);
}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitNormalVector
	//description:
	//arguments:     double ur1[3] ,double ur2[3]
	//return:        un
	//-----------------------------------------------------------------------------
	public vector ComputeUnitNormalVector(vector ur1 ,vector ur2)
	{
		vector un1 = new vector();
		
		//Compute Unit Normal Vector via the cross product
		un1.v[0] = ur2.v[1]*ur1.v[2] - ur2.v[2]*ur1.v[1];
		un1.v[1] = ur2.v[2]*ur1.v[0] - ur2.v[0]*ur1.v[2];
		un1.v[2] = ur2.v[0]*ur1.v[1] - ur2.v[1]*ur1.v[0];
		
		//Normalize Vector
		return (NormalizeVector(un1));
		
	}

	//-----------------------------------------------------------------------------
	//function:      ComputeUnitTangentialVector
	//description:   Compute Unit Tangential Vector
	//arguments:     double un[3] ,double ur.v[3] ,double ut[3]
	//return:        un
	//-----------------------------------------------------------------------------
	public vector ComputeUnitTangentialVector(vector un ,vector ur)
	{
		return (VectorCross3D(un, ur));
	}


	//-----------------------------------------------------------------------------
	// function:      RangeBearingToLatLon
	// description:   Convert range and bearing data to lat and lon
	// arguments:     latitude_rad - reference lat
	//					longitude_rad - reference lon
	//					heading_rad - bearing rel. to true north from ref location
	//					double distance_ft - dist(ft)
	//					double *latitude_out
	//					double *longitude_out
	// return:        latitude_out and longitude_out thru argument pointers
	//-----------------------------------------------------------------------------
	public WayPoint RangeBearingToLatLon(double latitude_rad, double longitude_rad, double heading_rad, double distance_ft)
	{
		
		double lat_rad, hdg_rad, dist_rad, clat_in, slat_in;
		double chdg_in, shdg_in, cdist_in, sdist_in, slat_out, lat_out_rad;
		double clat_out, delta_longitude, sdlong;
		double eps = 1.0e-14;
		double Re_ft = 2.09256463254593E+07;
		
		WayPoint wp_out = new WayPoint();
	
		lat_rad  = latitude_rad;
		hdg_rad  = heading_rad;
		dist_rad = distance_ft / Re_ft;
		clat_in  = cos( lat_rad );
		slat_in  = sin( lat_rad );
		chdg_in  = cos( hdg_rad );
		shdg_in  = sin( hdg_rad );
		cdist_in = cos( dist_rad );
		sdist_in = sin( dist_rad );
	
		slat_out     = slat_in * cdist_in + clat_in * sdist_in * chdg_in;
		lat_out_rad  = asin( slat_out );
		clat_out     = cos( lat_out_rad );
	
		if ( abs(clat_out) < eps ) //divide by zero protection
			delta_longitude = 0.0;
		else
		{
			sdlong          = ( sdist_in * shdg_in ) / clat_out;
			delta_longitude = asin( sdlong );
		}
		
		wp_out.longitude = longitude_rad + delta_longitude;
		wp_out.latitude = lat_out_rad;
	  
		return(wp_out);
	}

	//-----------------------------------------------------------------------------
	//function:      DistBetweenWaypoints
	//description:   Calculate the distance between waypoints in feet
	//arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	//return:        distance_ft
	//-----------------------------------------------------------------------------
	double DistBetweenWaypoints(double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	{
		double distance_ft = 0.0;

		vector ur1 = ComputeUnitRadialVector(lat1_rad, lon1_rad);
		vector ur2 = ComputeUnitRadialVector(lat2_rad, lon2_rad);
		vector un = ComputeUnitNormalVector(ur1 ,ur2);
		vector ut = ComputeUnitTangentialVector(un, ur2);
		distance_ft = VectorDot3D(ur1, ut) * earth_a_ft;
		
		return(distance_ft);
	}

	//-----------------------------------------------------------------------------
	// function:      DistToWayPoint
	// description:   Calculate the distance between waypoints in feet
	// arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	// return:        distance_ft
	//-----------------------------------------------------------------------------
	public double DistToWayPoint(WayPoint past_wp, WayPoint curr_wp, WayPoint curr_pos)
	{
	//	int inx;
		
		// unit radials
		vector ur_curr_pos = ComputeUnitRadialVector(curr_pos.latitude, curr_pos.longitude);
		vector ur_past_wp = ComputeUnitRadialVector(past_wp.latitude, past_wp.longitude);
		vector ur_curr_wp = ComputeUnitRadialVector(curr_wp.latitude, curr_wp.longitude);

		// unit normal prev to curr WayPoint
		vector un_past_curr_wp = ComputeUnitNormalVector(ur_past_wp,ur_curr_wp);
		
		// unit tangential prev to curr
		vector ut_past_curr_wp = ComputeUnitTangentialVector(un_past_curr_wp, ur_curr_wp);

		double distance_ft = VectorDot3D(ut_past_curr_wp, ur_curr_pos) * earth_a_ft;
		
	/*	
		// cross track component
		double cp = VectorDot3D(un_past_curr_wp, ur_curr_pos);
		vector cross_track = new vector();
		for(inx=0;inx<3;inx++)
		{
			cross_track.v[inx] = un_past_curr_wp.v[inx] * cp;
		}
		
		// ur_projected
		vector projected = new vector();
		for(inx=0;inx<3;inx++)
		{
			projected.v[inx] = ur_curr_pos.v[inx] - cross_track.v[inx];
		}

		vector ur_projected = NormalizeVector(projected);

		double distance_ft = VectorDot3D(ur_projected, ut_past_curr_wp) * earth_a_ft;
		*/
		
		return(distance_ft);
	}
	
	//-----------------------------------------------------------------------------
	// function:      CrossTrack
	// description:   Calculate the current cross track error
	// arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
	// return:        distance_ft
	//-----------------------------------------------------------------------------
	public double CrossTrack(WayPoint past_wp, WayPoint curr_wp, WayPoint curr_pos)
	{
		
		// unit radials
		vector ur_curr_pos = ComputeUnitRadialVector(curr_pos.latitude, curr_pos.longitude);
		vector ur_past_wp = ComputeUnitRadialVector(past_wp.latitude, past_wp.longitude);
		vector ur_curr_wp = ComputeUnitRadialVector(curr_wp.latitude, curr_wp.longitude);

		// unit normal prev to curr WayPoint
		vector un_past_curr_wp = ComputeUnitNormalVector(ur_past_wp,ur_curr_wp);
		
		// cross track component
		double cross_track_err_ft = VectorDot3D(un_past_curr_wp, ur_curr_pos) * earth_a_ft;
		return(cross_track_err_ft);
	}
	
}


