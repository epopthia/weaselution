package com.MR340;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
//import java.util.Random;
import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import static java.lang.Math.*;

public class MainActivity extends Activity implements LocationListener
{
	
	WayPointNav nav;
    WayPoint wp1; 
    WayPoint wp2; 
    WayPoint curr_pos; 
    WayPoint[] wps; 
    WayPoint[] cps;
    WayPoint[] rms;
    int wp_count;
    int curr_wp_index = 1;
    int cp_count;
    int rm_count;

    double ref_mile = 0.0;
    Date ref_time;
    Date last_tone_time;
    
    double avg_speed_mph = 0.0;
    
    boolean initialized = false;
   
    Button reset_speed_btn;
    TextView CrossTrackField; 
	TextView RiverMileField;
	SeekBar seekbar;
	
	ToneGenerator toneG;
	AudioManager audio;
	
    public int crosstrack_threshold_ft = 0;
	
	private LocationManager locationManager;
	private String provider;
	
  
	private final double rtd = 180.0/3.141592653589793238462643383279502884197169399375105820974944592;
	private final double dtr = 1.0/rtd;
			
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
	    super.onCreate(savedInstanceState);
	    
	    setContentView(R.layout.activity_main);
	    
	    if (!initialized)
	    {
		    nav = new WayPointNav();
		    wp1 = new WayPoint();
		    //wp2 = new WayPoint();
		    curr_pos = new WayPoint();
		    
		    //Read the waypoints
		    wp_count = ReadWaypoints();
	
		    //Read the rivermiles
		    rm_count = ReadRiverMiles();
		    
		    //update the waypoints with the appropriate river mile
		    int jnx;
		    int inx;
	    	for(inx=1,jnx=0;inx<wp_count&&jnx<rm_count;inx++)
	    	{
			    double dist_to_wp_ft = nav.DistToWayPoint(wps[inx-1], wps[inx], rms[jnx]);
			    if (dist_to_wp_ft>=0.0)
			    {
			    	wps[inx].rivermile = rms[jnx].rivermile;
			    	jnx++;
			    }
			    else
			    {
			    	wps[inx].rivermile = rms[jnx].rivermile-0.000189393939*dist_to_wp_ft; //0.000164578834*dist_to_wp_ft;//nautical
			    }
	    	}
		    
		    //Read the checkpoints
		    cp_count = ReadCheckpoints();
		    
		    
		    CrossTrackField = (TextView) findViewById(R.id.crosstrack);
		    RiverMileField = (TextView) findViewById(R.id.rivermile); 
		    reset_speed_btn = (Button) findViewById(R.id.button1);
		    
		    // Get the location manager
		    locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		    
		    // Define the criteria how to select the location provider -> use
		    // default
		    Criteria criteria = new Criteria();
		    criteria.setAccuracy(Criteria.ACCURACY_FINE);
		    criteria.setSpeedAccuracy(Criteria.ACCURACY_HIGH);
		    criteria.setBearingAccuracy(Criteria.ACCURACY_HIGH);
		    criteria.setBearingRequired(true);
		    criteria.setSpeedRequired(true);
		    
		    provider = locationManager.getBestProvider(criteria, false);
		    
		    Location location = locationManager.getLastKnownLocation(provider);
	
		    // seek bar
		    seekbar = (SeekBar) findViewById(R.id.seekbar1);
		    seekbar.setOnSeekBarChangeListener( new OnSeekBarChangeListener()
		    {
		        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
		        {
		            // TODO Auto-generated method stub
		            //value.setText("SeekBar value is "+progress);
		        	crosstrack_threshold_ft = progress*2;
		        }

				@Override
				public void onStartTrackingTouch(SeekBar arg0) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void onStopTrackingTouch(SeekBar arg0) {
					// TODO Auto-generated method stub
					
				}
		    });
		    
		    
		    // show location button click event
		    reset_speed_btn.setOnClickListener(new View.OnClickListener() 
		    {
	            @Override
	            public void onClick(View arg0) 
	            {        
		    		// reference mile and time for use in average speed calc
		    		ref_mile = wps[curr_wp_index].rivermile;
		    		ref_time = new Date();
	            }
	 	    });
		    // Initialize the location fields
		    if (location != null) 
		    {
		    	Toast.makeText(this, "Provider " + provider + " has been selected.",
		    	        Toast.LENGTH_SHORT).show();
	
		    	onLocationChanged(location);
		    } 
		    else 
		    {
	//	      latituteField.setText("Location not available");
	//	      longitudeField.setText("Location not available");
		    }

		
		    // Setup tone generator for tied to the notification volume
		    // note: seems to be a bug in android that will crash the app
		    // if create too many new instances of the tone generator
		    // therefore make this a static instance
	    	toneG = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, (int) (100));
	    
	    } //!initialized
    }	

	  /* Request updates at startup */
	  @Override
	  protected void onResume() 
	  {
		  super.onResume();
		  locationManager.requestLocationUpdates(provider, 400, 1, this);
	  }

	  /* Remove the location listener updates when Activity is paused */
	  @Override
	  protected void onPause() 
	  {
	    super.onPause();
	    //locationManager.removeUpdates(this);
	  
	  }
	  @Override
	  public void onBackPressed() {
	      // TODO Auto-generated method stub
	      super.onBackPressed();
	      locationManager.removeUpdates(this);
	  }

	  //private int passcount = 0;
	  @Override
	  public void onLocationChanged(Location location) 
	  {
	    double lat = location.getLatitude();
	    double lng = location.getLongitude();
    	
    	//int max = 39208;
    	//int min = 38678;
    	//Random r = new Random();
    	//lat = ((double) r.nextInt(max - min + 1) + min)/1000.0;
    	
    	//min = -94331;
    	//max = -91827;
    	//r = new Random();
    	//lng = ((double) r.nextInt(max - min + 1) + min)/1000.0;
	    
	    // near KC
	    //lat = 39.20896389;
	    //lng = -94.33191944;

	    // near franklin island
	    //lat = 38.98001389;
	    //lng = -92.82776944;
	    
	    //lat  = 38.67865556;
	    //lng = -91.82796111;
	    
	    // near robinson, IL
	    //lat = 39.00531944;
	    //lng = -87.73919444;
	    
	    double speed_mps = location.getSpeed();
	    double speed_mph = speed_mps * 2.2369362920544;
	    //double bearing_deg = location.getBearing();
	    	    
	    curr_pos.latitude = lat*dtr;
	    curr_pos.longitude = lng*dtr;
	    
	    //if (wp1.valid && wp2.valid)
	    if (curr_wp_index<wp_count && wps[curr_wp_index].valid && wps[curr_wp_index-1].valid)
	    {
	    	if (!initialized)
	    	{
	    		double min_dist = abs(nav.DistBetweenWaypoints(wps[curr_wp_index].latitude, wps[curr_wp_index].longitude, curr_pos.latitude, curr_pos.longitude));
	    		int jnx;
	    		for (jnx=0;jnx<wp_count-1;jnx++)
	    		{
	    			double min_dist_test = abs(nav.DistBetweenWaypoints(wps[jnx].latitude, wps[jnx].longitude, curr_pos.latitude, curr_pos.longitude));
	    			if (min_dist_test<min_dist)
	    			{
	    				curr_wp_index = jnx+1;
	    				min_dist = min_dist_test;
	    			}
	    		}
	
	    		// reference mile and time for use in average speed calc
	    		ref_mile = wps[curr_wp_index].rivermile;
	    		ref_time = new Date();
	    		initialized = true;
	    		
	    		last_tone_time = new Date();
	    	}
	    	
		    double dist_to_wp_ft = nav.DistToWayPoint(wps[curr_wp_index-1], wps[curr_wp_index], curr_pos);
		    
		    //cycle the waypoint
		    while(curr_wp_index<wp_count-1 && dist_to_wp_ft<0) 
	    	{
		    	curr_wp_index++;
			    //WayPointNumField.setText(String.valueOf(curr_wp_index));
		    	dist_to_wp_ft = nav.DistToWayPoint(wps[curr_wp_index-1], wps[curr_wp_index], curr_pos);
	    	}
		    double cross_track_err_ft = nav.CrossTrack(wps[curr_wp_index-1], wps[curr_wp_index], curr_pos);
		    
		    //calc the average speed
		    Date tmp_time = new Date();
		    double deltat_s = (double) (tmp_time.getTime() - ref_time.getTime()) / 1000.0;
		    double delta_mile = (ref_mile - wps[curr_wp_index].rivermile );
		    
		    if (deltat_s>0 && abs(delta_mile)>0)
		    {
		    	avg_speed_mph = delta_mile/deltat_s*3600.0;
		    }
		    else
		    {
		    	avg_speed_mph = speed_mph;
		    }

		    //check points
		    //find start of future checkpoints
		    int cp_inx = 0;
		    for (cp_inx=0;cp_inx<cp_count && (cps[cp_inx].rivermile - wps[curr_wp_index-1].rivermile)>0;cp_inx++);

		    //create info string
		    String info_str = "";
		    info_str += String.format("%s = %1.1f\n","River Mile", wps[curr_wp_index].rivermile);

		    //check point string
		    String cp_string = "";
		    for (int inx=cp_inx;inx<cp_count-1 && inx<(cp_inx+5);inx++)
		    {
		    	cp_string += (GetCheckpointData(inx)+"\n");
		    }
		    cp_string += GetCheckpointData(cp_count-1);
		    info_str += cp_string;
		    info_str += String.format("\n%s = %d (%1.0f)", "Waypoint", curr_wp_index, dist_to_wp_ft);
		    //if (crosstrack_threshold_ft>0) info_str += String.format("\n%s = %d", "Cross Track Warning", crosstrack_threshold_ft);
		    //else info_str += String.format("\n%s = %s", "Cross Track Warning", "inf");
	    	RiverMileField.setText(info_str);
	    	
	    	// Set the speed and Cross track field
	    	CrossTrackField.setText(String.format("%02.1f\t(%02.1f)\n%1.0f",speed_mph, avg_speed_mph, cross_track_err_ft));
	    		    	
	    	// Create tone if cross track is too big
	    	if (crosstrack_threshold_ft>0 && abs(cross_track_err_ft) >= crosstrack_threshold_ft ) 
	    	{
	    		if (cross_track_err_ft>0.0)
	    		{
	    			toneG.startTone(ToneGenerator.TONE_CDMA_ABBR_INTERCEPT, 100); // 200 is duration in ms
	    			toneG.startTone(ToneGenerator.TONE_PROP_BEEP, 100); // 200 is duration in ms
	    		}
	    		else
	    		{
	    			toneG.startTone(ToneGenerator.TONE_PROP_BEEP, 100); // 200 is duration in ms
	    			toneG.startTone(ToneGenerator.TONE_CDMA_ABBR_INTERCEPT, 100); // 200 is duration in ms
	    		}
	    	}
	    }
	  }
	  

	  @Override
	  public void onStatusChanged(String provider, int status, Bundle extras) {
	    // TODO Auto-generated method stub

	  }

	  @Override
	  public void onProviderEnabled(String provider) 
	  {
		  Toast.makeText(this, "Enabled new provider " + provider,
	        Toast.LENGTH_SHORT).show();

	  }

	  @Override
	  public void onProviderDisabled(String provider) 
	  {
	    Toast.makeText(this, "Disabled provider " + provider,
	        Toast.LENGTH_SHORT).show();
	  }	
	
	  public String WaypointFile = "waypoints.csv";
	  
		public int ReadWaypoints()
		{
			String myData = "";
			int wp_count = 0; 
			int jnx;
			
			AssetManager assetManager = this.getAssets();
			
				try
				{
					InputStreamReader istrm = new InputStreamReader (assetManager.open(WaypointFile));
					BufferedReader br = new BufferedReader(istrm);
					String strLine;
					
					StringBuilder sb_content = new StringBuilder();

					while ((strLine = br.readLine()) != null) 
					{
						sb_content.append(strLine);
						sb_content.append("\n");
					}
					istrm.close();
					
					//parse the input buffer into waypoints
					myData = sb_content.toString();
					String mlines[] =  myData.split("\n",wp_count);
					wp_count = mlines.length;
					
					wps = new WayPoint[wp_count]; 
					
					for (jnx=0;jnx<wp_count;jnx++)
					{
						String mtoks[] = mlines[jnx].split(",",2);
						
						double tmp1 = Double.parseDouble(mtoks[1]) * dtr;
					    double tmp2 = Double.parseDouble(mtoks[0]) * dtr;
						
					    wps[jnx] = new WayPoint();
						wps[jnx].latitude =  tmp1;
						wps[jnx].longitude = tmp2;
						wps[jnx].valid = true;
					}					
				} 
				catch (IOException e) 
				{
				    e.printStackTrace();
				}
				
		    	//Toast.makeText(this, "Total Waypoints = " + wp_count,
			    //    Toast.LENGTH_SHORT).show();
		
			return(wp_count);
		}

		private String RiverMilesFile = "river_miles.csv";
		public int ReadRiverMiles()
		{
		    String myData = "";
		    int wp_count = 0; 
		    int jnx;

		    AssetManager assetManager = this.getAssets();
		    try
		    {
		        InputStreamReader istrm = new InputStreamReader (assetManager.open(RiverMilesFile));
		        BufferedReader br = new BufferedReader(istrm);
		        String strLine;

		        StringBuilder sb_content = new StringBuilder();

		        while ((strLine = br.readLine()) != null) 
		        {
		            sb_content.append(strLine);
		            sb_content.append("\n");
		        }
		        istrm.close();

		        //parse the input buffer into river_miles
		        myData = sb_content.toString();
		        String mlines[] =  myData.split("\n",wp_count);
		        wp_count = mlines.length;

		        rms = new WayPoint[wp_count]; 

		        for (jnx=0;jnx<wp_count;jnx++)
		        {
		            String mtoks[] = mlines[jnx].split(",",3);

		            double tmp_lat_rad = Double.parseDouble(mtoks[1]) * dtr;
		            double tmp_lon_rad = Double.parseDouble(mtoks[0]) * dtr;
		            double tmp_rivermile = Double.parseDouble(mtoks[2]);

		            rms[jnx] = new WayPoint();
		            rms[jnx].latitude =  tmp_lat_rad;
		            rms[jnx].longitude = tmp_lon_rad;
		            rms[jnx].rivermile = tmp_rivermile;
		            rms[jnx].valid = true;

		        }                   
		    } 
		    catch (IOException e) 
		    {
		        e.printStackTrace();
		    }

		    //Toast.makeText(this, "Total river_miles = " + wp_count,
		    //    Toast.LENGTH_SHORT).show();

		    return(wp_count);
		}

		public String CheckpointsFile = "checkpoints.csv";
		public int ReadCheckpoints()
		{
		    String myData = "";
		    int wp_count = 0; 
		    int jnx;

		    AssetManager assetManager = this.getAssets();
		    try
		    {
		        InputStreamReader istrm = new InputStreamReader (assetManager.open(CheckpointsFile));
		        BufferedReader br = new BufferedReader(istrm);
		        String strLine;

		        StringBuilder sb_content = new StringBuilder();

		        while ((strLine = br.readLine()) != null) 
		        {
		            sb_content.append(strLine);
		            sb_content.append("\n");
		        }
		        istrm.close();

		        //parse the input buffer into river_miles
		        myData = sb_content.toString();
		        String mlines[] =  myData.split("\n",wp_count);
		        wp_count = mlines.length;

		        cps = new WayPoint[wp_count]; 

		        for (jnx=0;jnx<wp_count;jnx++)
		        {
		            String mtoks[] = mlines[jnx].split(",",4);

		            double tmp_lat_rad = Double.parseDouble(mtoks[1]) * dtr;
		            double tmp_lon_rad = Double.parseDouble(mtoks[0]) * dtr;
		            double tmp_rivermile = Double.parseDouble(mtoks[2]);

		            cps[jnx] = new WayPoint();
		            cps[jnx].latitude =  tmp_lat_rad;
		            cps[jnx].longitude = tmp_lon_rad;
		            cps[jnx].rivermile = tmp_rivermile;
		            cps[jnx].label = mtoks[3];
		            cps[jnx].valid = true;
		        }                   
		    } 
		    catch (IOException e) 
		    {
		        e.printStackTrace();
		    }

		    //Toast.makeText(this, "Total check points = " + wp_count,
		     //   Toast.LENGTH_SHORT).show();

		    return(wp_count);
		}

		  // ----------------------------------------------------------------------
		  //  GetCheckpointData
		  // ----------------------------------------------------------------------
		  private String GetCheckpointData(int cp_index)
		  {
			  
			  double delta_mile;
			  double eta; 
			  String cp_string = "";

			  delta_mile = wps[curr_wp_index-1].rivermile - cps[cp_index].rivermile;
			  
			  if (avg_speed_mph>0.0)
				{
				  eta = delta_mile / avg_speed_mph;
				  float eta_hr = (float) ((int) (eta));
			      float eta_min = (float) ((eta - eta_hr) * 60);
				  
				  cp_string += String.format("%1.0f:%1.0f, %3.1f, %3.1f - %s",eta_hr, eta_min, delta_mile, cps[cp_index].rivermile, cps[cp_index].label);
				}
				else
				{
					  cp_string += String.format("DNF, %3.1f, %3.1f - %s",delta_mile, cps[cp_index].rivermile, cps[cp_index].label);
				}

			  return(cp_string);
		  }

}
