package com.MR340;

public class WayPoint {
	
	public double latitude;
	public double longitude;
	public double rivermile;
	public String label;
	public boolean valid;   
	WayPoint()
	{
		latitude = 0.0;
		longitude = 0.0;
		rivermile = 0.0;
		valid = false;
	}
	
	/*
	public void setlatitude(double lat)
	{
		latitude = lat;
	}
	
	public double getlatitude()
	{
		return (latitude);
	}
	public void setlongitude(double lon)
	{
		longitude = lon;
	}
	
	public double getlongitude()
	{
		return (longitude);
	}
	
	*/
}
