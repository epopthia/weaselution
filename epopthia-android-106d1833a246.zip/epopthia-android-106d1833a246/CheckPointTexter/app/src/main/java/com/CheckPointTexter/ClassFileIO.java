package com.CheckPointTexter;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class ClassFileIO {

	ClassFileIO()
	{
	}

	// ----------------------------------------------------------------------
	// ReadCheckpoints
	// ----------------------------------------------------------------------
	//public String CheckpointsFile = "checkpoints.csv";
	CheckPoint[]  ReadCheckpoints(Context mCtx, String CheckpointsFile)
	{
	    String myData;

	    CheckPoint[] cps = null;
	    int wp_count = 0;
	    int jnx;
	    AssetManager assetManager = mCtx.getAssets();
	    try
	    {
	    	InputStreamReader i_stream;
			i_stream = new InputStreamReader (assetManager.open(CheckpointsFile));
			BufferedReader br = new BufferedReader(i_stream);
	        String strLine;

	        StringBuilder sb_content = new StringBuilder();

	        while ((strLine = br.readLine()) != null)
	        {
	            sb_content.append(strLine);
	            sb_content.append("\n");
	        }
	        i_stream.close();

	        //parse the input buffer into river_miles
	        myData = sb_content.toString();
			String[] m_lines = myData.split("\n", wp_count);
	        wp_count = m_lines.length;

	        cps = new CheckPoint[wp_count];

	        for (jnx=0;jnx<wp_count;jnx++)
	        {
				String[] m_tokens = m_lines[jnx].split(",", 9);
	            cps[jnx] = new CheckPoint();
	            cps[jnx].label = m_tokens[3];
				cps[jnx].is_checkpoint = (Integer.parseInt(m_tokens[4])==1);
	        }
	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }

	    return(cps);
	}

}
