package com.CheckPointTexter;

@SuppressWarnings("CopyConstructorMissesField")
class AppSettings {
	private boolean is_soft_start; // true if this is a soft kill of the app by the OS
	String boat_number;
	String checkpoint_phone;
	int start_cp_idx;
	private boolean enable_sms;

	AppSettings()
	{
		is_soft_start = false;
		boat_number = "";
		start_cp_idx = 0;
		checkpoint_phone = "8163406395";
        enable_sms = true;
	}

	AppSettings(AppSettings ref)
	{
		CopySettings(ref, this);
	}

	void CopySettings(AppSettings src, AppSettings dst)
	{
		dst.boat_number = src.boat_number;
		dst.checkpoint_phone = src.checkpoint_phone;
		dst.start_cp_idx = src.start_cp_idx;
		dst.is_soft_start = src.is_soft_start;
		dst.enable_sms = src.enable_sms;
	}
}