package com.CheckPointTexter;

//import java.util.Date;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

import java.util.List;
import java.util.Vector;


public class ActivityMain extends AppCompatActivity
{

	private static final int MY_CHILD_ACTIVITY = 10;
	private static ClassAppSettings settings = null;


	private AppSettings last_settings = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{

		super.onCreate(savedInstanceState);
	   	setContentView(R.layout.viewpager_layout);

	   	initialisePaging();

	   	// new instance of settings
		settings = ClassAppSettings.getInstance(this);
		
		last_settings = new AppSettings(settings.app);

    }

	@Override
	public void onResume()
	{
		super.onResume();
        //registerReceiver(smsSentReceiver, new IntentFilter("SMS_SENT"));
  	  
	}

	@Override
	public void onPause()
	{
		super.onPause();
	}
	
	@Override
	protected void onDestroy() 
	{		
		settings.saveSettings();
		super.onDestroy();
	}
	
	private void initialisePaging() 
	{
		List<Fragment> fragments = new Vector<>();
		fragments.add(Fragment.instantiate(this,Frag01_SMS_message.class.getName()));
		//fragments.add(Fragment.instantiate(this,Frag02_Log.class.getName()));

		PagerAdapter mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
		ViewPager pager = findViewById(R.id.viewpager);
		pager.setAdapter(mPagerAdapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		if (item.getItemId() == R.id.action_settings) {
			Intent intent = new Intent(this, ActivitySettings.class);
			Bundle b = new Bundle();

			b.putString("boat_number_str", settings.app.boat_number);
			b.putString("checkpoint_phone", settings.app.checkpoint_phone);

			b.putInt("start_cp_idx", settings.app.start_cp_idx);

			b.putStringArray("checkpoints", settings.getAllCheckpointLabels());

			intent.putExtras(b); //Put your id to your next Intent
			startActivityForResult(intent, MY_CHILD_ACTIVITY);

			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == MY_CHILD_ACTIVITY) {
			if (resultCode == Activity.RESULT_OK) {
				Bundle extras = data.getExtras();
				if (extras != null) {

					settings.app.CopySettings(settings.app, last_settings);
					settings.app.boat_number = extras.getString("boat_number_str", settings.app.boat_number);

					String tmp_str = extras.getString("checkpoint_phone");
					if (tmp_str != null) settings.app.checkpoint_phone = tmp_str;

					settings.app.start_cp_idx = extras.getInt("start_cp_idx", settings.app.start_cp_idx);

					processSettingsChanges();
				}
			}
		}
	}

	// ------------------------------------------------------------------------
	//	processSettingsChanges
	// ------------------------------------------------------------------------
	private void processSettingsChanges()
	{	
		//write settings to non-volatile
		settings.saveSettings();
	}


	//---------------------------------------------------------------------------
	// onSaveInstanceState
	//---------------------------------------------------------------------------
	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) 
	{
	  super.onSaveInstanceState(savedInstanceState);
	  
	  savedInstanceState.putBoolean("is_soft_start", true);
	  settings.saveSettings();

	}


    //---------------------------------------------------------------------------
    // sendSMS - send an SMS to the message app
    //---------------------------------------------------------------------------
    public void sendSMS(String number, String message)
    {
        Uri uri = Uri.parse("smsto:" + number);
        Intent it = new Intent(Intent.ACTION_SENDTO, uri);
        it.putExtra("sms_body", message);
        startActivity(it);
    }

}
