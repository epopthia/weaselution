package com.CheckPointTexter;

import java.util.Date;
import android.text.format.DateFormat;

class ClassUtility
{

	static String getRaceOwlTextTime()
	{
		Date curr_date = new Date();
		return (String) DateFormat.format("EEE hh:mma", curr_date);
	}

	// ------------------------------------------------------------------------
	  //	isInteger
	  // ------------------------------------------------------------------------
	  static boolean isInteger(String str)
	  {
		  try 
		  {
			  Integer.parseInt(str);
			  return true;
		  } catch (NumberFormatException ignored) {}
		  return false;
	  }

}
