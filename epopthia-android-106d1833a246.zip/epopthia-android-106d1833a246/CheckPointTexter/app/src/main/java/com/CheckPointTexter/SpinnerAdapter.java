package com.CheckPointTexter;

import java.util.List;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

class SpinnerAdapter extends ArrayAdapter<String>
{
	@SuppressWarnings("SameParameterValue")
	SpinnerAdapter(Context context, int textViewResourceId, List<String> list)
	{
		super(context, android.R.layout.simple_spinner_item, textViewResourceId, list);
		setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	}

	@NonNull
	@Override
	public View getView(int position, View convertView, @NonNull ViewGroup parent)
	{
		TextView tv;
		tv = (TextView) super.getView(position, convertView, parent);

		tv.setTextColor(Color.WHITE);
		tv.setBackgroundColor(Color.BLACK);
		tv.setTypeface(Typeface.SANS_SERIF);
		tv.setTextSize(40f);
		tv.setGravity(Gravity.CENTER);
		return tv;
	}
}
   
