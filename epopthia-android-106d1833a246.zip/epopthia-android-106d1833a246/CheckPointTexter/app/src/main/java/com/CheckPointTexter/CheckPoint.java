package com.CheckPointTexter;

class CheckPoint
{
	// --Commented out by Inspection (12/26/18, 12:27 PM):double latitude;
	//double longitude;
	String label;
	boolean is_checkpoint;

	CheckPoint()
	{
		label = "no name CP";
		//latitude = 0.0;
		//longitude = 0.0;
		is_checkpoint = false;
	}
}