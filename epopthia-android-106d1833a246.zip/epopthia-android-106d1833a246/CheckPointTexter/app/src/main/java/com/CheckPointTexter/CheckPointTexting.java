package com.CheckPointTexter;

class CheckPointTexting {


	private final ClassAppSettings settings;

	// ----------------------------------------------------------------------
	// Constructor
	// ----------------------------------------------------------------------
	CheckPointTexting()
	{
		settings = ClassAppSettings.getInstance();
	}

	// ----------------------------------------------------------------------
	// isValidCPIndex
	// ----------------------------------------------------------------------
	private boolean isValidCPIndex(int idx) {
		boolean ret = false;

		if (settings.cps != null) {
			if (idx >= 0 && idx < settings.cps.length) {
				ret = true;
			}
		}
		return ret;
	}


	// ---------------------------------------------------------------------------
	// getCheckpointMessage
	// ---------------------------------------------------------------------------
	String getCheckpointMessage(int cp_idx, int selection_idx)
	{
		String msg = "";
		if (isTextingCheckPoint(cp_idx))
		{
			String in_out_dnf = "";
			switch(selection_idx)
			{
				case 0:
					in_out_dnf = "in";
					break;
				case 1:
					in_out_dnf = "out";
					break;
				case 2:
					in_out_dnf = "dnf";
					break;
			}

			String time_str = ClassUtility.getRaceOwlTextTime();

			msg = String.format("%s %s %s %s",  settings.app.boat_number, settings.cps[cp_idx].label, time_str, in_out_dnf);
		}
		return (msg);
	}

	// ---------------------------------------------------------------------------
	// isTextingCheckPoint
	// ---------------------------------------------------------------------------
	private boolean isTextingCheckPoint(int cp_idx) {
		boolean ret = false;
		if (isCheckPoint(cp_idx)) 
		{
			ret = true;
		}
		return ret;
	}

	// ---------------------------------------------------------------------------
	// isCheckPoint
	// ---------------------------------------------------------------------------
	private boolean isCheckPoint(int cp_idx) {
		boolean ret = false;
		if (isValidCPIndex(cp_idx)) {
			ret = settings.cps[cp_idx].is_checkpoint;
		}
		return ret;
	}

}
