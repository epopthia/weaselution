package com.CheckPointTexter;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class ActivitySettings extends Activity
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_settings);
		initActivity();

		Button settings_button_ok = this.findViewById(R.id.settings_button_ok);
		settings_button_ok.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				setResults();
			}
		});

		Button use_mr340_button = this.findViewById(R.id.use_mr340);
		use_mr340_button.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				EditText et = findViewById(R.id.checkpoint_phone);
				et.setText(("8163406395"));
			}
		});
	}


	//---------------------------------------------------------------------------
	// initActivity
	//---------------------------------------------------------------------------
	private void initActivity()
	{
		Intent myintent = getIntent();
		if (myintent!=null)
		{
			Bundle b = myintent.getExtras();
			if (b!=null)
			{
				EditText et = findViewById(R.id.checkpoint_phone);
				et.setText((b.getString("checkpoint_phone")));
			}
		}
	}

	//---------------------------------------------------------------------------
	// setResults
	//---------------------------------------------------------------------------
	private void setResults()
	{

		Intent resultIntent = getIntent();

		EditText et = findViewById(R.id.checkpoint_phone);
		resultIntent.putExtra("checkpoint_phone", et.getText().toString());

		setResult(Activity.RESULT_OK, resultIntent);
		finish();

	}

}
