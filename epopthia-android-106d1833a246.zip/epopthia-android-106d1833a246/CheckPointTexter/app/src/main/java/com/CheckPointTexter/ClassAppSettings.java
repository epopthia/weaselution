package com.CheckPointTexter;


import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

class ClassAppSettings {

	private static ClassAppSettings objClassAppSettings;

	// preferences
	private final SharedPreferences preferences;
	final AppSettings app;
	CheckPoint[] cps = null;


	// ----------------------------------------------------------------------
	// getInstance
	// ----------------------------------------------------------------------
	static synchronized ClassAppSettings getInstance(Context app_context)
	{
	    if(objClassAppSettings == null)
	    {
	    	objClassAppSettings = new ClassAppSettings(app_context);
	    }
	    return objClassAppSettings;
	}
	// ----------------------------------------------------------------------
	// getInstance
	// ----------------------------------------------------------------------
	static synchronized ClassAppSettings getInstance()
	{
		return objClassAppSettings;
	}


	// ----------------------------------------------------------------------
	// Constructor
	// ----------------------------------------------------------------------
	private ClassAppSettings(Context context) {
		Context mCtx;
		mCtx = context;
		preferences = PreferenceManager.getDefaultSharedPreferences(mCtx);
		app = new AppSettings();
		loadSettings();
		readCheckPoints(mCtx);

	}

	private void loadSettings() {
		app.boat_number = preferences.getString("boat_number_str", "");

		app.checkpoint_phone = preferences.getString("checkpoint_phone", "8163406395");
		assert app.checkpoint_phone != null;
		if (app.checkpoint_phone.length() <= 0)
		{
			app.checkpoint_phone = "8163406395";
		}

		app.start_cp_idx = preferences.getInt("start_cp_idx", -1); // set to neg
																	// so that
																	// waypoints
																	// will set
																	// default

	}

	void saveSettings() {
		SharedPreferences.Editor editor = preferences.edit();

		editor.putString("boat_number_str", app.boat_number);
		editor.putString("checkpoint_phone", app.checkpoint_phone);
		editor.putInt("start_cp_idx", app.start_cp_idx);

		editor.apply();
	}

	// ----------------------------------------------------------------------
	// readCheckPoints
	// ----------------------------------------------------------------------
	private void readCheckPoints(Context ctx)
	{
		//Read the checkpoints
		ClassFileIO fio = new ClassFileIO();
		String fname = "checkpoints.csv";
		cps = fio.ReadCheckpoints(ctx, fname);
	}

	// ----------------------------------------------------------------------
	// getCheckpoints
	// ----------------------------------------------------------------------
	String[] getAllCheckpointLabels()
	{
		String[] ret = null;
		if (cps!=null)
		{
			ret = new String[cps.length];

			for(int inx=0;inx<cps.length;inx++)
			{
				ret[inx] = String.format("%s", cps[inx].label);
			}
		}
		return ret;
	}
}
