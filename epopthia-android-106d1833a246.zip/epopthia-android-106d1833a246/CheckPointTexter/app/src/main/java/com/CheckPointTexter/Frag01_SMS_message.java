package com.CheckPointTexter;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class Frag01_SMS_message extends Fragment
{
	private View v = null;
	private int send_selection;

	private Spinner spinner1;
	private EditText boat_number_edit;

	private String[] checkpoints = null;

	private TextView sms_message;
	private ClassAppSettings settings;
	private CheckPointTexting checkPointTexting;

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		setHasOptionsMenu(true);
		if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);
		v=inflater.inflate(R.layout.sms_layout, container, false);

		settings = ClassAppSettings.getInstance();
		checkpoints = settings.getAllCheckpointLabels();
		checkPointTexting = new CheckPointTexting();

		// if fragment is visible then update
		if (getUserVisibleHint())
		{
			update();
		}

		return v;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser && v!=null)
		{
			update();
		}
	}


	@Override
	public void onResume()
	{
		update();

		super.onResume();
	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{
		spinner1 = v.findViewById(R.id.text_checkpoint_list);
		if (spinner1==null) return;  //pop out of update if screen not drawn

		//GUI objects
		Button format_in_button = v.findViewById(R.id.format_in_btn);
		if (format_in_button ==null) return;  //pop out of update if screen not drawn

		Button format_out_button = v.findViewById(R.id.format_out_btn);
		if (format_out_button ==null) return;  //pop out of update if screen not drawn


		sms_message = v.findViewById(R.id.sms_message);
		if (sms_message==null) return;  //pop out of update if screen not drawn

		boat_number_edit = v.findViewById(R.id.boatid);
		if (boat_number_edit==null) return;  //pop out of update if screen not drawn

		Button withdraw_button = v.findViewById(R.id.btn_withdraw);
		if (withdraw_button ==null) return;  //pop out of update if screen not drawn

		//populate spinner

		int start_idx = settings.app.start_cp_idx;
		addItemsOnSpinner(checkpoints, spinner1, start_idx);

		//populate the boat number

		boat_number_edit.setText(getBoatNumber());

		spinner1.setOnItemSelectedListener(new OnItemSelectedListener()
		{
			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
									   int arg2, long arg3) {
				settings.app.start_cp_idx = arg2;
			}
			@Override
			public void onNothingSelected(AdapterView<?> arg0)
			{
			}
		});

		boat_number_edit.setOnFocusChangeListener(new OnFocusChangeListener()
		{
			public void onFocusChange(View v, boolean hasFocus)
			{
				if (!hasFocus)
				{
					settings.app.boat_number = getBoatNumber();
				}
			}
		});

		format_in_button.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				settings.app.boat_number = getBoatNumber();
				// get selected checkpoint
				int cp_idx = spinner1.getSelectedItemPosition();
				settings.app.start_cp_idx = cp_idx;

				// format the text message
				send_selection = 0;

				String msg = checkPointTexting.getCheckpointMessage(cp_idx, send_selection);
				sms_message.setText(msg);

				formatTextAndSend();

			}
		});

		format_out_button.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				settings.app.boat_number = getBoatNumber();

				// get selected checkpoint
				int cp_idx = spinner1.getSelectedItemPosition();
				settings.app.start_cp_idx = cp_idx;

				// format the text message
				send_selection = 1;
				String msg = checkPointTexting.getCheckpointMessage(cp_idx, send_selection);
				sms_message.setText(msg);

				formatTextAndSend();

			}
		});



		//------------------------------------------------------------------------------------------
		// withdraw from the race
		//------------------------------------------------------------------------------------------
		withdraw_button.setOnClickListener(
				new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						settings.app.boat_number = getBoatNumber();

						// get selected checkpoint
						int cp_idx = spinner1.getSelectedItemPosition();
						settings.app.start_cp_idx = cp_idx;

						// format the text message
						send_selection = 2;

						String msg = checkPointTexting.getCheckpointMessage(cp_idx, send_selection);
						sms_message.setText(msg);

						formatTextAndSend();

					}
				});

	}

	// ------------------------------------------------------------------------
	//	Are you sure dialog handler
	// ------------------------------------------------------------------------
	private final DialogInterface.OnClickListener dialogWithdrawClickListener = new DialogInterface.OnClickListener()
	{
		@Override
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
				case DialogInterface.BUTTON_POSITIVE:
					String sms = sms_message.getText().toString();
					String phoneNo = settings.app.checkpoint_phone; //sms_address.getText().toString();

					String[] phoneNos = phoneNo.split("\n");
					((ActivityMain) Objects.requireNonNull(getActivity())).sendSMS(phoneNos[0], sms);

					break;

				case DialogInterface.BUTTON_NEGATIVE:
					Toast.makeText(getActivity() , "DNF cancelled", Toast.LENGTH_LONG).show();
					break;
			}
		}
	};




	private void addItemsOnSpinner(String[] checkpoints, Spinner spinner, int init_position)
	{
		List<String> list = new ArrayList<>();
		Collections.addAll(list, checkpoints);
		SpinnerAdapter dataAdapter = new SpinnerAdapter(getActivity(), android.R.id.text1, list);

		spinner.setAdapter(dataAdapter);

		if (init_position >0 && init_position<checkpoints.length)
		{
			spinner.setSelection(init_position);
		}
	}


	private String getBoatNumber()
	{
		String ret = "";
		String tmp_boat_num = boat_number_edit.getText().toString();
		if (ClassUtility.isInteger(tmp_boat_num))
		{
			int tmp_int = Integer.parseInt(tmp_boat_num);
			ret = String.format("%04d", tmp_int);
		}
		return (ret);
	}


	private void formatTextAndSend()
	{
		String sms = sms_message.getText().toString();

		if (sms.length()>0)
		{
			String phoneNo = settings.app.checkpoint_phone; //sms_address.getText().toString();
			if (phoneNo.length() > 0) {
				if (send_selection != 2) {
					String[] phoneNos = phoneNo.split("\n");
					((ActivityMain) Objects.requireNonNull(getActivity())).sendSMS(phoneNos[0], sms);
				}
				else {

					AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
					builder.setMessage("Are you really sure you want to withdraw from the race?").setPositiveButton("Yes", dialogWithdrawClickListener)
							.setNegativeButton("No", dialogWithdrawClickListener).show();

				}
			}
			else
			{
				Toast.makeText(getActivity(), "No Phone Number! goto the settings menu.",Toast.LENGTH_LONG).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), "No message to send!",Toast.LENGTH_LONG).show();
		}


	}

}
