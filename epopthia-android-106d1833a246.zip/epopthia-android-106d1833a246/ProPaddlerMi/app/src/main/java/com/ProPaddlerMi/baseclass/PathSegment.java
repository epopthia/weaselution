package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.WayPointNav;
import com.ProPaddlerMi.utility.Const;

import static java.lang.Math.cos;

@SuppressWarnings({"WeakerAccess", "unused"})
public
class PathSegment {

    public final Vector3D ur; //unit radial Vector3D
    public final Vector3D un; //unit normal Vector3D
    public final Vector3D ut; //unit tangential Vector3D (from last to new point)
    public final double dr_rad; //arc between last and new
    public final double deltaNorth_m; // approximate change in north position
    public final double deltaEast_m; // approximate change in east position
    public final RangeBearing rb; //bearing angle and range from last location  (0 = north, 90deg = east)
    public long deltaT_ms; //time delta from last data
    public double speedLocationBase_mps; //speed based on distance and time

    PathSegment(LatLngRad point) {

        ur = WayPointNav.ComputeUnitRadialVector(point.latitude_rad, point.longitude_rad);
        un = new Vector3D();
        ut = new Vector3D();
        dr_rad = 0.0;
        deltaNorth_m = 0.0;
        deltaEast_m = 0.0;
        rb = new RangeBearing();
        deltaT_ms = 0;
        speedLocationBase_mps = 0.0;
    }

    PathSegment(LatLngTime point) {

        this(new LatLngRad(point.pt.latitude_rad, point.pt.longitude_rad));
    }

    PathSegment(PathSegment s0) {
        ur = new Vector3D(s0.ur);
        un = new Vector3D(s0.un);
        ut = new Vector3D(s0.ut);
        dr_rad = s0.dr_rad;
        deltaNorth_m = s0.deltaNorth_m;
        deltaEast_m = s0.deltaEast_m;
        rb = new RangeBearing(s0.rb);
        deltaT_ms = s0.deltaT_ms;
        speedLocationBase_mps = s0.speedLocationBase_mps;
    }

    PathSegment(LatLngRad pt1, LatLngRad pt0, PathSegment ps0)
    {
        // unit radial
        ur = WayPointNav.ComputeUnitRadialVector(pt1.latitude_rad, pt1.longitude_rad);
        // unit normal (last to new)
        un = WayPointNav.ComputeUnitNormalVector(ps0.ur, ur);
        // unit tangential (last to new)
        ut = WayPointNav.ComputeUnitTangentialVector(un, ur);
        // dr_rad (last to new)
        dr_rad = WayPointNav.VectorDot3D(ps0.ur, ut);
        // change in north position
        deltaNorth_m = (pt1.latitude_rad-pt0.latitude_rad)* Const.earth_a_m;
        // change in east position
        deltaEast_m = (pt1.longitude_rad-pt0.longitude_rad)*Const.earth_a_m*cos(pt0.latitude_rad);
        // bearing angle from last point
        rb = new RangeBearing(pt0, pt1);
        // deltat
        deltaT_ms = 0;
        // speed
        speedLocationBase_mps = 0.0;
    }

    PathSegment(LatLngTime pt1, LatLngTime pt0, PathSegment ps0)
    {
        this(pt1.pt, pt0.pt, ps0);
        deltaT_ms = pt1.utcTime_ms - pt0.utcTime_ms;
        double t_sec = Math.abs(deltaT_ms * Const.ms_to_sec);
        speedLocationBase_mps = t_sec > Const.epsilon ? rb.range_m / t_sec : 0.0;
    }

    //-----------------------------------------------------------------------------
    //	limitAngleRad
    //	limit angle between 0 and 360 deg
    //-----------------------------------------------------------------------------
    private static double limitAngleRad(double loc_bearing_rad)
    {
        double bearingLimited_rad = loc_bearing_rad;

        if (loc_bearing_rad<0.0)
        {
            bearingLimited_rad+= Const.two_pi;
        }
        else if (loc_bearing_rad>= Const.two_pi)
        {
            bearingLimited_rad-= Const.two_pi;
        }
        return (bearingLimited_rad);
    }

}
