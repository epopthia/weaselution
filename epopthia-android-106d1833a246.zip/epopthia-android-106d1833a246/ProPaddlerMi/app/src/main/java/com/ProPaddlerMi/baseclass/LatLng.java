package com.ProPaddlerMi.baseclass;

@SuppressWarnings("unused")
public class LatLng {

    final double latitude;
    final double longitude;

    public LatLng(double lat_deg, double lon_deg) {
        latitude = lat_deg;
        longitude = lon_deg;

    }
}
