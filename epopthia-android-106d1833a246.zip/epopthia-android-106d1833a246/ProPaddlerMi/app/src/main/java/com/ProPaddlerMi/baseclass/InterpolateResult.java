package com.ProPaddlerMi.baseclass;

public class InterpolateResult {
    public double alpha;
    public int iLower;
    public int iUpper;
    public double value;

    public InterpolateResult()
    {
        alpha = 0;
        iLower = 0;
        iUpper = 0;
        value = 0;
    }

    public double applyInterpolationResult(double[] values)
    {
        return ((1.0 - alpha) * values[iLower] + alpha * values[iUpper]);
    }

    public double applyInterpolationResult(double value0, double value1 )
    {
        return ((1.0 - alpha) * value0 + alpha * value1);
    }

}
