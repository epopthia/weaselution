package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;

public class Track
{
    public TrackSegment trackSegment;
    //public double totTrackDist_m; // the total distance of the racer's own path
    public ArrayList<ErrorCode> errors;

    public Track()
    {
        trackSegment = new TrackSegment();
        errors = new ArrayList<>();
        //totTrackDist_m = 0;
    }

    /// <summary>
    /// copy one Track to a new one
    /// </summary>
    /// <param s0="reference Track"></param>
    public Track(Track s0)
    {
        trackSegment = new TrackSegment(s0.trackSegment);
        errors = new ArrayList<>(s0.errors);
    }

    /// <summary>
    /// initialize the first Track without any state history
    /// </summary>
    /// <param p1="current pose"></param>
    public Track(Pose p1)
    {
        trackSegment = new TrackSegment(p1);
        errors = new ArrayList<>();
    }

    /// <summary>
    /// combine current pose with past racerstate to determine the current track. 
    /// The track describes path items independent of the race route definition.
    /// this is the nominal constructor for Track
    /// </summary>
    /// <param p1="current pose"></param>
    /// <param s0="the last racer state"></param>
    public Track(Pose p1, RacerState s0)
    {
        this(s0.track);

        errors = new ArrayList<>();
        TrackSegment testSegment = new TrackSegment(p1, s0.pose1);
        if (testSegment.posVel_mps > Const.maxSpeed_mps)
        {
            errors.add(ErrorCode.tooLargeDistance);
        }

        if (errors.size() == 0)
        {
            trackSegment = testSegment;

        }
    }
    public Track(Pose p1, Pose p0)
    {
        errors = new ArrayList<>();
        TrackSegment testSegment = new TrackSegment(p1, p0);
        if (testSegment.posVel_mps > Const.maxSpeed_mps)
        {
            errors.add(ErrorCode.tooLargeDistance);
        }
        if (errors.size() == 0)
        {
            trackSegment = testSegment;
        }
    }

    public enum ErrorCode
    {
        normal,
        tooLargeDistance
    }

    /// <summary>
    /// Translates the error code into an error message
    /// </summary>
    /// <param errorCode="error code"></param>
    /// <returns>errorMessage</returns>
    public static String ErrorCodeMessage(int code)
    {
        ErrorCode errorCode = ErrorCode.values()[code];
        String errorMessage;
        switch (errorCode)
        {
            case normal:
                errorMessage = "";
                break;
            case tooLargeDistance:
                errorMessage = "Too fast";//"Distance between GPS data points is physically impossible given speed";
                break;
            default:
                errorMessage = "Unknown error code";
                break;
        }
        return errorMessage;
    }

    //----------------------------------------------------------------------------------------------
    // isValidNewLocation
    // validate that a new position update is valid
    //----------------------------------------------------------------------------------------------
    private Boolean IsValidNewOwnPath(TrackSegment own_path)
    {
        boolean ret = true;
        // don't allow going back in time
        if (own_path.dT_ms <= 0) return (false);
        // JAM: comment out 5/29/19: the speed check has a side effect of locking in a possibly bad initial position
        //// don't too fast of a change
        //if (actualPath.speed_mps >= Const.max_speed_limit_mps) return (false);
        return (ret);
    }
}
