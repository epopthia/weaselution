package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.WayPointNav;
import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import org.json.JSONException;
import org.json.JSONObject;


@SuppressWarnings("WeakerAccess")
public class CheckPoint
{
	public String CutOff;
	public float MilesToNext;  //todo: deprecate this
	public String TakeoutSide;
	public String Name;
	public LatLngRad pt;
	public boolean isCheckpoint;
	public final WayPoint.Type type;
	public int order;
	public double prev_cp_dist_ft;
    public double value_m;
    public double riverMile;
	public double offset_ft;
    public int closest_wp_index;
    public boolean visible;
    public boolean isSupported;
    public boolean valid;

	// extra info
	public final double rest_hr;
	public final double plan_rest_hr;
	public Vector3D ur;
    public RangeBearing rb;
    public final double dr_past_rad;
    public final double dr_next_rad;


	public CheckPoint()
	{
        CutOff = "";
		prev_cp_dist_ft = 0.0;
		TakeoutSide = "";
		Name = "";
		MilesToNext = (float) 0.0;
		pt = new LatLngRad(0.0,0.0);
        isCheckpoint = true;
		type = WayPoint.Type.checkpoint;
		order = 0;
		rest_hr = 0.0;
		plan_rest_hr = 0.0;
        ur = new Vector3D();
        rb = new RangeBearing();
        dr_past_rad = -1.0;  //-1 is invalid
        dr_next_rad = -1.0;
        value_m = 0.0;
        riverMile = 0.0;
        offset_ft = 0;
        closest_wp_index = 0;
        visible = true;
        isSupported = false;
        valid = true;
    }

    public CheckPoint(LatLngRad refPoint)
    {
        this();
        pt = refPoint;
        ur =  WayPointNav.ComputeUnitRadialVector(pt.latitude_rad, pt.longitude_rad);
    }

    public CheckPoint(CheckPoint cp) {
        CutOff = cp.CutOff;
        prev_cp_dist_ft = cp.prev_cp_dist_ft;
        TakeoutSide = cp.TakeoutSide;
        Name = cp.Name;
        MilesToNext = cp.MilesToNext;
        pt = new LatLngRad(cp.pt);
        isCheckpoint = cp.isCheckpoint;
        type = cp.type;
        order = cp.order;
        rest_hr = cp.rest_hr;
        plan_rest_hr = cp.plan_rest_hr;
        ur = WayPointNav.ComputeUnitRadialVector(cp.pt.latitude_rad, cp.pt.longitude_rad);
        rb = new RangeBearing();
        dr_past_rad = cp.dr_past_rad;
        dr_next_rad = cp.dr_next_rad;
        value_m = cp.value_m;
        riverMile = cp.riverMile;
        offset_ft = cp.offset_ft;
        closest_wp_index = cp.closest_wp_index;
        visible = cp.visible;
        isSupported = cp.isSupported;
        valid = cp.valid;
    }

    public CheckPoint(CheckPoint cp0, CheckPoint cp1)
    {
        this(cp1);
        ur =  WayPointNav.ComputeUnitRadialVector(cp1.pt.latitude_rad, cp1.pt.longitude_rad);
        rb = new RangeBearing(cp0.pt, cp1.pt);
        value_m = cp1.value_m <= 0 ? cp0.value_m + rb.range_m : cp1.value_m;
    }


    public CheckPoint(JSONObject item)
    {
        this();

        try {
            CutOff = item.getString("CutOff");
            Name = item.getString("Name");
            order = item.getInt("Order");
            MilesToNext = item.getInt("MilesToNext");
            TakeoutSide = item.getString("TakeoutSide");
            String gpsStringDeg = item.getString("GPS");
            String[] toks = gpsStringDeg.split(",");
            if (toks.length == 2) {
                if (ClassUtility.isNumeric(toks[0])) {
                    pt.latitude_rad = Double.parseDouble(toks[0]) * Const.dtr;
                    pt.longitude_rad = Double.parseDouble(toks[1]) * Const.dtr;
                }
            }
            ur =  WayPointNav.ComputeUnitRadialVector(pt.latitude_rad, pt.longitude_rad);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}