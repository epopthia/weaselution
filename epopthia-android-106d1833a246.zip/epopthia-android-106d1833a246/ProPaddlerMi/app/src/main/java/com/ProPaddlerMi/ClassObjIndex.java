package com.ProPaddlerMi;

import java.util.ArrayList;

class ClassObjIndex {
	
	final ArrayList<Integer> objs;
	
	ClassObjIndex()
	{
		objs = new ArrayList<>();
	}

}
