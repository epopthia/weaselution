package com.ProPaddlerMi.baseclass;

public class LookupInfo
{
    public int iLower;
    public int iUpper;
    public final LatLngRad pt;
    public Boolean valid;

    public LookupInfo()
    {
        iLower = -1;
        iUpper = -1;
        pt = new LatLngRad();
        valid = false;
    }
}
