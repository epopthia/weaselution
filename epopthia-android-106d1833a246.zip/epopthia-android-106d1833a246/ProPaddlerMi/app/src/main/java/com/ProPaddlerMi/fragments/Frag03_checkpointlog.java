package com.ProPaddlerMi.fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.ProPaddlerMi.ActivityMain;
import com.ProPaddlerMi.Globals;
import com.ProPaddlerMi.R;
import com.ProPaddlerMi.RaceOwlClient;
import com.ProPaddlerMi.WayPointMission;
import com.ProPaddlerMi.adapters.CheckpointAdapter;
import com.ProPaddlerMi.baseclass.CheckPointCycle;
import com.ProPaddlerMi.infrastructure.NetworkMonitor;
import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import java.util.Objects;

public class Frag03_checkpointlog extends Fragment
{
	private View v = null;
	private CheckpointAdapter adapter = null; //= new CheckpointAdapter(globals.appState.ctx, android.R.layout.simple_list_item_1, android.R.id.text1, raceowl.cp_log, 0);
	private ListView listView;
	private TextView autoCheckinStatus; // = v.findViewById(R.id.update_status);
	private Handler mHandler;
	private Globals globals = null;
	private RaceOwlClient raceowl = null;
	private WayPointMission wp = null;

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{

		setHasOptionsMenu(true);

		if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);

		// singleton objects
		raceowl = RaceOwlClient.getInstance();
		wp = WayPointMission.getInstance();

		//get view
		v = inflater.inflate(R.layout.frag03_checkpointlog, container, false);


		initGui();

		return v;
	}

	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		globals = Globals.getInstance();
		globals.appState.ctx = context;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser && v!=null)
		{
			((ActivityMain)Objects.requireNonNull(getActivity())).manageScreenTransition();
			update();
		}
	}

	@Override
	public void onPause()
	{
		stopRepeatingTask();
		super.onPause();
	}

	@Override
	public void onResume()
	{
		update();

		//start timed activities
		if (mHandler==null)
		{
			mHandler = new Handler(); //setup for timed updates
		}
		startRepeatingTask();

		super.onResume();
	}

	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	private void startRepeatingTask()
	{
		mStatusChecker.run();
	}

	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
	private void stopRepeatingTask()
	{
		mHandler.removeCallbacks(mStatusChecker);
	}


	//---------------------------------------------------------------------------
	// mStatusChecker
	//---------------------------------------------------------------------------
	private final Runnable mStatusChecker = new Runnable()
	{
		@Override
		public void run()
		{
			update();
			mHandler.removeCallbacks(mStatusChecker);
			mHandler.postDelayed(mStatusChecker, Const.prime_deltat_ms);
			//Log.d(globals.appState.appName, String.format("Runnable - Frag03_checkpointlog.java - %s", ClassUtility.getRaceOwlNetTimeNow()));
		}
	};


	// ----------------------------------------------------------------------
	// CheckpointEditDialog
	// ----------------------------------------------------------------------
	private void CheckpointEditDialog(final Context activity, final int idx)
	{
		final Dialog myDialog = new Dialog(activity);

		try
		{
			Objects.requireNonNull(getActivity()).requestWindowFeature(Window.FEATURE_NO_TITLE );
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		CheckPointCycle item = raceowl.getCheckpointCycle(idx);

		if (item == null) return;

		myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		myDialog.setContentView(R.layout.dialog_checkpoint_edit);
		myDialog.setTitle("");
		myDialog.setCancelable(true);

		TextView boat_text = myDialog.findViewById(R.id.boat);
		boat_text.setText(String.format("%s",item.BoatNumber));

		Spinner spinner = myDialog.findViewById(R.id.checkpoints);
		ClassUtility.addItemsOnSpinner(getActivity(), wp.getAllCheckpointLabels(), spinner, wp.getCheckpointIndexByName(item.Checkpoint));

		TextView date_text = myDialog.findViewById(R.id.editDate);
		date_text.setText(ClassUtility.getDateStr(ClassUtility.parseRaceOwlNetTime(item.NetLocationTime)));

		TextView time_text = myDialog.findViewById(R.id.editTime);
		time_text.setText(ClassUtility.getTimeStr(ClassUtility.parseRaceOwlNetTime(item.NetLocationTime)));

		Spinner spinner1 = myDialog.findViewById(R.id.status1);
		String[]states = new String[]{"in","out"};
		int init_index = ClassUtility.getIndex(item.Status, states);
		ClassUtility.addItemsOnSpinner(getActivity(), states, spinner1, init_index);

		Button ok_button = myDialog.findViewById(R.id.ok_button);
		ok_button.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v) {
			CheckPointCycle item = globals.checkPointCycles.get(idx); // (CheckPointCycle) raceowl.getCheckpointCycle(idx);

			TextView boat_text = myDialog.findViewById(R.id.boat);
			item.BoatNumber = boat_text.getText().toString();

			Spinner spinner = myDialog.findViewById(R.id.checkpoints);
			item.Checkpoint = spinner.getSelectedItem().toString();

			TextView date_text = myDialog.findViewById(R.id.editDate);
			TextView time_text = myDialog.findViewById(R.id.editTime);
			item.NetLocationTime = ClassUtility.getRaceOwlNetTime(date_text.getText().toString(), time_text.getText().toString());

			Spinner spinner1 = myDialog.findViewById(R.id.status1);
			item.Status = spinner1.getSelectedItem().toString();

			//set raceowl status to pending because we will need to resend
			item.raceowl_status = CheckPointCycle.CheckPointCycleStatus.pending;
			item.acknowledged = false;

			globals.checkPointCycles.set(idx,item);

			raceowl.sendCheckpoint();
			myDialog.dismiss();
			update();
			}
		});

		Button cancel_button = myDialog.findViewById(R.id.cancel_button);
		cancel_button.setOnClickListener(new OnClickListener() {
			public void onClick(View v)
			{
				myDialog.dismiss();
			}
		});
		myDialog.show();
	}


	private void initGui()
	{
		autoCheckinStatus = v.findViewById(R.id.autoCheckinStatus);

		listView = v.findViewById(R.id.listView1);
		initListView();

		//enable and disable buttons
		//v.findViewById(R.id.start_track);
		Button startAutoChecking = v.findViewById(R.id.startAutoCheckin);
		startAutoChecking.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				globals.settings.enableAutoCheckin = true;
				update();
			}
		});

		//enable and disable buttongs
		//v.findViewById(R.id.stop_track);
		Button stopAutoChecking = v.findViewById(R.id.stopAutoCheckin);
		stopAutoChecking.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				globals.settings.enableAutoCheckin = false;
				update();
			}
		});
	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void initListView()
	{
		if (listView==null)  return;  //pop out of update if screen not drawn

		adapter = new CheckpointAdapter(globals.appState.ctx, R.id.listView1, globals.checkPointCycles);

		//list_array_count = globals.checkpoint_cycles.size();

		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener()
		{

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				int selected_position = position;
				if (adapter.getSelected() == position)
				{
					selected_position = -1;
				}
				adapter.setSelected(selected_position);
				//Toast.makeText(globals.appState.ctx ,String.format("position = %d", position) , Toast.LENGTH_LONG).show();
				update();
			}
		});

		// Long list view click listener
		listView.setOnItemLongClickListener(new OnItemLongClickListener()
		{

			public boolean onItemLongClick(AdapterView<?> arg0, View arg1,int pos, long id)
			{
				// int wp_idx = 0;//wp.getMappedCheckpointIndex(pos);
				adapter.setSelected(pos);

				int wp_idx = adapter.getSelected();
				if (wp_idx>=0)
				{
					// WayPointMission.selected_cp_index = wp_idx;
					CheckpointEditDialog(getActivity(), wp_idx);
				}
				update();
				return true;
			}
		});

		adapter.updateResults();

	}


	private void setAutoCheckinStatus(boolean isAutoCheckin)
	{
		if (isAutoCheckin && raceowl.isRaceEventValid(globals.settings.RaceEventID, false))
		{
			autoCheckinStatus.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
			autoCheckinStatus.setTextColor(getResources().getColor(android.R.color.white));
			String msg = "AutoCheckin Enabled";
			autoCheckinStatus.setText(msg);
		}
		else
		{
			autoCheckinStatus.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
			autoCheckinStatus.setTextColor(getResources().getColor(android.R.color.white));
			String msg = "AutoCheckin Disabled";
			autoCheckinStatus.setText(msg);
		}
	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{
		setAutoCheckinStatus(globals.settings.enableAutoCheckin);
		adapter.updateResults();
	}

    private enum map_menu
    {
        edit,
		delete_all,
        retry_send,
    }

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
	{
		menu.add(0,map_menu.edit.ordinal(),0,"Edit Selected");
		menu.add(0,map_menu.delete_all.ordinal(),0,"Delete All");
        menu.add(0,map_menu.retry_send.ordinal(),0,"Retry send now");
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{

	    map_menu value = map_menu.values()[item.getItemId()];

        AlertDialog.Builder builder;


		int log_count = globals.checkPointCycles.size();

		switch (value)
		{
			case edit:
				if (log_count>0) {
					int wp_idx = adapter.getSelected();
					if (wp_idx >= 0) {
						CheckpointEditDialog(getActivity(), wp_idx);
					}
				}
				break;
            case delete_all:
				if (log_count>0) {
					builder = new AlertDialog.Builder(getActivity());
					builder.setMessage("Remove ALL checkpoints from log. Are you sure?").setPositiveButton("Yes", dialogRemoveCheckpointClickListener2)
							.setNegativeButton("No", dialogRemoveCheckpointClickListener2).show();
				}

				break;
            case retry_send:
                globals.appState.isOnline = NetworkMonitor.isNetworkAvailable(globals.appState.ctx);
                raceowl.sendCheckpoint();
                break;
			default:
				super.onOptionsItemSelected(item);
		}
		update();

		return true;
	}

	// ------------------------------------------------------------------------
	//	Are you sure dialog handler
	// ------------------------------------------------------------------------
	private final DialogInterface.OnClickListener dialogRemoveCheckpointClickListener2 = new DialogInterface.OnClickListener()
	{
		@Override
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
				case DialogInterface.BUTTON_POSITIVE:
					globals.clearCheckpointsLog();
					break;

				case DialogInterface.BUTTON_NEGATIVE:
					break;
			}
		}
	};


	//---------------------------------------------------------------------------
	// showEmptyLogWarning
	//---------------------------------------------------------------------------
	private void showEmptyLogWarning() {
		ClassUtility.getConfirmDialog(globals.appState.ctx, "No Checkpoints yet", "As you send checkpoint information, a log is kept here for your review and edit.", "Ok", "No", false, true, new ActivityMain.AlertModal() {
			@Override
			public void onButtonClicked(boolean value) {
			}
		});
	}


}
