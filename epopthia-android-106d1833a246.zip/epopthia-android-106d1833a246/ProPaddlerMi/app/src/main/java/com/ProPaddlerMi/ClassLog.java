package com.ProPaddlerMi;

import android.graphics.PointF;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.abs;

public class ClassLog 
{
	private static ClassLog objClassLog;
	
	private static final float min_speed_mph = (float) 0.5;
	private final ClassLogData[] log;
	private int start_idx;
	private int end_idx;
	private boolean initlog;
	private final int buffer_size = 120;
	
	//totals
	private float speedsum;
	private float tracksum;
	private int count;

	// ----------------------------------------------------------------------
	// getInstance for singleton implementation
	// ----------------------------------------------------------------------
	public static synchronized ClassLog getInstance()
	{
	    if (objClassLog == null)
	   {
	    	objClassLog = new ClassLog();
	   }
	   return objClassLog;
    }
	
  	// ----------------------------------------------------------------------
	// Constructor
	// ----------------------------------------------------------------------
	private ClassLog()
	{
		log = new ClassLogData[buffer_size]; 
		for (int inx=0;inx<log.length;inx++)
		{
			ClassLogData new_item = new ClassLogData();
			log[inx] = new_item;
		}
		Reset();
	}

	void Reset()
	{	
		end_idx = 0;
		start_idx = 0;
		initlog = true;
		speedsum = 0;
		tracksum = 0;
		count = 0;
	}

	void addLogItem(ClassLogData new_item)
	{
		// add to averages only if moving
		if (abs(new_item.speed_mph)>min_speed_mph)
		{
			if (!initlog)
			{
				end_idx++;
			}
			if (end_idx>=log.length) end_idx = 0;
			if (end_idx==start_idx && !initlog) 
			{
				speedsum-=log[start_idx].speed_mph;
				tracksum-=log[start_idx].track_mph;
				count--;
				
				start_idx++;
				if (start_idx>=log.length) start_idx = 0;
			}
			initlog = false;

			log[end_idx].elapsed_time_hr = new_item.elapsed_time_hr;
			log[end_idx].value_m = new_item.value_m;
			log[end_idx].lat_rad = new_item.lat_rad;
			log[end_idx].lon_rad = new_item.lon_rad;
			log[end_idx].speed_mph = new_item.speed_mph;
			log[end_idx].track_mph = new_item.track_mph;

			speedsum+=log[end_idx].speed_mph;
			tracksum+=log[end_idx].track_mph;
			count++;
		}
	}
	private int get_last_idx()
	{
        return (end_idx);
	}
	
	private int get_first_idx()
	{
        return (start_idx);
	}

	int getBufferSize()
	{
		return (buffer_size);
	}

	double getAvgSpeed()
	{
		float avgspeed = 0;
		if (count>0)
		{
			avgspeed = speedsum/count;
		}
		return (avgspeed);
	}
	
	double getAvgTrack()
	{
		float avgspeed = 0;
		if (count>0)
		{
			avgspeed = tracksum/count;
		}
		return (avgspeed);
	}


    public double getTimeRange()
	{
		double ret;
		int lidx = get_last_idx();
		int fidx = get_first_idx();
		double lrm = log[lidx].elapsed_time_hr;
		double frm = log[fidx].elapsed_time_hr;
		ret = abs(lrm-frm);
		return (ret);
	}
	
	public int getCount()
	{
		return (count);
	}
	
	public double getMaxSpeed()
	{
		double speed_max = 0;
		if (count>0)
		{
			int idx = start_idx;
			do
			{
				if (idx==start_idx) 
				{
					speed_max = log[idx].speed_mph;
				}
				else
				{
					if (log[idx].speed_mph > speed_max)
					{
						speed_max = log[idx].speed_mph;
					}
				}
				idx++;
				if (idx>=log.length) idx=0;
			}while (idx!=end_idx);
		}
		return (speed_max);
	}

	public List<PointF> getSpeedPoints(float[] scale, float[] offset)
	{
		
		List<PointF> pts = new ArrayList<>();
		
		int idx = start_idx;		
		do
		{
			PointF pt = new PointF();

			double relative_time_hr = abs(log[idx].elapsed_time_hr - log[start_idx].elapsed_time_hr);
			pt.x = (int) (relative_time_hr * scale[0] + offset[0]); 
			pt.y = (int) (offset[1] - log[idx].speed_mph * scale[1] );
			pts.add(pt);
			idx++;
			if (idx>=log.length) idx=0;
		}while (idx!=end_idx);
		return (pts);
	}
	
	public List<PointF> getTrackPoints(float[] scale, float[] offset)
	{
		
		//double tot_rest_hr = 0;
		//calc hours
		List<PointF> pts = new ArrayList<>();
		
		int idx = start_idx;		
		
		do{
			PointF pt = new PointF();

			double relative_time = abs(log[idx].elapsed_time_hr - log[start_idx].elapsed_time_hr);
			pt.x = (int) (relative_time * scale[0] + offset[0]); 
			pt.y = (int) (offset[1] - log[idx].track_mph * scale[1] );
			pts.add(pt);
			idx++;
			if (idx>=log.length) idx=0;
		}while (idx!=end_idx);
		return (pts);
	}

}
