package com.ProPaddlerMi.utility;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

@SuppressWarnings({"unused", "WeakerAccess"})
public class UTCTime {
    public static long getCurrentUTC()
    {
        return (getUTCFromDateTime(new Date()));
    }

//    public static long GetUTCFromDateTime(Date localDateTime, TimeZone timeZone)
//    {

//        localDateTime.getTime();
//
//        var dateTimeUnspec = Date.SpecifyKind(localDateTime, DateTimeKind.Unspecified);
//        Date utcDateTime = TimeZone.ConvertTimeToUtc(dateTimeUnspec, timeZone);
//        long utc_ms = (long)Math.Round(utcDateTime.ToUniversalTime().Subtract(new Date(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds);
//        return (utc_ms);
//    }

//    public static Date GetUTCDateTimeFromDateTime(Date localDateTime, TimeZone timeZone)
//    {
//        var dateTimeUnspec = Date.SpecifyKind(localDateTime, DateTimeKind.Unspecified);
//        Date utcDateTime = TimeZone.ConvertTimeToUtc(dateTimeUnspec, timeZone);
//        return (utcDateTime);
//    }


//    public static Date GetUTCDateTimeFromDateTime(Date localDateTime, TimeZone timeZone)
//    {
//        Date fixerror;
//        if (!localDateTime.HasValue)
//        {
//            fixerror = Date.Now;
//        }
//        else
//        {
//            fixerror = localDateTime.Value;
//        }
//        var dateTimeUnspec = Date.SpecifyKind(fixerror, DateTimeKind.Unspecified);
//        Date utcDateTime = TimeZone.ConvertTimeToUtc(dateTimeUnspec, timeZone);
//        return (utcDateTime);
//    }

    public static long getUTCFromDateTime(Date dt)
    {
        return (dt.getTime());
    }

    public static Date getDateTimeFromUTC(long utc_ms)
    {
        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return new Date(utc_ms);
    }

    public static Date getDateTimeFromUTC(long utc_ms, String timeZone)
    {
        TimeZone timeZoneInfo; // = TimeZone.getTimeZone(time_zone);
        try{
            timeZoneInfo = TimeZone.getTimeZone(timeZone);
        } catch (Exception e) {
            timeZoneInfo = TimeZone.getTimeZone("Central Standard Time");
        }
        return (getDateTimeFromUTC(utc_ms, timeZoneInfo));
    }

    public static Date getDateTimeFromUTC(long utc_ms, TimeZone timeZone)
    {
        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.setTimeZone(timeZone);
        return new Date(utc_ms);
    }

    public static String MilliSecondsToString(long elapsedTime_ms)
    {
        int seconds = (int) (elapsedTime_ms / 1000) % 60;
        int minutes =  ((int)(elapsedTime_ms / 1000) / 60) % 60;
        int hours = (int)(elapsedTime_ms / 1000) / 3600;
        return (String.format("%02d:%02d:%02d",hours, minutes,seconds));
    }

}
