package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;

@SuppressWarnings({"WeakerAccess", "unused"})
public class Pose
{
    public long utc_ms;                 // location time. the number of milliseconds between a specified date and midnight of January 1, 1970,
    public LatLngRad pt;                // location lat and lon in radians
    public final double gpsVel_mps;           // reported speed
    public final double gpsBrg_rad;           // reported bearing
    public ArrayList<ErrorCode> errors;      // list of error codes associated with Pose
    //calculated
    public Vector3D ur;                 // calculated unit radial
    public final double accuracy_m;

    public Pose()
    {
        pt = new LatLngRad();
        utc_ms = 0;
        gpsVel_mps = -Const.epsilon;              // gpsSpeed_mps < 0 = invalid speed
        gpsBrg_rad = 0;
        errors = new ArrayList<>();
        ur = new Vector3D();
        accuracy_m = 50;
    }

    public Pose(LatLngRad d1)
    {
        this();
        pt = new LatLngRad(d1);
        ur = TrackSegment.ComputeUnitRadialVector(d1);
    }
    public Pose(GPSData d1)
    {
        pt = new LatLngRad(d1.ptt.pt);
        errors = VerifyLocation();
        utc_ms = d1.ptt.utcTime_ms;
        gpsVel_mps = d1.speed_mps;
        gpsBrg_rad = d1.bearing_rad;
        ur = TrackSegment.ComputeUnitRadialVector(d1.ptt.pt);
        accuracy_m = d1.accuracy_m;
    }

    public Pose(GPSData d1, RacerState s0)
    {
        pt = new LatLngRad(d1.ptt.pt);
        utc_ms = d1.ptt.utcTime_ms;
        errors = VerifyLocation(s0);
        gpsVel_mps = d1.speed_mps;
        gpsBrg_rad = d1.bearing_rad;
        ur = TrackSegment.ComputeUnitRadialVector(d1.ptt.pt);
        accuracy_m = d1.accuracy_m;
    }

    public Pose(Pose d1)
    {
        pt = new LatLngRad(d1.pt);
        errors = new ArrayList<>(d1.errors);
        utc_ms = d1.utc_ms;
        gpsVel_mps = d1.gpsVel_mps;
        gpsBrg_rad = d1.gpsBrg_rad;
        ur = new Vector3D(d1.ur);
        accuracy_m = d1.accuracy_m;

    }
    public Pose(double lat_rad, double lon_rad, long utc0_ms)
    {
        this();
        pt = new LatLngRad(lat_rad, lon_rad);
        errors = VerifyLocation();
        utc_ms = utc0_ms;
        ur = TrackSegment.ComputeUnitRadialVector(pt);
    }

    //public Pose(GPSData d1, RacerState s0):this(d1)
    //{
    //}

    //----------------------------------------------------------------------------------------------
    // isValidNewLocation
    // validate that a new position update is valid
    //----------------------------------------------------------------------------------------------
    private ArrayList<ErrorCode> VerifyLocation()
    {
        ArrayList<ErrorCode> errorCodes = new ArrayList<>();
        // don't be 0,0
        if (pt.latitude_rad <= Const.epsilon && pt.longitude_rad <= Const.epsilon) errorCodes.add(ErrorCode.latLonAtZero);
        return (errorCodes);
    }
    //----------------------------------------------------------------------------------------------
    // isValidNewLocation
    // validate that a new position update is valid
    //----------------------------------------------------------------------------------------------
    private ArrayList<ErrorCode> VerifyLocation(RacerState s0)
    {
        ArrayList<ErrorCode> errorCodes = VerifyLocation();
        // don't be older
        if (utc_ms < s0.reported.utcTime_ms) errorCodes.add(ErrorCode.oldData);
        return (errorCodes);
    }

    public enum ErrorCode
    {
        normal,
        latLonAtZero,
        oldData
    }
    public static String ErrorCodeMessage(int code)
    {
        ErrorCode retcode = ErrorCode.values()[code];
        String errorMessage;
        switch (retcode)
        {
            case normal:
                errorMessage = "";
                break;
            case latLonAtZero:
                errorMessage = "Invalid Position";//"Uninitalized position. Lat/lon cannot be 0,0";
                break;
            case oldData:
                errorMessage = "old Position";//"attempt to update position with old data";
                break;
            default:
                errorMessage = "Unknown error code";
                break;
        }
        return errorMessage;
    }
}
