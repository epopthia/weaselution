package com.ProPaddlerMi.fragments;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ProPaddlerMi.ActivityMain;
import com.ProPaddlerMi.Globals;
import com.ProPaddlerMi.R;
import com.ProPaddlerMi.UIUtil;
import com.ProPaddlerMi.WayPointMission;
import com.ProPaddlerMi.utility.Const;

@SuppressWarnings("ALL")
@SuppressLint("DefaultLocale")
public class Frag06_big_display extends Fragment
{

	private View v = null;

	private ImageView myImageView = null;
	private Handler mHandler = null ;


	private static final long MAX_DURATION = 800;
	private BroadcastReceiver mPositionUpdate = null;


	private Globals globals;
	private WayPointMission wp;

    private Bitmap bitmap = null;
	private Canvas canvas = null;

	private Paint paint_black = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{

		setHasOptionsMenu(true);

		if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);

		//get a the wp instance
		wp = WayPointMission.getInstance();

		v = inflater.inflate(R.layout.frag06_big_display, container, false);
		v.setKeepScreenOn(true);


		initPaint();

	    // if fragment is visible then update
	    if (getUserVisibleHint())
	    {
	    	update();
	    }

		return v;
	}

	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		globals = Globals.getInstance();
		globals.appState.ctx = context;
	}


	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
	    super.setUserVisibleHint(isVisibleToUser);
	    if (isVisibleToUser && v!=null)
	    {
            ((ActivityMain)getActivity()).manageScreenTransition();
	    	update();
	    }
	}

	@Override
	public void onPause()
	{
		update_source_management(true);
		myImageView = null;
		super.onPause();
	}

	@Override
	public void onResume()
	{
		update_source_management(false);
		update();
		super.onResume();
	}

	//-----------------------------------------------------------------------------
	// getTextItems
	//-----------------------------------------------------------------------------
	private String[] getTextItems()
	{
		String [] txt_items = new String[1];
        txt_items[0] = String.format("%s",wp.getSelectedInfoItem(globals.settings.display_idx[4]));
		return txt_items;
	}

	//-----------------------------------------------------------------------------
	// DrawTextItems
	//-----------------------------------------------------------------------------
	private void drawTextItems(Canvas canvas, String[] txt_items, int[] colors)
	{
        //int height = canvas.getHeight();
		//int width = canvas.getWidth();

		Paint paint_text = new Paint();
		paint_text.setFilterBitmap(true);
		paint_text.setDither(true);
		paint_text.setAntiAlias(true);

        int def_color = getHighContrastColor(Color.RED);

        // colors
        int[] tcolors = new int[]{def_color, def_color, def_color, def_color};
        if (colors!=null)
        {
        	for (int inx=0;inx<4;inx++)
        	{
        		tcolors[inx] = getHighContrastColor(colors[inx]);
        	}
        }

        paint_text.setColor(tcolors[0]);
        //canvas.drawText(txt_items[0],(float) 0.05*width, (float) 0.5*height, paint_text);


        drawText(canvas, paint_text, txt_items[0]);

    }

//    private double min(double n1,double n2)
//    {
//        if (n1<n2) return n1;
//        else return n2;
//
//
//    }

    //---------------------------------------------------------------------------
	// registBroadcastReceiver
	//---------------------------------------------------------------------------
	private void registBroadcastReceiver()
	{
	    final IntentFilter theFilter = new IntentFilter();

	    theFilter.addAction("Mi_LOCATION");

	    mPositionUpdate = new BroadcastReceiver()
	    {
	        @Override
	        public void onReceive(Context context, Intent intent) {
	            String strAction = intent.getAction();

	            if (strAction.equals("Mi_LOCATION"))
	            {
	            	update();
	            }
	        }
	    };

	    getActivity().registerReceiver(mPositionUpdate, theFilter);
	}


	//---------------------------------------------------------------------------
	// unregisterReceiver
	//---------------------------------------------------------------------------
	private void unregisterReceiver()
	{
	    int apiLevel = Build.VERSION.SDK_INT;

	    if (apiLevel >= 7) {
	        try {
	            getActivity().unregisterReceiver(mPositionUpdate);
	        }
	        catch (IllegalArgumentException e) {
	            mPositionUpdate = null;
	        }
	    }
	    else {
	    	getActivity().unregisterReceiver(mPositionUpdate);
	        mPositionUpdate = null;
	    }
	}

	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	private void startRepeatingTask()
	{
		mStatusChecker.run();
	}

	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
    private void stopRepeatingTask()
    {
    	if (mHandler!=null)
    	{
		    mHandler.removeCallbacks(mStatusChecker);
		    mHandler = null;
    	}
	}
	//---------------------------------------------------------------------------
	// mStatusChecker
	//---------------------------------------------------------------------------
	private final Runnable mStatusChecker = new Runnable()
	{
	    @Override
	    public void run()
	    {
	    	update();
			mHandler.removeCallbacks(mStatusChecker);
	    	mHandler.postDelayed(mStatusChecker, Const.prime_deltat_ms);
	    }
	};


	//-----------------------------------------------------------------------------
	// update_source_management
	//-----------------------------------------------------------------------------
	private void update_source_management(boolean isStopAll)
	{
		if (isStopAll)
		{
			unregisterReceiver();
			stopRepeatingTask();
		}
		else
		{
			if (globals.appState.enableSimulation)
			{
		   	    //start timed activites
				if (mHandler==null)
				{
					mHandler = new Handler(); //setup for timed updates
				}
		   	    startRepeatingTask();
				unregisterReceiver();
			}
			else
			{
				stopRepeatingTask();
				registBroadcastReceiver();
			}
		}
	}

	//-----------------------------------------------------------------------------
	// MyOnTouchListener
	//-----------------------------------------------------------------------------
	private long startTime = 0;
	private int clickCount = 0;
	private long duration = 0;

	private OnTouchListener MyOnTouchListener = new OnTouchListener()
	{
	  @Override
	  public boolean onTouch(View view, MotionEvent event)
	  {
		switch(event.getAction() & MotionEvent.ACTION_MASK)
		  {
	      	case MotionEvent.ACTION_DOWN:
	            long time = System.currentTimeMillis() - startTime;
	            duration = duration + time;
	            if (duration> MAX_DURATION)
	            {
	                clickCount = 0;
	                duration = 0;
	            }
	      		if (clickCount==0) startTime = System.currentTimeMillis();
	            clickCount++;

	            if (isVirtualButtonEnabled())
	            {
		    		float posx, posy;
		    		posx = event.getX()/canvas.getWidth();
		    		posy = event.getY()/canvas.getHeight();
		    		processVirtualButton(posx,posy);

	            }

	            break;
		  }
		  return true;
	  }
   };

    // ----------------------------------------------------------------------
	// getHighContrastColor
	// ----------------------------------------------------------------------
	private int getHighContrastColor(int def_color)
	{
		int ret = def_color;

		if (globals.settings.enable_high_contrast_color)
		{
			switch (def_color)
			{
				default:
					ret = Color.WHITE;
			}
		}
		return ret;
	}

	// ----------------------------------------------------------------------
	// initPaint
	// ----------------------------------------------------------------------
	private void initPaint()
	{
		paint_black = new Paint();
		paint_black.setFilterBitmap(true);
		paint_black.setDither(true);
		paint_black.setAntiAlias(true);
		paint_black.setColor(Color.BLACK);
		paint_black.setStrokeWidth(globals.settings.base_line_width);
		paint_black.setStyle(Paint.Style.STROKE);
	}

    // ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{
		if (getUserVisibleHint())
		{

			myImageView = (ImageView) v.findViewById(R.id.imageView1);
			if (myImageView==null) return;  //pop out of update if screen not drawn
			int width = myImageView.getWidth();
			int height = myImageView.getHeight();

			if (width==0 ||height==0 ) return; // pop out if the image has not been generated

			bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
			canvas = new Canvas(bitmap);

			myImageView.setOnTouchListener(MyOnTouchListener);

            // text display
            String[] txt_items = getTextItems();
            drawTextItems(canvas, txt_items, null);

            // update the image
            myImageView.setImageBitmap(bitmap);

        }
	}

	private MenuItem local_menu;
	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
	{
		local_menu = menu.add(0,0,0,"Toggle Channel Audio");
		local_menu = menu.add(0,1,0,"Toggle Status Audio");
        local_menu = menu.add(0,2,0,"Toggle High Contrast");
        local_menu = menu.add(0,3,0,"Select Display");
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		boolean ret = true;
		int idx = item.getItemId();

	    switch (idx)
	    {
	        case 0:
				((ActivityMain)getActivity()).toggleChannelAudioWarning();
	        	break;
	        case 1:
				((ActivityMain)getActivity()).toggleAudioStatus();
	        	break;
	        case 2:
	        	globals.settings.enable_high_contrast_color = !globals.settings.enable_high_contrast_color;
	        	break;
            case 3:
                int dynamic_display_index = 4;
                String msg2 = "Select display";
                listDialog( "Select item for display", msg2, getActivity(), wp.display_options,  globals.settings.display_idx[dynamic_display_index], dynamic_display_index);
                break;
	        default:
	            ret = super.onOptionsItemSelected(item);
	    }
    	update();
	    return (ret);
	}

	// ----------------------------------------------------------------------
	// isVirtualButtonEnabled - return true if the screen is capable of pinch to zoom
	// ----------------------------------------------------------------------
	private boolean isVirtualButtonEnabled()
	{
		boolean virtual_button = false;

		switch (globals.settings.nav_origin)
		{
		case 0: //center_boat
		case 1: //center track
			virtual_button = true;
			break;
		}
		return(virtual_button);
	}


	//lower left screen location as a screen fraction
	private final double[][] virtual_buttons_loc =
			{
			  {0.45, 0.55},
			};

	//button width and height as a screen fraction
	private final double[][] virtual_buttons_width_height =
		{
		  {0.1, 0.1}
		};

    // ----------------------------------------------------------------------
	// processVirtualButton
	// ----------------------------------------------------------------------
	private void processVirtualButton(float posx, float posy)
	{
		boolean button_press = false;
		int inx;
        int numbuttons = 1;
        for (inx=0;!button_press&&inx< numbuttons;inx++)
		{
			if (posx>=virtual_buttons_loc[inx][0] && posx<=virtual_buttons_loc[inx][0]+virtual_buttons_width_height[inx][0] &&
				posy<=virtual_buttons_loc[inx][1] && posy>=virtual_buttons_loc[inx][1]-virtual_buttons_width_height[inx][1])
				button_press = true;
		}

		if (button_press)
		{
			int dynamic_display_index = 4;
			String msg2 = "Select display";
			listDialog( "Select item for display", msg2, getActivity(), wp.display_options,  globals.settings.display_idx[dynamic_display_index], dynamic_display_index);
		}

	}

	// ----------------------------------------------------------------------
	// listDialog - select an item from a list
	// ----------------------------------------------------------------------
	private void listDialog(String title, String message, final Context activity, final String[] items, final int selected_item_idx, final int display_id)
	{

        final Dialog myDialog = new Dialog(activity);

        myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        myDialog.setContentView(R.layout.dialog_list_pick);
        myDialog.setTitle(title);
        myDialog.setCancelable(true);

        ListView list_view = (ListView) myDialog.findViewById(R.id.listView1);
        TextView label = (TextView) myDialog.findViewById(R.id.list_pick_label);
        label.setText(message);

		UIUtil.addItemsOnListView(getActivity(), items, list_view, selected_item_idx);

		list_view.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				globals.settings.display_idx[display_id] = arg2;
				String msg = String.format("display set to %s", items[arg2]);
				Toast.makeText(getActivity(), msg ,Toast.LENGTH_LONG).show();
                myDialog.dismiss();
			}
		});


        Button cancel_button = (Button) myDialog.findViewById(R.id.cancel_button);
        cancel_button.setOnClickListener(new OnClickListener() {
            public void onClick(View v)
            {
                myDialog.dismiss();
            }
        });

        //show the dialog
        myDialog.show();
    }


    private void drawText(Canvas canvas, Paint paint, String text)
    {

		//Log.d("ProPaddlerMi", String.format("canvas.getWidth = %d",canvas.getWidth() ));
        int textsize = determineMaxTextSize(text, canvas.getWidth()*0.9,canvas.getHeight()*0.9);


		//int textsize = 80;
        paint.setTextSize(textsize);

        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);
        int x = (canvas.getWidth() / 2) - (bounds.width() / 2);
        int y = (canvas.getHeight() / 2) + (bounds.height() / 2);
        //y += (Math.abs(bounds.height()))/2;
        canvas.drawText(text, x, y, paint);
    }


    private int determineMaxTextSize(String str, double maxWidth, double maxHeight)
    {
        int size = 0;
        Paint paint = new Paint();

		float str_width;
        do {
            paint.setTextSize(++ size);
			str_width = paint.measureText(str);
        } while(str_width < maxWidth  && size < 1000);//while(str_width < maxWidth && size<2000);

        Rect bounds = new Rect();
        paint.getTextBounds(str, 0, str.length(), bounds);

        if (bounds.height()>maxHeight) {
            do {
                paint.setTextSize(-- size);
                paint.getTextBounds(str, 0, str.length(), bounds);
            } while(bounds.height()>maxHeight);
        }

        return size;
    } //End getMaxTextSize()
}
