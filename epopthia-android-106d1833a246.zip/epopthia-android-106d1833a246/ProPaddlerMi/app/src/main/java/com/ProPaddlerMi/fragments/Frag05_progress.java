package com.ProPaddlerMi.fragments;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.ProPaddlerMi.ActivityMain;
import com.ProPaddlerMi.ClassLog;
import com.ProPaddlerMi.Globals;
import com.ProPaddlerMi.R;
import com.ProPaddlerMi.UIUtil;
import com.ProPaddlerMi.WayPointMission;
import com.ProPaddlerMi.utility.Const;

import java.util.List;
import java.util.Objects;

import static java.lang.Math.abs;
import static java.lang.Math.max;

@SuppressLint("DefaultLocale")
public class Frag05_progress extends Fragment
{

	private View v = null;

	private float[] scale;
	private float[] offset;
	private double[] maxscale;

	private ImageView myImageView = null;
	private Handler mHandler = null ;


	private static final long MAX_DURATION = 800;
	private BroadcastReceiver mPositionUpdate = null;

	private Globals globals;
	private WayPointMission wp;
	private ClassLog history;

	private Bitmap bitmap = null;
	private Canvas canvas = null;

	public Frag05_progress() {
	}

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{

		setHasOptionsMenu(true);

		if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);

		float zoomRef = (float) 1.0;

//		PointF[] xys = new PointF[4];
//		for (int inx = 0; inx< xys.length; inx++)
//		{
//			xys[inx] = new PointF();
//		}

		//get the history
		history = ClassLog.getInstance();

		//get a the wp instance
		wp = WayPointMission.getInstance();

		v = inflater.inflate(R.layout.frag05_nav, container, false);
		v.setKeepScreenOn(true);


		initPaint();

		// if fragment is visible then update
		if (getUserVisibleHint())
		{
			update();
		}

		return v;
	}

	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		globals = Globals.getInstance();
		globals.appState.ctx = context;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser && v!=null)
		{
			((ActivityMain)Objects.requireNonNull(getActivity())).manageScreenTransition();
			update();
		}
	}

	@Override
	public void onPause()
	{
		updateSourceManagement(true);
		myImageView = null;
		super.onPause();
	}

	@Override
	public void onResume()
	{
		updateSourceManagement(false);
		update();
		super.onResume();
	}

	//-----------------------------------------------------------------------------
	// getTextItems
	//-----------------------------------------------------------------------------
	private String[] getTextItems()
	{
		String [] txt_items = new String[4];
		for (int inx=0;inx<txt_items.length;inx++)
		{
			txt_items[inx] = String.format("%s",wp.getSelectedInfoItem(globals.settings.display_idx[inx]));
		}
		return txt_items;
	}

	//-----------------------------------------------------------------------------
	// DrawTextItems
	//-----------------------------------------------------------------------------
	private void drawTextItems(Canvas canvas, String[] txt_items, int[] colors)
	{
		int height = canvas.getHeight();
		int width = canvas.getWidth();

		Paint paint_text = new Paint();
		paint_text.setFilterBitmap(true);
		paint_text.setDither(true);
		paint_text.setAntiAlias(true);

		//Draw text upcoming_races
		int textSize = (int) (height*0.065);
		paint_text.setTextSize(textSize);

		int def_color = getHighContrastColor(Color.RED);

		// colors
		int[] tColors = new int[]{def_color, def_color, def_color, def_color};
		if (colors!=null)
		{
			for (int inx=0;inx<4;inx++)
			{
				tColors[inx] = getHighContrastColor(colors[inx]);
			}
		}

		paint_text.setColor(tColors[0]);
		canvas.drawText(txt_items[0],(float) 0.15*width, (float) 0.10*height, paint_text);
		paint_text.setColor(tColors[1]);
		canvas.drawText(txt_items[1],(float) 0.15*width, (float) 0.20*height, paint_text);
		paint_text.setColor(tColors[2]);
		canvas.drawText(txt_items[2],(float) 0.67*width, (float) 0.10*height, paint_text);
		paint_text.setColor(tColors[3]);
		canvas.drawText(txt_items[3],(float) 0.67*width, (float) 0.20*height, paint_text);

	}

	@SuppressLint("DefaultLocale")
	private void DrawProgressTextItems(Canvas canvas)
	{
		int height = canvas.getHeight();
		int width = canvas.getWidth();

		Paint paint_text = new Paint();
		paint_text.setFilterBitmap(true);
		paint_text.setDither(true);
		paint_text.setAntiAlias(true);

		//Draw text upcoming_races
		int textSize = (int) (height*0.032);
		paint_text.setTextSize(textSize);
		paint_text.setColor(getHighContrastColor(Color.CYAN));

		float sh = (float) 0.77;
		float sw = (float) 0.30;
		float dsh = (float) 0.045;

		String text = String.format("goal = %1.1f hr, est = %1.1f", globals.settings.desired_finish_hr, wp.getEstimatedFinish_sec() * Const.sec_to_hour);
		canvas.drawText(text, sw *width, sh *height, paint_text);

		sh+=dsh;
		text = String.format("planned speed = %1.1f mph", globals.settings.desired_speed_mph);

		canvas.drawText(text, sw *width, sh *height, paint_text);

		sh+=dsh;
		double tmpSpeed = wp.getPlanSpeed();
		String tmpSpeedText =  tmpSpeed >= 0 ? String.format("%1.1f mph", tmpSpeed) : "NA";
		text = String.format("needed speed = %s", tmpSpeedText);
		canvas.drawText(text, sw *width, sh *height, paint_text);
	}





	//---------------------------------------------------------------------------
	// updateGraphics
	//---------------------------------------------------------------------------
	private void updateGraphics()
	{
		//updatePlan();

        if (globals.settings.selectedProgress == 1) { //speed graph
            updateSpeed();
        } else {
            updatePlan();
        }

		//Toast.makeText(v, "graphics update",Toast.LENGTH_LONG).show();
	}


	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	private void startRepeatingTask()
	{
		mStatusChecker.run();
	}

	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
	private void stopRepeatingTask()
	{
		if (mHandler!=null)
		{
			mHandler.removeCallbacks(mStatusChecker);
			mHandler = null;
		}
	}
	//---------------------------------------------------------------------------
	// mStatusChecker
	//---------------------------------------------------------------------------
	private final Runnable mStatusChecker = new Runnable()
	{
		@Override
		public void run()
		{
			update();
			mHandler.removeCallbacks(mStatusChecker);
			mHandler.postDelayed(mStatusChecker, Const.prime_deltat_ms);
		}
	};

	//-----------------------------------------------------------------------------
	//	DrawLine
	//-----------------------------------------------------------------------------
	private void DrawLine(List<PointF> xys, Canvas canvas, Paint paint)
	{
		Path path = new Path();
		int num = xys.size();
		PointF xy;
		if (num>0)
		{
			xy = xys.get(0);
			path.moveTo(xy.x, xy.y);
		}
		for (int inx=1;inx<num;inx++)
		{
			xy = xys.get(inx);
			path.lineTo(xy.x, xy.y);
		}
		canvas.drawPath(path, paint);
	}

	//-----------------------------------------------------------------------------
	// updatePlan
	//-----------------------------------------------------------------------------
	private void updatePlan()
	{

		Paint paint_actual = new Paint();
		paint_actual.setFilterBitmap(true);
		paint_actual.setDither(true);
		paint_actual.setAntiAlias(true);
		paint_actual.setStyle(Paint.Style.STROKE);
		paint_actual.setStrokeWidth(globals.settings.base_line_width);
		paint_actual.setColor(Color.YELLOW);

		getHighContrastPaint(paint_actual);

		Paint paint_plan = new Paint();
		paint_plan.setFilterBitmap(true);
		paint_plan.setDither(true);
		paint_plan.setAntiAlias(true);
		paint_plan.setStyle(Paint.Style.STROKE);
		paint_plan.setStrokeWidth(globals.settings.base_line_width);
		paint_plan.setColor(Color.RED);

		getHighContrastPaint(paint_plan);

		Paint paintEstimate = new Paint();
		paintEstimate.setFilterBitmap(true);
		paintEstimate.setDither(true);
		paintEstimate.setAntiAlias(true);
		paintEstimate.setStyle(Paint.Style.STROKE);
		paintEstimate.setStrokeWidth(globals.settings.base_line_width);
		paintEstimate.setColor(Color.CYAN);


		getHighContrastPaint(paintEstimate);


		ImageView myImageView = v.findViewById(R.id.imageView1);

		//return if no image
		if (myImageView==null || myImageView.getWidth()<=0) return;

		//return if no checkpoints
		if (globals.route.cps == null) return;

		bitmap = Bitmap.createBitmap(myImageView.getWidth(), myImageView.getHeight(), Bitmap.Config.RGB_565);
		canvas = new Canvas(bitmap);

		int height = canvas.getHeight();
		int width = canvas.getWidth();

		offset = new float[]{(float) (width*0.1),(float) (height*0.9)};  //x and y offset

		double total_miles =  wp.getTotalTrackMiles();

		double estimated_finish_hr = wp.getEstimatedCheckPointTimeHour(globals.settings.finishCheckpointIndex,true, false, true);
		double estimated_finish_plan_hr = wp.getEstimatedCheckPointTimeHour(globals.settings.finishCheckpointIndex,true, true, true);

		double scale_x_hr = max(max(estimated_finish_hr,estimated_finish_plan_hr), globals.settings.desired_finish_hr)* 1.05;
		double scale_y_mile = total_miles * 1.05;

		double pixel_to_y = scale_y_mile / (height-(height-offset[1]));  //miles/pixel
		double y_to_pixel = 1/pixel_to_y;  //pixel/feet
		double pixel_to_x = scale_x_hr / (width-offset[0]);  //hours/pixel
		double x_to_pixel = 1/pixel_to_x;  //pixel/feet

		//update objects
		scale = new float[]{(float) x_to_pixel,(float) y_to_pixel};  //x and y scale

		//update objects
		maxscale = new double[]{scale_x_hr,scale_y_mile};  //x and y max

		//boat
		PointF boat = new PointF();
		boat.x = (int) ((wp.getElapsedTimeSec(true)*Const.sec_to_hour) * scale[0] + offset[0]);
		boat.y = (int) (offset[1] - wp.getCurrentTrackMiles() * scale[1]);

		List<PointF> xysPlanned = wp.calcPlannedPerformance(scale, offset);
		List<PointF> xysActual = wp.calcActualPerformance(scale, offset);
		List<PointF> xysPredicted = wp.calcPredictedPerformance(scale, offset, boat);

		DrawLine(xysPlanned, canvas, paint_plan);

		DrawLine(xysActual, canvas, paint_actual);

		DrawLine(xysPredicted, canvas, paintEstimate);

		float radius = (float)(20);
		canvas.drawCircle(boat.x, boat.y, radius, paint_actual);

		drawAxis(canvas, "hours", "miles",scale, offset, maxscale);

		DrawProgressTextItems(canvas);

		myImageView.setImageBitmap(bitmap);
	}


	//-----------------------------------------------------------------------------
	// drawAxis
	//-----------------------------------------------------------------------------
	private void drawAxis(Canvas canvas, String x_label, String y_label, float[] scale2, float[] offset2, double[] maxscale)
	{

		Paint paint = new Paint();
		paint.setColor(Color.WHITE);
		paint.setFilterBitmap(true);
		paint.setDither(true);
		paint.setStrokeWidth(globals.settings.base_line_width*5);

		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeJoin(Paint.Join.ROUND);
		paint.setStrokeCap(Paint.Cap.ROUND);

		float last_x = offset2[0];
		float last_y = offset2[1];

		Path mypath = new Path();
		mypath.moveTo(last_x, last_y);
		float new_y = (float) (offset2[1]- (maxscale[1]*scale2[1]));
		mypath.lineTo(last_x, new_y);

		paint.setStrokeWidth(globals.settings.base_line_width);

		int textsize = (int) (canvas.getHeight()*0.032);
		paint.setTextSize(textsize);

		paint.setTypeface(Typeface.SANS_SERIF);


		//drawTextOnPath() was not supported with hardware acceleration until Android 4.1.
		//To work around this problem, simply set a software layer type on your View when
		//running on Android < 4.1. Just call View.setLayerType(View.LAYER_TYPE_SOFTWARE, null).
		//This will force software rendering and fix your problem.

		canvas.drawTextOnPath(y_label, mypath, (float)( abs(new_y-last_y)*0.5), -10, paint);
		canvas.drawPath(mypath, paint);


		Path mypath2 = new Path();
		mypath2.moveTo(last_x, last_y);
		float new_x = (float) ((maxscale[0]*scale2[0])+offset2[0]);
		mypath2.lineTo(new_x, last_y);
		canvas.drawTextOnPath(x_label, mypath2, (float) ((new_x-last_x)*0.4), 30, paint);

		canvas.drawPath(mypath2, paint);


	}

	//-----------------------------------------------------------------------------
	// updateSourceManagement
	//-----------------------------------------------------------------------------
	private void updateSourceManagement(boolean isStopAll)
	{
		if (isStopAll)
		{
			stopRepeatingTask();
		}
		else
		{
			if (globals.appState.enableSimulation)
			{
				//start timed activites
				if (mHandler==null)
				{
					mHandler = new Handler(); //setup for timed updates
				}
				startRepeatingTask();
			}
			else
			{
				stopRepeatingTask();
			}
		}
	}

	//-----------------------------------------------------------------------------
	// MyOnTouchListener
	//-----------------------------------------------------------------------------
	private long startTime = 0;
	private int clickCount = 0;
	private long duration = 0;

	private final OnTouchListener MyOnTouchListener = new OnTouchListener()
	{
		@SuppressLint("ClickableViewAccessibility")
		@Override
		public boolean onTouch(View view, MotionEvent event)
		{
			float distx, disty;
			float zoomrat;
			switch(event.getAction() & MotionEvent.ACTION_MASK)
			{
				case MotionEvent.ACTION_DOWN:
					long time = System.currentTimeMillis() - startTime;
					duration = duration + time;
					if (duration> MAX_DURATION)
					{
						clickCount = 0;
						duration = 0;
					}
					if (clickCount==0) startTime = System.currentTimeMillis();
					clickCount++;

					break;
				case MotionEvent.ACTION_UP:
					time = System.currentTimeMillis() - startTime;
					duration = duration + time;
					if(clickCount >= 2)
					{
						//String msg = String.format("%d - %d",clickCount, duration);
						if(duration<= MAX_DURATION)
						{
							processDoubleClick(event);
							//Toast.makeText(getActivity(), msg + "double tap",Toast.LENGTH_LONG).show();
						}
						clickCount = 0;
						duration = 0;
					}
					break;



			}
			return true;
		}
	};

	//-----------------------------------------------------------------------------
	// MyOnTouchListener
	//-----------------------------------------------------------------------------
	@SuppressLint("DefaultLocale")
	private void processDoubleClick(MotionEvent event)
	{
		float distX, distY;
		distX = event.getX(0);
		distY = event.getY(0);
		String msg;
		float x = (distX-offset[0])/scale[0];
		float y = (offset[1] - distY)/scale[1];

		switch (globals.settings.selectedProgress)
		{
			case 0: //planning graph
				msg = String.format("%1.1f hr, %1.1f mi",x,y);
				Toast.makeText((getActivity()), msg ,Toast.LENGTH_LONG).show();
				break;
			case 1: //speed graph
				float myTime = (float) (x- history.getTimeRange());
				String myTimeStr = wp.convertHourToHourStr(myTime,false);
				msg = String.format("T%s, %1.1f mph",myTimeStr,y);
				Toast.makeText(getActivity(), msg ,Toast.LENGTH_LONG).show();
		}
	}

	//-----------------------------------------------------------------------------
	// updateSpeed
	//-----------------------------------------------------------------------------
	private void updateSpeed()
	{

		Paint paint_speed = new Paint();
		paint_speed.setFilterBitmap(true);
		paint_speed.setDither(true);
		paint_speed.setAntiAlias(true);
		paint_speed.setStyle(Paint.Style.STROKE);
		paint_speed.setStrokeWidth(globals.settings.base_line_width*2);
		paint_speed.setColor(Color.CYAN);

		getHighContrastPaint(paint_speed);

		Paint paint_track = new Paint();
		paint_track.setFilterBitmap(true);
		paint_track.setDither(true);
		paint_track.setAntiAlias(true);
		paint_track.setStyle(Paint.Style.STROKE);
		paint_track.setStrokeWidth(globals.settings.base_line_width);
		paint_track.setColor(Color.YELLOW);

		getHighContrastPaint(paint_track);

		ImageView myImageView = v.findViewById(R.id.imageView1);

		//return if no image
		if (myImageView==null || myImageView.getWidth()<=0) return;

		bitmap = Bitmap.createBitmap(myImageView.getWidth(), myImageView.getHeight(), Bitmap.Config.RGB_565);
		canvas = new Canvas(bitmap);

		int height = canvas.getHeight();
		int width = canvas.getWidth();

		offset = new float[]{(float) (width*0.1),(float) (height*0.9)};  //x and y offset

		float scale_x_time = (float) (history.getTimeRange() * 1.05);
		float scale_y_speed = (float) (max(history.getMaxSpeed(), 5) * 1.10);

		float pixel_to_y = scale_y_speed / (height-(height-offset[1]));  //miles/pixel
		float y_to_pixel = 1/pixel_to_y;  //pixel/feet
		float pixel_to_x = scale_x_time / (width-offset[0]);  //hours/pixel
		float x_to_pixel = 1/pixel_to_x;  //pixel/feet

		//update objects
		scale = new float[]{x_to_pixel,y_to_pixel};  //x and y scale

		//update objects
		maxscale = new double[]{scale_x_time,scale_y_speed};  //x and y max

		List<PointF> xys_speed = history.getSpeedPoints(scale, offset);
		List<PointF> xys_track = history.getTrackPoints(scale, offset);

		DrawLine(xys_speed, canvas, paint_speed);

		DrawLine(xys_track, canvas, paint_track);

		drawAxis(canvas, "Time", "speed", scale, offset, maxscale);

		if (history.getCount() <= 0)
		{
			//paint_speed.setTextSize(30);
			int textSize = (int) (canvas.getHeight()*0.032);
			paint_speed.setTextSize(textSize);

			paint_speed.setStrokeWidth(globals.settings.base_line_width);
			String text = "No Data";
			canvas.drawText(text,(float) 0.5* width, (float) 0.5*height, paint_speed);
		}

		// text upcoming_races
		String[] txt_items = new String[4];
		final int[] txt_colors = new int[]{Color.CYAN, Color.CYAN, Color.YELLOW, Color.YELLOW};
		txt_items[0] = String.format("%1.1f",wp.getSpeed());
		txt_items[1] = String.format("%1.1f",wp.getAvgSpeed());
		//paint.setColor(getHighContrastColor(Color.YELLOW));
		txt_items[2] = String.format("%1.1f",wp.getTrackSpeed());
		txt_items[3] = String.format("%1.1f",wp.getAvgTrackSpeed());
		drawTextItems(canvas, txt_items, txt_colors);
		myImageView.setImageBitmap(bitmap);
	}

	// ----------------------------------------------------------------------
	// getHighContrastColor
	// ----------------------------------------------------------------------
	private int getHighContrastColor(int def_color)
	{
		int ret = def_color;

		if (globals.settings.enable_high_contrast_color)
		{
			ret = Color.WHITE;
		}
		return ret;
	}

	// ----------------------------------------------------------------------
	// initPaint
	// ----------------------------------------------------------------------
	private void initPaint()
	{
		Paint paint_black = new Paint();
		paint_black.setFilterBitmap(true);
		paint_black.setDither(true);
		paint_black.setAntiAlias(true);
		paint_black.setColor(Color.BLACK);
		paint_black.setStrokeWidth(globals.settings.base_line_width);
		paint_black.setStyle(Paint.Style.STROKE);
	}

	// ----------------------------------------------------------------------
	// getHighContrastPaint
	// ----------------------------------------------------------------------
	private void getHighContrastPaint(Paint paint)
	{
		if (globals.settings.enable_high_contrast_color)
		{
			paint.setColor(Color.WHITE);
			paint.setStrokeWidth(paint.getStrokeWidth() * 3);
		}
	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{
		if (getUserVisibleHint())
		{

			myImageView = v.findViewById(R.id.imageView1);
			if (myImageView==null) return;  //pop out of update if screen not drawn
			int width = myImageView.getWidth();
			int height = myImageView.getHeight();

			if (width==0 ||height==0 ) return; // pop out if the image has not been generated

			bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
			canvas = new Canvas(bitmap);

			myImageView.setOnTouchListener(MyOnTouchListener);

			updateGraphics();
		}
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
	{
		menu.add(0,0,0,"Progress Graph");
		menu.add(0,1,0,"Speed Graph");
		menu.add(0,2,0,"Toggle Channel Audio");
		menu.add(0,3,0,"Toggle Status Audio");
		menu.add(0,4,0,"Toggle High Contrast");
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		boolean ret = true;
		int idx = item.getItemId();

		switch (idx)
		{
			case 0:
			case 1:
				globals.settings.selectedProgress = idx;
				break;
			case 2:
				((ActivityMain)Objects.requireNonNull(getActivity())).toggleChannelAudioWarning();
				break;
			case 3:
				((ActivityMain)Objects.requireNonNull(getActivity())).toggleAudioStatus();
				break;
			case 4:
				globals.settings.enable_high_contrast_color = !globals.settings.enable_high_contrast_color;
				break;
			default:
				ret = super.onOptionsItemSelected(item);
		}
		update();
		return (ret);
	}




	//lower left screen location as a screen fraction
	private final double[][] virtual_buttons_loc =
			{
					{0.15, 0.10},
					{0.15, 0.20},
					{0.67, 0.10},
					{0.67, 0.20}
			};

	//button width and height as a screen fraction
	private final double[][] virtual_buttons_width_height =
			{
					{0.25, 0.06},
					{0.25, 0.06},
					{0.25, 0.06},
					{0.25, 0.06}
			};

	// ----------------------------------------------------------------------
	// processVirtualButton
	// ----------------------------------------------------------------------
	private void processVirtualButton(float posx, float posy)
	{
		boolean button_press = false;
		int inx;
		for (inx=0;!button_press&&inx<4;inx++)
		{
			if (posx>=virtual_buttons_loc[inx][0] && posx<=virtual_buttons_loc[inx][0]+virtual_buttons_width_height[inx][0] &&
					posy<=virtual_buttons_loc[inx][1] && posy>=virtual_buttons_loc[inx][1]-virtual_buttons_width_height[inx][1])
				button_press = true;
		}

		if (button_press)
		{
			int dynamic_display_index = inx-1;
			String msg2 = String.format("Select display item %d:", dynamic_display_index+1);
			listDialog( "Select item for display", msg2, getActivity(), wp.display_options,  globals.settings.display_idx[dynamic_display_index], dynamic_display_index);
		}

	}

	// ----------------------------------------------------------------------
	// listDialog - select an item from a list
	// ----------------------------------------------------------------------
	@SuppressWarnings("SameParameterValue")
	private void listDialog(String title, String message, final Context activity, final String[] items, final int selected_item_idx, final int display_id)
	{

		final Dialog myDialog = new Dialog(activity);

		myDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		myDialog.setContentView(R.layout.dialog_list_pick);
		myDialog.setTitle(title);
		myDialog.setCancelable(true);

		ListView list_view = myDialog.findViewById(R.id.listView1);
		TextView label = myDialog.findViewById(R.id.list_pick_label);
		label.setText(message);

		UIUtil.addItemsOnListView(getActivity(), items, list_view, selected_item_idx);

		list_view.setOnItemClickListener(new OnItemClickListener(){

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
									long arg3) {
				// TODO Auto-generated method stub
				globals.settings.display_idx[display_id] = arg2;
				String msg = String.format("display %d set to %s", display_id+1, items[arg2]);
				Toast.makeText(getActivity(), msg ,Toast.LENGTH_LONG).show();
				myDialog.dismiss();
			}
		});


		Button cancel_button = myDialog.findViewById(R.id.cancel_button);
		cancel_button.setOnClickListener(new OnClickListener() {
			public void onClick(View v)
			{
				myDialog.dismiss();
			}
		});

		//show the dialog
		myDialog.show();
	}


}
