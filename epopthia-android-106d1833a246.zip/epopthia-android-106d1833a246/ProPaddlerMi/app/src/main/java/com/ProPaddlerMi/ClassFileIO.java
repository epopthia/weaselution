package com.ProPaddlerMi;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.AssetManager;
import android.net.ParseException;
import android.os.Environment;
import android.util.Log;

import com.ProPaddlerMi.baseclass.CheckPoint;
import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashSet;

import static java.lang.Math.max;
import static java.lang.Math.min;

//import android.widget.Toast;
//import android.widget.Toast;

@SuppressWarnings("SameParameterValue")
@SuppressLint("DefaultLocale")
public class ClassFileIO {

	static final String mylogfile = "log_file";
	private static final String mytextlogfile = "text_log_file";
	private static final double rtd = 180.0/3.141592653589793238462643383279502884197169399375105820974944592;
	private static final double dtr = 1/rtd;

    private final Context mCtx;

	ClassFileIO(Context context)
	{
	    mCtx = context; //<-- declare a Context reference
	}


	// ------------------------------------------------------------------------
	// getLogLineStr
	// ------------------------------------------------------------------------
	String getLogLineStr(ClassLogData pt, boolean append_newline, boolean convert_units)
	{
		
		String[] toks = new String[9];
		toks[ClassLogData.log_time_col] = String.format("%1.3f", pt.elapsed_time_hr);
		toks[ClassLogData.log_value_col] = String.format("%1.2f", pt.value_m);
		toks[ClassLogData.log_totalmile_col] = String.format("%1.2f", pt.totalmile);
		if (convert_units)
		{
			toks[ClassLogData.log_lat_col] = String.format("%1.7f", pt.lat_rad*rtd);
			toks[ClassLogData.log_lon_col] = String.format("%1.7f", pt.lon_rad*rtd);
		}
		else
		{
			toks[ClassLogData.log_lat_col] = String.format("%1.9f", pt.lat_rad);
			toks[ClassLogData.log_lon_col] = String.format("%1.9f", pt.lon_rad);
		}
		toks[ClassLogData.log_speed_col] = String.format("%1.2f", pt.speed_mph);
		toks[ClassLogData.log_track_col] = String.format("%1.2f", pt.track_mph);
		toks[ClassLogData.log_avg_speed_col] = String.format("%1.2f", pt.avg_speed_mph);
		toks[ClassLogData.log_avg_track_col] = String.format("%1.2f", pt.avg_track_mph);

		
		String ret =  ClassUtility.stringArrayToString(toks, ",");

		if (append_newline)
		{
			ret = ret + "\n";
		}
		
		return ret;
	}

	// ------------------------------------------------------------------------
	//	deleteLog
	// ------------------------------------------------------------------------
	void deleteLog()
	{
		File log_file = mCtx.getFileStreamPath(mylogfile);
		deleteFile(log_file);
	}

	// ------------------------------------------------------------------------
	//	deleteLog
	// ------------------------------------------------------------------------
	void deleteTextLog()
	{
		File log_file = mCtx.getFileStreamPath(mytextlogfile);
		deleteFile(log_file);
	}
	// ------------------------------------------------------------------------
	//	writeLog - internal/external storage
	// ------------------------------------------------------------------------
	@SuppressWarnings("SameParameterValue")
	boolean writeLog(String fname, ClassLogData[] pts, String exernal_path)
	{
		boolean ret = true;
		if (pts.length>0)
		{
			String[] header_toks = new String[9];
			header_toks[ClassLogData.log_time_col] = "elapsed_time_hr";
			header_toks[ClassLogData.log_value_col] = "value_m";
			header_toks[ClassLogData.log_totalmile_col] = "totalmile";
			header_toks[ClassLogData.log_lat_col] = "lat_deg";
			header_toks[ClassLogData.log_lon_col] = "lon_deg";
			header_toks[ClassLogData.log_speed_col] = "speed_mph";
			header_toks[ClassLogData.log_track_col] = "track_mph";
			header_toks[ClassLogData.log_avg_speed_col] = "avg_speed_mph";
			header_toks[ClassLogData.log_avg_track_col] = "avg_track_speed_mph";
			
			
			String[] linepts = new String[pts.length+1];
			
			linepts[0] = ClassUtility.stringArrayToString(header_toks,",");
			
			for (int inx=0;inx<pts.length;inx++)
			{
				linepts[inx+1] = getLogLineStr(pts[inx], false, true);
			}
			if (exernal_path.length()>0)
			{
				ret = writeExternalFile(exernal_path, fname, linepts);
			}
			else
			{
				writeToFile(linepts, fname);
			}
		}
		return ret;
	}

	// ------------------------------------------------------------------------
	//	readLog
	// ------------------------------------------------------------------------
	@SuppressWarnings("SameParameterValue")
	ClassLogData[] readLog(String fname)
	{
		String[] pts_str = readFromFile(fname);
		boolean log_corruption = false;

		ClassLogData[] log = null;
		if (pts_str!=null)
		{
			log = new ClassLogData[pts_str.length];
			for (int inx=0;inx<pts_str.length;inx++)
				try {
					String[] mtoks = pts_str[inx].split(",", 9);
					if (mtoks.length == 9) {
						if (log != null) {
							log[inx] = new ClassLogData();
							log[inx].elapsed_time_hr = Float.parseFloat(mtoks[ClassLogData.log_time_col]);
							log[inx].lat_rad = Double.parseDouble(mtoks[ClassLogData.log_lat_col]);
							log[inx].lon_rad = Double.parseDouble(mtoks[ClassLogData.log_lon_col]);
							log[inx].speed_mph = Float.parseFloat(mtoks[ClassLogData.log_speed_col]);
							log[inx].track_mph = Float.parseFloat(mtoks[ClassLogData.log_track_col]);
							log[inx].value_m = Float.parseFloat(mtoks[ClassLogData.log_value_col]);
							log[inx].totalmile = Float.parseFloat(mtoks[ClassLogData.log_totalmile_col]);
							log[inx].avg_speed_mph = Float.parseFloat(mtoks[ClassLogData.log_avg_speed_col]);
							log[inx].avg_track_mph = Float.parseFloat(mtoks[ClassLogData.log_avg_track_col]);
						}
					} else {
						log_corruption = true;
					}
				} catch (ParseException e) {
					Log.e("readLog", "Corrupt log file: " + e.toString());
					log = null;
				}

        }
		if (log_corruption)
		{
			Log.e("readLog", "Corrupt log file: " + "token count");
	        log = null;
		}
		return log;
	}

	// ------------------------------------------------------------------------
	//	writeToFile
	// ------------------------------------------------------------------------
	private void writeToFile(String[] lines, String fname)
	{
	    try
	    {
	        OutputStreamWriter outputStreamWriter = new OutputStreamWriter( mCtx.openFileOutput(fname, Context.MODE_PRIVATE));
            for (String line : lines) {
                outputStreamWriter.write(line);
            }
	        outputStreamWriter.close();
	    }
	    catch (IOException e)
	    {
	        Log.e("writeToFile", "File write failed: " + e.toString());
	    }
	}

	// ------------------------------------------------------------------------
	//	readFromFile
	// ------------------------------------------------------------------------
    private String[] readFromFile(String fname)
    {
	    String[] ret = null;

	    try
	    {
	    	//mCtx.getFileStreamPath(mylogfile)
	        InputStream inputStream = mCtx.openFileInput(fname);

	        if ( inputStream != null )
	        {
	            InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
	            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
	            String receiveString;
	            StringBuilder stringBuilder = new StringBuilder();

	            while ( (receiveString = bufferedReader.readLine()) != null )
	            {
	                stringBuilder.append(receiveString);
	                stringBuilder.append("\n");
	            }

	            inputStream.close();
	            ret = stringBuilder.toString().split("\n",0);
	        }
	        
	      
	    }
	    catch (FileNotFoundException e)
	    {
	        Log.e("readFromFile", "File not found: " + e.toString());
	    } catch (IOException e) {
			e.printStackTrace();
		}

		//Toast.makeText(mCtx , "readFromFile: " +  fname  , Toast.LENGTH_LONG).show();

	    return ret;
	}


    // ------------------------------------------------------------------------
	//	appendToFile
	// ------------------------------------------------------------------------
	void appendToFile(String line, String fname)
	{
	    try
	    {
	        OutputStreamWriter outputStreamWriter = new OutputStreamWriter( mCtx.openFileOutput(fname, Context.MODE_APPEND));
        	outputStreamWriter.write(line);
	        outputStreamWriter.close();
	    }
	    catch (IOException e)
	    {
	        Log.e("appendToFile", "File write failed: " + e.toString());
	    }
	}

	// ------------------------------------------------------------------------
	//	writeExternalFile
	// ------------------------------------------------------------------------
	@SuppressWarnings("ResultOfMethodCallIgnored")
	private static boolean writeExternalFile(String path, String fname, String[] lines)
	{
		boolean ret = true;

		final String newline = "\n";
		if (isExternalStorageWritable())
		{
			String root = Environment.getExternalStorageDirectory().toString();
			File myDir = new File(root + "/" + path);

			if (!myDir.exists()) {
				myDir.mkdirs();
			}
			if (myDir.exists()) {
				File file = new File(myDir, fname);
				if (file.exists()) ret = file.delete();
				if (ret)
				{
					try {
						FileOutputStream out = new FileOutputStream(file);

						for (String line : lines) {
							out.write(line.getBytes());
							out.write(newline.getBytes());
						}
						out.close();
						ret = true;
					} catch (Exception e) {
						ret = false;
						e.printStackTrace();
					}
				}
			}
		}
		return ret;
	}

   // ------------------------------------------------------------------------
    //	writeExternalFile
    // ------------------------------------------------------------------------
    @SuppressWarnings("UnusedReturnValue")
	public static boolean writeExternalFile(String filename, ArrayList<String> lines)
    {
        boolean ret = false;

        final String newline = "\n";
        if (isExternalStorageWritable())
        {
            String root = Environment.getExternalStorageDirectory().toString();
            File myDir = new File(root + "/" + "RaceOwl");

            Boolean success = myDir.mkdirs();

            File file = new File (myDir, filename);
            if (file.exists ())
            {
				//noinspection ResultOfMethodCallIgnored
				file.delete();
            }
            try
            {
                FileOutputStream out = new FileOutputStream(file);

                for (String line : lines) {
                    out.write(line.getBytes());
                    out.write(newline.getBytes());
                }
                out.close();
                ret = true;
            }
            catch (Exception e)
            {
                ret = false;
                e.printStackTrace();
            }
        }
        return ret;
    }


	// ------------------------------------------------------------------------
	// Checks if external storage is available for read and write
	// ------------------------------------------------------------------------
    static private boolean isExternalStorageWritable()
	{
	    String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

	// ------------------------------------------------------------------------
	//	writeKML
	// ------------------------------------------------------------------------
	boolean writeKML(String path, String fileName, ClassLogData[] logItems)
	{
		boolean ret;

		//make sure that lat and lon are correct length
		ArrayList<String> lines = new ArrayList<>();
		lines.add("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        lines.add("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");
        lines.add("<Document>");
        lines.add(String.format("<name>%s</name>", fileName));
        lines.add("<Style id=\"bluepoly\">");
        lines.add("<LineStyle>");
        lines.add("<color>7fff0000</color>");
        lines.add("<width>4</width>");
        lines.add("</LineStyle>");
        lines.add("<PolyStyle>");
        lines.add("<color>7fff5500</color>");
        lines.add("</PolyStyle>");
        lines.add("</Style>");
        lines.add("<Placemark>");
        lines.add("<styleUrl>#bluepoly</styleUrl>");
        lines.add("<LineString>");
        lines.add("<extrude>1</extrude>");
        lines.add("<tessellate>1</tessellate>");
        lines.add("<coordinates>");
        for (ClassLogData logItem : logItems) {
            if (logItem.lat_rad != 0.0 && logItem.lon_rad != 0.0) {
                lines.add(String.format("%.6f,%.6f,%.1f", logItem.lon_rad * rtd, logItem.lat_rad * rtd, 0.0));
            }
        }
	    lines.add("</coordinates>");
	    lines.add("</LineString>");
	    lines.add("</Placemark>");
	    lines.add("</Document>");
	    lines.add("</kml>");
	    String[] mStringArray = new String[lines.size()];
	    mStringArray = lines.toArray(mStringArray);
	    ret = writeExternalFile(path,  fileName, mStringArray);
		return ret;
	}

  	// ----------------------------------------------------------------------
	// readCheckpoints
	// ----------------------------------------------------------------------
	//public String CheckpointsFile = "checkpoints.csv";
	CheckPoint[] readCheckpoints(String CheckpointsFile)
	{
	    String myData;

	    CheckPoint[] cps = null;
	    int wp_count = 0;
	    int jnx;
	    AssetManager assetManager = mCtx.getAssets();
	    try
	    {
	    	InputStreamReader reader;
			reader = new InputStreamReader (assetManager.open(CheckpointsFile));
			BufferedReader br = new BufferedReader(reader);
	        String strLine;

	        StringBuilder sb_content = new StringBuilder();

	        while ((strLine = br.readLine()) != null)
	        {
	            sb_content.append(strLine);
	            sb_content.append("\n");
	        }
	        reader.close();

	        //parse the input buffer into river_miles
	        myData = sb_content.toString();
			String[] mLines = myData.split("\n", wp_count);
	        wp_count = mLines.length;

	        cps = new CheckPoint[wp_count];

	        for (jnx=0;jnx<wp_count;jnx++)
	        {
				String[] mTokens = mLines[jnx].split(",", 10);

	            double tmp_lon_rad = Double.parseDouble(mTokens[0]) * dtr;
	            double tmp_lat_rad = Double.parseDouble(mTokens[1]) * dtr;
	            
	            double tmpValue = Double.parseDouble(mTokens[2]);
	            cps[jnx] = new CheckPoint();
	            cps[jnx].pt.latitude_rad =  tmp_lat_rad;
	            cps[jnx].pt.longitude_rad = tmp_lon_rad;
	            cps[jnx].value_m = tmpValue;
	            cps[jnx].Name = mTokens[3];
	            cps[jnx].valid = true;
                cps[jnx].isCheckpoint = (Integer.parseInt(mTokens[4])==1);
				cps[jnx].isSupported = (Integer.parseInt(mTokens[5])==1);

	        }
	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }

	    //Toast.makeText(mCtx , "readCheckpoints" , Toast.LENGTH_LONG).show();

	    return(cps);
	}


	Boolean FileExist(String filePath)
	{
		boolean ret = false;
		//File file = new File(filePath);
		File file = mCtx.getFileStreamPath(filePath);

		if(file.exists())
		{
			ret = true;
		}
		return(ret);
	}


	public final ArrayList<ClassObj> objects = new ArrayList<>();

	void ReadObjects()
	{
		AssetManager assetManager = mCtx.getAssets();

		try
	    {
			String objectFile = "objects.csv";
			InputStreamReader istrm = new InputStreamReader (assetManager.open(objectFile));
	        BufferedReader br = new BufferedReader(istrm);
	        String strLine;
	        while ((strLine = br.readLine()) != null)
	        {
				ClassObj obj = new ClassObj();

	        	String[] toks = strLine.split(",",3);
	        	if (toks.length>=3)
	        	{
			        obj.value_km[0] = Float.parseFloat(toks[0]);
			        obj.value_km[1] = Float.parseFloat(toks[1]);
			        obj.rawobj = toks[2];  	//the coordinates

//					toks = obj.rawobj.split(",");
//
//					int numCoords = (toks.length)/2;
//					obj.lat_rad = new double[numCoords];
//					obj.lon_rad = new double[numCoords];
//
//					for (int jnx=0;jnx<numCoords;jnx++)
//					{
//						obj.lon_rad[jnx] = Double.parseDouble(toks[jnx*2])*dtr;
//						obj.lat_rad[jnx] = Double.parseDouble(toks[jnx*2+1])*dtr;
//					}
//					obj.rawobj = "";


				}
		        objects.add(obj);
	        }
	        istrm.close();
	    }
	    catch (IOException e)
	    {
	        e.printStackTrace();
	    }

	}


    public ArrayList<Integer> GetObjects(double value_m, double radius_m, ClassObjIndex[] objIndices)
	{

		ArrayList<Integer> ret = new ArrayList<>();
		int startIdx = (int) max((value_m-radius_m) * Const.m_to_km,0);
		int endIdx = (int) min((value_m+radius_m) * Const.m_to_km,objIndices.length-1);

		
		//form combined index of objects to plot
		for (int inx=startIdx;inx<=endIdx;inx++)
		{
			ret.addAll(objIndices[inx].objs);
		}
		
		ret = new ArrayList<>(new HashSet<>(ret));
		for (int inx=0;inx<ret.size();inx++)
		{
			ClassObj obj = objects.get(ret.get(inx));
			if (obj.lat_rad==null)
			{
				String[] toks = obj.rawobj.split(",");

				int numCoords = (toks.length)/2;
				obj.lat_rad = new double[numCoords];
				obj.lon_rad = new double[numCoords];

				for (int jnx=0;jnx<numCoords;jnx++)
				{
					obj.lon_rad[jnx] = Double.parseDouble(toks[jnx*2])*dtr;
					obj.lat_rad[jnx] = Double.parseDouble(toks[jnx*2+1])*dtr;
				}
				obj.rawobj = "";
			}
		}
		return (ret);
	}

    // ------------------------------------------------------------------------
	//	deleteDirectory
	// ------------------------------------------------------------------------
	@SuppressWarnings("ResultOfMethodCallIgnored")
	private void deleteFile(File file)
	{
		if(file.exists())
	    {
			file.delete();
	    }
	}
}
