package com.ProPaddlerMi.baseclass;


import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;

//import static com.ProPaddlerMi.baseclass.RacerState.checkpoint_radius_dr_rad;

@SuppressWarnings("WeakerAccess")
public class RouteRelative {

    public enum StartState
    {
        unknown,
        armed,
        restart
    }

    public enum ErrorCode
    {
        normal,
        locationNotOnRoute,
        badWayPointDefinition,
        invalidGeometry,
        locationNotNearStart,
        invalidCheckpointTransition,
        backwardsProgress,
        locationPastRaceEnd
    }


    public double cpIndex;              // a checkpoint_index + checkpoint_frac = a combined overall checkpoint state representation value
    public Boolean atCp;                   // true if the racer is considered at a checkpoint. this is typically 500ft in distance before and 500ft after the geolocation point
    public int wpIndex;                 // serves as a current waypoint index to start search for with locating self in waypoints
    public int prevWpIndex;             // the past waypoint index
    public double value_m;              // value of the route (typically the rivermile or distance)
    public double crossTrack_rad;       // crosstrack arc Length from past checkpoint to current position
    public double segment_frac;         // fraction that represents the downtrack position of a racer between 2 checkpoints. <0 behind checkpoint 1,
    // 0 = at waypoint 1, between 0 and 1 = between waypoint 1 and 2,  1 = at waypoint 2, > 1 ahead of waypoint 2
    public ArrayList<ErrorCode> errors;      // ArrayList of error codes associated with RouteRelative
    public StartState startState;             // true if we are in the starting box

    //constructor
    public RouteRelative()
    {
        cpIndex = 0.0;
        atCp = false;                   //true if considered at a checkpoint
        crossTrack_rad = Const.two_pi;  //init to a large number since we are checking for them to be very small
        prevWpIndex = -1;               //init to invalid point
        wpIndex = -1;                   //init to invalid point
        value_m = 0.0;
        //maxRouteDist_m = 0.0;
        segment_frac = Const.large;     //init to a large number since we are checking for them to be between 0 and 1
        errors = new ArrayList<>();
        startState = StartState.unknown;
    }

    public RouteRelative(RouteRelative s0)
    {
        cpIndex = s0.cpIndex;
        atCp = s0.atCp;
        crossTrack_rad = s0.crossTrack_rad;
        wpIndex = s0.wpIndex;
        prevWpIndex = s0.prevWpIndex;
        value_m = s0.value_m;
        //maxRouteDist_m = s0.maxRouteDist_m;
        segment_frac = s0.segment_frac;
        errors = new ArrayList<>();
        startState = s0.startState;
    }
    public RouteRelative(Route r0)
    {
        this();
        if (r0.wps.length > 1)
        {
            crossTrack_rad = 0;
            wpIndex = 1;
            prevWpIndex = 0;
            value_m = r0.wps[0].value_m;
            segment_frac = 0;
        }
    }


    // ----------------------------------------------------------------------
    //  RouteRelative with no previous data (reset)
    //	Given Lat/lon and route, propagate the racer state
    /// <param name="p1">pose of the racer</param>
    /// <param name="route">race route</param>
    // ----------------------------------------------------------------------
    public RouteRelative(Pose p1, Route route)
    {
        this(route);
        RouteRelative r1 = null;
        double minValue_m;
        double maxValue_m;
        Bound bound = new Bound();

        // check for a good route
        if (route.wps.length < 2)
        {
            errors.add(ErrorCode.badWayPointDefinition);
        }

        // check for bounding box
        if (errors.size() == 0) {
            minValue_m = route.minValue();
            maxValue_m = route.maxValue();
            bound = new Bound(p1.pt, route, minValue_m, maxValue_m, route.maxCrossTrack_rad);
            if (!bound.isValidBound)
            {
                errors.add(ErrorCode.locationNotOnRoute);
            }
        }

        // find first acceptable match
        if (errors.size() == 0)
        {
            ArrayList<RouteGeometry> rr1s = RouteGeometry.CalcRouteGeometry(p1, null, route, bound);

            // best selection
            //RouteGeometry selRouteGeometry = RouteGeometrySelection.SelectMinCost(rr1s, route, minValue_m, maxValue_m, 0, null);
            RouteGeometry selRouteGeometry = RouteGeometrySelection.SelectMinCrossTrack(rr1s, route);

            // error if there are still no matching within constraints
            // find where we are at in the waypoints
            if (selRouteGeometry.errorCode == ErrorCode.invalidGeometry)
            {
                ErrorCode err = ErrorCode.locationNotOnRoute;
                errors.add(err);
            }

            // post selection filter
            if (errors.size() <= 0 && Math.abs(selRouteGeometry.crossTrack_rad) > route.maxCrossTrack_rad)
            {
                ErrorCode err = ErrorCode.locationNotOnRoute;
                errors.add(err);
            }

//            // post selection filter (within threshold value up stream)
//            if (errors.size() <= 0 && (selRouteGeometry.value_m/Const.earth_a_m) < -route.maxDownTrack_rad)
//            {
//                ErrorCode err = ErrorCode.locationNotOnRoute;
//                errors.add(err);
//            }
//
//            // post selection filter (within threshold value up stream)
//            if (errors.size() <= 0 && (selRouteGeometry.value_m / Const.earth_a_m) > route.wps[route.wps.length - 1].value_m + route.maxDownTrack_rad)
//            {
//                ErrorCode err = ErrorCode.locationNotOnRoute;
//                errors.add(err);
//            }

            if (errors.size() == 0)
            {
                r1 = new RouteRelative(selRouteGeometry, route);
            }
        }

        if (r1 != null && errors.size() == 0)
        {
            atCp = r1.atCp;                     //true if the racer is considered at a checkpoint. this is typically 500ft in distance before and 500ft after the geolocation point
            cpIndex = r1.cpIndex;               //a checkpoint_index + checkpoint_frac = a combined overall checkpoint state representation value
            crossTrack_rad = r1.crossTrack_rad; //crosstrack arc Length from past checkpoint to current position
            prevWpIndex = r1.prevWpIndex;               //serves as a current waypoint index to start search for with locating self in waypoints
            wpIndex = r1.wpIndex;               //serves as a current waypoint index to start search for with locating self in waypoints
            value_m = r1.value_m;               //value of the route (typically the rivermile or distance)
            segment_frac = r1.segment_frac;     //fraction that represents the downtrack position of a racer between 2 checkpoints. <0 behind checkpoint 1,
        }
    }


    // ----------------------------------------------------------------------
    //  RouteRelative
    //	Given Lat/lon, last state and route, propagate the racer state
    // ----------------------------------------------------------------------
    public RouteRelative(LatLngTime rep1, Pose p1, Track t1, Route route, RacerState s0)
    {
        this(s0.routeRelative);

        // init the starting way point index. NOTE: you don't want to start at 0 index. will always be
        // the waypoint you are going to, not coming from
        int startWpIndex;
        RouteRelative r1 = new RouteRelative();

        // check for min wp size()
        if (route.wps.length < 2)
        {
            errors.add(ErrorCode.badWayPointDefinition);
        }

        ArrayList<RouteGeometry> rr1s = new ArrayList<>(); //RouteGeometry.CalcRouteGeometry(p1, selWayPoints);

        double maxValue_m;
        double minValue_m;
        if (errors.size() == 0)
        {

            //select values based upon time and speed
            double maxSpeed_mps = s0.summary.InitSpeed() ? route.maxSpeed_mps(): Math.max(Math.min(s0.summary.maxSpeed_mps * 1.3, route.maxSpeed_mps()), Const.minSpeed_mps);
            double deltaTime_s = (rep1.utcTime_ms - s0.pose1.utc_ms) * Const.ms_to_sec ;
            double maxDeltaValue_m = deltaTime_s * maxSpeed_mps;

            minValue_m = s0.routeRelative.value_m;
            maxValue_m = maxDeltaValue_m > 0 ? s0.routeRelative.value_m + maxDeltaValue_m : s0.routeRelative.value_m;

            //select route bound based on last state and the max possible route progression
            Bound lowerBound = route.GetBound(minValue_m, Const.maxMeasurementError_m);
            Bound upperBound = route.GetBound(maxValue_m, Const.maxMeasurementError_m);
            Bound selBound = new Bound(lowerBound.bnd0, upperBound.bnd1, route);

            // Calculate the geometry of the point relative to the selected waypoints
            rr1s = RouteGeometry.CalcRouteGeometry(p1, t1, route, selBound);

            if (rr1s.size() == 0)
            {
                errors.add(ErrorCode.locationNotOnRoute);
            }
        }

        if (errors.size() == 0)
        {
            RouteGeometry selRouteGeometry;

            // take the geometry and select the best relative position given the location
            //selRouteGeometry = RouteGeometrySelection.SelectMinCost(rr1s, route, minValue_m, maxValue_m, targetValue_m, s0);
            selRouteGeometry = RouteGeometrySelection.SelectMinCrossTrack(rr1s, route);

            // error if there are still no matching within constraints
            // find where we are at in the waypoints
            if (selRouteGeometry.errorCode != RouteRelative.ErrorCode.normal)
            {
                errors.add(ErrorCode.locationNotOnRoute);
            }
            else
            {
                // select the first as our best location
                r1 = new RouteRelative(selRouteGeometry, route);

            }

            // verify the best route relative
            if (errors.size() == 0)
            {
                errors = VerifyRouteRelative(r1, route);
            }

            // finalize the route relative
            if (errors.size() == 0)
            {
                // is this a variable start? if so, then we have to be in the start box if to start the race
                if (s0.checkPointStatus.startIndex == 1)
                {
                    if (!s0.checkPointStatus.RaceStarted())
                    {
                        if (s0.checkPointStatus.current.currentCycle.state != PointHistory.PointHistoryState.armed && r1.cpIndex > 1)
                        {
                            errors.add(ErrorCode.locationNotNearStart);
                        }
                        else if ((r1.cpIndex > 0 && r1.cpIndex < 1))
                        {
                            r1.startState = StartState.armed;
                        }
                    }
//                    else if (r1.cpIndex < 1) // race started but back behind the start line
//                    {
//
//                    }
                }
            }
        }

        if (errors.size() == 0)
        {
            atCp = r1.atCp;                     //true if the racer is considered at a checkpoint. this is typically 500ft in distance before and 500ft after the geolocation point
            cpIndex = r1.cpIndex;               //a checkpoint_index + checkpoint_frac = a combined overall checkpoint state representation value
            crossTrack_rad = r1.crossTrack_rad; //crosstrack arc Length from past checkpoint to current position
            wpIndex = r1.wpIndex;               //serves as a current waypoint index to start search for with locating self in waypoints
            prevWpIndex = r1.prevWpIndex;
            value_m = r1.value_m;               //value of the route (typically the rivermile or distance)
            segment_frac = r1.segment_frac;     //fraction that represents the downtrack position of a racer between 2 checkpoints. <0 behind checkpoint 1,
            startState = r1.startState;
        }
    }

    private RouteRelative(RouteGeometry s0, Route route)
    {
        cpIndex = FindCheckpointIndex(s0.value_m, route.cps);
        crossTrack_rad = s0.crossTrack_rad;
        prevWpIndex = s0.prevWpIndex;
        wpIndex = s0.currWpIndex;
        value_m = s0.value_m;
        //maxRouteDist_m = route.maxValue();
        segment_frac = s0.segment_frac;
        errors = new ArrayList<>();
        atCp = IsCheckpoint(this, route);  //do this last!
        startState = StartState.unknown;
    }


    public static String ErrorCodeMessage(int code)
    {
        ErrorCode retcode = ErrorCode.values()[code];
        String errorMessage;
        switch (retcode)
        {
            case normal:
                errorMessage = "";
                break;
            case locationNotOnRoute:
                errorMessage = "off race course";//"Geo location is outside the route location bounds";
                break;
            case badWayPointDefinition:
                errorMessage = "bad race route"; // "Insufficient number of waypoints defined. You must have at least 2";
                break;
            case invalidGeometry:
                errorMessage = "no route fix";//"Route geometry is invalid";
                break;
            case locationNotNearStart:
                errorMessage = "bad start point";// Geo location is not near the race start. This is required for beginning of the race";
                break;
            case invalidCheckpointTransition:
                errorMessage = "Invalid Checkpoint Transition"; //"Auto Checkpoints must not skip numbers"
                break;
            case backwardsProgress:
                errorMessage = "Backwards progress"; //"Racer is going the wrong direction"
                break;
            case locationPastRaceEnd:
                errorMessage = "Past race end"; //"Racer beyond the finish line"
                break;
            default:
                errorMessage = "Unknown error code";
                break;
        }
        return errorMessage;
    }


    // ----------------------------------------------------------------------
    //  FindCheckpointIndex
    // ----------------------------------------------------------------------
    public static double FindCheckpointIndex(double value, CheckPoint[] cps)
    {
        double cpv;
        int idx = BinarySearchIterative(value, cps);
        if (idx < cps.length - 1)
        {
            double cpDelta = (cps[idx + 1].value_m - cps[idx].value_m);
            double ownDelta = value - cps[idx].value_m;
            cpv = idx + ownDelta / cpDelta; //form a ratio and then add to the index
        }
        else
        {
            cpv = idx;
        }
        return (cpv);
    }

    // ----------------------------------------------------------------------
    //  BinarySearchIterative
    //	return the best index that has a value less than or equal to value
    // ----------------------------------------------------------------------
    public static int BinarySearchIterative(double value, CheckPoint[] cps)
    {
        int min = 0;
        int max = cps.length - 1;
        int mid;
        int dir = cps[max].value_m > cps[min].value_m ? 1 : -1;
        if (dir > 0)
        {
            while (min < max)
            {
                mid = (min + max) / 2;
                if (value == cps[mid].value_m)
                {
                    return mid;
                }
                else if (value < cps[mid].value_m)
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }
            }
            //adjust min to always be the nearest to the value
            min = value < cps[min].value_m ? Math.max(min - 1, 0) : min;

        }
        else
        {
            while (min < max)
            {
                mid = (min + max) / 2;
                if (value == cps[mid].value_m)
                {
                    return mid;
                }
                else if (value > cps[mid].value_m)
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }
            }
            //adjust min to always be the nearest to the value
            min = value > cps[min].value_m ? Math.max(min - 1, 0) : min;

        }
        return (min);
    }

    // ----------------------------------------------------------------------
    // IsCheckpoint
    // ----------------------------------------------------------------------
    public static Boolean IsCheckpoint(RouteRelative rr1, Route route)
    {
        boolean ret = false;
        if (!Double.isInfinite(rr1.cpIndex) && !Double.isNaN(rr1.cpIndex) && rr1.cpIndex >= 0)
        {
            int nearCheckPointIndex = (int)Math.round(rr1.cpIndex);
            if (nearCheckPointIndex < route.cps.length)
            {
                double cp_delta_m = Math.abs(rr1.value_m - route.cps[nearCheckPointIndex].value_m);

                // default this to false - not at a checkpoint
                if (cp_delta_m < route.checkPointRadius_rad * Const.earth_a_m)
                {
                    ret = true;
                }
            }
        }
        return (ret);
    }
    private ArrayList<ErrorCode> VerifyRouteRelative(RouteRelative r1, Route route)
    {
        ArrayList<ErrorCode> errorCodes = new ArrayList<>();
        // don't exceed the cross track
        if (Math.abs(r1.crossTrack_rad) > route.maxCrossTrack_rad) errorCodes.add(ErrorCode.locationNotOnRoute);

        return (errorCodes);
    }
}