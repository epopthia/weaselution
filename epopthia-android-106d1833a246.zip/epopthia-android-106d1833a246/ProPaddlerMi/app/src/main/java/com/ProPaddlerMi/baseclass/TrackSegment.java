package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

@SuppressWarnings({"WeakerAccess", "unused"})
public
class TrackSegment {

    public Vector3D ur; //unit radial Vector3D
    public Vector3D un; //unit normal Vector3D
    public Vector3D ut; //unit tangential Vector3D (from last to new point)
    public double dr_rad; //arc between last and new
    public double dN_m; // approximate change in north position
    public double dE_m; // approximate change in east position
    public double dT_ms; // delta time change from last position
    public RangeBearing rb; //bearing angle and range from last location  (0 = north, 90deg = east)
    public double posVel_mps; //location/time based speed between last location and this location

    public TrackSegment()
    {
        ur = new Vector3D();
        un = new Vector3D();
        ut = new Vector3D();
        dr_rad = 0.0;
        dN_m = 0.0;
        dE_m = 0.0;
        dT_ms = 0.0;
        rb = new RangeBearing();
        posVel_mps = 0.0;
    }

    /// <summary>
    /// copy constructor
    /// </summary>
    /// <param s0="reference TrackSegment"></param>
    public TrackSegment(TrackSegment s0)
    {
        ur = new Vector3D(s0.ur);
        un = new Vector3D(s0.un);
        ut = new Vector3D(s0.ut);
        dr_rad = s0.dr_rad;
        dN_m = s0.dN_m;
        dE_m = s0.dE_m;
        dT_ms = s0.dT_ms;
        rb = new RangeBearing(s0.rb);
        posVel_mps = s0.posVel_mps;
    }

    //-----------------------------------------------------------------------------
    // TrackSegment
    //-----------------------------------------------------------------------------
    public TrackSegment(LatLngRad p0, LatLngRad p1)
    {
        this();

        Vector3D ur0 = ComputeUnitRadialVector(p0.latitude_rad, p0.longitude_rad);
        // unit radial
        ur = ComputeUnitRadialVector(p1.latitude_rad, p1.longitude_rad);
        // unit normal (last to new)
        un = ComputeUnitNormalVector(ur0, ur);
        // unit tangential (last to new)
        ut = ComputeUnitTangentialVector(un, ur);
        // dr_rad (last to new)
        dr_rad = VectorDot3D(ur0, ut);
        // change in north position
        dN_m = (p1.latitude_rad - p0.latitude_rad) * Const.earth_a_m;
        // change in east position
        dE_m = (p1.longitude_rad - p0.longitude_rad) * Const.earth_a_m * Math.cos(p0.latitude_rad);
        // change in time
        dT_ms = 0.0;
        // bearing angle from last point
        rb = new RangeBearing(p0, p1);
    }

    /// <summary>
    /// Initial call to the track segment with no prior history to draw from
    /// </summary>
    /// <param p1="current pose"></param>
    public TrackSegment(Pose pt0)
    {
        this();
        rb = new RangeBearing();
        rb.bearing_rad = pt0.gpsBrg_rad;
        ur = pt0.ur; //ComputeUnitRadialVector(pt0.pt.latitude_rad, pt0.pt.longitude_rad);
    }

    /// <summary>
    /// combine current pose with past racerstate to determine the current track segment.
    /// The track segment describes the path that the racer has taken between current position
    /// and the last position. this is independent of the race route definition.
    /// this is the nominal constructor
    /// </summary>
    /// <param p1="current pose"></param>
    /// <param s0="the last racer state"></param>
    public TrackSegment(Pose p1, Pose p0)
    {
        this();
        // unit radial
        ur = ComputeUnitRadialVector(p1.pt.latitude_rad, p1.pt.longitude_rad);
        // unit normal (last to new)
        un = ComputeUnitNormalVector(p0.ur, ur);
        // unit tangential (last to new)
        ut = ComputeUnitTangentialVector(un, ur);
        // dr_rad (last to new)
        dr_rad = VectorDot3D(p0.ur, ut);
        // change in north position
        dN_m = (p1.pt.latitude_rad - p0.pt.latitude_rad) * Const.earth_a_m;
        // change in east position
        dE_m = (p1.pt.longitude_rad - p0.pt.longitude_rad) * Const.earth_a_m * Math.cos(p0.pt.latitude_rad);
        // bearing angle from last point
        rb = new RangeBearing(p0.pt, p1.pt);
        // change in time
        dT_ms = p1.utc_ms - p0.utc_ms;
        //speed
        if (dT_ms > 0)
        {
            posVel_mps = this.dr_rad * Const.earth_a_m / (dT_ms * Const.ms_to_sec);
        }
    }


    //-----------------------------------------------------------------------------
    // CalcAngleBetweenSegments
    //-----------------------------------------------------------------------------
    public static double CalcAngleBetweenSegments(TrackSegment t0, TrackSegment t1)
    {
        Vector3D Un = NegateVector(t0.ur);
        return (Math.atan2(VectorDot3D(VectorCross3D(t0.ut, t1.ut), Un), VectorDot3D(t0.ut, t1.ut)));
    }

    //-----------------------------------------------------------------------------
    //function:      DistBetweenWaypoints
    //description:   Calculate the distance between waypoints in feet
    //arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
    //return:        distance_m
    //-----------------------------------------------------------------------------
    public static double DistBetweenWaypointsMeters(LatLngRad pt0, LatLngRad pt1)
    {
        Vector3D ur1 = ComputeUnitRadialVector(pt0.latitude_rad, pt0.longitude_rad);
        Vector3D ur2 = ComputeUnitRadialVector(pt1.latitude_rad, pt1.longitude_rad);
        Vector3D un = ComputeUnitNormalVector(ur1, ur2);
        Vector3D ut = ComputeUnitTangentialVector(un, ur2);
        return (VectorDot3D(ur1, ut) * Const.earth_a_m);
    }
    //-----------------------------------------------------------------------------
    //function:      ComputeUnitRadialVector
    //-----------------------------------------------------------------------------
    public static Vector3D ComputeUnitRadialVector(LatLngRad pt)
    {
        return ComputeUnitRadialVector(pt.latitude_rad, pt.longitude_rad);
    }
    //-----------------------------------------------------------------------------
    //function:      ComputeUnitRadialVector
    //description:   Given a Lat/lon compute the unit radial Vector3D
    //arguments:     double latitude_rad, double longitude_rad, double ur.v[3]
    //return:        ur
    //-----------------------------------------------------------------------------
    public static Vector3D ComputeUnitRadialVector(double latitude_rad, double longitude_rad)
    {

        Vector3D ur = new Vector3D();

        double sin_lat;
        double sin_lon;
        double cos_lat;
        double cos_lon;
        double radial_magnitude;

        sin_lat = Math.sin(latitude_rad);
        sin_lon = Math.sin(longitude_rad);
        cos_lat = Math.cos(latitude_rad);
        cos_lon = Math.cos(longitude_rad);
        radial_magnitude = Math.sqrt(1.0 - Const.gd_two_e2_minus_e4 * sin_lat * sin_lat);

        ur.v[0] = cos_lat * cos_lon / radial_magnitude;
        ur.v[1] = cos_lat * sin_lon / radial_magnitude;
        ur.v[2] = (1.0 - Const.gd_e2) * sin_lat / radial_magnitude;

        return (ur);
    }

    //-----------------------------------------------------------------------------
    //function:      calcUnitNormalVector
    //description:
    //arguments:     double ur1[3] ,double ur2[3]
    //return:        un
    //-----------------------------------------------------------------------------
    public static Vector3D ComputeUnitNormalVector(Vector3D ur1, Vector3D ur2)
    {
        Vector3D un1 = new Vector3D();


        //Compute Unit Normal Vector via the cross product
        un1.v[0] = ur2.v[1] * ur1.v[2] - ur2.v[2] * ur1.v[1];
        un1.v[1] = ur2.v[2] * ur1.v[0] - ur2.v[0] * ur1.v[2];
        un1.v[2] = ur2.v[0] * ur1.v[1] - ur2.v[1] * ur1.v[0];

        //Normalize Vector
        return (NormalizeVector(un1));

    }

    //-----------------------------------------------------------------------------
    //function:      ComputeUnitTangentialVector
    //description:   Compute Unit Tangential Vector
    //arguments:     double un[3] ,double ur.v[3] ,double ut[3]
    //return:        un
    //-----------------------------------------------------------------------------
    public static Vector3D ComputeUnitTangentialVector(Vector3D un, Vector3D ur)
    {
        return (VectorCross3D(un, ur));
    }

    //-----------------------------------------------------------------------------
    //function:      VectorDot3D
    //description:   Compute the dot product between 2 vectors A.B = C
    //arguments:     A   - Vector3D source  0
    //              B   - Vector3D source  1
    //return:        dot product
    //-----------------------------------------------------------------------------
    public static double VectorDot3D(Vector3D a, Vector3D b)
    {
        double dp = 0.0;
        for (int inx = 0; inx < 3; inx++)
        {
            dp += (a.v[inx] * b.v[inx]);
        }
        return (dp);
    }

    //-----------------------------------------------------------------------------
    //function:      VectorNorm3D
    //description:   compute the vector norm
    //arguments:     A   - Vector3D source  0
    //return:        norm
    //-----------------------------------------------------------------------------
    public static double VectorNorm3D(Vector3D a)
    {
        double dp = a.v[0] * a.v[0];
        dp += a.v[1] * a.v[1];
        dp += a.v[2] * a.v[2];
        return (Math.sqrt(dp));
    }

    //------------------------------------------------------------------------------
    //Function:       VectorCross3D
    //Description:    3D cross product  a X b
    //Arguments:      a
    //              b
    //              cross_prod_out
    //Return value:   cross_prod_out
    //------------------------------------------------------------------------------
    public static Vector3D VectorCross3D(Vector3D a, Vector3D b)
    {
        Vector3D cross_prod_out = new Vector3D();
        cross_prod_out.v[0] = a.v[1] * b.v[2] - a.v[2] * b.v[1];
        cross_prod_out.v[1] = a.v[2] * b.v[0] - a.v[0] * b.v[2];
        cross_prod_out.v[2] = a.v[0] * b.v[1] - a.v[1] * b.v[0];
        return (cross_prod_out);
    }

    //-----------------------------------------------------------------------------
    //function:      DistBetweenWaypoints
    //description:   Calculate the distance between waypoints in feet
    //arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
    //return:        distance_m
    //-----------------------------------------------------------------------------
    public static double VelocityBetweenWaypointsMps(Pose pt0, Pose pt1)
    {
        double velocity = 0.0;
        long deltaT = (pt1.utc_ms - pt0.utc_ms);
        if (deltaT > 0.0)
        {
            Vector3D ur1 = ComputeUnitRadialVector(pt0.pt.latitude_rad, pt0.pt.longitude_rad);
            Vector3D ur2 = ComputeUnitRadialVector(pt1.pt.latitude_rad, pt1.pt.longitude_rad);
            Vector3D un = ComputeUnitNormalVector(ur1, ur2);
            Vector3D ut = ComputeUnitTangentialVector(un, ur2);
            velocity = VectorDot3D(ur1, ut) * Const.earth_a_m / (deltaT * Const.ms_to_sec);
        }
        return (velocity);
    }
    //-----------------------------------------------------------------------------
    //function:      DistBetweenWaypoints
    //description:   Calculate the distance between waypoints in feet
    //arguments:     double lat1_rad, double lon1_rad, double lat2_rad, double lon2_rad)
    //return:        distance_m
    //-----------------------------------------------------------------------------
    public static double VelocityBetweenValueMps(double deltaValue_m, long deltaT_ms)
    {
        double velocity = 0.0;
        if (deltaT_ms > 0.0)
        {
            velocity = deltaValue_m / (deltaT_ms * Const.ms_to_sec);
        }
        return (velocity);
    }


    public static Vector3D NegateVector(Vector3D v)
    {
        return (new Vector3D(-v.v[0], -v.v[1], -v.v[2]));
    }


    //-----------------------------------------------------------------------------
    //function:      normalizeVector
    //description:
    //arguments:
    //return:        v_out
    //-----------------------------------------------------------------------------
    public static Vector3D NormalizeVector(Vector3D v_in)
    {

        Vector3D v_out = new Vector3D();
        double mag_v_in_sq;
        double Normalize_Vector_1_1;
        double check_val_out;
        int i;

        mag_v_in_sq = 0.0;
        for (i = 0; i < 3; i++)
        {
            mag_v_in_sq += v_in.v[i] * v_in.v[i];
        }
        Normalize_Vector_1_1 = Math.sqrt(mag_v_in_sq);

        check_val_out = Normalize_Vector_1_1;

        if ((Math.abs(Normalize_Vector_1_1) < 1.0E-008))
        {
            check_val_out = 1.0E-008;
        }

        //normalize
        for (i = 0; i < 3; i++)
        {
            v_out.v[i] = v_in.v[i] / check_val_out;
        }

        return (v_out);
    }
}
