package com.ProPaddlerMi.infrastructure;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class NetworkMonitor {

    static public boolean isNetworkAvailable(Context context) {
        boolean ret = false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        if (null != activeNetwork) {
            int type = activeNetwork.getType();
            if (type == ConnectivityManager.TYPE_MOBILE || type == ConnectivityManager.TYPE_WIFI)
            {
                ret = true;
            }
        }
        return ret;
    }
}