package com.ProPaddlerMi;

//
//public class RaceOwlGlobals {
//    String race_owl_races;
//
//    public RaceOwlGlobals()
//    {
//        race_owl_races = "";
//    }
//}
