package com.ProPaddlerMi.baseclass;

public class Interpolate {
    //-----------------------------------------------------------------------------
    //   function:      interpolateIndex2D
    //   description:   Linear 2D interpolation
    //   arguments:     U - input scalar, Us vector of U values,
    //                  note: any y can be evaluated with Y = (1.0 - result.alpha) * Ys[result.iLower] + result.alpha * Ys[result.iUpper];
    //-----------------------------------------------------------------------------
    public static InterpolateResult InterpolateIndex2D(double U, double[] Us)
    {

        InterpolateResult result = new InterpolateResult();

        int totbp = Us.length;
        int itotbp = totbp - 1;
        int k;

        if (Us[itotbp] - Us[0] > 0)
        {

            //Linear Interp
            if (U <= Us[0])
            {
                result.iLower = 1;
                result.iUpper = 0;
            }
            else if (U >= Us[itotbp])
            {
                result.iLower = itotbp - 1;
                result.iUpper = itotbp;
            }
            else
            {
                result.iLower = 0;
                result.iUpper = itotbp;
                while (result.iUpper - result.iLower > 1)
                {
                    k = (result.iUpper + result.iLower) / 2;
                    if (Us[k] > U) result.iUpper = k;
                    else result.iLower = k;
                }
            }
        }
        else
        {

            //Linear Interp
            if (U >= Us[0])
            {
                result.iLower = 1;
                result.iUpper = 0;
            }
            else if (U <= Us[itotbp])
            {
                result.iLower = itotbp - 1;
                result.iUpper = itotbp;
            }
            else
            {
                result.iLower = 0;
                result.iUpper = itotbp;
                while (result.iUpper - result.iLower > 1)
                {
                    k = (result.iUpper + result.iLower) / 2;
                    if (Us[k] < U) result.iUpper = k;
                    else result.iLower = k;
                }
            }
        }
        result.alpha = (U - Us[result.iLower]) / (Us[result.iUpper] - Us[result.iLower]);
        result.value = (1.0 - result.alpha) * Us[result.iLower] + result.alpha * Us[result.iUpper];

        return (result);
    }

    //-----------------------------------------------------------------------------
    //   function:      interpolateIndex2D
    //   description:   Linear 2D interpolation
    //   arguments:     U - input scalar, Us vector of U values,
    //                  output: result.alpha: linear fraction for interpolation between break points
    //                  result.iLower: lower index
    //                  uupper: uppder index
    //                  note: any y can be evaluated with Y = (1.0 - result.alpha) * Ys[result.iLower] + result.alpha * Ys[result.iUpper];
    //-----------------------------------------------------------------------------
    public static InterpolateResult InterpolateIndex2D(long U, long[] Us)
    {
        InterpolateResult result = new InterpolateResult();

        int totbp = Us.length;
        int itotbp = totbp - 1;
        int k;

        if (Us[itotbp] - Us[0] > 0)
        {

            //Linear Interp
            if (U <= Us[0])
            {
                result.iLower = 0;
                result.iUpper = 1;
            }
            else if (U >= Us[itotbp])
            {
                result.iLower = itotbp - 1;
                result.iUpper = itotbp;
            }
            else
            {
                result.iLower = 0;
                result.iUpper = itotbp;
                while (result.iUpper - result.iLower > 1)
                {
                    k = (result.iUpper + result.iLower) / 2;
                    if (Us[k] > U) result.iUpper = k;
                    else result.iLower = k;
                }
            }
        }
        else
        {

            //Linear Interp
            if (U >= Us[0])
            {
                result.iLower = 0;
                result.iUpper = 1;
            }
            else if (U <= Us[itotbp])
            {
                result.iLower = itotbp - 1;
                result.iUpper = itotbp;
            }
            else
            {
                result.iLower = 0;
                result.iUpper = itotbp;
                while (result.iUpper - result.iLower > 1)
                {
                    k = (result.iUpper + result.iLower) / 2;
                    if (Us[k] < U) result.iUpper = k;
                    else result.iLower = k;
                }
            }
        }
        result.alpha = (U - Us[result.iLower]) / (double) (Us[result.iUpper] - Us[result.iLower]);
        result.value = (1.0 - result.alpha) * Us[result.iLower] + result.alpha * Us[result.iUpper];

        return (result);
    }
}
