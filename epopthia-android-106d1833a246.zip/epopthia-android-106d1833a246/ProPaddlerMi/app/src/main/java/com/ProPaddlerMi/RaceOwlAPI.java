package com.ProPaddlerMi;

import com.ProPaddlerMi.baseclass.CheckPoint;
import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;
import java.util.Date;

public class RaceOwlAPI
{

    // Race item fields
    @SuppressWarnings("WeakerAccess")
    public static class RaceEvent {
        public int RaceEventID;
        public String RaceName; //note: this may be a duplicate
        public String RaceCode; //unique String
        int RaceID;
        public String RaceEventDesc;
        String RaceEventToken;
        public String StartDate;
        public String EndDate;
        String CheckpointTextNumber;
        String LocationTextNumber;
        public boolean IsMiles;
        public final boolean IsThrowdown;
        public final boolean HasPenaltyMinutes;
        public final boolean AutoCheckin;
        public final boolean VariableStart;
        public final int LocationSecondsPerSample;
		public String StartGPS; // "lat,lon" in degrees
  

        public RaceEvent()
        {
            RaceEventID = 0;
            RaceName = "";
            RaceCode = "";
            RaceID = 0;
            RaceEventDesc = "";
            RaceEventToken = "";
            StartDate = ClassUtility.getRaceOwlNetTime(new Date(),0);
            EndDate = ClassUtility.getRaceOwlNetTime(new Date(),24);
            CheckpointTextNumber = "";
            LocationTextNumber = "";
            IsMiles = true;
            IsThrowdown = false;
            HasPenaltyMinutes = false;
            AutoCheckin = false;
            VariableStart = false;
            LocationSecondsPerSample = (int) (5 * Const.minute_to_sec);

        }

        public RaceEvent(RaceEvent ref_event) {
            RaceEventID = ref_event.RaceEventID;
            RaceName = ref_event.RaceName;
            RaceCode = ref_event.RaceCode;
            RaceID = ref_event.RaceID;
            RaceEventDesc = ref_event.RaceEventDesc;
            RaceEventToken = ref_event.RaceEventToken;
            StartDate = ref_event.StartDate;
            EndDate = ref_event.EndDate;
            CheckpointTextNumber = ref_event.CheckpointTextNumber;
            LocationTextNumber = ref_event.LocationTextNumber;
            IsMiles = ref_event.IsMiles;
            IsThrowdown = ref_event.IsThrowdown;
            HasPenaltyMinutes = ref_event.HasPenaltyMinutes;
            AutoCheckin = ref_event.AutoCheckin;
            VariableStart = ref_event.VariableStart;
            LocationSecondsPerSample = ref_event.LocationSecondsPerSample;
            StartGPS = ref_event.StartGPS;
        }

    }


    // raceowl checkpoints
    @SuppressWarnings("WeakerAccess")
    public static class ApiUpsertCheckpoints
    {
        public int RaceEventID;
        public String UID;
        public String AndroidCheckpointJson1;  //JSON String containig list of UpsertCheckpoint items
    }

    // raceowl checkpoints
    @SuppressWarnings("WeakerAccess")
    public static class UploadCheckpoint {
        final int CheckpointID;
        final String Name;
        final double Lat;       //deg
        final double Lng;       //deg
        final int MilesToNext;
        final String AuthCode;  //8 char max
        final String Cutoff;    //MMddyyyyHHmmss
        final int Order;

        UploadCheckpoint(CheckPoint lcp)
        {
            Name = lcp.Name;
            Lat = lcp.pt.latitude_rad * Const.rtd;
            Lng = lcp.pt.longitude_rad * Const.rtd;
            MilesToNext = Math.round(lcp.MilesToNext);
            CheckpointID = 0;
            AuthCode = "";
            Cutoff = lcp.CutOff;
            Order = lcp.order;
        }
        UploadCheckpoint()
        {
            Name = "";
            Lat = 0.0;
            Lng = 0.0;
            MilesToNext = 0;
            CheckpointID = 0;
            AuthCode = "";
            Cutoff = "";
            Order = 0;
        }
    }

    @SuppressWarnings("unused")
    public static class UploadCheckpointModel extends UploadCheckpoint
    {
        public String Response;
        public Boolean Success;
    }

    // raceowl checkpoints
    @SuppressWarnings("unused")
    static class UpsertCheckpoint {
        final int CheckpointID;
        final String Name;
        final double Lat; //deg
        final double Lng; //deg
        final int MilesToNext;
        final String AuthCode; //8 char max
        final Boolean Delete;
        final String Cutoff; //MMddyyyyHHmmss
        final int Order;

        UpsertCheckpoint(CheckPoint lcp)
        {
            Name = lcp.Name;
            Lat = lcp.pt.latitude_rad * Const.rtd;
            Lng = lcp.pt.longitude_rad * Const.rtd;
            MilesToNext = Math.round(lcp.MilesToNext);
            Delete = false;
            CheckpointID = 0;
            AuthCode = "";
            Cutoff = lcp.CutOff;
            Order = lcp.order;
        }
        UpsertCheckpoint()
        {
            Name = "";
            Lat = 0.0;
            Lng = 0.0;
            MilesToNext = 0;
            Delete = false;
            CheckpointID = 0;
            AuthCode = "";
            Cutoff = "";
            Order = 0;
        }
    }

    @SuppressWarnings("unused")
    private static class UpsertCheckpointModel extends UpsertCheckpoint
    {
        public String Response;
        public Boolean Success;
    }


    @SuppressWarnings("unused")
    static class UpsertRaceEvent
    {
        int RaceEventID;
        String Description;
        String RaceDate;   //RaceOwlNetTime
        String TimeZone;
        Boolean IsMiles;
        String RaceName;
        String RaceCode;
        String CheckpointTextNumber;
        String UID;  //unique device ID
        String AndroidCheckpointJson1; //array list for checkpoints is saved as a String, this was needed to correctly transmit to Raceowl API //ArrayList<RaceOwlClient.UpsertCheckpoint> Checkpoints;
    }

    // New Race item fields
    @SuppressWarnings({"WeakerAccess", "unused"})
    public static class RegisterData
    {
        int RaceEventID;
        final int RaceTeamID;
        int DivisionID;
        String BoatNumber;
        String FirstName;
        String LastName;
        String Email;
        String Phone;
        String PhoneCrew;
        String Spot;
        String InReach;
        String TeamName;
        final String uid;

        @SuppressWarnings("unused")
        public RegisterData()
        {
            RaceEventID = -1;
            RaceTeamID = 0;
            DivisionID = -1;
            BoatNumber = "";
            TeamName = "";
            Spot = "";
            InReach = "";
            FirstName = "";
            LastName = "";
            Email = "";
            Phone = "";
            PhoneCrew = "";
            uid = "";
        }

        @SuppressWarnings("unused")
        public RegisterData(RegisterData reg_init)
        {
            RaceEventID = reg_init.RaceEventID;
            RaceTeamID = reg_init.RaceTeamID;
            DivisionID = reg_init.DivisionID;
            BoatNumber = reg_init.BoatNumber;
            TeamName = reg_init.TeamName;
            Spot = reg_init.Spot;
            InReach = reg_init.InReach;
            FirstName = reg_init.FirstName;
            LastName = reg_init.LastName;
            Email = reg_init.Email;
            Phone = reg_init.Phone;
            PhoneCrew = reg_init.PhoneCrew;
            uid = reg_init.uid;
        }

        public RegisterData(SettingsData s0)
        {
            this();
            BoatNumber = s0.BoatNumber;
            TeamName = s0.TeamName;
            Spot = s0.Spot;
            InReach = s0.InReach;
            FirstName = s0.FirstName;
            LastName = s0.LastName;
            Email = s0.Email;
            Phone = s0.Phone;
        }
        public RegisterData(RegisterData reg_init, SettingsData s0)
        {
            this();
            RaceEventID = reg_init.RaceEventID;
  //          RaceTeamID = reg_init.RaceTeamID;
            DivisionID = reg_init.DivisionID;
            BoatNumber = s0.BoatNumber;
            TeamName = s0.TeamName;
            Spot = s0.Spot;
            InReach = s0.InReach;
            FirstName = s0.FirstName;
            LastName = s0.LastName;
            Email = s0.Email;
            Phone = s0.Phone;
            PhoneCrew = reg_init.PhoneCrew;
//            uid = reg_init.uid;
        }

    }


    // New Race item fields
    static class RegisterResponse
    {
        final int RaceTeamID;
        String Response;
        Boolean Success;

        RegisterResponse() {

            RaceTeamID = 0;
            Response = "";
            Success = false;
        }

    }

    // New Race item fields
    @SuppressWarnings("unused")
    public static class FeedbackData
    {
        String Name;
        String Phone;
        final String Device;
        final Boolean RequestContact;
        String Feedback;
        String Version;

        public FeedbackData() {
            RequestContact = false;
            Device = "Android";
        }

        public FeedbackData(FeedbackData finit) {
            Name = finit.Name;
            Phone = finit.Phone;
            Device = finit.Device;
            RequestContact = finit.RequestContact;
            Feedback = finit.Feedback;
            Version = finit.Version;
        }
    }

    // New Race item fields
    static class FeedbackResponse
    {
        final String Response;
        Boolean Success;

        FeedbackResponse() {
            Response = "";
            Success = false;
        }
    }

    // RaceTeamLocation1
    @SuppressWarnings("WeakerAccess")
    public static class RaceTeamLocationRequest
    {
        public String BoatNumber;
        public int RaceEventID;
        public double AvgSpeed;
        public double Latitude;
        public double Longitude;
        public String LocationTime;
        public int MessageID;
    }

    // RaceTeamLocation1 item fields
    @SuppressWarnings("WeakerAccess")
    public static class RaceTeamLocationResponse
    {
        public final String Response;
        public final Boolean Success;
        public final int MessageID;

        public RaceTeamLocationResponse() {
            Response = "";
            Success = false;
            MessageID = -1;
        }
    }

    // New Race item fields
    @SuppressWarnings("unused")
    static class SettingsData
    {
        final String BoatNumber;
        final String TeamName;
        final String Spot;
        final Boolean spot_verified;
        final String InReach;
        final String FirstName;
        final String LastName;
        final String Email;
        final String Phone;
        final String PhoneCrew;
        final String authorization_code;

        public SettingsData()
        {
            BoatNumber = "";
            TeamName = "";
            Spot = "";
            spot_verified = false;
            InReach = "";
            FirstName = "";
            LastName = "";
            Email = "";
            Phone = "";
            PhoneCrew = "";
            authorization_code = "";
        }

        public SettingsData(SettingsData settings_data)
        {
            BoatNumber = settings_data.BoatNumber;
            TeamName = settings_data.TeamName;
            Spot = settings_data.Spot;
            spot_verified = settings_data.spot_verified;
            FirstName = settings_data.FirstName;
            LastName = settings_data.LastName;
            Email = settings_data.Email;
            Phone = settings_data.Phone;
            PhoneCrew = settings_data.PhoneCrew;
            authorization_code = settings_data.authorization_code;
            InReach = settings_data.InReach;

        }
    }

    // tracker registration (response = ApiReturnMessage)
    public static  class TrackerRegistration
    {
        final String MessageID;
        final String BoatNumber; // { get; set; }
        final int RaceEventID;// { get; set; }
        final String Spot;// { get; set; }
        final String InReach;// { get; set; }

        public TrackerRegistration()
        {
            MessageID = "";
            BoatNumber = "";
            RaceEventID = -1;
            Spot = "";
            InReach = "";
        }
    }
    static class ApiReturnMessage
    {
        final String Response;
        final String MessageID;
        final Boolean Success;

        ApiReturnMessage() {

            Response = "";
            MessageID = "";
            Success = false;
        }
    }


    // individual racer periodic ETA text message
    //
    // use case:
    //      App user requests status on a racer to a specified checkpoint/servicepoint. Raceowl
    //      calculates the ETA in time of day to the selected checkpoint based upon average speed
    //      and delta miles between the racer and the checkpoint. Resulting message is text messaged to the
    //      requester. This sequence repeats periodically every hour until a stop condition has occurred.
    // rules:
    //      1) one tracked racer per device (UID)
    //      2) limit of 88 (TBR) text messages sent per device
    //      3) if racer has already cycled the requested checkpoint, then raceowl will auto-select
    //         the next checkpoint/servicepoint
    // stop conditions:
    //      1) racer has finished
    //      2) maximum text count has been met
    //      3) app user cancels the text request with a disable message (either by text message cancel
    //         response or by app)

    // Request to raceowl from app
    @SuppressWarnings("unused")
    private static class RaceTeamETATextRequest
    {
        public String RacerNumber;                  //racer ID number
        public boolean Enable;                      //true to enable text messages, false to cancel
        public int RaceEventID;                     //race event ID
        public int CheckpointID;                    //checkpoint id to calculate ETA to
        public String Phone;                        //phone number to send text message
        public String UID;                          //unique device ID
        public int MessageID;                       //message ID number to echo back to the app
    }

    // Response from raceowl
    @SuppressWarnings("unused")
    static class RaceTeamETATextResponse
    {
        final String Response;
        final Boolean Success;
        final int MessageID;

        public RaceTeamETATextResponse() {
            Response = "";
            Success = false;
            MessageID = -1;
        }
    }



    // RaceTeamLocationBulk response fields
    @SuppressWarnings({"unused", "WeakerAccess"})
    public static class RaceTeamLocationBulkResponse
    {
        public final String Response;
        public final Boolean Success;
        public final int MessageID;
        public final int PlaceDivision;       // racer current division place
        public final int RaceInfoID;          // official race information ID, a different number for each mass email text (eg barge at RM 125)

        public RaceTeamLocationBulkResponse() {
            Response = "";
            Success = false;
            MessageID = -1;
            PlaceDivision = -1;
            RaceInfoID = -1;
        }
    }


    // RaceInfoRequest request
    private static class RaceInfo
    {
        public int RaceInfoID;          // official race information ID, a different number for each mass email text (eg barge at RM 125)
        public String RaceInfo;         // official race information: (eg barge at RM 125)
    }


    // RaceInfoRequest request
    @SuppressWarnings("unused")
    private static class RaceInfoRequest
    {
        public int RaceEventID;        //race event ID
        public int RaceInfoID;         //race info request by ID, RaceInfoID<0 indicates a request for all
        public int MessageID;          //message ID number to echo back to the app
    }

    // RaceInfoResponse from raceowl
    @SuppressWarnings("unused")
    static class RaceInfoResponse
    {
        final String Response;
        final Boolean Success;
        final int MessageID;
        final ArrayList<RaceInfo> raceInfos;

        public RaceInfoResponse() {
            Response = "";
            Success = false;
            MessageID = -1;
            raceInfos = new ArrayList<>();
        }
    }
}
