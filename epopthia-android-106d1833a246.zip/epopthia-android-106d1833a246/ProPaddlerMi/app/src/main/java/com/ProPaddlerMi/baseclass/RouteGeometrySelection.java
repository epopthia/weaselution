package com.ProPaddlerMi.baseclass;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class RouteGeometrySelection
{
    /// <summary>
    /// Use this method to find the best values for Checkpoints
    /// </summary>
    /// <param name="rr0s">ArrayList of RouteGeometry data</param>
    /// <param name="route">WPS and CPS route data</param>
    public static ArrayList<RouteGeometry> RankOrderBestCrossTrackErrors(ArrayList<RouteGeometry> rr0s, Route route)
    {
        Collections.sort(rr0s, new RouteGeometryCrossTrackComparator());
        return (rr0s);
    }

    private static class LocalResult
    {
        public int localIndex;
        public double val;
    }

    public static RouteGeometry SelectMinCrossTrack(ArrayList<RouteGeometry> rr0s, Route route)
    {
        ArrayList<RouteGeometry> rr1s = RankOrderBestCrossTrackErrors(rr0s, route);
        return rr1s.size() > 0 ? rr1s.get(0): new RouteGeometry();
    }

    /// <summary>
    /// Use this method as RacerState propagation happens
    /// </summary>
    /// <param name="rr0s">ArrayList of RouteGeometry data</param>
    /// <param name="route">WPS and CPS route data</param>
    /// <param name="minValue_m">minValue_m</param>
    /// <param name="maxValue_m">maxValue_m</param>
    /// <param name="targetValue_m">targetValue_m</param>
    /// <param name="s0">last RacerState</param>
    public static RouteGeometry SelectMinCost(ArrayList<RouteGeometry> rr0s, Route route, double minValue_m, double maxValue_m, double targetValue_m, RacerState s0)
    {
        boolean initRace = s0 == null || !s0.checkPointStatus.RaceStarted();

        //        if (rr0s.size() > 0)
//        {
//            ArrayList<RouteGeometry> rr2s = new ArrayList<RouteGeometry>();
//            double lastValue = s0 != null ? s0.routeRelative.value_m : 0;
//
//            rr2s = new ArrayList<RouteGeometry>();
//            Dictionary<int, double> res = new Dictionary<int, double>();
//            ArrayList<LocalResult> i1 = rr1s.Select((z, i) => new { z, i, v = (Math.Abs(z.segment_frac - 0.5)) }).OrderBy(x => x.v).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//            ArrayList<LocalResult> i2 = rr1s.Select((z, i) => new { z, i, v = (Math.Abs(z.crossTrack_rad)) }).OrderBy(x => x.v).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//            ArrayList<LocalResult> i3;
//            ArrayList<LocalResult> i4;
//            if (initRace)
//            {
//                i3 = rr1s.Select((z, i) => new { z, i, v = Math.Abs(lastValue - z.value_m) }).OrderBy(x => x.v).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//                i4 = rr1s.Select((z, i) => new { z, i, v = 0 }).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//            }
//            else
//            {
//                i3 = rr1s.Select((z, i) => new { z, i, v = (z.value_m > lastValue ? 0 : lastValue - z.value_m) }).OrderBy(x => x.v).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//                i4 = rr1s.Select((z, i) => new { z, i, v = Math.Abs(TrackSegment.VelocityBetweenValueMps(z.value_m - s0.routeRelative.value_m, z.pose.utc_ms - s0.pose1.utc_ms) - s0.summary.avgSpeed_mps) }).OrderBy(x => x.v).Select(y => new LocalResult() { localIndex = y.i, val = y.v }).ToList();
//            }
//
//            // get normalize values
//            double maxi1 = i1.max(z => z.val); // segment fraction
//            double maxi2 = route.maxCrossTrack_rad; //i2.max(z => z.val); // cross track
//            double maxi3 = Math.max(i3.max(z => z.val), 1.0); // down track
//            double maxi4 = Math.max(i4.max(z => z.val), 0.1); // speed
//
//            for (int inx = 0; inx < i1.Count; inx++)
//            {
//                int jnx = i2.Select((y, i) => new { y, i }).Where(z => z.y.localIndex.Equals(i1[inx].localIndex)).Select(x => x.i).First();
//                int knx = i3.Select((y, i) => new { y, i }).Where(z => z.y.localIndex.Equals(i1[inx].localIndex)).Select(x => x.i).First();
//                int mnx = i4.Select((y, i) => new { y, i }).Where(z => z.y.localIndex.Equals(i1[inx].localIndex)).Select(x => x.i).First();
//                // normalize
//                double i1Value = i1[inx].val / maxi1 * 6.0;// good for labenit = 6.0; //4.5;
//                double i2Value = i2[jnx].val / maxi2 * 0.7;// good for labenit = 0.7; //0.3;
//                double i3Value = i3[knx].val / maxi3 * 5.0;// good for labenit = 5.0; //5.0;
//                double i4Value = i4[mnx].val / maxi4 * 0.5;// good for labenit = 0.5; //0.0;
//                res.add(i1[inx].localIndex, i1Value + i2Value + i3Value + i4Value);  //heavily weight downtrack to not select going backwards
//            }
//
//            var cost = res.OrderBy(x => x.Value).ThenBy(y => y.Key).ToList();
//            int minindex = cost.First().Key;
//            rr2s.Add(rr1s[minindex]);
//
//            if (rr2s.Count > 0) ret = rr2s.First();
//        }
        return (new RouteGeometry());
    }


}

//a negative int if this < that
//0 if this == that
//a positive int if this > that
class RouteGeometryCrossTrackComparator implements Comparator<RouteGeometry>
{
    private double getCost(RouteGeometry x)
    {
        // cost = f(crosstrack + downtrack)
        // don't penalize the cost for points between waypoints
        double cost = (Math.abs(x.crossTrack_rad));
        cost += (x.segment_frac >= 0 && x.segment_frac <= 1) ? 0.0 : Math.min(Math.abs(x.dr_pt_to_p0_rad), Math.abs(x.dr_pt_to_p1_rad));
        return (cost);
    }

    public int compare(RouteGeometry left, RouteGeometry right)
    {
        return Double.compare(getCost(left), getCost(right));
    }
}


