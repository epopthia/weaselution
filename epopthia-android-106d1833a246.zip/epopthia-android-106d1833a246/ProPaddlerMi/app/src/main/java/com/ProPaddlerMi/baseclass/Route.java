package com.ProPaddlerMi.baseclass;

import android.annotation.SuppressLint;

import com.ProPaddlerMi.WayPointNav;
import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;


@SuppressWarnings({"unused", "ConstantConditions"})
public class Route {

    public enum RouteVehicleType
    {
        kayak,
        human,
        bike,
        powerboat,
        car
    }

    public final String name; //name of this route
    public double[] ivs;  //this vector provides for speed, it need only be populated once and then used for every position estimate for all racers
    public WayPoint[] wps;
    public ArrayList<Bound> wpBounds;
    public CheckPoint[] cps;
    public double maxCrossTrack_rad;
    public double maxDownTrack_rad;
    public double checkPointRadius_rad;
    public LatLngRad[] boundingBox;  //bounds the race with a bounding box via upper left and lower right corners
    public final String routeTimeZone;  //string that represents the route's timezone
    public final RouteVehicleType routeVehicleType;

    public Route(Route inRoute)
    {
        name = inRoute.name;
        routeVehicleType = inRoute.routeVehicleType;
        routeTimeZone = inRoute.routeTimeZone;
        wps = new WayPoint[inRoute.wps.length];
        System.arraycopy(inRoute.wps, 0, wps, 0, inRoute.wps.length);
        ivs = new double[inRoute.ivs.length];
        System.arraycopy(inRoute.ivs, 0, ivs, 0, inRoute.ivs.length);
        cps = new CheckPoint[inRoute.cps.length];
        System.arraycopy(inRoute.cps, 0, cps, 0, inRoute.cps.length);
        wpBounds = new ArrayList<>(inRoute.wpBounds);
        boundingBox = new LatLngRad[inRoute.boundingBox.length];
        System.arraycopy(inRoute.boundingBox, 0, boundingBox, 0, inRoute.boundingBox.length);
        maxCrossTrack_rad = inRoute.maxCrossTrack_rad;
        maxDownTrack_rad = inRoute.maxDownTrack_rad;
        checkPointRadius_rad = inRoute.checkPointRadius_rad;
    }


    public boolean isAscending()
    {
        return (wps.length > 0 && (wps[wps.length - 1].value_m - wps[0].value_m) >= 0);
    }

    public double maxValue()
    {
        double ret = 0;
        if (wps.length > 0)
        {
            ret = isAscending() ? wps[wps.length-1].value_m : wps[0].value_m;
        }
        return (ret);
    }

    public double minValue()
    {
        double ret = 0;
        if (wps.length > 0)
        {
            ret = isAscending() ? wps[0].value_m : wps[wps.length-1].value_m;
        }
        return (ret);
    }

    public double minSpeed_mps()
    {
        double speedLimit_mps = 0.0;
        switch (routeVehicleType)
        {
            case human:
            case kayak:
            case bike:
            case powerboat:
            case car:
                speedLimit_mps = 2.5 * Const.mph_to_mps;
                break;
        }
        return (speedLimit_mps);
    }

//    static public double MinSpeed()
//    {
//        return (2.5 * Const.mph_to_mps);
//    }

    public double maxSpeed_mps()
    {
        double speedLimit_mps = 0.0;
        switch (routeVehicleType)
        {
            case human:
                speedLimit_mps = 20 * Const.mph_to_mps;
                break;
            case kayak:
                speedLimit_mps = 18 * Const.mph_to_mps;
                break;
            case bike:
                speedLimit_mps = 35 * Const.mph_to_mps;
                break;
            case powerboat:
                speedLimit_mps = 100 * Const.mph_to_mps;
                break;
            case car:
                speedLimit_mps = 250 * Const.mph_to_mps;
                break;

        }
        return (speedLimit_mps);

    }

    static public double MaxSpeed()
    {
        return (18 * Const.mph_to_mps);
    }


    public Route()
    {
        name = "";
        ivs = new double[0];
        wps = new WayPoint[0];
        wpBounds = new ArrayList<>();
        cps = new CheckPoint[0];
        maxCrossTrack_rad = Const.maxCrossTrackDr_rad;
        maxDownTrack_rad = Const.maxDownTrackDr_rad;
        checkPointRadius_rad = Const.maxCheckPointRadius_rad;
        routeTimeZone = "Central Standard Time";
        routeVehicleType = RouteVehicleType.kayak;
        boundingBox = new LatLngRad[0];
    }

    public Route(CheckPoint[] checkpoints, WayPoint[] waypoints, String timeZone, String routeName)
    {
        name = routeName;
        routeVehicleType = RouteVehicleType.kayak;
        routeTimeZone = timeZone;
        wps = new WayPoint[waypoints.length];
        System.arraycopy(waypoints, 0, wps, 0, waypoints.length);
        cps = new CheckPoint[checkpoints.length];
        System.arraycopy(checkpoints, 0, cps, 0, checkpoints.length);
        UpdateRouteCalcs();
    }

    boolean InBoundingBox(LatLngRad pt)
    {
        boolean ret = false;
        if (boundingBox.length == 2)
        {
            ret = pt.latitude_rad >= boundingBox[0].latitude_rad && pt.latitude_rad <= boundingBox[1].latitude_rad;
            if (ret) ret = pt.longitude_rad >= boundingBox[0].longitude_rad && pt.longitude_rad <= boundingBox[1].longitude_rad;
        }
        return ret;
    }

//    LatLngRad[] CalcBoundingBox()
//    {
//        final double offset_rad = 1000 * Const.ft_to_mile * Const.mile_to_m / Const.earth_a_m;
//        LatLngRad minCorner = new LatLngRad(wps.Min(x => x.pt.latitude_rad) - offset_rad, wps.Min(x => x.pt.longitude_rad) - offset_rad);
//        LatLngRad maxCorner = new LatLngRad(wps.Max(x => x.pt.latitude_rad) + offset_rad, wps.Max(x => x.pt.longitude_rad) + offset_rad);
//        List<LatLngRad> bound = new List<LatLngRad>() { minCorner, maxCorner };
//        return (bound);
//    }


    public void UpdateRouteCalcs()
    {
        boolean success = true;
        UpdateWayPointData();
        ivs = new double[wps.length];
        for (int inx = 0; inx< wps.length; inx++)
        {
            ivs[inx] = wps[inx].value_m;
        }
        CalcCheckPointRadius();
        if (!UpdateCheckPointData())
        {
            //keep valid checkpoints
            ArrayList<CheckPoint> newCps = new ArrayList<>();
            for (CheckPoint cp : cps) {
                if (cp.value_m >= 0) {
                    newCps.add(cp);
                }
            }
            cps = new CheckPoint[newCps.size()];
            for(int inx=0;inx<newCps.size();inx++) {
                cps[inx] = new CheckPoint(newCps.get(inx));
            }
        }
    }

    void UpdateWayPointData()
    {
        if (wps.length == 0) return;
        // index
        for (int inx = 0; inx < wps.length; inx++)
        {
            wps[inx].index = inx;
        }
        WayPoint.CalcWayPointAngles(wps);
        CalcMaxCrossTrack();
        maxDownTrack_rad = Const.maxDownTrackDr_rad;
        UpdateBounds(maxCrossTrack_rad);
    }

    void UpdateBounds(double maxError_rad)
    {
        final int binSize = 100;
        final int overLap = 2;
        wpBounds = new ArrayList<>();
        for (int inx = 0; inx < wps.length; inx += (binSize - overLap))
        {
            int bnd1 = Math.min(inx + binSize, wps.length) - 1;
            wpBounds.add(new Bound(inx, bnd1, this));
        }
    }

    void CalcMaxCrossTrack()
    {
        maxCrossTrack_rad = Const.maxCrossTrackDr_rad;
    }
    void CalcCheckPointRadius()
    {
        final double k = 2000 * Const.ft_to_mile / 340.0; //use the 340 as a rule of thumb
        double raceCheckPointRadius_rad = (wps[wps.length-1].value_m * k) / Const.earth_a_m;
        checkPointRadius_rad = Math.max(Math.min(raceCheckPointRadius_rad, Const.maxCheckPointRadius_rad), Const.minCheckPointRadius_rad);

        double check = checkPointRadius_rad * Const.earth_a_m * Const.m_to_ft;
    }

    static public double CalcCheckPointRadius(double maxVal_m)
    {
        final double k = 2000 * Const.ft_to_mile / 340.0; //use the 340 as a rule of thumb
        double raceCheckPointRadius_rad = (maxVal_m * k) / Const.earth_a_m;

        return (Math.max(Math.min(raceCheckPointRadius_rad, Const.maxCheckPointRadius_rad), Const.minCheckPointRadius_rad));
    }


    // return < 0 if error
    boolean UpdateCheckPointData()
    {
        boolean allValid = true;
        double lastValue = 0.0;

        for (int inx = 0; inx < cps.length; inx++)
        {
            if (cps[inx].Name.length() == 0) cps[inx].Name = String.format("CP_%d", inx); //the name
            InterpolateResult ptInfo = getInterpolation(cps[inx].value_m);
            cps[inx].riverMile = ptInfo.applyInterpolationResult(wps[ptInfo.iLower].riverMile, wps[ptInfo.iUpper].riverMile );
            cps[inx].offset_ft = (cps[inx].value_m - wps[ptInfo.iLower].value_m) * Const.m_to_ft ;
            cps[inx].closest_wp_index = ptInfo.iUpper;  //assumes downstream direction
        }
        return allValid;
    }


    // ----------------------------------------------------------------------
    //  getValue
    //  note: assumes the waypoints are sorted for value
    //  boundingBoxSize = meters of side of box to force geometry to be withing, 0 disables the bounds down select of geometry
    // ----------------------------------------------------------------------
    public Bound GetBound(double value_m, double maxError_m)
    {

        ArrayList<Bound> selBounds = new ArrayList<>();
        Bound ret = new Bound(); // invalid bound

        for (int inx=0;inx<wpBounds.size();inx++)
        {
            if (value_m >= (wpBounds.get(inx).valLimits[0] - maxError_m) &&
                    value_m <= (wpBounds.get(inx).valLimits[1] + maxError_m))
            {
                selBounds.add(wpBounds.get(inx));
            }
        }
        Bound selBound = new Bound(selBounds);

        if (selBound.isValidBound) {
            if (isAscending()) {
                if (wps[selBound.bnd1].value_m < value_m) {
                    ret = new Bound(selBound.bnd1 - 1, selBound.bnd1, this);
                } else {
                    for (int inx = selBound.bnd0 + 1; inx <= selBound.bnd1; inx++) {
                        if (wps[inx].value_m >= value_m) {
                            ret = new Bound(inx - 1, inx, this);
                            break;
                        }
                    }
                }
            } else {
                if (wps[selBound.bnd0].value_m > value_m) {
                    ret = new Bound(selBound.bnd0, selBound.bnd0 + 1, this);
                } else {
                    for (int inx = selBound.bnd0 + 1; inx <= selBound.bnd1; inx++) {
                        if (wps[inx].value_m <= value_m) {
                            ret = new Bound(inx - 1, inx, this);
                            break;
                        }
                    }
                }
            }
        }
        return (ret);
    }

    public double GetValue(LatLngRad pt, Bound bound)
    {
        // initial bound
        if (bound == null)
        {
            bound = new Bound(pt, this, -1.0, -1.0, this.maxCrossTrack_rad);
        }

        //bool orderAscending = route.isAscending;

        //get default
        double value_m;
        if (bound.isValidBound)
        {
            //value_m = wps[bound.bnd0].value_m;

            ArrayList<WayPoint> selWayPoints = new ArrayList<>(Arrays.asList(wps).subList(bound.bnd0, bound.bnd1 + 1));

            ArrayList<RouteGeometry> rgs = RouteGeometry.CalcRouteGeometry(new Pose(pt), null, selWayPoints, boundingBox);
            if (rgs.size() > 0) rgs = RouteGeometrySelection.RankOrderBestCrossTrackErrors(rgs, this);
            if (rgs.size() > 0)
            {
                value_m = rgs.get(0).value_m;
            }
            else
            {
                value_m = -999; //set an invalid value
            }
        }
        else
        {
            value_m = -999; //set an invalid value
        }
        return (value_m);
    }

	

    public ArrayList<CheckPoint> getCheckPoints()
    {
        ArrayList<CheckPoint> ret = new ArrayList<>();
        Collections.addAll(ret, cps);
        return (ret);
    }
	
	
    public CheckPoint[] getCheckPointArray()
    {
        CheckPoint[] ret = new CheckPoint[cps.length];
        for (int inx=0; inx< cps.length; inx++)
        {
            ret[inx] = new CheckPoint(cps[inx]);
        }
        return (ret);
    }
	
	

//    private WayPoint[] createWayPointsFromWayPoints(WayPoint[] wayPoints)
//    {
//        WayPoint[] points = new WayPoint[wayPoints.length];
//        if (points.length > 0) {
//            points[0] = new WayPoint(wayPoints[0]);
//            for (int inx = 1; inx < points.length; inx++) {
//                points[inx] = new WayPoint(points[inx-1], wayPoints[inx]);
//            }
//        }
//        return (points);
//    }

//    private WayPoint[] createWayPointsFromCheckPoints(CheckPoint[] checkPoints)
//    {
//        WayPoint[] points = new WayPoint[checkPoints.length];
//        points[0] = new WayPoint(checkPoints[0]);
//        for (int inx = 1; inx < checkPoints.length; inx++) {
//            points[inx] = new WayPoint(points[inx-1], checkPoints[inx]);
//        }
//        return (points);
//    }
//
//    private CheckPoint[] createCheckPointsFromCheckPoints(CheckPoint[] checkPoints)
//    {
//        CheckPoint[] points = new CheckPoint[checkPoints.length];
//        if (points.length > 0) {
//            points[0] = new CheckPoint(checkPoints[0]);
//            for (int inx = 1; inx < points.length; inx++) {
//                points[inx] = new CheckPoint(points[inx-1], checkPoints[inx]);
//            }
//        }
//        return (points);
//    }
//
//    private CheckPoint[] createCheckPointsFromWayPoints(WayPoint[] wps)
//    {
//        wps = createWayPointsFromWayPoints(wps);
//        CheckPoint[] points = new CheckPoint[0];
//        if (wps.length > 1) {
//            points = new CheckPoint[2];
//            points[0] = new CheckPoint(wps[0].pt);
//            points[0].value_m = wps[0].value_m;
//            points[0].Name = wps[0].label.length() > 0 ? wps[0].label : "start";
//            points[1] = new CheckPoint(wps[wps.length-1].pt);
//            points[1].value_m = wps[wps.length-1].value_m;
//            points[1].Name = wps[wps.length-1].label.length() > 0 ? wps[wps.length-1].label : "finish";
//            points = createCheckPointsFromCheckPoints(points);
//        }
//        return (points);
//    }

    // ---------------------------------------------------------------------------------------------
    // orderWaypointsByDist
    // ---------------------------------------------------------------------------------------------
    @SuppressLint("DefaultLocale")
    public void orderWaypointsByDist()
    {

        if (wps.length <= 1) return;

        // set all waypoints to STOPPED
        Boolean[] enable = new Boolean[wps.length];
        for (int inx = 0; inx< wps.length; inx++) enable[inx] = true;

        // get the start point, This will be set to the first wp in the wp list
        int si = findWpType(wps.length-1);

        // set Order and turn off the start waypoint
        int order = 0;
        wps[si].index = order++;
        wps[si].label = String.format("ptt %d", order);
        enable[si] = false;
        int idx;

        do {
            idx = findClosePoint(wps[si].pt.latitude_rad, wps[si].pt.longitude_rad, enable, toLatLngRad(wps));
            if(idx >=0)
            {
                si = idx;
                wps[si].index = order++;
                wps[si].label = String.format("ptt %d", order);
                enable[si] = false;
            }
        } while (idx>=0);

        WayPoint.sortWaypoints(wps, false);

    }

    // ---------------------------------------------------------------------------------------------
    // findWpType
    // set_waypoint type_if_not_found - if true, will assign the wp type (start and stop waypoint only)
    // if not_type then find return points that do not match
    // note: assumes at least 2 points
    // ---------------------------------------------------------------------------------------------
    private int findWpType(int end_idx)
    {
        int idx = -1;

        // verification of minimal data
        if (wps.length < 2) return (idx);

        // search for specified type
        int dir = ((end_idx >= 0) ? 1 : -1);
        int stop_idx = end_idx + dir;
        int inx = 0;
        boolean found = false;
        do
        {
            if ((WayPoint.Type.startpoint == wps[inx].type))
            {
                idx = inx;
                found = true;
            }
            inx += dir;
        } while (!found && inx != stop_idx);

        return (idx);
    }

    // ----------------------------------------------------------------------
    //  findClosePoint
    //	Given Lat/lon then calculate the best starting waypoint
    // ----------------------------------------------------------------------
    public static int findClosePoint(double ref_lat_rad, double ref_lon_rad, Boolean[] enable, LatLngRad[] localPoints) {
        int pt_idx = -1;
        int count = localPoints.length;
        boolean use_enable = (enable != null) && (enable.length == count);
        boolean is_at_least_one_enabled = false;
        if (count > 0)
        {
            if (use_enable)
            {
                // search localPoints check if at least one wp is STOPPED
                for (int inx = 0; inx< count; inx++)
                {
                    if (enable[inx])
                    {
                        pt_idx = inx;
                        is_at_least_one_enabled = true;
                        break;
                    }
                }
            }
            else
            {
                is_at_least_one_enabled = true;
                pt_idx = 0;
            }

            final double min_dist_ft = 2;

            if (is_at_least_one_enabled) {
                double curr_min_dist_between_wp = Math.abs(WayPointNav.DistBetweenWaypoints(localPoints[pt_idx].latitude_rad, localPoints[pt_idx].longitude_rad, ref_lat_rad, ref_lon_rad));
                int jnx;

                for (jnx = pt_idx; jnx < count; jnx++) {
                    if (!use_enable || enable[jnx]) {
                        double dist_test = Math.abs(WayPointNav.DistBetweenWaypoints(localPoints[jnx].latitude_rad, localPoints[jnx].longitude_rad, ref_lat_rad, ref_lon_rad));
                        if (dist_test > min_dist_ft)
                        {
                            if (dist_test < curr_min_dist_between_wp) {
                                pt_idx = jnx;
                                curr_min_dist_between_wp = dist_test;
                            }
                        }
                    }
                }
            }
        }

        //TODO: need to set the curr waypoint along the own_path
        return pt_idx;
    }

    //---------------------------------------------------------------------------
    // toLatLngRad - for checkpoints
    //---------------------------------------------------------------------------
    private static LatLngRad[] toLatLngRad(CheckPoint[] localPoints)
    {
        LatLngRad[] ret = new LatLngRad[localPoints.length];
        for(int inx = 0; inx<localPoints.length; inx++)
        {
            ret[inx] = new LatLngRad(localPoints[inx].pt.latitude_rad, localPoints[inx].pt.longitude_rad );
        }
        return(ret);
    }

    //---------------------------------------------------------------------------
    // toLatLngRad - for waypoints
    //---------------------------------------------------------------------------
    public static LatLngRad[] toLatLngRad(WayPoint[] localPoints)
    {
        LatLngRad[] ret = new LatLngRad[localPoints.length];
        for(int inx = 0; inx<localPoints.length; inx++)
        {
            ret[inx] = new LatLngRad(localPoints[inx].pt.latitude_rad, localPoints[inx].pt.longitude_rad );
        }
        return(ret);
    }

    /// <summary>
    /// given a value, return interpolation data
    /// </summary>
    public InterpolateResult getInterpolation(double value_m)
    {
        InterpolateResult interpolateResult = new InterpolateResult();
        Bound bound = GetBound(value_m, maxCrossTrack_rad * Const.earth_a_m);
        if (bound.isValidBound)
        {
            interpolateResult = Interpolate.InterpolateIndex2D(value_m, new double[] { wps[bound.bnd0].value_m, wps[bound.bnd1].value_m });
            if (interpolateResult.iUpper > interpolateResult.iLower)
            {
                interpolateResult.iLower = bound.bnd0; // remap the bound index since we reconstructed the lookup y values
                interpolateResult.iUpper = bound.bnd1; // remap the bound index since we reconstructed the lookup y values
            }
            else
            {
                interpolateResult.iLower = bound.bnd1; // remap the bound index since we reconstructed the lookup y values
                interpolateResult.iUpper = bound.bnd0; // remap the bound index since we reconstructed the lookup y values
            }
        }
        return (interpolateResult);
    }

    /// <summary>
    /// give a value, lookup the rivermile and provide the best estimate
    /// </summary>
    public double GetRiverMile(double value_m)
    {
        InterpolateResult ptInfo = getInterpolation(value_m);
        return (ptInfo.applyInterpolationResult(wps[ptInfo.iLower].riverMile, wps[ptInfo.iUpper].riverMile));
    }

    // ----------------------------------------------------------------------
    // getStartCheckpointIndex
    // ----------------------------------------------------------------------
    public static int getStartCheckpointIndex(CheckPoint[] localCheckPoints)
    {
        int idx = 0;
        for (int inx=0;inx<localCheckPoints.length;inx++)
        {
            if (localCheckPoints[inx].type == WayPoint.Type.startpoint)
            {
                idx = inx;
                break;
            }
        }
        return (idx);
    }

//    /// <summary>
//    /// return the mapped river mile given a value
//    /// </summary>
//    public double getRiverMile(double value_m)
//    {
//        Bound bnd = GetBound(value_m, Const.maxCrossTrack_rad * Const.earth_a_m);
//        double myVal =
//
//
//    }

    // ----------------------------------------------------------------------
    // getStopCheckpointIndex
    // ----------------------------------------------------------------------
    public static int getStopCheckpointIndex(CheckPoint[] localCheckPoints) {
        int idx = localCheckPoints.length-1;
        for (int inx=localCheckPoints.length-1;inx>=0;inx--)
        {
            if (localCheckPoints[inx].type == WayPoint.Type.stoppoint)
            {
                idx = inx;
                break;
            }
        }
        return (idx);
    }

    // ----------------------------------------------------------------------
    // getWayPoint
    // ----------------------------------------------------------------------
    public WayPoint getWayPoint(int idx) {
        WayPoint wp;
        if (isValidWPIndex(idx)) {
            wp = wps[idx];
        }
        else
        {
            wp = new WayPoint();
        }
        return wp;
    }
    // ----------------------------------------------------------------------
    // getPrevWP
    // ----------------------------------------------------------------------
    public int getPrevWP(int currWp) {
        int ret = currWp;
        int delta = (int) getNextWpInc();
        int prevWp = (currWp - delta);
        if (isValidWPIndex(prevWp)) ret = prevWp;
        return ret;
    }

    // ----------------------------------------------------------------------
    // getNextWpInc
    // ----------------------------------------------------------------------
    private double getNextWpInc()
    {
        //		if (getStartCheckpointIndex() > getStopCheckpointIndex())
//		{
//			ret = 1;
//		}
//		else
//		{
//			ret = -1;
//		}

        return 1;
    }

    // ----------------------------------------------------------------------
    // isValidWPIndex
    // ----------------------------------------------------------------------
    private Boolean isValidWPIndex(int idx) {
        boolean ret = false;
        if (wps != null) {
            if (idx >= 0 && idx < wps.length) {
                ret = true;
            }
        }
        return ret;
    }

    // ----------------------------------------------------------------------
    // verifyRoute
    // ----------------------------------------------------------------------
    public static Boolean verifyRoute (Route route)
    {
        boolean isValid = route != null;
        isValid = isValid && route.cps.length > 0;
        isValid = isValid && route.wps.length > 0;
        return (isValid);
    }


    // ----------------------------------------------------------------------
    // return the waypoint offset from the given idx. +offset is always the
    // going to waypoints, -offset is always the coming from waypoints
    // ----------------------------------------------------------------------
    public WayPoint getWaypointOffset(int idx, int offset)
    {
        WayPoint ret = new WayPoint();
        if (wps.length > 0)
        {
            int jnx = isAscending() ? idx + offset : idx - offset; //todo isAscending may not be best choice
            jnx = Math.min(Math.max(jnx,0), wps.length - 1);
            ret = wps[jnx];
        }
        return(ret);
    }
}

