package com.ProPaddlerMi.utility;

@SuppressWarnings({"unused", "WeakerAccess"})
public class Const
{


	public static final double pi = 3.141592653589793238462643383279502884197169399375105820974944592;
	public static final double two_pi = 2*pi;
	public static final double pi_over_2 = pi/2.0;
	public static final double rtd = 180.0/pi;
	public static final double dtr = 1.0/rtd;
	public static final double ft_to_m = 0.3048;
	public static final double ft_to_km = ft_to_m/1000.0;
	public static final double m_to_ft = 1.0/ft_to_m;
	public static final double ft_to_mile = 1.0/5280.0;
	public static final double m_to_mile = m_to_ft * ft_to_mile;
	public static final double m_to_km = 1.0 / 1000.0;
	public static final double km_to_m = 1000.0;
	public static final double mile_to_m = 1.0 / m_to_mile;
	public static final double mph_to_fps = 1.466667;
	public static final double mph_to_mps = mph_to_fps * ft_to_m;
	public static final double mps_to_mph = 1.0 / mph_to_mps;
	public static final int hour_to_sec = 60*60;
	public static final int hour_to_min = 60;
	public static final double sec_to_hour = 1.0/hour_to_sec;
	public static final int sec_to_ms = 1000;
	public static final double sec_to_min = 1.0/60.0;
	public static final double ms_to_sec = 1.0/1000.0;
	public static final double ms_to_min = 1.0/60000.0;
	public static final double min_to_ms = 60000.0;
	public static final double fps_to_mph = 0.681818181818182;
	public static final double mile_to_feet = 5280.01056;
	public static final double epsilon = 1e-12;
	public static final double epsilon_times_2 = epsilon * 2;
	public static final double large = 1e12;
	public static final double earth_a_ft = 20925646.325459316;
	public static final double earth_a_m = earth_a_ft * ft_to_m;
	public static final double gd_e2 = 0.00669437999013;
	public static final double gd_two_e2_minus_e4 = 0.013343945256807746;
	public static final long minute_to_msec = 60000;
	public static final long minute_to_sec = 60;
	public static final long day_to_msec = 24 * 60 * minute_to_msec;
	public static final long day_to_sec = 24 * 60 * minute_to_sec;
	public static final String lat_lon_format = "%1.6f";
	public static final String speed_format = "%1.1f";
	public static final double min_point_dist_rad = 30 / earth_a_ft;
	public static final int hour_to_ms = hour_to_sec * sec_to_ms;
	public static final String RACEOWL_RACE_SELECT = "Mi_RACE_SELECT";
	public static final String RACEOWL_LOCATION = "Mi_LOCATION";
	public static final String RACEOWL_NETWORK = "Mi_NETWORK";
	public static final double minSpeedLimit_mps = 0.5 * Const.mph_to_mps;
	public static final double maxCheckPointRadius_rad = mile_to_m / earth_a_m; // radius under which we are considered at a checkpoint
	public static final double minCheckPointRadius_rad = 200 * ft_to_m / earth_a_m; // radius under which we are considered at a checkpoint
	public static final double maxSpeed_mps = 40.0 * mph_to_mps;
        public static final double minSpeed_mps = 3.0 * mph_to_mps;

	public static final double checkpoint_radius_m = 0.5 * mile_to_m;
	public static final double checkpoint_radius_dr_rad = checkpoint_radius_m / earth_a_m; // radius under which we are considered at a checkpoint
	public static final double maxSpeedLimit_mps = 100.0 * Const.mph_to_mps;
	public static final String RaceEventUrl = "http://www.raceowl.com";
	public static final String start_date_format = "yyyy/MM/dd,kk:mm:ss";
	public static final long prime_deltat_ms = sec_to_ms;
	public static final String GROUP_NOTIFICATION = "com.ProPaddlerMi.NOTIFICATION";
	public static final String appPackage = "com.ProPaddlerMi";
	public static final double min_speed_limit_mps = 0.5 * mph_to_mps;
	public static final double avg_speed_tau = 0.3; //time constant for calculation of average speed
	        public static final double maxMeasurementError_m = 30;

	public static final double maxSegmentCrossTrackAspectRatio = 0.3; // cross track must be less than maxSegmentCrossTrackAspectRatio * segment length
	public static final double maxCrossTrack_rad = 5 * mile_to_m / earth_a_m;
	public static final double maxCrossTrackDr_rad = 1 * mile_to_feet / earth_a_ft; // radius under which we are considered close enough to the course
        public static final double shortSegmentThreshold = 5 * mile_to_m;

	public static final double maxDownTrackDr_rad = 1 * mile_to_feet / earth_a_ft; // radius under which we are considered close enough to the course

	public static final float max_zoom = (float) (60.0 * mile_to_m);
	public static final float min_zoom = (float) (10);

}
