package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;

public class Bound {
    public int bnd0;
    public int bnd1;
    public Double[] latLimits;
    public Double[] lonLimits;
    public Double[] valLimits;
    public boolean isValidBound;
    
    private Bound getLimits(Route route, Bound inBound)
    {
        Bound bound = new Bound(inBound);
        if (inBound.isValidBound) {
            bound.latLimits[0] = route.wps[inBound.bnd0].pt.latitude_rad;
            bound.latLimits[1] = bound.latLimits[0];
            bound.lonLimits[0] = route.wps[inBound.bnd0].pt.longitude_rad;
            bound.lonLimits[1] = bound.lonLimits[0];
            
            bound.valLimits[0] = Math.min(route.wps[inBound.bnd0].value_m, route.wps[inBound.bnd1].value_m);
            bound.valLimits[1] = Math.max(route.wps[inBound.bnd0].value_m, route.wps[inBound.bnd1].value_m);
            
            for (int inx = inBound.bnd0 + 1; inx <= inBound.bnd1; inx++) {
                if (route.wps[inx].pt.latitude_rad < bound.latLimits[0]) bound.latLimits[0] = route.wps[inx].pt.latitude_rad;
                else if (route.wps[inx].pt.latitude_rad > bound.latLimits[1]) bound.latLimits[1] = route.wps[inx].pt.latitude_rad;

                if (route.wps[inx].pt.longitude_rad < bound.lonLimits[0]) bound.lonLimits[0] = route.wps[inx].pt.longitude_rad;
                else if (route.wps[inx].pt.longitude_rad > bound.lonLimits[1]) bound.lonLimits[1] = route.wps[inx].pt.longitude_rad;
            }
        }
        return (bound);
    }

    public int count() {
        return (bnd0 >= 0 && bnd1 >= 0 ? bnd1 - bnd0 + 1 : 0);
    }

    public Bound()
    {
        bnd0 = -1; //invalid
        bnd1 = -1; //invalid
        latLimits = new Double[2];
        lonLimits = new Double[2];
        valLimits = new Double[2];
        isValidBound = false;
    }

    public Bound(int b0, int b1)   //make this one private
    {
        this();
        bnd0 = b0;
        bnd1 = b1;
    }

    public Bound(Route route)
    {
        this();
        if (route.wps.length > 0)
        {
            bnd0 = 0;
            bnd1 = route.wps.length - 1;
            isValidBound = true;
            Bound refBound = getLimits(route, this);
            latLimits = refBound.latLimits;
            lonLimits = refBound.lonLimits;
            valLimits = refBound.valLimits;
        }
    }


    public Bound(int b0, int b1, Route route)
    {
        this(b0, b1);

        if (route.wps.length > 0 && bnd0 >= 0 && bnd1 < route.wps.length)
        {
            isValidBound = true;
            Bound refBound = getLimits(route, this);
            latLimits = refBound.latLimits;
            lonLimits = refBound.lonLimits;
            valLimits = refBound.valLimits;
        }
    }

    /// <summary>
    /// deep copy the reference Bound
    /// </summary>
    public Bound(Bound inBound)
    {
        bnd0 = inBound.bnd0;
        bnd1 = inBound.bnd1;
        isValidBound = inBound.isValidBound;
        latLimits = new Double[]{inBound.latLimits[0],inBound.latLimits[1]};
        lonLimits = new Double[]{inBound.lonLimits[0],inBound.lonLimits[1]};
        valLimits = new Double[]{inBound.valLimits[0],inBound.valLimits[1]};
    }


    /// <summary>
    /// Combine the first set of contiguous bounds
    /// will throw out non contiguous (useful for circular
    /// routes where we want to select the first valid along 
    /// the path
    /// </summary>
    /// <param bnds=Bounds that will be combined into one Bound></param>
    public Bound(ArrayList<Bound> bounds)
    {
        this();
        if (bounds.size() > 0)
        {

            final Bound b0 = new Bound(bounds.get(0));
            bnd0 = b0.bnd0;
            bnd1 = b0.bnd1;
            isValidBound = b0.isValidBound;
            latLimits = new Double[]{b0.latLimits[0],b0.latLimits[1]};
            lonLimits = new Double[]{b0.lonLimits[0],b0.lonLimits[1]};
            valLimits = new Double[]{b0.valLimits[0],b0.valLimits[1]};

            for (int inx = 1; inx< bounds.size(); inx ++)
            {
                if ((bounds.get(inx).bnd0 - bounds.get(inx-1).bnd1) > 1) return; // drop non-contiguous bounds

                bnd0 = Math.min(bnd0, bounds.get(inx).bnd0);
                bnd1 = Math.max(bnd1, bounds.get(inx).bnd1);
                latLimits = new Double[]{ Math.min(latLimits[0], bounds.get(inx).latLimits[0]), Math.max(latLimits[1], bounds.get(inx).latLimits[1])};
                lonLimits = new Double[]{ Math.min(lonLimits[0], bounds.get(inx).lonLimits[0]), Math.max(lonLimits[1], bounds.get(inx).lonLimits[1])};
                valLimits = new Double[]{ Math.min(valLimits[0], bounds.get(inx).valLimits[0]), Math.max(valLimits[1], bounds.get(inx).valLimits[1])};
                isValidBound = isValidBound && bounds.get(inx).isValidBound;
            }
        }
    }

    public Bound(LatLngRad pt, Route route, Double lowerValue_m, Double upperValue_m, Double maxError_rad)
    {
        lowerValue_m = lowerValue_m >= 0 ? lowerValue_m : route.minValue();
        upperValue_m = upperValue_m >= 0 ? upperValue_m : route.maxValue();
        maxError_rad = maxError_rad >= 0 ? maxError_rad : Const.maxCrossTrackDr_rad;


        ArrayList<Bound> selBounds = new ArrayList<>();
        for (Bound bnd:route.wpBounds)
        {
            if (bnd.valLimits[0] <= upperValue_m &&
                    bnd.valLimits[1] >= lowerValue_m &&
                    pt.latitude_rad >= (bnd.latLimits[0] - maxError_rad) && pt.latitude_rad <= (bnd.latLimits[1] + maxError_rad) &&
                    pt.longitude_rad >= (bnd.lonLimits[0] - maxError_rad) && pt.longitude_rad <= (bnd.lonLimits[1] + maxError_rad))
            {
                selBounds.add((bnd));
            }
        }
        Bound selBound = new Bound(selBounds);  //select first grouping. this means we will always select the closest acceptable region to the route start or current position along the route

        bnd0 = selBound.bnd0;
        bnd1 = selBound.bnd1;
        isValidBound = selBound.isValidBound;
        latLimits = new Double[]{selBound.latLimits[0],selBound.latLimits[1]};
        lonLimits = new Double[]{selBound.lonLimits[0],selBound.lonLimits[1]};
        valLimits = new Double[]{selBound.valLimits[0],selBound.valLimits[1]};
    }

    /// <summary>
    /// return true if the point is within the specified bounds. 
    /// </summary>
    /// <param pt=Lat/Lon point to test for bounding box></param>
    /// <param maxError_rad=tolerance that point is allowed to lie beyond the box and still be considered bounded></param>
    public boolean IsPointBounded(LatLngRad pt, Double maxError_rad)
    {
        boolean passLat = false;
        boolean passLon = false;
        if (isValidBound)
        {
            Double[] boundLat = new Double[2];
            boundLat[0] = latLimits[0] - maxError_rad;
            boundLat[1] = latLimits[1] + maxError_rad;
            passLat = pt.latitude_rad > boundLat[0] && pt.latitude_rad < boundLat[1];

            Double[] boundLon = new Double[2];
            boundLon[0] = lonLimits[0] - maxError_rad;
            boundLon[1] = lonLimits[1] + maxError_rad;
            passLon = pt.longitude_rad > boundLon[0] && pt.longitude_rad < boundLon[1];
        }
        return (passLat && passLon);
    }
}
