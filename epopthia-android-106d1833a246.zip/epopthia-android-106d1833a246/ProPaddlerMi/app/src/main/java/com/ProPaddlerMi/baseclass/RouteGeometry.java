package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;

public class RouteGeometry {

    public double dr_p0_to_p1_rad;                  //arc from p0 to p1
    public double dt_dr_p0_to_pt_rad;               //downtrack arc from p0 to tp
    public double dt_dr_pt_to_p1_rad;               //downtrack arc from tp to p1
    public double dr_pt_to_p0_rad;                  //arc from pt to p0
    public double dr_pt_to_p1_rad;                  //arc from pt to p1

    public double crossTrack_rad;                   //crosstrack arc from arc cp0-cp1 to tp
    public double segment_frac;                     //fraction that represents the downtrack position of a racer between 2 checkpoints. <0 behind checkpoint 1,
    public double value_m;                          //value of current location along race Course
    public int prevWpIndex;                         //previous wp index (wp that we are coming from)
    public int currWpIndex;                         //current wp index (wp that we are going to)
    public RouteRelative.ErrorCode errorCode;
    public RangeBearing rb;                         // wp segment range bearing (from prev wp to current)
    public double trackToRouteAngle_rad;            // Angle between own track velocity vector and waypoint prev -> curr directional vector
    public Pose pose;                               // the pose we are testing
    public Boolean inRouteBoundingBox;

    public RouteGeometry()
    {
        dr_p0_to_p1_rad = 0.0;
        dt_dr_p0_to_pt_rad = 0.0;
        dt_dr_pt_to_p1_rad = 0.0;
        dr_pt_to_p0_rad = 0.0;
        dr_pt_to_p1_rad = 0.0;
        crossTrack_rad = 0.0;
        segment_frac = 0.0;
        value_m = 0.0;
        prevWpIndex = 0;
        currWpIndex = 0;
        rb = new RangeBearing();
        trackToRouteAngle_rad = 0;
        inRouteBoundingBox = false;
        pose = new Pose();

        errorCode = RouteRelative.ErrorCode.invalidGeometry;
    }

    public RouteGeometry(Pose pose1, Track track, ArrayList<WayPoint> wps, LatLngRad[] bounds, int idx)
    {
        this();
        if (wps.size() < 2) return;

        if ((wps.get(idx - 1).ur != null) && (wps.get(idx).ur != null) && (pose1.ur != null))
        {
            prevWpIndex = wps.get(idx - 1).index;
            currWpIndex = wps.get(idx).index;
            Vector3D un = Vector3D.CalcUnitNormalVector(wps.get(idx - 1).ur, wps.get(idx).ur);
            Vector3D ut = Vector3D.VectorCross3D(wps.get(idx - 1).ur, un);

            dr_p0_to_p1_rad = Vector3D.VectorDot3D(wps.get(idx).ur, ut);                      //arc from p0 to p1
            dt_dr_p0_to_pt_rad = Vector3D.VectorDot3D(pose1.ur, ut);            //downtrack arc from p0 to tp
            dt_dr_pt_to_p1_rad = dr_p0_to_p1_rad - dt_dr_p0_to_pt_rad;      //downtrack arc from tp to p1

            dr_pt_to_p0_rad = Vector3D.CalcArcDist(pose1.ur, wps.get(idx - 1).ur);           //arc from p0 to pt
            dr_pt_to_p1_rad = Vector3D.CalcArcDist(pose1.ur, wps.get(idx).ur);           //arc from pt to p1

            crossTrack_rad = Vector3D.VectorDot3D(un, pose1.ur);            //crosstrack arc from cp0-cp1 to tp

            // adjust dt_dr_pt_to_p1_rad to account for cross track error induced
            // segment interference
            double theta0 = wps.get(idx - 1).nextPsi_rad / 2.0;
            double deltaDr0_rad = (crossTrack_rad * Math.tan(theta0));
            dt_dr_p0_to_pt_rad -= deltaDr0_rad;

            double theta1 = wps.get(idx).nextPsi_rad / 2.0;
            double deltaDr1_rad = (crossTrack_rad * Math.tan(theta1));
            dt_dr_pt_to_p1_rad -= deltaDr1_rad;

            // find distance along the actualPath regardless of how far off the actualPath laterally we are
            // this allows for an estimate of closeness to checkpoint regardless of the actualPath the route
            // takes between checkpoints.

            // TODO: verify that dr_cp0_to_cp1_rad is not zero. this can be accomplished at CP verification during route creation
            dr_p0_to_p1_rad = Math.abs(dr_p0_to_p1_rad) > Const.min_point_dist_rad ? dr_p0_to_p1_rad : Const.min_point_dist_rad;

            // add impact of CT
            dr_p0_to_p1_rad -= (deltaDr0_rad + deltaDr1_rad);

            // get the segment fraction
            segment_frac = dt_dr_p0_to_pt_rad / dr_p0_to_p1_rad;

            // Get the value
            value_m = wps.get(idx - 1).value_m + (wps.get(idx).value_m - wps.get(idx - 1).value_m) * segment_frac;

            // wp segment range bearing
            rb = new RangeBearing(wps.get(idx - 1).pt, wps.get(idx).pt);

            // the point we are testing
            pose = new Pose(pose1);

            // Angle between test and waypoints
            trackToRouteAngle_rad = track != null ? RangeBearing.CalcDeltaAngle(track.trackSegment.rb.bearing_rad, rb.bearing_rad) : 0.0;

            // in route bounding box
            if (bounds.length == 2)
            {
                inRouteBoundingBox = pose1.pt.latitude_rad >= bounds[0].latitude_rad
                        && pose1.pt.longitude_rad >= bounds[0].longitude_rad
                        && pose1.pt.latitude_rad <= bounds[1].latitude_rad
                        && pose1.pt.longitude_rad <= bounds[1].longitude_rad;
            }
            else
            {
                inRouteBoundingBox = true;  //true because there is no bounds
            }
            // set valid
            errorCode = RouteRelative.ErrorCode.normal;
        }
    }

    public RouteGeometry(Pose pose1, Track track, WayPoint wp0, WayPoint wp1)
    {
        this();

        if ((wp0.ur != null) && (wp1.ur != null) && (pose1.ur != null))
        {
            prevWpIndex = wp0.index;
            currWpIndex = wp1.index;
            Vector3D un = Vector3D.CalcUnitNormalVector(wp0.ur, wp1.ur);
            Vector3D ut = Vector3D.VectorCross3D(wp0.ur, un);

            dr_p0_to_p1_rad = Vector3D.VectorDot3D(wp1.ur, ut);                         //arc from p0 to p1
            dt_dr_p0_to_pt_rad = Vector3D.VectorDot3D(pose1.ur, ut);                    //downtrack arc from p0 to tp
            dt_dr_pt_to_p1_rad = dr_p0_to_p1_rad - dt_dr_p0_to_pt_rad;                  //downtrack arc from tp to p1

            dr_pt_to_p0_rad = Vector3D.CalcArcDist(pose1.ur, wp0.ur);                   //arc from p0 to pt
            dr_pt_to_p1_rad = Vector3D.CalcArcDist(pose1.ur, wp1.ur);                   //arc from pt to p1

            crossTrack_rad = Vector3D.VectorDot3D(un, pose1.ur);            //crosstrack arc from cp0-cp1 to tp

            // adjust dt_dr_pt_to_p1_rad to account for cross track error induced
            // segment interference
            double theta0 = wp0.nextPsi_rad / 2.0;
            double deltaDr0_rad = (crossTrack_rad * Math.tan(theta0));
            dt_dr_p0_to_pt_rad -= deltaDr0_rad;

            double theta1 = wp1.nextPsi_rad / 2.0;
            double deltaDr1_rad = (crossTrack_rad * Math.tan(theta1));
            dt_dr_pt_to_p1_rad -= deltaDr1_rad;

            // find distance along the actualPath regardless of how far off the actualPath laterally we are
            // this allows for an estimate of closeness to checkpoint regardless of the actualPath the route
            // takes between checkpoints.

            // TODO: verify that dr_cp0_to_cp1_rad is not zero. this can be accomplished at CP verification during route creation
            dr_p0_to_p1_rad = Math.abs(dr_p0_to_p1_rad) > Const.min_point_dist_rad ? dr_p0_to_p1_rad : Const.min_point_dist_rad;

            // add impact of CT
            dr_p0_to_p1_rad -= (deltaDr0_rad + deltaDr1_rad);

            // get the segment fraction
            segment_frac = dt_dr_p0_to_pt_rad / dr_p0_to_p1_rad;

            // Get the value
            value_m = wp0.value_m + (wp1.value_m - wp0.value_m) * segment_frac;

            // wp segment range bearing
            rb = new RangeBearing(wp0.pt, wp1.pt);

            // the point we are testing
            pose = new Pose(pose1);

            // Angle between test and waypoints
            trackToRouteAngle_rad = track != null ? RangeBearing.CalcDeltaAngle(track.trackSegment.rb.bearing_rad, rb.bearing_rad) : 0.0;

            // no bounds, so set true
            inRouteBoundingBox = true;  //true because there is no bounds

            // set valid
            errorCode = RouteRelative.ErrorCode.normal;
        }
    }

    public static ArrayList<RouteGeometry> CalcRouteGeometry(Pose pose, Track track, ArrayList<WayPoint> wps, LatLngRad[] bounds)
    {
        ArrayList<RouteGeometry> rgs = new ArrayList<>();
        for(int inx = 1; inx< wps.size(); inx++)
        {
            rgs.add(new RouteGeometry(pose, track, wps, bounds, inx));
        }
        return (rgs);
    }

    public static ArrayList<RouteGeometry> CalcRouteGeometry(Pose pose, Track track, Route route, Bound selBound)
    {
        ArrayList<RouteGeometry> rgs = new ArrayList<>();
        if (selBound.isValidBound) {
            for (int inx = selBound.bnd0+1; inx <= selBound.bnd1; inx++) {
                rgs.add(new RouteGeometry(pose, track, route.wps[inx-1], route.wps[inx]));
            }
        }
        return (rgs);
    }
}
