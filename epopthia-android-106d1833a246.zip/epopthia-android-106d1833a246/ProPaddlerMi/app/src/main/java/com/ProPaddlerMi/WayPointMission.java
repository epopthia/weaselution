package com.ProPaddlerMi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.PointF;
import android.os.Handler;
import android.widget.Toast;

import com.ProPaddlerMi.baseclass.CheckPoint;
import com.ProPaddlerMi.baseclass.CheckPointCycle;
import com.ProPaddlerMi.baseclass.CheckPointTime;
import com.ProPaddlerMi.baseclass.Interpolate;
import com.ProPaddlerMi.baseclass.InterpolateResult;
import com.ProPaddlerMi.baseclass.LatLngRad;
import com.ProPaddlerMi.baseclass.LookupInfo;
import com.ProPaddlerMi.baseclass.RacerState;
import com.ProPaddlerMi.baseclass.Route;
import com.ProPaddlerMi.baseclass.WayPoint;
import com.ProPaddlerMi.infrastructure.BatteryMonitor;
import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;
import com.ProPaddlerMi.utility.VariableLagFilter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.ProPaddlerMi.WayPointNav.CrossTrack;
import static com.ProPaddlerMi.baseclass.CheckPointCycle.CheckPointCycleStatus.pending;
import static java.lang.Math.abs;
import static java.lang.Math.ceil;
import static java.lang.Math.cos;
import static java.lang.Math.floor;
import static java.lang.Math.max;
import static java.lang.Math.min;


@SuppressWarnings("WeakerAccess")
@SuppressLint("DefaultLocale")

public class WayPointMission {

    private static WayPointMission objWayPointMission;

    private final Handler mRunner;

    private final VariableLagFilter speed_filter = new VariableLagFilter(8);

    private int speed_update_count;

    public static final ArrayList<String> sms_log = new ArrayList<>();
    private static final double min_accuracy_ft = 40;

    public final int min_speed_update_count = 10;

    public final String cp_times_file = "CheckPointTimes.csv";

    public ClassObjIndex[] objIndices;
    private final Globals globals;
    private final ClassLog history;
    public final ClassFileIO fio;

    public final double cp_in_out_tolerance_ft = 500;
    public final double cp_in_out_tolerance_mile = cp_in_out_tolerance_ft * Const.ft_to_mile;

    public static int selected_cp_index;
    public static WayPoint currentPosition;
    private static int[] checkpoint_map;
    public static int curr_wp_index = 1;
    private double dist_to_wp_ft;
    private double cross_track_err_ft;
    private double bearing_deg = 0.0;
    boolean initialized = false;

    private static int rm_count;


    public double wp_bearing_deg = 0.0;
    public double max_speed_mph = 0.0;
    private double bearing_error_deg = 0.0;
    private double plan_speed_mph = 0.0;
    private double avg_speed_mph = 0.0;
    private double avg_track_mph = 0.0;
    private double track_mph = 0.0;
    private double speed_mph = 0.0;
    private double gps_speed_mph = 0.0;
    private double accuracy_ft = 0.0;
    private double elapsed_time_s = 0.0;
    private RacerState s0 = null;

    //private final Context globals.AppState.ctx; //<-- declare a Context reference


    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
	public static synchronized WayPointMission getInstance()
    {

	    if (objWayPointMission == null) {
			objWayPointMission = new WayPointMission();
		}
		return objWayPointMission;
	}

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------
	private WayPointMission() {

        mRunner = new Handler();

        globals = Globals.getInstance();

        fio = new ClassFileIO(globals.appState.ctx);

        history = ClassLog.getInstance();

        reset_speed_update_count(min_speed_update_count);

        currentPosition = new WayPoint();

        //create the route
        globals.route = new Route(readCheckPoints(), ReadWaypoints(), "Central Standard Time", "Mi");

        //validate the start/stop checkpoints
        validateStartStop();

        //default the cp times
        if (globals.checkPointTimes.size() != globals.route.cps.length) {
            globals.checkPointTimes = setDefaultRest(globals.route.cps);
        }

        //index objects assumes object file has been indexed
        fio.ReadObjects();
        objIndices = new ClassObjIndex[0];
        IndexObjects();

    }

    // ----------------------------------------------------------------------
    // WaypointDestructor
    // ----------------------------------------------------------------------
//    public void WaypointDestructor() {
//        if (globals.route.cps != null)
//        {
//            ClassFileIO fio = new ClassFileIO(globals.appState.ctx);
//            fio.WriteCheckpointTimes(globals.route.cps, cp_times_file);
//        }
//    }

    // ----------------------------------------------------------------------
    // IndexObjects
    // ----------------------------------------------------------------------
    private void IndexObjects() {
        //allocate index array

        int maxRouteKm = (int) ceil(max(abs(globals.route.wps[globals.route.wps.length - 1].value_m), abs(globals.route.wps[0].value_m))/1000);
        objIndices = new ClassObjIndex[maxRouteKm + 1];
        for (int inx = 0; inx < objIndices.length; inx++) {
            objIndices[inx] = new ClassObjIndex();
        }

        // index objects
        for (int inx = 0; inx < fio.objects.size(); inx++) {
            ClassObj obj = fio.objects.get(inx);
            float objMin = min(obj.value_km[0], obj.value_km[1]);
            float objMax = max(obj.value_km[0], obj.value_km[1]);
            int idx0 = (int) max(floor(objMin), 0);
            int idx1 = (int) min(ceil(objMax), maxRouteKm);

            for (int jnx = idx0; jnx <= idx1; jnx++) {
                objIndices[jnx].objs.add(inx);
            }
        }
    }

    // ----------------------------------------------------------------------
    // getCheckpoints
    // ----------------------------------------------------------------------
    public String[] getAllCheckpointLabels() {
        String[] ret = null;
        if (globals.route.cps != null) {
            ret = new String[globals.route.cps.length];

            for (int inx = 0; inx < globals.route.cps.length; inx++) {
                ret[inx] = String.format("%s", globals.route.cps[inx].Name);
            }
        }
        return ret;
    }


    // ----------------------------------------------------------------------
    // isCheckpointVisible
    //	true if the given checkpoint index can be seen on the checkpoint
    //	listing
    // ----------------------------------------------------------------------
    private boolean isCheckpointVisible(int idx) {
        boolean ret = false;

        if (isValidCPIndex(idx)) {
            ret = globals.route.cps[idx].visible;
        }
        return ret;
    }

    // ----------------------------------------------------------------------
    // getCheckpointsVisible
    // ----------------------------------------------------------------------
    public void SetCheckpointVisibilityMap() {
        //if (!globals.verifyCheckpoints(Math.max( globals.settings.startCheckpointIndex,  globals.settings.finishCheckpointIndex))) return;

        int numvis = 0;

        // set all visibility off for init
        for (CheckPoint cp : globals.route.cps) {
            cp.visible = false;
        }

        //evaluate visibility of checkpoints
        double wpDirection = getWpDirection();

        for (int inx = globals.settings.startCheckpointIndex; inx != globals.settings.finishCheckpointIndex + wpDirection; inx += wpDirection) {

            //default all visible

            // if not supported
            globals.route.cps[inx].visible = !globals.settings.displayCheckpointsOnly || globals.route.cps[inx].isSupported;

            // if cycled
            if (globals.checkPointTimes.get(inx).actual_in_hr >= 0 && !globals.settings.displayCycledCheckpoints) {
                globals.route.cps[inx].visible = false;
            }

            if (globals.route.cps[inx].visible) numvis++;
        }

        //create mapping
        checkpoint_map = new int[numvis];
        int jnx = 0;

        for (int inx = globals.settings.startCheckpointIndex; inx != globals.settings.finishCheckpointIndex + wpDirection; inx += wpDirection) {
            if (globals.route.cps[inx].visible) {
                checkpoint_map[jnx++] = inx;
            }
        }

        //check selected cp visibility
        if (!isCheckpointVisible(selected_cp_index)) {
            selected_cp_index = 0;
            if (checkpoint_map.length > 0) {
                selected_cp_index = checkpoint_map[0];
            }
        }
    }

    // ----------------------------------------------------------------------
    // getWayPoint
    // ----------------------------------------------------------------------
    public WayPoint getWayPoint(int idx) {
        WayPoint wp = null;
        if (isValidWPIndex(idx)) {
            wp = globals.route.wps[idx];
        }
        return wp;
    }

    // ----------------------------------------------------------------------
    // getCheckPoint
    // ----------------------------------------------------------------------
    public CheckPoint getCheckPoint(int idx) {
        CheckPoint cp = null;
        if (isValidCPIndex(idx)) {
            cp = globals.route.cps[idx];
        }
        return cp;
    }

    // ----------------------------------------------------------------------
    // cycleCheckpoint
    // ----------------------------------------------------------------------
    private void cycleCheckpoint() {
        if (globals.route.cps == null) return;

        final double tolerance = 10 * Const.mile_to_m;
        double value = getCurrentValue();
        boolean cycledCheckpoint;
        double wpdir = getWpDirection();

        for (int inx = globals.settings.startCheckpointIndex; inx != globals.settings.finishCheckpointIndex + wpdir; inx += wpdir)
        {

            if (globals.isInvalidCheckpoint(inx)) return;

            // needs to be within a tolerance of the checkpoint for auto check point to function
            if (Math.abs(value - globals.route.cps[inx].value_m)< tolerance) {

                //in/out

                cycledCheckpoint = (globals.checkPointTimes.get(inx).actual_in_hr >= 0) && (globals.checkPointTimes.get(inx).actual_out_hr >= 0);

                if (!cycledCheckpoint) {

                    // in
                    if ((globals.checkPointTimes.get(inx).actual_in_hr < 0) &&
                            (((wpdir * (globals.route.cps[inx].value_m - wpdir * cp_in_out_tolerance_mile) - wpdir * value)) < 0)) {

                        globals.checkPointTimes.get(inx).actual_in_hr = getElapsedTimeSec(true) * Const.sec_to_hour;
                        if (globals.settings.enableAutoCheckin && isTextCheckPoint(inx)) {
                            CheckPointCycle cpc = makeCheckPointCycle(globals.settings.boat_number, globals.route.cps[inx].Name, new Date(), "in");
                            globals.checkPointCyclesAdd(cpc);

                        }
                    }

                    //out
                    if ((globals.checkPointTimes.get(inx).actual_out_hr < 0) && (((wpdir * (globals.route.cps[inx].value_m + wpdir * cp_in_out_tolerance_mile) - wpdir * value)) < 0)) {
                        globals.checkPointTimes.get(inx).actual_out_hr = getElapsedTimeSec(true) * Const.sec_to_hour;
                        if (globals.settings.enableAutoCheckin && isTextCheckPoint(inx)){
                            CheckPointCycle cpc = makeCheckPointCycle(globals.settings.boat_number, globals.route.cps[inx].Name, new Date(), "out");
                            globals.checkPointCyclesAdd(cpc);
                        }
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // makeCheckPointCycle
    // ---------------------------------------------------------------------------------------------
    private CheckPointCycle makeCheckPointCycle(String boat, String checkpoint, Date cp_time, String status)
    {
        CheckPointCycle cpc = new CheckPointCycle();
        cpc.Authorization = globals.settings.authorizationCode;
        cpc.BoatNumber = boat;
        cpc.Checkpoint = checkpoint;
        cpc.locationTime = cp_time;
        cpc.TextLocationTime = ClassUtility.getRaceOwlTextTime(cp_time);
        cpc.NetLocationTime  = ClassUtility.getRaceOwlNetTime(cp_time);
        cpc.RaceEventID = globals.settings.RaceEventID;
        cpc.Status = status;
        cpc.raceowl_status = pending;
        cpc.checkpoint_index = getCheckpointIndexByName(checkpoint);
        return(cpc);
    }


    // ----------------------------------------------------------------------
    // IsExclusionCP
    // ----------------------------------------------------------------------
    private boolean IsExclusionCP(int cp)
    {
        return cp == globals.settings.startCheckpointIndex || cp == globals.settings.finishCheckpointIndex;
    }

    // ----------------------------------------------------------------------
    //	getMappedCheckpointIndex
    //	return the cp index given the visible index (map_idx)
    // ----------------------------------------------------------------------
    public int getMappedCheckpointIndex(int map_idx) {
        int ret = -1;
        if (map_idx >= 0 && map_idx < checkpoint_map.length) {
            ret = checkpoint_map[map_idx];
        }
        return (ret);
    }

    // ----------------------------------------------------------------------
    //	getCheckpointIndexToMapped - return -1 if not successful
    // ----------------------------------------------------------------------
    public int getCheckpointIndexToMapped(int cp_idx) {
        int ret = -1;
        if (checkpoint_map != null) {
            for (int inx = 0; inx < checkpoint_map.length; inx++) {
                if (cp_idx == checkpoint_map[inx]) {
                    ret = inx;
                    break;
                }
            }
        }
        return (ret);
    }

    // ----------------------------------------------------------------------
    // getCheckpointStatus
    // ----------------------------------------------------------------------
    @SuppressLint("DefaultLocale")
    public void getCheckpointStatus(ArrayList<String> status) {

        status.clear();

        SetCheckpointVisibilityMap();

        if (checkpoint_map == null || globals.route.cps == null || checkpoint_map.length == 0) {
            status.add(String.format("%s", "No checkpoints to display"));
            return;
        }

        for (int idx : checkpoint_map) {
            double eta_hr = getEstimatedCheckPointTimeHour(idx, false, false, true);
            double delta_mile = getCheckPointDeltaMile(idx);
            double elapsed_time_hr = getElapsedTimeSec(true) * Const.sec_to_hour;

            String instr;
            String outstr;

            String eta_str = getEstimatedCheckPointTimeHourStr(idx);
            String line1 = String.format("%s", globals.route.cps[idx].Name);
            String line2 = String.format("\t%-10s%s/%1.1f", "time/dist", eta_str, delta_mile);

            //actual
            String line3;
            String line4;
            double in_hr = 0;
            double out_hr = 0;
            boolean in_out_hr_valid;
            in_out_hr_valid = true;

            if (globals.checkPointTimes.get(idx).actual_in_hr >= 0) {
                in_hr = globals.checkPointTimes.get(idx).actual_in_hr;
                instr = convertHourToHourStr(in_hr, false);
                if (globals.checkPointTimes.get(idx).actual_out_hr < 0) {

                    out_hr = globals.checkPointTimes.get(idx).actual_in_hr + globals.checkPointTimes.get(idx).rest_hr;
                    outstr = convertHourToHourStr(out_hr, false);
                    line3 = String.format("\t%-10s%s/%s", "in(a)/out", instr, outstr);
                } else {
                    out_hr = globals.checkPointTimes.get(idx).actual_out_hr;
                    outstr = convertHourToHourStr(out_hr, false);
                    line3 = String.format("\t%-10s%s/%s", "in/out(a)", instr, outstr);
                }

            }
            //estimated
            else if (eta_hr > 0) {
                in_hr = elapsed_time_hr + eta_hr;
                out_hr = elapsed_time_hr + eta_hr + globals.checkPointTimes.get(idx).rest_hr;
                instr = convertHourToHourStr(in_hr, false);
                outstr = convertHourToHourStr(out_hr, false);
                line3 = String.format("\t%-10s%s/%s", "in/out(e)", instr, outstr);
            } else {
                in_out_hr_valid = false;
                line3 = String.format("\t%-10s", "in/out(e)");
            }

            if (in_out_hr_valid) {
                line4 = String.format("\t%-10s%s\n\t%-10s%s", "clock in",
                        ClassUtility.dayTimeFromDateNoSec(globals.settings.startDate, in_hr),
                        "clock out",
                        ClassUtility.dayTimeFromDateNoSec(globals.settings.startDate, out_hr));
            } else {
                line4 = String.format("\t%-10s", "clock");
            }
            String line5 = String.format("\t%-10s%1.2f", "rivermile", globals.route.cps[idx].riverMile);
            status.add(String.format("%s\n%s\n%s\n%s\n%s\n", line1, line2, line3, line4, line5));
        }
    }


    // ----------------------------------------------------------------------
    // calcSpeedOrHourGoal
    // ----------------------------------------------------------------------
    public void calcSpeedOrHourGoal() {
        double tot_rest_hr;
        double goal_hr;
        double plan_speed_mph;
        if (globals.route.cps != null && globals.route.cps.length > 0) {

            tot_rest_hr = getTotalPlannedRestHour();

            double wpdir = getWpDirection();

            //calc total miles
            double tot_mile = wpdir * (globals.route.cps[globals.settings.finishCheckpointIndex].value_m - globals.route.cps[globals.settings.startCheckpointIndex].value_m) * Const.m_to_mile;

            //set plan speed from user

            // if desired finish time has been entered, then use that as a basis for speed calc
            if (globals.appState.useDesiredFinishHr) {
                //Get goal
                goal_hr = globals.settings.desired_finish_hr;

                //Calculate needed speed
                double tmp = (goal_hr - tot_rest_hr);
                if (tmp > 0) {
                    plan_speed_mph = tot_mile / tmp;
                    globals.settings.desired_speed_mph = (float) plan_speed_mph;
                }
            }

            //Get goal
            plan_speed_mph = globals.settings.desired_speed_mph;
            goal_hr = tot_mile / plan_speed_mph + tot_rest_hr;
            globals.settings.desired_finish_hr = (float) goal_hr;
        }
    }

    // ----------------------------------------------------------------------
    // calcPlannedPerformance
    // ----------------------------------------------------------------------
    public List<PointF> calcPlannedPerformance(float[] scale, float[] offset) {
        //double tot_rest_hr = 0;
        //calc hours
        List<PointF> pts = new ArrayList<>();

        //double goal_hr;
        double plan_speed_mph;

        if (globals.route.cps != null && globals.route.cps.length > 0) {

            //update desired speed or hour goal
            calcSpeedOrHourGoal();
            //
            //goal_hr = globals.globals.desired_finish_hr;
            plan_speed_mph = globals.settings.desired_speed_mph;

            if (globals.route.cps.length > 0 && plan_speed_mph > 0) {
                PointF pt = new PointF();
                pt.x = (int) offset[0];
                pt.y = (int) offset[1];
                pts.add(pt);

                double totX = 0;
                double totY;

                double wpdir = getWpDirection();

                for (int inx = (int) (globals.settings.startCheckpointIndex + wpdir); inx != globals.settings.finishCheckpointIndex + wpdir; inx += wpdir) {

                    double deltaX = wpdir * (globals.route.cps[inx].value_m - globals.route.cps[(int) (inx - wpdir)].value_m) * Const.m_to_mile;

                    pt = new PointF();

                    //time on x axis
                    totX += ((deltaX / plan_speed_mph));
                    pt.x = (int) (totX * scale[0] + offset[0]);

                    //river mile on y axis
                    totY = ((globals.route.cps[inx].value_m) - globals.route.cps[globals.settings.startCheckpointIndex].value_m ) * wpdir * Const.m_to_mile;
                    pt.y = (int) (offset[1] - totY * scale[1]);

                    pts.add(pt);

                    //if rest time > 0 then add a time out
                    if (globals.checkPointTimes.get(inx).plan_rest_hr > 0 && inx != globals.settings.finishCheckpointIndex && inx != globals.settings.startCheckpointIndex) {
                        PointF pt2 = new PointF();
                        totX += (globals.checkPointTimes.get(inx).plan_rest_hr);
                        pt2.x = (int) (totX * scale[0] + offset[0]);
                        pt2.y = pt.y;
                        pts.add(pt2);
                    }
                }
            }
        }
        return (pts);
    }

    // ----------------------------------------------------------------------
    // calcPredictedPerformance
    // ----------------------------------------------------------------------
    public List<PointF> calcPredictedPerformance(float[] scale, float[] offset, PointF boat) {
        //calc hours
        List<PointF> pts = new ArrayList<>();

        if (globals.route.cps != null && globals.route.cps.length > 0 && isValidCPIndex(globals.settings.startCheckpointIndex) && isValidCPIndex(globals.settings.finishCheckpointIndex)) {
            PointF pt = new PointF();
            pt.x = boat.x;
            pt.y = boat.y;
            pts.add(pt);

            double wpdir = getWpDirection();


            for (int inx = (int) (globals.settings.startCheckpointIndex + wpdir); inx != globals.settings.finishCheckpointIndex + wpdir; inx = (int) (inx + wpdir)) {
                double deltaMile = getCheckPointDeltaMile(inx);
                if (deltaMile > 0) {
                    double estimatedCheckPointTimeHour = getEstimatedCheckPointTimeHour(inx, true, false, true);
                    double checkpointMilesFromStart = ((globals.route.cps[inx].value_m) - globals.route.cps[globals.settings.startCheckpointIndex].value_m ) * wpdir * Const.m_to_mile;

                    if (globals.checkPointTimes.get(inx).actual_in_hr < 0 && checkpointMilesFromStart > 0) {
                        pt = new PointF();
                        pt.x = (int) (estimatedCheckPointTimeHour * scale[0] + offset[0]);
                        pt.y = (int) (offset[1] - checkpointMilesFromStart * scale[1]);
                        pts.add(pt);
                    }

                    if (globals.checkPointTimes.get(inx).actual_out_hr < 0 && checkpointMilesFromStart > 0 && inx != globals.settings.finishCheckpointIndex) {
                        pt = new PointF();
                        if (globals.checkPointTimes.get(inx).actual_in_hr > 0) {
                            pt.x = (int) ((globals.checkPointTimes.get(inx).actual_in_hr + globals.checkPointTimes.get(inx).rest_hr) * scale[0] + offset[0]);
                        } else {
                            pt.x = (int) ((estimatedCheckPointTimeHour + globals.checkPointTimes.get(inx).rest_hr) * scale[0] + offset[0]);
                        }
                        pt.y = (int) (offset[1] - checkpointMilesFromStart * scale[1]);
                        pts.add(pt);
                    }
                }
            }
        }
        return (pts);
    }


    // ----------------------------------------------------------------------
    // calcActualPerformance
    // ----------------------------------------------------------------------
    public List<PointF> calcActualPerformance(float[] scale, float[] offset) {
        //calc hours
        List<PointF> pts = new ArrayList<>();

        if (globals.route.cps != null && globals.route.cps.length > 0) {
            PointF pt = new PointF();
            pt.x = (int) offset[0];
            pt.y = (int) offset[1];
            pts.add(pt);

            double wpdir = getWpDirection();

            for (int inx = (int) (globals.settings.startCheckpointIndex + wpdir); inx != globals.settings.finishCheckpointIndex + wpdir; inx += wpdir) {
                double mile_since_start = ((globals.route.cps[inx].value_m) - globals.route.cps[globals.settings.startCheckpointIndex].value_m ) * wpdir * Const.m_to_mile;
                if (globals.checkPointTimes.get(inx).actual_in_hr >= 0 && mile_since_start > 0) {
                    pt = new PointF();
                    pt.x = (int) (globals.checkPointTimes.get(inx).actual_in_hr * scale[0] + offset[0]);
                    pt.y = (int) (offset[1] - mile_since_start * scale[1]);
                    pts.add(pt);
                }
                if (globals.checkPointTimes.get(inx).actual_out_hr >= 0 && mile_since_start > 0) {
                    pt = new PointF();
                    pt.x = (int) (globals.checkPointTimes.get(inx).actual_out_hr * scale[0] + offset[0]);
                    pt.y = (int) (offset[1] - mile_since_start * scale[1]);
                    pts.add(pt);
                }
            }
        }
        return (pts);
    }


    // ----------------------------------------------------------------------
    // ResetCheckPoints
    // ----------------------------------------------------------------------
    public void resetCheckPointRestTime() {
        globals.checkPointTimes = setDefaultRest(globals.route.cps);
    }

    // ----------------------------------------------------------------------
    // ----------------------------------------------------------------------
    public void updatePlanRestTime() {
        for (CheckPointTime cp : globals.checkPointTimes) {
            cp.plan_rest_hr = cp.rest_hr;
        }
    }

    // ----------------------------------------------------------------------
    // readCheckPoints
    // ----------------------------------------------------------------------
    private CheckPoint[] readCheckPoints() {
        //Read the checkpoints
        ClassFileIO fio = new ClassFileIO(globals.appState.ctx);
        String fileName = "checkpoints.csv";
        return (fio.readCheckpoints(fileName));
    }

    // ----------------------------------------------------------------------
    // setDefaultRest
    // ----------------------------------------------------------------------
    private ArrayList<CheckPointTime> setDefaultRest(CheckPoint[] cps)
    {

        ArrayList<CheckPointTime> localCheckPointTimes = new ArrayList<>();

        if (globals.route.cps!=null) {


            //select default sleeps
            globals.settings.sleep1_cp_idx = globals.settings.sleep1_cp_idx < 0 ? getCheckpointIndexByName("Miami") : globals.settings.sleep1_cp_idx;
            globals.settings.sleep2_cp_idx = globals.settings.sleep2_cp_idx < 0 ? getCheckpointIndexByName("Cooper's Landing") : globals.settings.sleep2_cp_idx;
            globals.settings.sleep3_cp_idx = globals.settings.sleep3_cp_idx < 0 ? getCheckpointIndexByName("Hermann") : globals.settings.sleep3_cp_idx;

            //set normal wait
            for (int inx = 0; inx < globals.route.cps.length; inx++) {
                CheckPointTime cp = new CheckPointTime();

                if (globals.route.cps[inx].isSupported && !(inx == globals.settings.startCheckpointIndex || inx == globals.settings.finishCheckpointIndex)) {
                    cp.rest_hr = globals.settings.default_checkpoint_rest_hr;
                } else {
                    cp.rest_hr = 0;
                }

                //update sleep init
                if (inx == globals.settings.sleep1_cp_idx) {
                    cp.rest_hr = globals.settings.defaultSleepHr;
                }
                if (inx == globals.settings.sleep2_cp_idx) {
                    cp.rest_hr = globals.settings.defaultSleepHr;
                }
                if (inx == globals.settings.sleep3_cp_idx) {
                    cp.rest_hr = globals.settings.defaultSleepHr;
                }

                cp.plan_rest_hr = cp.rest_hr;
//                if (!globals.settings.freeze_baseline_plan) {
//                    cp.plan_rest_hr = cp.rest_hr;
//                }
                localCheckPointTimes.add(cp);
            }
        }
        return (localCheckPointTimes);
    }

    private WayPoint[] ReadWaypoints() {
        int wp_count;
        WayPoint[] wps = new WayPoint[0];

        AssetManager assetManager = globals.appState.ctx.getAssets();

        try {
            String waypointFile = "waypoints.csv";
            InputStreamReader iStr = new InputStreamReader(assetManager.open(waypointFile));
            BufferedReader br = new BufferedReader(iStr);
            String strLine;

            strLine = br.readLine();
            String[] numWpStr = strLine.split(",");
            wp_count = Integer.parseInt(numWpStr[0]);
            wps = new WayPoint[wp_count];

            for (int inx = 0; inx < wp_count; inx++) {
                strLine = br.readLine();
                String[] mToks = strLine.split(",", 4);
                double lat_rad = Double.parseDouble(mToks[1]) * Const.dtr;
                double lon_rad = Double.parseDouble(mToks[0]) * Const.dtr;
                double value_m = Double.parseDouble(mToks[2]);
                double riverMile = Double.parseDouble(mToks[3]);
                wps[inx] = new WayPoint(lat_rad,lon_rad,value_m,riverMile);
            }
            iStr.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Toast.makeText(this, "Total Waypoints = " + wp_count,Toast.LENGTH_SHORT).show();

        return (wps);
    }


    // ----------------------------------------------------------------------
    //  getCheckPointDeltaMile - return miles to specified checkpoint from current location
    // ----------------------------------------------------------------------
    public double getCheckPointDeltaMile(int cp_index) {
        double ret = 0.0;
        if (isValidCPIndex(cp_index)) {
            double wpDir = getWpDirection();
            ret = (globals.route.cps[cp_index].value_m - getCurrentValue()) * Const.m_to_mile * wpDir;
        }
        return (ret);
    }

    // ----------------------------------------------------------------------
    //  calcTrackSpeed
    // ----------------------------------------------------------------------
    private double calcTrackSpeed() {
        double speed_mph = getSpeed();
        double wp_bearing_deg = getWaypointBearing();
        double bearing_deg = getBearing();
        double alpha_rad = (bearing_deg - wp_bearing_deg) * Const.dtr;
        alpha_rad = WayPointNav.limit_angle_rad(alpha_rad);
        return speed_mph * cos(alpha_rad);
    }

    // ----------------------------------------------------------------------
    // getTrackSpeed
    // ----------------------------------------------------------------------
    public double getTrackSpeed() {
        return track_mph;
    }

    // ----------------------------------------------------------------------
    // getAccuracy
    // ----------------------------------------------------------------------
    public double getAccuracy() {
        return accuracy_ft;
    }

    // ----------------------------------------------------------------------
    // getAvgTrackSpeed
    // ----------------------------------------------------------------------
    public double getAvgTrackSpeed() {
        return avg_track_mph;
    }



    // ----------------------------------------------------------------------
    // getPlannedRestHour
    // find rest time from current location to the selected index
    // ----------------------------------------------------------------------
    private float getDeltaPlannedRestHour(int cp_index, boolean use_plan) {
        //find rest time to the selected index
        float rest_time_hr = 0;
        int inx = getNextCheckPointIndex(0, true);  //next checkpoint
        double wpdir = getWpDirection();

        if ((((inx < cp_index) && wpdir > 0) || ((inx > cp_index) && wpdir < 0)))  //if converging to cp_index
        {
            while (cp_index != inx && isValidCPIndex(inx)) {
                if (use_plan) {
                    rest_time_hr += globals.checkPointTimes.get(inx).plan_rest_hr;
                } else {
                    rest_time_hr += globals.checkPointTimes.get(inx).rest_hr;
                }
                inx = (int) (inx + wpdir);
            }
        } else {
            rest_time_hr = (float) 0.0;
        }
        return rest_time_hr;
    }


    // ----------------------------------------------------------------------
    // getTotalPlannedRestHour
    // find total rest time from start to finish
    // ----------------------------------------------------------------------
    private float getTotalPlannedRestHour() {
        float tot_rest_hr = (float) 0.0;

        //get total rest between start and finish
        double wpdir = getWpDirection();

        for (int inx = (int) (globals.settings.startCheckpointIndex + wpdir); inx != globals.settings.finishCheckpointIndex; inx += wpdir) {
            tot_rest_hr += globals.checkPointTimes.get(inx).rest_hr;
        }
        return tot_rest_hr;
    }


    // ----------------------------------------------------------------------
    //  getEstimatedCheckPointTimeHour
    //	get estimated delta time to specified
    //	set absolute_est to true to add the elapsed time
    // ----------------------------------------------------------------------
    public double getEstimatedCheckPointTimeHour(int cpIndex, boolean useAbsoluteTimeEstimate, boolean use_plan, boolean useRest) {
        double estimateTimeToCheckpoint_hr = 0.0;
        double elapsedTimeHr = getElapsedTimeSec(true) * Const.sec_to_hour;

        if (isValidCPIndex(cpIndex)) {

            // get the average speed
            double localAvgSpeed_mph = getAvgTrackSpeed();
            if (localAvgSpeed_mph <= 0.0) {
                localAvgSpeed_mph = getPlanSpeed();
            }
            if (localAvgSpeed_mph <= 0.0) {
                localAvgSpeed_mph = globals.settings.desired_speed_mph;
            }

            if (localAvgSpeed_mph > 0.0) {
                //find miles to the selected index
                double delta_mile = getCheckPointDeltaMile(cpIndex);

                //find rest time to the selected index
                double rest_time_hr = 0;
                if (useRest) {
                    rest_time_hr = getDeltaPlannedRestHour(cpIndex, use_plan);
                }

                estimateTimeToCheckpoint_hr = delta_mile > 0 ? rest_time_hr + delta_mile / localAvgSpeed_mph : 0;  //estimated time to selected checkpoint

                if (useAbsoluteTimeEstimate) {
                    estimateTimeToCheckpoint_hr += elapsedTimeHr;
                }
            }
        } else {
            estimateTimeToCheckpoint_hr = -999.0;
        }
        return estimateTimeToCheckpoint_hr;
    }

    public void resetCurrentPosition()
    {
        currentPosition = new WayPoint();
    }

    // ----------------------------------------------------------------------
    //  updateNav
    //	Update the Navigation data with the latest GPS data
    // ----------------------------------------------------------------------
    public void updateNav(double lat_deg, double lon_deg, double speed_mps, double actual_bearing_deg, double accuracy_m, long time_ms)
    {

        //check that elapsed time is > 0 then exit
        boolean started =  getElapsedTimeSec(false)>0;

        //update the vehicle state
        s0 = RacerStateManager.setRacerState(lat_deg, lon_deg, speed_mps, actual_bearing_deg, accuracy_m, time_ms);

        //update current bearing, pos and speed
        bearing_deg = actual_bearing_deg;
        speed_mph = speed_mps * Const.mps_to_mph;  //current gps speed
        gps_speed_mph = s0.summary.selSpeed_mps * Const.mps_to_mph;
        currentPosition.pt.latitude_rad = s0.pose1.pt.latitude_rad; ////lat_deg * Const.dtr;
        currentPosition.pt.longitude_rad = s0.pose1.pt.longitude_rad; ////lon_deg * Const.dtr;
        accuracy_ft = s0.pose1.accuracy_m * Const.m_to_ft; //accuracy_m * Const.m_to_ft;


        //update reference
        WayPointNav.setReferenceLatLon(currentPosition.pt.latitude_rad, currentPosition.pt.longitude_rad);

        //cycle the waypoint
        curr_wp_index = s0.routeRelative.wpIndex;    //initCurrentWaypoint(currentPosition.pt.latitude_rad, currentPosition.pt.longitude_rad);

        if (!initialized || !started) {

            if (started)
            {
                initialized = true;
                // select closest checkpoint
                setNearestCheckpointIndex();
            }
        }

        dist_to_wp_ft = WayPointNav.DistToWayPoint(globals.route.wps[getPrevWP(curr_wp_index)].pt, globals.route.wps[curr_wp_index].pt, currentPosition.pt);

        //double wpdir = getWpDirection();

        //set current value
        setCurrentValue( s0.routeRelative.value_m );

        //get cross track
        cross_track_err_ft =  s0.routeRelative.crossTrack_rad * Const.earth_a_ft; //CrossTrack(wps[getPrevWP(curr_wp_index)].pt, wps[curr_wp_index].pt, currentPosition.pt);

        //calculate total miles
        double delta_ft = calcTotalMiles(currentPosition.pt.latitude_rad, currentPosition.pt.longitude_rad);

        //calculate location based speed
        if (globals.settings.location_based_speed && !globals.appState.enableSimulation) {
            speed_mph = calcLocationBasedSpeed(delta_ft, speed_mph, time_ms);
        }

        //track speed
        track_mph = calcTrackSpeed();

        // calcPlanSpeed()
        plan_speed_mph = calcPlanSpeed();

        max_speed_mph = calcMaxSpeed(speed_mph);

        //average speed
        avg_speed_mph = history.getAvgSpeed();
        avg_track_mph = history.getAvgTrack();

        //wp
        wp_bearing_deg = calcWaypointBearing();
        bearing_error_deg = calcBearingError();

        //check for a cycle of a checkPoint
        if (started) {
            cycleCheckpoint();
        }

        double distToSelectedCheckpoint = getCheckPointDeltaMile(getSelectedCheckpointIndex());
        if (distToSelectedCheckpoint <=0) setNearestCheckpointIndex(10);


    }

    private int count_audio = 0;

    // ----------------------------------------------------------------------
    //  setAudioCounter
    // ----------------------------------------------------------------------
    private void setAudioCounter(int count)
    {
        count_audio = count;  // this counter decrements
    }

    // ----------------------------------------------------------------------
    //  decrementAudioCounter
    // ----------------------------------------------------------------------
    public void decrementAudioCounter()
    {
        if (count_audio > 0) count_audio--;
    }

    // ----------------------------------------------------------------------
    //  clearToSpeak
    // ----------------------------------------------------------------------
    private boolean isClearToSpeak()
    {
        return (count_audio<=0);
    }



    // ----------------------------------------------------------------------
    //  toggleAudioStatus
    // ----------------------------------------------------------------------
    public void toggleAudioStatus2()
    {

        String txt = "Set audio status updates ";

        // toggle audio
        globals.settings.enableAudibleStatus = !globals.settings.enableAudibleStatus;

        //  start the audio
        if (globals.settings.enableAudibleStatus)
        {
            txt = txt + "on";
        }
        else
        {
            txt = txt + "off";
        }

        Toast.makeText(globals.appState.ctx , txt, Toast.LENGTH_LONG).show();

        if (globals.settings.enableAudibleStatus) {
            audibleStatus();
        }
    }


    // ----------------------------------------------------------------------
    //  toggleAudioWarningTrack
    // ----------------------------------------------------------------------
    public void toggleAudioWarningTrack()
    {

        String txt = "Set audio warning track ";

        // toggle audio
        globals.settings.enableAudibleWarningTrack = !globals.settings.enableAudibleWarningTrack;

        //  start the audio
        if (globals.settings.enableAudibleWarningTrack)
        {
            txt = txt + "on";
        }
        else
        {
            txt = txt + "off";
        }

        Toast.makeText(globals.appState.ctx , txt, Toast.LENGTH_LONG).show();

        setAudioCounter(0);

    }

    // ----------------------------------------------------------------------
    //  sayLine
    // ----------------------------------------------------------------------
    public void sayLine(String line)
    {
        ArrayList<String> lines = new ArrayList<>();
        lines.add(line);
        broadcastTTS(lines);
    }

    // ----------------------------------------------------------------------
    //  audibleStatus - use TTV to relay status
    // ----------------------------------------------------------------------
    public void audibleStatus() {
        String stat;
        ArrayList<String> lines = new ArrayList<>();

        // update the elapsed time
        double elapsed_time_s = calcElapsedTimeSec();

        if (elapsed_time_s>0) {
            int num_items = 4; //globals.globals.display_idx.length;
            for (int inx = 0; inx < num_items; inx++) {
                stat = getAudioStatus(globals.settings.display_idx[inx]);
                if (stat.length() > 0) {
                    lines.add(stat);
                }
            }
        }
        else
        {
            lines.add((String.format("%s", formatSecToHourMinAudio(getElapsedTimeSec(false)))));
        }

        BatteryMonitor battery = BatteryMonitor.getInstance();
        if (battery.isLowBatteryWarning)
        {
            lines.add(String.format("warning! %1.0f percent battery", battery.batteryPercent));
        }

        broadcastTTS(lines);
        lines.clear();
    }

    //---------------------------------------------------------------------------
    // broadcastTTS
    //---------------------------------------------------------------------------
    private void broadcastTTS(ArrayList<String> list)
    {
        Intent i = new Intent("Mi_TTS");
        i.putExtra("text", list);
        globals.appState.ctx.sendBroadcast(i);
    }


//    private long tictoc_last_ms = 0;

//    // ----------------------------------------------------------------------
//    //  tictoc - say seconds since last call
//    // ----------------------------------------------------------------------
//    public void tictoc() {
//
//        long currentMilliSeconds = ClassUtility.getCurrentMilliSeconds();
//        float delta = currentMilliSeconds - tictoc_last_ms;
//        String delta_str;
//
//
// //       Toast.makeText(globals.AppState.ctx, String.format("%1.0f = %d - %d", delta,currentMilliSeconds,tictoc_last_ms), Toast.LENGTH_LONG).show();
//        Toast.makeText(globals.AppState.ctx, String.format("%1.0f seconds", delta/1000), Toast.LENGTH_LONG).show();
//
//        delta = delta/1000;
//
//        if (delta<1000) {
//            delta_str = String.format("%1.0f", delta);
//        }
//        else {
//            delta_str = "mark";
//        }
//
//        tictoc_last_ms = currentMilliSeconds;
//        broadcastTTS(delta_str);
//    }


    double last_cross_track_error_ft = 0;
    Boolean ct_warning_has_been_triggered = false;
    // ----------------------------------------------------------------------
    //  AudibleCrossTrackWarning
    // ----------------------------------------------------------------------
    public void AudibleCrossTrackWarning() {
        double crosstrack_ft = getCrossTrack();
        double gps_acc_ft = getAccuracy();

        ArrayList<String> lines = new ArrayList<>();

        // Create tone if cross track is too big
        if (isClearToSpeak() && (globals.settings.crosstrack_warning > gps_acc_ft || ct_warning_has_been_triggered))  //if accuracy is not good, then don't speak
        {
            if (abs(crosstrack_ft) > globals.settings.crosstrack_warning)  //are we outside of the warning track?
            {
                if (crosstrack_ft > 0.0) //right of channel
                {
                    if (crosstrack_ft > (last_cross_track_error_ft + 1))
                    {
                        lines.add(String.format("left %1.0f", crosstrack_ft));
                    }
                }
                else
                {
                    if (crosstrack_ft < (last_cross_track_error_ft -1)) {
                        lines.add(String.format("right %1.0f", abs(crosstrack_ft)));
                    }
                }
                if (lines.size() > 0) {
                    broadcastTTS(lines);
                    setAudioCounter((int) (0.2 * globals.settings.triggersPerMinute));
                    ct_warning_has_been_triggered = true;
                }
                last_cross_track_error_ft = crosstrack_ft;
            }
            else
            {
                if (ct_warning_has_been_triggered)
                {
                    double bearing_err_deg = calcBearingError();

                    lines.add("in channel");
                    if (crosstrack_ft > 0.0) //right of channel
                    {
                        lines.add(String.format("left %1.0f", crosstrack_ft));
                    }
                    else
                    {
                        lines.add(String.format("right %1.0f", abs(crosstrack_ft)));
                    }
                    if (bearing_err_deg > 0.0) //bearing error
                    {
                        lines.add(String.format("counter clock wise %1.0f degrees", bearing_err_deg));
                    }
                    else
                    {
                        lines.add(String.format("clock wise %1.0f degrees", abs(bearing_err_deg)));
                    }

                    broadcastTTS(lines);
                    setAudioCounter((int) (0.2 * globals.settings.triggersPerMinute));
                    ct_warning_has_been_triggered = false;
                    last_cross_track_error_ft = 0.0;
                }
            }
        }
    }

    // ----------------------------------------------------------------------
    //  calcTotalMiles
    // ----------------------------------------------------------------------
    private double calcTotalMiles(double curr_pos_latitude_rad, double curr_pos_longitude_rad) {
        double dist_ft = 0.0;
        if (getElapsedTimeSec(false) >= 0) //only integrate miles if the race has begun
        {
            if (globals.settings.tot_mile_last_lat_rad != 0.0 && globals.settings.tot_mile_last_lon_rad != 0.0) {
                if (curr_pos_latitude_rad != 0.0 && curr_pos_longitude_rad != 0) {
                    dist_ft = WayPointNav.DistBetweenWaypoints(globals.settings.tot_mile_last_lat_rad, globals.settings.tot_mile_last_lon_rad, curr_pos_latitude_rad, curr_pos_longitude_rad);
                    globals.settings.tot_mile += (dist_ft * Const.ft_to_mile);
                }
            }
            //save curr lat lon as last lat lon
            globals.settings.tot_mile_last_lat_rad = curr_pos_latitude_rad;
            globals.settings.tot_mile_last_lon_rad = curr_pos_longitude_rad;
        }
        return (dist_ft);
    }

    private double last_time_sec;
    private double last_dist_speed_mph;

    // ----------------------------------------------------------------------
    //  reset_speed_update_count
    // ----------------------------------------------------------------------
    public void reset_speed_update_count(int count) {
        speed_update_count = count;
    }

    // ----------------------------------------------------------------------
    //  calcTotalMiles
    // ----------------------------------------------------------------------
    private double calcLocationBasedSpeed(double dist_ft, double speed_mph, long time_ms) {
        double ret_speed_mph;
        double speed_fps;

        double curr_time_sec = time_ms / 1000.0;
        double delta_sec = curr_time_sec - last_time_sec;
        last_time_sec = curr_time_sec;

        if (speed_update_count > 0) speed_update_count--;

        if (speed_update_count <= 0 && ActivityMain.isGoodGpsWatchdog(globals.appState.enableSimulation, true)) {
            speed_update_count = 0;
            if (dist_ft > 0.0 && delta_sec > 0 && accuracy_ft < min_accuracy_ft) {
                speed_fps = dist_ft / delta_sec;
                ret_speed_mph = speed_fps * Const.fps_to_mph;
                ret_speed_mph = speed_filter.step(ret_speed_mph, false, time_ms);
            } else //no update from GPS location, use last speed
            {
                ret_speed_mph = speed_filter.step(last_dist_speed_mph, false, time_ms);
            }
        } else //default to gps speed if not moving or bad accuracy
        {
            ret_speed_mph = speed_filter.step(speed_mph, true, time_ms);  //initial the filter to the GPS speed
        }

        last_dist_speed_mph = ret_speed_mph;

        return (ret_speed_mph);
    }


    // ----------------------------------------------------------------------
    //  getTotalMiles
    // ----------------------------------------------------------------------
    public float getTotalMiles() {
        return (globals.settings.tot_mile);
    }

    // ----------------------------------------------------------------------
    //  calcMaxSpeed
    // ----------------------------------------------------------------------
    private double calcMaxSpeed(double speed_mph) {
        if (speed_mph > max_speed_mph) {
            max_speed_mph = speed_mph;
        }
        return (max_speed_mph);
    }


    // ----------------------------------------------------------------------
    // calcPlanSpeed
    // ----------------------------------------------------------------------
    private float calcPlanSpeed()
    {
        float retValue = (float) 0.0;

        double delta_mile = getCheckPointDeltaMile(globals.settings.finishCheckpointIndex);

        //find rest time to the selected index
        double restTimeHr = getDeltaPlannedRestHour(globals.settings.finishCheckpointIndex, false);

        double desiredFinishHr = globals.settings.desired_finish_hr;

        double elapsedTime_hr = getElapsedTimeSec(true) * Const.sec_to_hour;

        double time = desiredFinishHr - elapsedTime_hr - restTimeHr;

        if ((abs(time) - 0.00001) > 0) {
            retValue = (float) (delta_mile / time);
        }
        return retValue;
    }

    // ----------------------------------------------------------------------
    // getWpDirection
    // ----------------------------------------------------------------------
    public double getWpDirection() {
        if (globals.settings.startCheckpointIndex > globals.settings.finishCheckpointIndex) {
            return (-1);
        } else {
            return (1);
        }
    }

    // ----------------------------------------------------------------------
    // getSpeed
    // ----------------------------------------------------------------------
    public double getSpeed()
    {
        return speed_mph;
    }

    // ----------------------------------------------------------------------
    // getGpsSpeed
    // ----------------------------------------------------------------------
    private double getGpsSpeed() {
        return gps_speed_mph;
    }

    // ----------------------------------------------------------------------
    // getMaxSpeed
    // ----------------------------------------------------------------------
    public double getMaxSpeed() {
        return max_speed_mph;

    }

    // ----------------------------------------------------------------------
    // getLongitude
    // ----------------------------------------------------------------------
    public double getLongitude() {
        return currentPosition.pt.longitude_rad;
    }

    // ----------------------------------------------------------------------
    // getLatitude
    // ----------------------------------------------------------------------
    public double getLatitude() {
        return currentPosition.pt.latitude_rad;
    }

    // ----------------------------------------------------------------------
    // getBearing
    // ----------------------------------------------------------------------
    public double getBearing() {
        return bearing_deg;
    }

    // ----------------------------------------------------------------------
    // getBearing
    // ----------------------------------------------------------------------
    public double getBearingError() {
        return bearing_error_deg;
    }

    // ----------------------------------------------------------------------
    // calcBearingError
    // ----------------------------------------------------------------------
    private double calcBearingError() {
        double bearing_deg = getBearing();
        double wpbearing_deg = getWaypointBearing();

        double min_speed_mph = 0.5;
        if (getSpeed() > min_speed_mph) {
            bearing_error_deg = bearing_deg - wpbearing_deg;
            //limit to +/- 180
            if (bearing_error_deg > 180) bearing_error_deg -= 360.0;
            else if (bearing_error_deg < -180) bearing_error_deg += 360.0;
        }
        return bearing_error_deg;
    }


    // ----------------------------------------------------------------------
    // calcWaypointBearing
    // ----------------------------------------------------------------------
    private double calcWaypointBearing() {
        int curr_wp = getCurrentWaypoint();
        int prev_wp = getPrevWP(curr_wp);

        double lat_rad = getWaypointLatitude(curr_wp);
        double lon_rad = getWaypointLongitude(curr_wp);
        double plat_rad = getWaypointLatitude(prev_wp);
        double plon_rad = getWaypointLongitude(prev_wp);

        //wp_bear_deg
        return WayPointNav.limit_angle_rad(WayPointNav.LatLonToBearing(plat_rad, plon_rad, lat_rad, lon_rad)) * Const.rtd;
    }

    // ----------------------------------------------------------------------
    // getWaypointBearing
    // ----------------------------------------------------------------------
    public double getWaypointBearing() {
        return (wp_bearing_deg);
    }

    // ----------------------------------------------------------------------
    // getElapsedTime - return number of seconds since start time
    // ----------------------------------------------------------------------
    public double getElapsedTimeSec(boolean positive_only) {
        if (positive_only) {
            return Math.max(elapsed_time_s, 0);
        } else {
            return elapsed_time_s;
        }
    }

    // ----------------------------------------------------------------------
    // getElapsedTime - return number of seconds since start time
    // ----------------------------------------------------------------------
    public double calcElapsedTimeSec() {
        Date now = new Date();
        Date start_time = globals.settings.startDate;
        long diff_ms = now.getTime() - start_time.getTime();
        double diff_s = diff_ms / 1000.0;
        elapsed_time_s = diff_s;

        return diff_s;
    }


    // ----------------------------------------------------------------------
    // getAvgSpeed
    // ----------------------------------------------------------------------
    public double getAvgSpeed() {
        return avg_speed_mph;
    }

    // ----------------------------------------------------------------------
    // getCurrentValue
    // ----------------------------------------------------------------------
    public double getCurrentValue() {
        return currentPosition.value_m;
    }

    // ----------------------------------------------------------------------
    // getCurrentRiverMile
    // ----------------------------------------------------------------------
    public double getCurrentRiverMile() {
        return (globals.route.GetRiverMile(currentPosition.value_m));
    }

    // ----------------------------------------------------------------------
    // setCurrentValue
    // ----------------------------------------------------------------------
    private void setCurrentValue(double value_m) {
        currentPosition.value_m = value_m;

        //set start value if this has been reset
        if (globals.settings.startValue < 0)
        {
            globals.settings.startValue = (float) value_m;
        }
    }


    // ----------------------------------------------------------------------
    // getPlanSpeed
    // ----------------------------------------------------------------------
    public double getPlanSpeed() {
        return plan_speed_mph;
    }

    // ----------------------------------------------------------------------
    // getPlanSpeedStr
    // ----------------------------------------------------------------------
    public String getPlanSpeedStr() {
        String str;

        double ps = getPlanSpeed();
        if (ps <= 0) {
            str = "err";
        } else {
            str = String.format("%1.1f", getPlanSpeed());

        }
        return str;
    }

    // ----------------------------------------------------------------------
    // getCrossTrack
    // ----------------------------------------------------------------------
    public double getCrossTrack() {
        return cross_track_err_ft;
    }

    // ----------------------------------------------------------------------
    // getDistanceToWaypoint
    // ----------------------------------------------------------------------
    public double getDistanceToWaypoint() {
        return dist_to_wp_ft;
    }

    // ----------------------------------------------------------------------
    // getCurrentWaypoint
    // ----------------------------------------------------------------------
    public int getCurrentWaypoint() {
        return curr_wp_index;
    }

    // ----------------------------------------------------------------------
    // getWaypointLatitude
    // ----------------------------------------------------------------------
    public double getWaypointLatitude(int wp_index) {
        double ret = 0.0;
        if (isValidWPIndex(wp_index)) {
            ret = globals.route.wps[wp_index].pt.latitude_rad;
        }
        return (ret);
    }

    // ----------------------------------------------------------------------
    // getWaypointCount
    // ----------------------------------------------------------------------
    public int getWaypointCount() {
        return globals.route.wps.length;
    }

    // ----------------------------------------------------------------------
    // getWaypointLongitude
    // ----------------------------------------------------------------------
    public double getWaypointLongitude(int wp_index) {
        double ret = 0.0;

        if (isValidWPIndex(wp_index)) {
            ret = globals.route.wps[wp_index].pt.longitude_rad;
        }
        return (ret);

    }

    // ----------------------------------------------------------------------
    //	getEfficiency
    //	ratio of the planned track progress to actual
    // ----------------------------------------------------------------------
    public double getEfficiency() {
        double ret = 0.0;

        double avgtrack = getAvgTrackSpeed();
        double avgspeed = getAvgSpeed();

        if (avgspeed > 0) {
            ret = avgtrack / avgspeed;
        }
        return ret;
    }


    // ----------------------------------------------------------------------
    //  BinarySearchIterative
    //	return the best index that has a value less than or equal to value
    // ----------------------------------------------------------------------
    public int BinarySearchWaypoints(double value)
    {

        int minIdx = 0;
        int maxIdx = globals.route.wps.length - 1;
        if (maxIdx <= 0 ) return (minIdx);

        int midIdx;
        int dir = globals.route.wps[maxIdx].value_m > globals.route.wps[minIdx].value_m ? 1 : -1;
        if (dir > 0)
        {
            while (minIdx < maxIdx)
            {
                midIdx = (minIdx + maxIdx) / 2;
                if (value == globals.route.wps[midIdx].value_m)
                {
                    return midIdx;
                }
                else if (value < globals.route.wps[midIdx].value_m)
                {
                    maxIdx = midIdx - 1;
                }
                else
                {
                    minIdx = midIdx + 1;
                }
            }
            //adjust min to always be the nearest to the value
            minIdx = value < globals.route.wps[minIdx].value_m ? max(minIdx - 1, 0) : minIdx;

        }
        else
        {
            while (minIdx < maxIdx)
            {
                midIdx = (minIdx + maxIdx) / 2;
                if (value == globals.route.wps[midIdx].value_m)
                {
                    return midIdx;
                }
                else if (value > globals.route.wps[midIdx].value_m)
                {
                    maxIdx = midIdx - 1;
                }
                else
                {
                    minIdx = midIdx + 1;
                }
            }
            //adjust min to always be the nearest to the value
            minIdx = value > globals.route.wps[minIdx].value_m ? max(minIdx - 1, 0) : minIdx;

        }
        return (minIdx);
    }

    private static class Bound
    {
        final int bnd0;
        final int bnd1;

        public Bound(int b0, int b1)
        {
            bnd0 = b0;
            bnd1 = b1;
        }
        public Bound(Bound ibnd)
        {
            bnd0 = ibnd.bnd0;
            bnd1 = ibnd.bnd1;
        }
    }

    private Bound selectBounds(LatLngRad pt, Bound initBound, boolean[] boundingSelection)
    {
        Bound bnd = new Bound(initBound);

        if (boundingSelection[0] || boundingSelection[1]) {
            boolean continueBinarySearch = true;
            int delta = initBound.bnd1 - initBound.bnd0;

            //reduce the bnd from the whole dataset to minimal
            ArrayList<Bound> bounds;  //= new ArrayList<Bounds>();
            do {
                bounds = new ArrayList<>();

                ArrayList<Integer> idxs = new ArrayList<>();
                for (int idx = bnd.bnd0; idx <= bnd.bnd1; idx = Math.min(idx + delta, bnd.bnd1)) {
                    idxs.add(idx);
                    if (idx == bnd.bnd1) break;
                }

                for (int idx = 1; idx < idxs.size(); idx++) {
                    Bound indexBound = new Bound(idxs.get(idx - 1), idxs.get(idx));
                    if (isPointBounded(pt, indexBound, boundingSelection)) {
                        bounds.add(indexBound);
                    }
                }

                if (bounds.size() == 1) {
                    bnd = bounds.get(0);
                } else {
                    break;
                }
                delta = (int) Math.round(delta * 0.5);

            } while (delta > 1);
        }
        return (bnd);
    }
    // ----------------------------------------------------------------------
    //  getIndex
    //	Given Lat/lon then find the wp series value
    // ----------------------------------------------------------------------
    public int getIndex(LatLngRad pt)
    {
        int wp_idx = 0;

        int startIdx = 0;
        int finishIdx = globals.route.wps.length - startIdx - 1;
        boolean isLatPrime = abs(globals.route.wps[finishIdx].pt.latitude_rad - globals.route.wps[startIdx].pt.latitude_rad) > abs(globals.route.wps[finishIdx].pt.longitude_rad - globals.route.wps[startIdx].pt.longitude_rad);
        boolean[] boundingSelection = new boolean[]{isLatPrime, !isLatPrime};   //{sort lat, sort lon)

        Bound pass1 = selectBounds(pt, new Bound(startIdx, finishIdx), boundingSelection);
        boundingSelection[0] = !boundingSelection[0];
        boundingSelection[1] = !boundingSelection[1];
        Bound pass2 = selectBounds(pt, pass1, boundingSelection);

        // now search the remaining data and find the min distance
        double min_dist = -999;
        for (int jnx = pass2.bnd0; jnx <= pass2.bnd1; jnx++) {
            double min_dist_test = abs(WayPointNav.DistBetweenWaypoints(globals.route.wps[jnx].pt.latitude_rad, globals.route.wps[jnx].pt.longitude_rad, pt.latitude_rad, pt.longitude_rad));
            if (min_dist_test < min_dist || min_dist < 0) {
                wp_idx = jnx + 1;
                min_dist = min_dist_test;
            }
       }

        return (wp_idx);
    }

    private boolean isPointBounded(LatLngRad pt, Bound bound, boolean[] boundingSelection)
    {
        // note assumption that bound index has been verified
        double minLat;
        double maxLat;
        double minLon;
        double maxLon;
        boolean passLat = true;
        boolean passLon = true;

        if (boundingSelection[0]) {
            if (globals.route.wps[bound.bnd0].pt.latitude_rad < globals.route.wps[bound.bnd1].pt.latitude_rad) {
                minLat = globals.route.wps[bound.bnd0].pt.latitude_rad;// - Const.maxCrossTrack_rad;
                maxLat = globals.route.wps[bound.bnd1].pt.latitude_rad;// + Const.maxCrossTrack_rad;
            } else {
                minLat = globals.route.wps[bound.bnd1].pt.latitude_rad;// - Const.maxCrossTrack_rad;
                maxLat = globals.route.wps[bound.bnd0].pt.latitude_rad;// + Const.maxCrossTrack_rad;
            }
            passLat = pt.latitude_rad > minLat && pt.latitude_rad < maxLat;
        }

        if (boundingSelection[1]) {
            if (globals.route.wps[bound.bnd0].pt.longitude_rad < globals.route.wps[bound.bnd1].pt.longitude_rad) {
                minLon = globals.route.wps[bound.bnd0].pt.longitude_rad;// - Const.maxCrossTrack_rad;
                maxLon = globals.route.wps[bound.bnd1].pt.longitude_rad;// + Const.maxCrossTrack_rad;
            } else {
                minLon = globals.route.wps[bound.bnd1].pt.longitude_rad;// - Const.maxCrossTrack_rad;
                maxLon = globals.route.wps[bound.bnd0].pt.longitude_rad;// + Const.maxCrossTrack_rad;
            }
            passLon = pt.longitude_rad > minLon && pt.longitude_rad < maxLon;
        }
        return (passLat && passLon);
    }

    // ----------------------------------------------------------------------
    //  initCurrentWaypoint
    //	Given Lat/lon then calculate the best starting waypoint
    // ----------------------------------------------------------------------
    private int initCurrentWaypoint(double lat_rad, double lon_rad) {
        int wp_idx = 0;
        if (globals.route.wps != null)
        {
            wp_idx = getIndex(new LatLngRad(lat_rad,lon_rad));
        }
        return wp_idx;
    }

    // ----------------------------------------------------------------------
    //  estimateLocationFromValue
    //	Given river mile, return wp index
    // ----------------------------------------------------------------------
    public LookupInfo estimateLocationFromValue(double value_m) {
        LookupInfo ret = new LookupInfo();
        if (globals.route.wps.length > 0)
        {
            InterpolateResult ires = Interpolate.InterpolateIndex2D(value_m, globals.route.ivs);
            final double alpha = ires.alpha;
            ret.iLower = ires.iLower;
            ret.iUpper = ires.iUpper;
            ret.pt.latitude_rad = (1.0 - alpha) * globals.route.wps[ires.iLower].pt.latitude_rad + alpha * globals.route.wps[ires.iUpper].pt.latitude_rad;
            ret.pt.longitude_rad = (1.0 - alpha) * globals.route.wps[ires.iLower].pt.longitude_rad + alpha * globals.route.wps[ires.iUpper].pt.longitude_rad;
            ret.valid = true;
        }
        return ret;
    }


    //---------------------------------------------------------------------------
    // toLatLngRad - for checkpoints
    //---------------------------------------------------------------------------
    public LatLngRad[] toLatLngRad(CheckPoint[] lcps)
    {
        LatLngRad[] ret = new LatLngRad[lcps.length];
        for(int inx = 0; inx<lcps.length; inx++)
        {
            ret[inx] = new LatLngRad(lcps[inx].pt.latitude_rad, lcps[inx].pt.longitude_rad );
        }
        return(ret);
    }

    // ----------------------------------------------------------------------
    // isValidWPIndex
    // ----------------------------------------------------------------------
    private boolean isValidWPIndex(int idx) {
        boolean ret = false;
        if (globals.route.wps != null) {
            if (idx >= 0 && idx < globals.route.wps.length) {
                ret = true;
            }
        }
        return ret;
    }

    // ----------------------------------------------------------------------
    // isValidCPIndex
    // ----------------------------------------------------------------------
    public boolean isValidCPIndex(int idx) {
        boolean ret = false;

        if (globals.route.cps != null) {
            if (idx >= 0 && idx < globals.route.cps.length) {
                ret = true;
            }
        }
        return ret;
    }

    // ----------------------------------------------------------------------
    // isNotValidStartStopCPIndex
    // ----------------------------------------------------------------------
    private boolean isNotValidStartStopCPIndex(int sidx, int eidx) {
        double wpdir;

        //double wpdir = getWpDirection();
        if (globals.settings.waypoint_reverse) {
            wpdir = -1;
        } else {
            wpdir = 1;
        }

        boolean ret = true;
        if (!isValidCPIndex(sidx)
                || !isValidCPIndex(eidx)
                || eidx == sidx
                || (sidx >= globals.route.cps.length - 1 && wpdir > 0)
                || (sidx <= 0 && wpdir < 0)
                || (eidx > sidx && wpdir < 0)
                || (eidx < sidx && wpdir > 0)
                ) {
            ret = false;
        }
        return !ret;

    }

    // ----------------------------------------------------------------------
    //  setWaypoint
    //	set wp index
    // ----------------------------------------------------------------------
    public void setWaypoint(int curr_wp) {
        if (isValidWPIndex(curr_wp)) {
            curr_wp_index = curr_wp;
        }
    }

    // ----------------------------------------------------------------------
    // getNextWP
    // ----------------------------------------------------------------------
    public int getNextWP(int currwp) {
        int ret = currwp;
        int wpdir = (int) getWpDirection();

        int nxt = currwp + wpdir;
        if (isValidWPIndex(nxt)) ret = nxt;
        return ret;
    }

    // ----------------------------------------------------------------------
    // getPrevWP
    // ----------------------------------------------------------------------
    public int getPrevWP(int currwp) {
        int wpdir = (int) getWpDirection();
        int ret = currwp;
        int nxt = (currwp - wpdir);
        if (isValidWPIndex(nxt)) ret = nxt;
        return ret;
    }

    // ----------------------------------------------------------------------
    // getNextCheckPointIndex
    //	any_access_point - false, only returns checkpoints (exclude access points only)
    // ----------------------------------------------------------------------
    public int getNextCheckPointIndex(double tolerance_mile, boolean any_access_point) {
        int inx = -1;

        // if checkpoints are defined
        if (globals.route.cps != null && s0 != null) {

            inx = (int) Math.ceil(s0.routeRelative.cpIndex);
            //bound check
            if (!(inx >= 0 && inx < globals.route.cps.length)) {
                inx = -1;
            }
        }
        return inx;
    }

    // ----------------------------------------------------------------------
    // getCheckpointItem
    // item = 0 -> name
    // item = 1 -> eta
    // item = 2 -> dist
    // ----------------------------------------------------------------------
    public String getCheckpointItem(int idx, int item) {
        String ret = "";
        if (globals.route.cps != null && idx < globals.route.cps.length && idx >= 0) {
            switch (item) {
                case 1:
                    double eta_s = getEstimatedCheckPointTimeHour(idx, false, false, true) * Const.hour_to_sec;
                    if (eta_s > 0) {
                        ret = convertSecToHourStr(eta_s, false);
                    }
                    break;
                case 2:
                    double delta_mile = getCheckPointDeltaMile(idx);
                    ret = String.format("%1.1f", delta_mile);
                    break;
                default:
                    ret = String.format("%s", globals.route.cps[idx].Name);
            }
        }
        return ret;
    }

    // ----------------------------------------------------------------------
    // getSelectedCheckpointIndex
    // ----------------------------------------------------------------------
    public int getSelectedCheckpointIndex() {
        return (selected_cp_index);
    }

    // ----------------------------------------------------------------------
    // getClosestCheckpointIndex
    // ----------------------------------------------------------------------
    public void setNearestCheckpointIndex(int delay_ms) {
        mRunner.postDelayed(runSetNearestCheckpoint, delay_ms);
    }
    //---------------------------------------------------------------------------
    // runSetNearestCheckpoint
    //---------------------------------------------------------------------------
    public final Runnable runSetNearestCheckpoint = new Runnable()
    {
        @Override
        public void run()
        {
            setNearestCheckpointIndex();
        }
    };

    // ----------------------------------------------------------------------
    // getClosestCheckpointIndex
    // ----------------------------------------------------------------------
    public void setNearestCheckpointIndex() {
        boolean success = false;
        int close_cp_idx = 0;

        if (isValidLatLngRad(currentPosition.pt)) {
            close_cp_idx = getNextCheckPointIndex(0.0, false);
            success = setSelectedCheckpointIndex(close_cp_idx);
        }
        if (success) {
            String msg = String.format("Set selected checkpoint = %s", globals.route.cps[close_cp_idx].Name);
            Toast.makeText(globals.appState.ctx, msg, Toast.LENGTH_LONG).show();
        }

    }


    // ----------------------------------------------------------------------
    // setSelectedCheckpointIndex
    // ----------------------------------------------------------------------
    private boolean setSelectedCheckpointIndex(int cp_index) {
        boolean success = false;

        //check selected cp visibility
        if (isCheckpointVisible(cp_index)) {
            selected_cp_index = cp_index;
            success = true;
        }
        return (success);
    }

    // ----------------------------------------------------------------------
    // getTotalTrackMiles
    // ----------------------------------------------------------------------
    public float getTotalTrackMiles() {
        float ret = (float) 0.0;

        if (isValidCPIndex(globals.settings.finishCheckpointIndex) && isValidCPIndex(globals.settings.startCheckpointIndex)) {
            ret = (float) ( abs(globals.route.cps[globals.settings.finishCheckpointIndex].value_m - globals.route.cps[globals.settings.startCheckpointIndex].value_m ) * Const.m_to_mile) ;
        }

        return (ret);
    }

    // ----------------------------------------------------------------------
    // getCurrentTrackMiles
    // ----------------------------------------------------------------------
    public float getCurrentTrackMiles() {
        float ret = (float) 0.0;

        if (isValidCPIndex(globals.settings.startCheckpointIndex)) {
            ret = (float) (abs(currentPosition.value_m - globals.route.cps[globals.settings.startCheckpointIndex].value_m) * Const.m_to_mile);
        }

        return (ret);
    }

    // ----------------------------------------------------------------------
    // getFinalCheckpoint
    // ----------------------------------------------------------------------
    public int getFinalCheckpoint() {
        return globals.settings.finishCheckpointIndex;  //final_cp_index;
    }

    // ----------------------------------------------------------------------
    //	getElapsedTimeHourStr
    // ----------------------------------------------------------------------
    public String getElapsedTimeHourStr() {
        return (convertSecToHourStr(getElapsedTimeSec(false), false));
    }


    // ----------------------------------------------------------------------
    // getEstimatedFinish_sec - return estimated finish time in seconds
    // ----------------------------------------------------------------------
    public double getEstimatedFinish_sec() {
        double elapsed_sec = getElapsedTimeSec(true);
        double finish_eta_sec = getEstimatedCheckPointTimeHour(globals.settings.finishCheckpointIndex, false, false, true) * Const.hour_to_sec;
        double total_time_sec;
        if (finish_eta_sec >= 0) {
            total_time_sec = elapsed_sec + finish_eta_sec;
        }
        else {
            total_time_sec = finish_eta_sec;

        }
        return (total_time_sec);
    }



    // ----------------------------------------------------------------------
    // getEstimatedFinishHourStr
    // ----------------------------------------------------------------------
    public String getEstimatedFinishHourStr() {
        double total_time_sec = getEstimatedFinish_sec();
        return (convertSecToHourStr(total_time_sec, true));
    }

    // ----------------------------------------------------------------------
    // getEstimatedCheckPointTimeHourStr
    // ----------------------------------------------------------------------
    private String getEstimatedCheckPointTimeHourStr(int checkpointIndex) {
        return (convertSecToHourStr(getEstimatedCheckPointTimeHour(checkpointIndex, false, false, true) * Const.hour_to_sec, false));
    }

    // ----------------------------------------------------------------------
    // getCheckpointValue
    // ----------------------------------------------------------------------
    public double getCheckpointValue(int idx) {
        double ret = 0.0;
        if (isValidCPIndex(idx)) {
            ret = globals.route.cps[idx].value_m;
        }
        return (ret);
    }

    // ----------------------------------------------------------------------
    // convertSecToHourMin
    // ----------------------------------------------------------------------
    private double[] convertSecToHourMin(double sec)
    {
        double[] ret = {0,0,1};
        double sgn = sign(sec);
        double hours = sec * sgn * Const.sec_to_hour;
        double hours_int = floor(hours);
        double minutes = (hours - hours_int) * 60.0;
        ret[0] = hours_int;
        ret[1] = minutes;
        ret[2] = sgn;
        return ret;
    }

    // ----------------------------------------------------------------------
    // convertSecToHourStr
    // ----------------------------------------------------------------------
    public String convertSecToHourStr(double sec, boolean dnf_for_negative) {
        String ret;
        double sgn = sign(sec);
        double hours = sec * sgn * Const.sec_to_hour;
        double hours_int = floor(hours);
        double minutes = (hours - hours_int) * 60.0;
        ret = String.format("%02.0f:%02.0f", hours_int, minutes);
        if (sgn < 0) ret = "-" + ret;
        if (dnf_for_negative && sgn < 0) ret = "DNF";
        return ret;
    }

    // ----------------------------------------------------------------------
    // convertHourToHourStr
    // ----------------------------------------------------------------------
    public String convertHourToHourStr(double hour, boolean dnf_for_negative) {
        String ret;
        double sgn = sign(hour);
        double sec = hour / Const.sec_to_hour;
        double hours = sec * sgn * Const.sec_to_hour;
        double hours_int = floor(hours);
        double minutes = (hours - hours_int) * 60.0;
        ret = String.format("%02.0f:%02.0f", hours_int, minutes);
        if (sgn < 0) ret = "-" + ret;
        if (dnf_for_negative && sgn < 0) ret = "DNF";
        return ret;
    }

    // ----------------------------------------------------------------------
    // sign
    // ----------------------------------------------------------------------
    private double sign(double val) {
        if (val > 0) return 1.0;
        else return -1.0;
    }

    //---------------------------------------------------------------------------
    // ClearActualCheckpointArrivalTimes
    //---------------------------------------------------------------------------
    public void ClearActualCheckpointArrivalTimes() {
        if (globals.checkPointTimes != null) {
            for (CheckPointTime cp : globals.checkPointTimes) {
                cp.actual_in_hr = -999;
                cp.actual_out_hr = -999;
                cp.text_out = false;
            }
        }
    }

    //---------------------------------------------------------------------------
    // ResetStatistics
    //---------------------------------------------------------------------------
    public void ResetStatistics() {
        max_speed_mph = getSpeed();
        history.Reset();
    }

    //---------------------------------------------------------------------------
    // isTextCheckPoint
    //---------------------------------------------------------------------------
    public boolean isTextCheckPoint(int cp_idx) {
        boolean ret = false;
        if (isCheckPoint(cp_idx)) {
            if (!IsExclusionCP(cp_idx)) {
                ret = true;
            }
        }
        return ret;
    }

    //---------------------------------------------------------------------------
    // isCheckPoint
    //---------------------------------------------------------------------------
    private boolean isCheckPoint(int cp_idx) {
        boolean ret = false;
        if (isValidCPIndex(cp_idx)) {
            ret = globals.route.cps[cp_idx].isCheckpoint;
        }
        return ret;
    }


    public boolean validateStartStop() {
        boolean ret = true;

        //default
        if (globals.route.cps.length > 0) {
            if (globals.settings.startCheckpointIndex < 0) globals.settings.startCheckpointIndex = 0;
            if (globals.settings.finishCheckpointIndex < 0) globals.settings.finishCheckpointIndex = globals.route.cps.length - 1;
        }

        if (isNotValidStartStopCPIndex(globals.settings.startCheckpointIndex, globals.settings.finishCheckpointIndex)) {
            //swap the start/stop
            int tmp = globals.settings.startCheckpointIndex;
            globals.settings.startCheckpointIndex = globals.settings.finishCheckpointIndex;
            globals.settings.finishCheckpointIndex = tmp;
            if (isNotValidStartStopCPIndex(globals.settings.startCheckpointIndex, globals.settings.finishCheckpointIndex)) {
                globals.setDefaultStartStop(globals.route.cps);
            }
            ret = false;
            String msg = String.format("Start checkpoint = %s\nEnd checkpoint = %s ",
                    globals.route.cps[globals.settings.startCheckpointIndex].Name,
                    globals.route.cps[globals.settings.finishCheckpointIndex].Name);
            Toast.makeText(globals.appState.ctx, msg, Toast.LENGTH_LONG).show();
        }
        return (ret);
    }


    //default = 2,6,7,9,1
    public final String[] display_options = {"none",
            "current speed",
            "average speed",
            "track speed",
            "average track speed",
            "max speed",
            "distance to selected cp",
            "time to selected cp",
            "distance to finish",
            "estimated finish time",
            "total mile",
            "elapsed time",
            "river mile",
            "cross track error",
            "gps speed",
            "plan speed",
            "current time",
            "average overall speed",
            "average route speed",
            "battery"};



    //---------------------------------------------------------------------------
    // getAudioStatus
    // note: must match
    // display_options
    public String getAudioStatus(int selected_item) {
        String retStr = "";
        String stringFormat;
        switch (selected_item) {
            case 1:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"speed %1.1f";
                retStr = String.format(stringFormat, getSpeed());
                break;
            case 2:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"average speed %1.1f";
                retStr = String.format(stringFormat, getAvgSpeed());
                break;
            case 3:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"track speed %1.1f";
                retStr = String.format(stringFormat, getTrackSpeed());
                break;
            case 4:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"average track speed %1.1f";
                retStr = String.format(stringFormat, getAvgTrackSpeed());
                break;
            case 5:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"maximum speed %1.1f";
                retStr = String.format(stringFormat, getMaxSpeed());
                break;
            case 6:
                if (globals.settings.enableAudibleStatusNoWords)
                {
                    retStr = String.format("%s",  getCheckpointItem(getSelectedCheckpointIndex(),2));
                }
                else {
                    retStr = String.format("%s in %s miles", getCheckpointItem(getSelectedCheckpointIndex(), 0), getCheckpointItem(getSelectedCheckpointIndex(), 2));
                }
                break;
            case 7:
                // getCheckpointItem
                // item = 0 -> name
                // item = 1 -> eta
                // item = 2 -> dist
                double secs_to_checkpoint = getEstimatedCheckPointTimeHour(getSelectedCheckpointIndex(), false, false, false) * Const.hour_to_sec;
                if (globals.settings.enableAudibleStatusNoWords)
                {
                    retStr = String.format("%s",  formatSecToHourMinAudio(secs_to_checkpoint));
                }
                else {
                    retStr = String.format("%s in %s", getCheckpointItem(getSelectedCheckpointIndex(), 0), formatSecToHourMinAudio(secs_to_checkpoint));
                }
                break;
            case 8:
                if (globals.settings.enableAudibleStatusNoWords) {
                    retStr = String.format("%s", getDistanceToFinish());
                }
                else {
                    retStr = String.format("finish in %s miles", getDistanceToFinish());
                }
                break;
            case 9:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%s":"finish time %s";
                retStr = String.format(stringFormat, formatSecToHourMinAudio(getEstimatedFinish_sec()));
                break;
            case 10: //"total mile"
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"total miles %1.1f";
                retStr = String.format(stringFormat, getTotalMiles());
                break;
            case 11:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%s":"elapsed time %s";
                retStr = String.format(stringFormat, formatSecToHourMinAudio(getElapsedTimeSec(false)));
                break;
            case 12: //"River mile"
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"river mile %1.1f";
                retStr = String.format(stringFormat, getCurrentRiverMile());
                break;
            case 13:
                double ct = getCrossTrack();
                String msg = "";
                if (ct<0) msg = msg + " minus ";
                msg = msg + String.format("%1.0f", abs(getCrossTrack()));

                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%s":"cross track %s";
                retStr = String.format(stringFormat, msg);

                break;
            case 14:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"GPS speed %1.1f";
                retStr = String.format(stringFormat, getGpsSpeed());
                break;
            case 15:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"plan speed %1.1f";
                retStr = String.format(stringFormat, getPlanSpeed());
                break;
            case 16:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%s":"time %s";
                retStr = String.format(stringFormat, ClassUtility.getCurrentTime());
                break;
            case 17:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"average total speed %1.1f";
                retStr = String.format(stringFormat, getTotalMileAverageSpeed());
                break;
            case 18:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.1f":"average river speed %1.1f";
                retStr = String.format(stringFormat, getRouteDistanceAverageSpeed());
                break;
            case 19:
                stringFormat = globals.settings.enableAudibleStatusNoWords ?"%1.0f":"battery %1.0f";
                BatteryMonitor batteryMonitor = BatteryMonitor.getInstance();
                retStr = String.format(stringFormat, batteryMonitor.batteryPercent);
                break;
            default:
                break;
        }
        return retStr;
    }

    //---------------------------------------------------------------------------
    // getSelectedInfoItem
    // note: must match
    // display_options
    public String getSelectedInfoItem(int selected_item) {
        String retstr = "";
        switch (selected_item) {
            case 1:
                retstr = String.format("%1.1f", getSpeed());
                break;
            case 2:
                retstr = String.format("%1.1f", getAvgSpeed());
                break;
            case 3:
                retstr = String.format("%1.1f", getTrackSpeed());
                break;
            case 4:
                retstr = String.format("%1.1f", getAvgTrackSpeed());
                break;
            case 5:
                retstr = String.format("%1.1f", getMaxSpeed());
                break;
            case 6:
                retstr = String.format("%1.1f", getCheckPointDeltaMile(getSelectedCheckpointIndex()));
                break;
            case 7:
                retstr = String.format("%s", getCheckpointItem(getSelectedCheckpointIndex(), 1));
                break;
            case 8:
                retstr = getDistanceToFinish();
                break;
            case 9:
                retstr = String.format("%s", getEstimatedFinishHourStr());
                break;
            case 10: //"total mile"
                retstr = String.format("%1.1f", getTotalMiles());
                break;
            case 11:
                retstr = String.format("%s", getElapsedTimeHourStr());
                break;
            case 12: //"River mile"
                retstr = String.format("%1.1f", getCurrentRiverMile());
                break;
            case 13:
                retstr = String.format("%1.0f", getCrossTrack());
                break;
            case 14:
                retstr = String.format("%1.1f", getGpsSpeed());
                break;
            case 15:
                retstr = String.format("%1.1f", getPlanSpeed());
                break;
            case 16:
                retstr = String.format("%s", ClassUtility.getCurrentTime());
                break;
            case 17:
                retstr = String.format("%1.1f", getTotalMileAverageSpeed() );
                break;
            case 18:
                retstr = String.format("%1.1f", getRouteDistanceAverageSpeed() );
                break;
            case 19:
                BatteryMonitor batteryMonitor = BatteryMonitor.getInstance();
                retstr = String.format("%1.0f", batteryMonitor.batteryPercent);
                break;

            default:
                break;
        }
        return retstr;
    }

    private String getDistanceToFinish() {
        int idx = getFinalCheckpoint();
        return (getCheckpointItem(idx, 2));
    }

    //---------------------------------------------------------------------------
    // formatSecToHourMinAudio
    //---------------------------------------------------------------------------
    private String formatSecToHourMinAudio(double time_sec)
    {
        String retstr = "";

        double[] hr_min = convertSecToHourMin(time_sec);

        if (hr_min[0] > 0.0)
        {
            retstr = retstr + String.format("%1.0f ",hr_min[0]);
            if (hr_min[0] > 1.0)
            {
                retstr = retstr + "hours";
            }
            else
            {
                retstr = retstr + "hour";
            }
        }
        if (hr_min[1] > 0.0)
        {
            retstr = retstr + String.format("%1.0f ",hr_min[1]);
            if (hr_min[1] > 1.0)
            {
                retstr = retstr + "minutes";
            }
            else
            {
                retstr = retstr + "minute";
            }
        }
        if (hr_min[2] < 0)
        {
            retstr = "T minus " + retstr;
        }
        return (retstr);
    }


    // ----------------------------------------------------------------------
    //  isValidLatLngRad
    // ----------------------------------------------------------------------
    boolean isValidLatLngRad(LatLngRad pt)
    {
        boolean ret = false;
        if (pt!=null) {
            ret = pt.latitude_rad != 0.0 && pt.longitude_rad != 0.0;
        }
        return (ret);

    }

    // ----------------------------------------------------------------------
    //  calcPathSegmentProjections
    // ----------------------------------------------------------------------
    public double[] calcPathSegmentProjections(LatLngRad pt, LatLngRad[] pts)
    {
        double[] down_track = new double[pts.length];
        if (pts.length > 0) {
            int minct_idx = 0;
            double min_cros_track = -1.0;
            down_track[0] = 1.0;
            for (int inx = 1; inx < pts.length; inx++) {
                if (isValidLatLngRad(pt)) {
                    down_track[inx] = WayPointNav.calcDownTrackPerc(pts[inx - 1], pts[inx], pt);
                    down_track[inx] = Math.max(down_track[inx], 0.0);
                    down_track[inx] = Math.min(down_track[inx], 1.0);
                    if (down_track[inx] >= 0 && down_track[inx] < 1) {
                        double test_cros_track = Math.abs(CrossTrack(pts[inx - 1], pts[inx], pt));
                        // attempt to find the current segment for complex race tracks by selection of the minimum cross track
                        if (test_cros_track <= min_cros_track || min_cros_track < 0) {
                            down_track[minct_idx] = 1.0;  //declare previous segment traversed
                            minct_idx = inx;
                            min_cros_track = test_cros_track;
                        }
                    }
                } else {
                    down_track[inx] = 0.0;
                }
            }
        }

        return down_track;
    }

    // ----------------------------------------------------------------------
    //  updateCheckpoints
    // ----------------------------------------------------------------------
    public CheckPoint[] updateCheckpoints(CheckPoint[] incps)
    {
        return (updateDistFromPrevCP(incps));
    }

    private double total_route_ft;
    // ----------------------------------------------------------------------
    //  updateDistFromPrevCP
    // ----------------------------------------------------------------------
    private CheckPoint[] updateDistFromPrevCP(CheckPoint[] incps)
    {
        CheckPoint[] lcps = null;
        total_route_ft = 0;
        if (incps!=null) {

            lcps = incps.clone();

            if (lcps.length > 0) {
                lcps[0].prev_cp_dist_ft = 0;
            }
            for (int inx = 1; inx < lcps.length; inx++) {
                lcps[inx].prev_cp_dist_ft = WayPointNav.DistBetweenWaypoints(lcps[inx - 1].pt.latitude_rad, lcps[inx - 1].pt.longitude_rad, lcps[inx].pt.latitude_rad, lcps[inx].pt.longitude_rad);
                total_route_ft += lcps[inx].prev_cp_dist_ft;
            }
        }
        return (lcps);
    }



    //---------------------------------------------------------------------------
    // getValueDelta
    //---------------------------------------------------------------------------
    private float getValueDelta()
    {
        return (abs((float) getCurrentValue() - globals.settings.startValue));
    }

    // ----------------------------------------------------------------------
    // getRouteDistanceAverageSpeed()
    // ----------------------------------------------------------------------
    private double getRouteDistanceAverageSpeed()
    {
        double elapsedTime_sec = getElapsedTimeSec(true);
        double avgSpeed_mps = (elapsedTime_sec>0) ? getValueDelta()/elapsedTime_sec : 0;
        return (avgSpeed_mps * Const.mps_to_mph);
    }

    // ----------------------------------------------------------------------
    // getTotalMileAverageSpeed()
    // ----------------------------------------------------------------------
    private double getTotalMileAverageSpeed()
    {
        double total_avg_speed_mph;
        double elapsed_time_hour = getElapsedTimeSec(true) * Const.sec_to_hour;
        double total_miles = getTotalMiles();

        if (elapsed_time_hour>0)
        {
            total_avg_speed_mph =  total_miles/elapsed_time_hour;
        }
        else
        {
            total_avg_speed_mph = 0;
        }

        return (total_avg_speed_mph);
    }
    // ----------------------------------------------------------------------
    //  getPercentComplete
    // ----------------------------------------------------------------------
    float getPercentComplete(LatLngRad pt)
    {
        double pcomplete = 0;
        double ft_traveled= 0.0;
        if (total_route_ft <=0)
        {
            globals.route.cps = updateDistFromPrevCP(globals.route.cps);
        }

        // get closest checkpoint
        if (total_route_ft > 0) {
            double[] segments = calcPathSegmentProjections(pt, toLatLngRad(globals.route.cps));

            for (int inx = 1; inx < globals.route.cps.length; inx++)
            {
                if (segments[inx] < 1)
                {
                    ft_traveled += segments[inx]*globals.route.cps[inx].prev_cp_dist_ft;
                    break;
                }
                else
                {
                    ft_traveled += globals.route.cps[inx].prev_cp_dist_ft;

                }
            }
            pcomplete = ft_traveled/total_route_ft;
        }
        return ((float) pcomplete * 100);
    }
	
	public void setCurrectCheckpointIndex(int idx)
	{
		if (idx>=0 && idx< globals.route.cps.length)
		{
			globals.settings.checkpoint_selected = globals.route.cps[idx].Name;
		}
	}
	
		
    //---------------------------------------------------------------------------
	// getCheckpointIndexByName
	//---------------------------------------------------------------------------
	public int getCheckpointIndexByName(String checkpointName)
	{
		int idx = -1;
		for (int inx = 0; inx < globals.route.cps.length; inx++)
		{
			if (globals.route.cps[inx].Name.equals(checkpointName))
			{
				idx = inx;
				break;
			}
		}
		return idx;
	}

    // ----------------------------------------------------------------------
    // ----------------------------------------------------------------------
    public void setCheckpoints(CheckPoint[] lcps)
    {
        globals.route.cps = lcps;
    }


    // ----------------------------------------------------------------------
    // ----------------------------------------------------------------------
    public CheckPoint[] getCheckPoints()
    {
        return (globals.route.cps);
    }
}

