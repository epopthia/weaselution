package com.ProPaddlerMi.baseclass;
import com.ProPaddlerMi.utility.Const;
//import com.google.android.gms.maps.model.LatLng;

public class LatLngRad {
    public double latitude_rad;
    public double longitude_rad;

    public LatLngRad(double v, double v1) {
        latitude_rad = v;
        longitude_rad = v1;
    }
    public LatLngRad() {
        latitude_rad = 0;
        longitude_rad = 0;
    }
    public LatLngRad(LatLng pt) {
        this();
        if (pt!=null) {
            latitude_rad = pt.latitude * Const.dtr;
            longitude_rad = pt.longitude * Const.dtr;
        }
    }
    public LatLngRad(LatLngRad pt) {
        this();
        if (pt!=null) {
            latitude_rad = pt.latitude_rad;
            longitude_rad = pt.longitude_rad;
        }
    }

    // ----------------------------------------------------------------------
    //  isValidLatLngRad
    // ----------------------------------------------------------------------
    public static boolean isValidLatLngRad(LatLngRad pt)
    {
        boolean ret = false;
        if (pt!=null) {
            ret = pt.latitude_rad != 0.0 && pt.longitude_rad != 0.0;
        }
        return (ret);
    }

}

