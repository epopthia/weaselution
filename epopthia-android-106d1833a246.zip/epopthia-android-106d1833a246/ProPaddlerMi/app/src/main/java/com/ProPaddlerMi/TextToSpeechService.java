package com.ProPaddlerMi;// --------------------------------------------------

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.speech.tts.TextToSpeech;
import android.util.Log;

import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;
import java.util.Locale;

public class TextToSpeechService extends Service
{
    private TextToSpeech mTts;
    private boolean isLoaded;
    private static BroadcastReceiver mTTSReceiver;

    @Override
    public IBinder onBind(Intent arg0) {

        return null;
    }

    // ---------------------------------------------------------------------------------------------
    //  onCreate
    // ---------------------------------------------------------------------------------------------
    @Override
    public void onCreate() {
        isLoaded = false;
        mTts = null;
        super.onCreate();

//        int NOTIFICATION_ID = 9954;
//        int NOTIFICATION_ID = (int) (System.currentTimeMillis()%10000);
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            startForeground(NOTIFICATION_ID, getNotification());
//        }

        int NOTIFICATION_ID = 9955;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, getNotification());
        }

    }

    // ---------------------------------------------------------------------------------------------
    // notification must be setup for api > 26 for background use
    // ---------------------------------------------------------------------------------------------
    private Notification getNotification() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String chid = String.format("%s%d", Const.appPackage, 2);
            NotificationChannel channel = new NotificationChannel(chid,"ProPaddler Foreground Service", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            Notification.Builder builder = new Notification.Builder(getApplicationContext(),chid);
            return builder.build();
        }
        return null;
    }


    // ---------------------------------------------------------------------------------------------
    //  onStartCommand
    // ---------------------------------------------------------------------------------------------
    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {

        try
        {
            TextToSpeech.OnInitListener onInitListener = new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int status) {
                    if (status == TextToSpeech.SUCCESS) {
                        int result = mTts.setLanguage(Locale.US);
                        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                            Log.e("error", "This Language is not supported");
                        }
                        isLoaded = true;

                    } else {
                        Log.e("error", "Initialization Failed!");
                    }
                }
            };
            mTts = new TextToSpeech(this, onInitListener);
        } catch (Exception e) {
            isLoaded = false;
            e.printStackTrace();
        }

        registerBroadcastReceiver();

        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        return START_STICKY;
    }

    // ---------------------------------------------------------------------------------------------
    //  Override
    // ---------------------------------------------------------------------------------------------
    @Override
    public void onDestroy() {
        shutDown();
        Log.v("STOP_TTS_SERVICE", "DONE");
        super.onDestroy();
    }

    // ---------------------------------------------------------------------------------------------
    //  shutDown
    // ---------------------------------------------------------------------------------------------
    private void shutDown()
    {
        unregisterBroadcastReceiver();

        if (mTts != null) {
            mTts.stop();
            mTts.shutdown();
        }
        isLoaded = false;
    }

    // ---------------------------------------------------------------------------------------------
    //  addQueue
    // ---------------------------------------------------------------------------------------------
    private void addQueue(String text)
    {
        if (isLoaded)
        {
            mTts.speak(text, TextToSpeech.QUEUE_ADD, null);
        }
        else
        {
            Log.e("error", "TTS Not Initialized");
        }
    }

    // ---------------------------------------------------------------------------------------------
    //  initQueue
    // ---------------------------------------------------------------------------------------------
    private void initQueue(String text)
    {
        if (isLoaded)
        {
            mTts.speak(text, TextToSpeech.QUEUE_FLUSH, null);
        }
        else
        {
            Log.e("error", "TTS Not Initialized");
        }
    }

    // ---------------------------------------------------------------------------------------------
    //  sayText
    // ---------------------------------------------------------------------------------------------
    private void sayText(ArrayList<String> list)
    {
        if (isLoaded && list!=null && list.size()>0)
        {
            initQueue(list.get(0));
            for (int inx=1;inx<list.size();inx++) {
                addQueue(list.get(inx));
            }
        }
    }


    // ------------------------------------------------------------------------
    //      registerBroadcastReceiver
    // ------------------------------------------------------------------------
    private void registerBroadcastReceiver()
    {
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("Mi_TTS");
        mTTSReceiver = new BroadcastReceiver()
        {
            @Override
            public void onReceive(Context context, Intent intent)
            {
                String strAction = intent.getAction();
                assert strAction != null;
                if (strAction.equals("Mi_TTS"))
                {
                    ArrayList<String> list = intent.getStringArrayListExtra("text");

                    if (list!=null && list.size()>0)
                    {
                        sayText(list);
                    }
                }
            }
        };
        this.registerReceiver(mTTSReceiver, theFilter);
    }

    //---------------------------------------------------------------------------
    // unregisterReceiver
    //---------------------------------------------------------------------------
    private void unregisterBroadcastReceiver()
    {
        int apiLevel = Build.VERSION.SDK_INT;

        if (apiLevel >= 7)
        {
            try
            {
                this.unregisterReceiver(mTTSReceiver);
            }
            catch (IllegalArgumentException e)
            {
                mTTSReceiver = null;
            }
        }
        else
        {
            this.unregisterReceiver(mTTSReceiver);
            mTTSReceiver = null;
        }
    }
}