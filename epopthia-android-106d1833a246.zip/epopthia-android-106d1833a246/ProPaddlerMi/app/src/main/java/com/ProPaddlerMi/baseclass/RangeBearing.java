package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

@SuppressWarnings({"unused", "WeakerAccess"})
public class RangeBearing {

    public final double range_m;
    public double bearing_rad;

    public RangeBearing()
    {
        range_m = 0.0;
        bearing_rad = Const.large; //invalid heading
    }

    public RangeBearing(double inRange_m, double inBearing_rad)
    {
        range_m = inRange_m;
        bearing_rad = inBearing_rad;
    }
	
    public RangeBearing(RangeBearing item0)
    {
        range_m = item0.range_m;
        bearing_rad = item0.bearing_rad;
    }

    public RangeBearing(double from_lat_rad, double from_lon_rad, double to_lat_rad, double to_lon_rad)
    {
        this(new LatLngRad(from_lat_rad, from_lon_rad), new LatLngRad(to_lat_rad, to_lon_rad));
    }
    //-----------------------------------------------------------------------------
    // RangeBearing
    //-----------------------------------------------------------------------------
    public RangeBearing(LatLngRad pt0, LatLngRad pt1)
    {
        double delta_n_m = (pt1.latitude_rad - pt0.latitude_rad) * Const.earth_a_m;
        double delta_e_m = (pt1.longitude_rad - pt0.longitude_rad) * Const.earth_a_m * Math.cos(pt0.latitude_rad);
        range_m = Math.pow((delta_n_m * delta_n_m + delta_e_m * delta_e_m), 0.5);
        bearing_rad = Math.atan2(delta_e_m, delta_n_m);
        bearing_rad = LimitAngleRad(bearing_rad);
    }

    //-----------------------------------------------------------------------------
    //	limit_angle_rad
    //	limit angle between 0 and 360 deg
    //-----------------------------------------------------------------------------
    private static double LimitAngleRad(double loc_bearing_rad)
    {
        double lim_bearing_rad = loc_bearing_rad;

        if (loc_bearing_rad < 0.0)
        {
            lim_bearing_rad += Const.two_pi;
        }
        else if (loc_bearing_rad >= Const.two_pi)
        {
            lim_bearing_rad -= Const.two_pi;
        }
        return (lim_bearing_rad);

    }

    //	calcDeltaAngle
    /// <summary>
    /// get delta angle relative to a0_rad, limit +/- 2PI
    /// </summary>
    /// <param name="a0_rad">reference angle</param>
    /// <param name="a1_rad">test angle</param>
    public static double CalcDeltaAngle(double a0_rad, double a1_rad)
    {
        double delta_rad = a1_rad - a0_rad;
        return (Math.min(Const.two_pi - delta_rad, delta_rad));
    }


    //-----------------------------------------------------------------------------
    // function:      RangeBearingToLatLon
    // description:   Convert range and bearing data to Lat and lon
    // arguments:     latitude_rad - reference Lat
    //				  longitude_rad - reference lon
    // return:        latitude_out and longitude_out
    //-----------------------------------------------------------------------------
    public LatLngRad RangeBearingToLatLon(LatLngRad pt)
    {
        double lat_rad, hdg_rad, dist_rad, clat_in, slat_in;
        double chdg_in, shdg_in, cdist_in, sdist_in, slat_out, lat_out_rad;
        double clat_out, delta_longitude, sdlong;

        lat_rad = pt.latitude_rad;
        hdg_rad = bearing_rad;
        dist_rad = range_m / Const.earth_a_m;
        clat_in = Math.cos(lat_rad);
        slat_in = Math.sin(lat_rad);
        chdg_in = Math.cos(hdg_rad);
        shdg_in = Math.sin(hdg_rad);
        cdist_in = Math.cos(dist_rad);
        sdist_in = Math.sin(dist_rad);

        slat_out = slat_in * cdist_in + clat_in * sdist_in * chdg_in;
        lat_out_rad = Math.asin(slat_out);
        clat_out = Math.cos(lat_out_rad);

        if (Math.abs(clat_out) < Const.epsilon) //divide by zero protection
            delta_longitude = 0.0;
        else
        {
            sdlong = (sdist_in * shdg_in) / clat_out;
            delta_longitude = Math.asin(sdlong);
        }

        return (new LatLngRad(lat_out_rad, pt.longitude_rad + delta_longitude));
    }
}

