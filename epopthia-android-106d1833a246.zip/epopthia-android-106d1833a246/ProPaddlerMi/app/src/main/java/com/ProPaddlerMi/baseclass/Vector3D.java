package com.ProPaddlerMi.baseclass;

public class Vector3D
{
    public final double[] v ;

    public Vector3D()
    {
        v = new double[3];
    }
    public Vector3D(double[] i)
    {
        v = i;
    }
    public Vector3D(Vector3D v0)
    {
        v = new double[]{v0.v[0],v0.v[1],v0.v[2]};
    }
    public Vector3D(double i, double j, double k)
    {
        v = new double[] { i, j, k };
    }

    //------------------------------------------------------------------------------
    //Function:         VectorCross3D
    //Description:      3D cross product  a X b
    //arguments:        A   - Vector3D source  0
    //                  B   - Vector3D source  1
    //Return value:     cross_prod_out
    //------------------------------------------------------------------------------
    public static Vector3D VectorCross3D(Vector3D a, Vector3D b)
    {
        Vector3D cross_prod_out = new Vector3D();
        cross_prod_out.v[0] = a.v[1] * b.v[2] - a.v[2] * b.v[1];
        cross_prod_out.v[1] = a.v[2] * b.v[0] - a.v[0] * b.v[2];
        cross_prod_out.v[2] = a.v[0] * b.v[1] - a.v[1] * b.v[0];
        return (cross_prod_out);
    }


    //-----------------------------------------------------------------------------
    //function:         VectorDot3D
    //description:      Compute the dot product between 2 vectors A.B = C
    //arguments:        A   - Vector3D source  0
    //                  B   - Vector3D source  1
    //return:           dot product
    //-----------------------------------------------------------------------------
    public static double VectorDot3D(Vector3D a, Vector3D b)
    {
        double dp = 0.0;
        for (int inx = 0; inx < 3; inx++)
        {
            dp += (a.v[inx] * b.v[inx]);
        }
        return (dp);
    }


    //-----------------------------------------------------------------------------
    //function:      calcUnitNormalVector
    //description:
    //arguments:     Vector3D ur1, Vector3D ur2
    //return:        un
    //-----------------------------------------------------------------------------
    public static Vector3D CalcUnitNormalVector(Vector3D ur1, Vector3D ur2)
    {
        Vector3D un1 = new Vector3D();

        //Compute Unit Normal Vector via the cross product
        un1.v[0] = ur2.v[1] * ur1.v[2] - ur2.v[2] * ur1.v[1];
        un1.v[1] = ur2.v[2] * ur1.v[0] - ur2.v[0] * ur1.v[2];
        un1.v[2] = ur2.v[0] * ur1.v[1] - ur2.v[1] * ur1.v[0];

        //Normalize Vector
        return (NormalizeVector(un1));
    }
    //-----------------------------------------------------------------------------
    //function:      normalizeVector
    //description:
    //arguments:
    //return:        v_out
    //-----------------------------------------------------------------------------
    public static Vector3D NormalizeVector(Vector3D v_in)
    {

        Vector3D v_out = new Vector3D();
        double mag_v_in_sq;
        double Normalize_Vector_1_1;
        double check_val_out;
        int i;

        mag_v_in_sq = 0.0;
        for (i = 0; i < 3; i++)
        {
            mag_v_in_sq += v_in.v[i] * v_in.v[i];
        }
        Normalize_Vector_1_1 = Math.sqrt(mag_v_in_sq);

        check_val_out = Normalize_Vector_1_1;

        if ((Math.abs(Normalize_Vector_1_1) < 1.0E-008))
        {
            check_val_out = 1.0E-008;
        }

        //normalize
        for (i = 0; i < 3; i++)
        {
            v_out.v[i] = v_in.v[i] / check_val_out;
        }

        return (v_out);
    }

    //-----------------------------------------------------------------------------
    //function:      CalcArcDist
    //description:   Calculate the arc distance between 2 radial vectors
    //-----------------------------------------------------------------------------
    public static double CalcArcDist(Vector3D ur1, Vector3D ur2)
    {
        double arc_dist_rad;
        Vector3D un = CalcUnitNormalVector(ur1, ur2);
        Vector3D ut = VectorCross3D(un, ur2);
        arc_dist_rad = VectorDot3D(ur1, ut);
        return (Math.abs(arc_dist_rad));
    }
}
