package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

import java.util.Arrays;
import java.util.Comparator;

@SuppressWarnings({"unused", "WeakerAccess"})
public class WayPoint {
    public enum Type {
        startpoint,
        checkpoint,
        waypoint,
        stoppoint
    }

    public final Type type;
    public final LatLngRad pt;
    public double value_m;  //numeric identifier, typically the distance along the route or rivermile
    public String label;
    public final Vector3D ur;
    public double nextPsi_rad;  //bearing angle to the next waypoint
    public final double riverMile;  //optional alternate numeric value corresponding to authority value assignment
    public int index;

    public WayPoint() {
        type = Type.waypoint;
        pt = new LatLngRad(0, 0);
        value_m = 0.0;
        label = "";
        ur = new Vector3D();
        nextPsi_rad = 0.0;
        index = 0;
        riverMile = 0;
    }

    public WayPoint(WayPoint init)
    {
        type = init.type;
        pt = new LatLngRad(init.pt);
        value_m = init.value_m;
        label = init.label;
        ur = new Vector3D(init.ur);
        nextPsi_rad = init.nextPsi_rad;
        index = init.index;
        riverMile = init.riverMile;
    }

    public WayPoint(double lat_rad, double lon_rad, double in_value_mile) {
        type = Type.waypoint;
        label = "";
        pt = new LatLngRad(lat_rad, lon_rad);
        riverMile = in_value_mile;
        value_m = in_value_mile * Const.mile_to_m;
        ur = TrackSegment.ComputeUnitRadialVector(lat_rad, lon_rad);
        nextPsi_rad = 0.0;
    }

    public WayPoint(double lat_rad, double lon_rad, double inValue_m, double inRiverMile) {
        type = Type.waypoint;
        label = "";
        pt = new LatLngRad(lat_rad, lon_rad);
        riverMile = inRiverMile;
        value_m = inValue_m;
        ur = TrackSegment.ComputeUnitRadialVector(lat_rad, lon_rad);
        nextPsi_rad = 0.0;
    }


    public WayPoint(CheckPoint cp) {
        type = Type.waypoint;
        label = cp.Name;
        pt = new LatLngRad(cp.pt.latitude_rad, cp.pt.longitude_rad);
        value_m = cp.value_m;
        riverMile = cp.value_m * Const.m_to_mile;
        ur = TrackSegment.ComputeUnitRadialVector(cp.pt.latitude_rad, cp.pt.longitude_rad);
        nextPsi_rad = 0.0;
    }

    // ---------------------------------------------------------------------------------------------
    // sortWaypoints
    // set location in array to be the same as the specified waypoint Order
    // ---------------------------------------------------------------------------------------------
    public static void CalcWayPointAngles(WayPoint[] wps) {
        if (wps.length > 1) {
            TrackSegment last = new TrackSegment(wps[0].pt, wps[1].pt); //wp 0 has 0 angle by definition
            for (int inx = 1; inx < wps.length - 2; inx++) {
                TrackSegment curr = new TrackSegment(wps[inx].pt, wps[inx + 1].pt);
                wps[inx].nextPsi_rad = TrackSegment.CalcAngleBetweenSegments(last, curr);
                last = curr;
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    // sortWaypoints
    // set location in array to be the same as the specified waypoint Order
    // ---------------------------------------------------------------------------------------------
    public static void sortWaypoints(WayPoint[] wps, boolean descending) {
        if (descending) {
            Arrays.sort(wps, new WayPointItemComparatorDescending());
        } else {
            Arrays.sort(wps, new WayPointItemComparator());
        }
    }
}

// ---------------------------------------------------------------------------------------------
// WayPointItemComparator
// compare waypoint item
// ---------------------------------------------------------------------------------------------
class WayPointItemComparator implements Comparator<WayPoint> {
    public int compare(WayPoint left, WayPoint right) {
        return Double.compare(left.value_m, right.value_m);
    }
}

// ---------------------------------------------------------------------------------------------
// WayPointItemComparator
// compare waypoint item
// ---------------------------------------------------------------------------------------------
class WayPointItemComparatorDescending implements Comparator<WayPoint> {
    public int compare(WayPoint left, WayPoint right) {
        return Double.compare(right.value_m, left.value_m);
    }
}
