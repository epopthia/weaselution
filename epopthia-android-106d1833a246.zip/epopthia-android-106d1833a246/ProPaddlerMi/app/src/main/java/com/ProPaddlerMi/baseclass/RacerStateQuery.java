package com.ProPaddlerMi.baseclass;

public enum RacerStateQuery
{
    Speed,
    AvgSpeed,
    TrackSpeed,
    AvgTrackSpeed,
    MaxSpeed,
    CheckPointDeltaMile,
    CheckpointItem,
    EstimatedFinishHourStr,
    TotalMiles,
    ElapsedTimeHourStr,
    Value,
    CrossTrack,
    GpsSpeed,
    PlanSpeed,
    CurrentTime,
    TotalMileAverageSpeed,
    RouteAverageSpeed
}
