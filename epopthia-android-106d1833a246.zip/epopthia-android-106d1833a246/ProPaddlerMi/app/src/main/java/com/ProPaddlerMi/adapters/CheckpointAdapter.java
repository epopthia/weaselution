package com.ProPaddlerMi.adapters;

import java.util.ArrayList;
import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.ProPaddlerMi.R;
import com.ProPaddlerMi.RaceOwlClient;
import com.ProPaddlerMi.baseclass.CheckPointCycle;
import com.ProPaddlerMi.utility.ClassUtility;

public class CheckpointAdapter extends ArrayAdapter<CheckPointCycle> {

	private int m_selected;

	private static class ViewHolder
	{
		private TextView itemView;
	}

	public CheckpointAdapter(Context context, int textViewResourceId, ArrayList<CheckPointCycle> items)
    {
		super(context, textViewResourceId, items);
	}

	public void updateResults()
	{
		notifyDataSetChanged();
	}

	public int getSelected()
	{
		return(m_selected);
	}

    public void setSelected(int selected)
    {
        m_selected = selected;
    }

    @NonNull
	public View getView(int position, View convertView, @NonNull ViewGroup parent) {

		ViewHolder viewHolder;
		if (convertView == null)
        {
            convertView = LayoutInflater.from(this.getContext()).inflate(R.layout.listview_checkpoint, parent, false);
			viewHolder = new ViewHolder();
			viewHolder.itemView = convertView.findViewById(R.id.textRow);
			convertView.setTag(viewHolder);
		}
        else
        {
			viewHolder = (ViewHolder) convertView.getTag();
		}

		CheckPointCycle item = getItem(position);
		if (item!= null) {
			// My layout has only one TextView
			// do whatever you want with your string and long
			viewHolder.itemView.setText(String.format("%s %s\n%s %s\nstatus = %s",
					item.BoatNumber, item.Checkpoint,
					ClassUtility.getRaceOwlTextTime(ClassUtility.parseRaceOwlNetTime(item.NetLocationTime)) , item.Status,
					RaceOwlClient.getCheckPointCycleStatusText(item.raceowl_status)));

			viewHolder.itemView.setTextColor(RaceOwlClient.getCheckPointCycleStatusColor(item.raceowl_status));
            if (position!= m_selected)
            {
                viewHolder.itemView.setBackgroundColor(Color.BLACK);
            }
            else
            {
                viewHolder.itemView.setBackgroundColor(Color.BLUE);
            }
        }
		return convertView;
	}
}
   
