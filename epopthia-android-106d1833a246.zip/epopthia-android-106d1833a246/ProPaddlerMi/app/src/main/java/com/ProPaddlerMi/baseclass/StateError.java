package com.ProPaddlerMi.baseclass;

import java.util.ArrayList;

public class StateError {
    public ErrorType errorType;
    public int code;
    public final String message;

    public enum ErrorType
    {
        None,
        Pose,
        Track,
        RouteRelative,
        CheckPointStatus,
        RacerState
    }

    public StateError()
    {
        errorType = ErrorType.None;
        code = 0;
        message = "";
    }

    public StateError(StateError s0)
    {
        errorType = s0.errorType;
        code = s0.code;
        message = s0.message;
    }

    public StateError(ErrorType type, int inCode, String inMessage)
    {
        errorType = type;
        code = inCode;
        message = inMessage;
    }

    public static String GetErrorString(ArrayList<StateError> errors)
    {
        StringBuilder error = new StringBuilder();
        for (StateError err: errors) {
            error.append(err.message).append(";");
        }
        return (error.toString());
    }
}

class MinStateError
{
    public final StateError.ErrorType errorType;
    public final int code;

    public MinStateError()
    {
        errorType = StateError.ErrorType.None;
        code = 0;
    }
    public MinStateError (StateError error)
    {
        errorType = error.errorType;
        code = error.code;
    }
}
