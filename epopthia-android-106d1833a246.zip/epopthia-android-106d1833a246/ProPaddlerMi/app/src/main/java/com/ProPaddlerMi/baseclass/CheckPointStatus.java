package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;
import com.ProPaddlerMi.utility.UTCTime;

import java.util.ArrayList;

public class CheckPointStatus {
    public CheckPointHistory[] checkPointHistories;     // history of checkpoints that have been cycled
    public CheckPointCurrent current;
    public int startIndex;  //race start index
    public int finishIndex; //race finish index

    public boolean Valid()
    {
        return (checkPointHistories.length > 0);

    }
    public boolean IsPossibleRacing()
    {
        return (!RaceWithDraw() && !RaceFinished());
    }
    public boolean IsActive()
    {
        return (RaceStarted() && !RaceWithDraw() && !RaceFinished());
    }

    public boolean getUpdateCheckPoint() {
        for (CheckPointHistory checkPointHistory : checkPointHistories) {
            if (checkPointHistory.update) {
                return (true);
            }
        }
        return (false);
    }

    public void setUpdateCheckPoint(boolean value) {
        for (CheckPointHistory cp:
                checkPointHistories) {
            cp.update = value;
        }
    }

    public String Status()
    {
        if (!RaceStarted())
        {
            return ("DNS");
        }
        else if (RaceFinished())
        {
            return ("FINISH");
        }
        else if (RaceWithDraw())
        {
            return ("DNF");
        }
        else
        {
            return (current.isEntry ? "IN" : "OUT");
        }
    }


    public double StartValue()
    {
        return checkPointHistories.length > startIndex ? checkPointHistories[startIndex].value_m : 0.0;
    }

    public double FinishValue()
    {
        return checkPointHistories.length > finishIndex ? checkPointHistories[finishIndex].value_m : 0.0;
    }

    public boolean RaceStarted()
    {
        return checkPointHistories.length > startIndex && checkPointHistories[startIndex].exit.state == PointHistory.PointHistoryState.cycled;
    }
    public boolean RaceFinished()
    {
        return checkPointHistories.length > finishIndex && checkPointHistories[finishIndex].enter.state == PointHistory.PointHistoryState.cycled;
    }
    public boolean RaceWithDraw()
    {
        for (CheckPointHistory cp:checkPointHistories) {
            if (cp.exit.state == PointHistory.PointHistoryState.dnf) {
                return true;
            }
        }return false;
    }

    public long StartTime()  //start time in ms (UTC)
    {
        return (RaceStarted() ? checkPointHistories[startIndex].exit.time : 0);
    }
    public long FinishTime()  //finish time in ms (UTC)
    {
        return (RaceFinished() ? checkPointHistories[finishIndex].enter.time : 0);
    }

    public CheckPointStatus()
    {
        checkPointHistories = new CheckPointHistory[0];
        current = new CheckPointCurrent();
        startIndex = 0;
        finishIndex = 0;
    }

    public CheckPointStatus(CheckPointStatus s0)
    {
        startIndex = s0.startIndex;
        finishIndex = s0.finishIndex;
        checkPointHistories = CopyCheckPointHistory(s0.checkPointHistories);
        current = new CheckPointCurrent(s0.current);
    }



    public CheckPointStatus(CheckPoint[] cps, long startTime_ms, boolean variableStart )
    {
        this();
        startIndex = variableStart ? Math.min(1, cps.length) : 0;
        finishIndex = cps.length - 1;
        checkPointHistories = new CheckPointHistory[cps.length];

        for (int i = 0; i < checkPointHistories.length; i++)
        {
            checkPointHistories[i] = new CheckPointHistory();
            checkPointHistories[i].CheckpointName = cps[i].Name;
            checkPointHistories[i].SeqNbr = i;
            checkPointHistories[i].value_m = cps[i].value_m;
            checkPointHistories[i].enter = new PointHistory();
            checkPointHistories[i].enter.state = PointHistory.PointHistoryState.unknown;
            checkPointHistories[i].exit = new PointHistory();
            checkPointHistories[i].exit.state = PointHistory.PointHistoryState.unknown;
        }
        if (checkPointHistories.length > 0)
        {
            checkPointHistories[0].enter.state = PointHistory.PointHistoryState.cycled;
            checkPointHistories[0].enter.time = startTime_ms;
            if (0 < startIndex)
            {
                checkPointHistories[0].exit.state = PointHistory.PointHistoryState.cycled;
                checkPointHistories[0].exit.time = startTime_ms;
            }
        }

        current = new CheckPointCurrent(checkPointHistories); //checkPointHistories, startTime_ms, route, variableStart);

        //autocheckin first point
        if (!variableStart && checkPointHistories.length > 0 && UTCTime.getCurrentUTC() > startTime_ms && checkPointHistories[0].exit.state != PointHistory.PointHistoryState.cycled)
        {
            current.isEntry = false;
            current.currentIndex = 0;
            current.currentCycle = new PointHistory();
            current.currentCycle.time = startTime_ms;
            current.currentCycle.state = PointHistory.PointHistoryState.cycled;
            current.autoCheckpointStatus = String.format("%s_OUT", cps[current.currentIndex].Name);
            current.nextCheckpointIndex = current.currentIndex + 1;

            checkPointHistories[current.currentIndex].exit = new PointHistory(current.currentCycle);
            checkPointHistories[current.currentIndex].update = true;
        }
    }

    public CheckPointStatus(Pose pose, RouteRelative routeRelative, StateSummary summary, Route route, RacerState s0)
    {
        this(s0.checkPointStatus);

        checkPointHistories = ProcessCheckpointCycle(pose, routeRelative, summary, s0, route);

        for (int inx = checkPointHistories.length-1; inx>=0; inx--)
        {
            if (checkPointHistories[inx].exit.state != PointHistory.PointHistoryState.unknown)
            {
                current.nextCheckpointIndex = Math.min(checkPointHistories.length - 1, inx + 1);
                current.isEntry = false;
                current.currentIndex = inx;
                current.currentCycle.state = checkPointHistories[inx].exit.state;
                current.currentCycle.time = checkPointHistories[inx].exit.time;
                break;
            }
            else if(checkPointHistories[inx].enter.state != PointHistory.PointHistoryState.unknown)
            {
                current.nextCheckpointIndex = Math.min(checkPointHistories.length - 1, inx + 1);
                current.isEntry = true;
                current.currentIndex = inx;
                current.currentCycle.state = checkPointHistories[inx].enter.state;
                current.currentCycle.time = checkPointHistories[inx].enter.time;
                break;
            }
        }
    }

    private CheckPointHistory[] CopyCheckPointHistory(CheckPointHistory[] cph0)
    {
        CheckPointHistory[] cph1 = new CheckPointHistory[cph0.length];
        for(int inx = 0; inx< cph1.length; inx++)
        {
            CheckPointHistory obj = new CheckPointHistory(cph0[inx]);
            cph1[inx] = obj;
        }
        return (cph1);
    }

    //----------------------------------------------------------------------------------------------
    //Receive new position data
    //----------------------------------------------------------------------------------------------
    private CheckPointHistory[] ProcessCheckpointCycle(Pose pose, RouteRelative routeRelative, StateSummary summary, RacerState s0, Route route)
    {

        current = new CheckPointCurrent(s0.checkPointStatus.current);
        CheckPointHistory[] cps = CopyCheckPointHistory(s0.checkPointStatus.checkPointHistories);

        long[] utc_limits_ms = new long[2];

        // -----------------------------------------------------------------------------------------
        // Verify inputs
        // verify route exists
        if (route.cps == null)
        {
            return (cps);
        }

        // verify current racer state checkpoint is valid in context of the current route, return if invalid
        int s1idx = (int)Math.floor(routeRelative.cpIndex);
        if (!(s1idx >= 0 && s1idx < route.cps.length))
        {
            return (cps);
        }

        // verify last racer state checkpoint is valid in context of the current route, if invalid flag and continue
        int s0idx = Math.max((int)Math.floor(s0.routeRelative.cpIndex), 0);
        boolean valid_s0idx = s0idx >= 0 && s0idx < route.cps.length;

        // verify the closest index
        int near_idx = (int)Math.round(routeRelative.cpIndex);
        boolean valid_near_idx = near_idx >= 0 && near_idx < route.cps.length;

        // check if this is a variable start race
        boolean isVariableStart = startIndex > 0;

        // -----------------------------------------------------------------------------------------
        // check for entering a checkpoint

        // racer is at a checkpoint and entry has not been recorded.
        // use the near index, because we may be coming into the checkpoint but we've not yet cycled the cp index yet
        if (routeRelative.atCp && valid_near_idx && (cps[near_idx].enter.state == PointHistory.PointHistoryState.unknown))
        {
            cps[near_idx].enter.state = PointHistory.PointHistoryState.cycled;

            // look ahead logic with prior racer state
            // we don't necessarily know exactly when the racer entered the checkpoint, so if the previous update is valid, use it to estimate entry
            // time cant be greater than the exit of the checkpoint
            long utc_in_time_ms = CalcBestEntryTime(near_idx, pose, routeRelative, summary, s0, route, pose.utc_ms);

            cps[near_idx].enter.state = PointHistory.PointHistoryState.cycled;
            cps[near_idx].enter.time = utc_in_time_ms;
            cps[near_idx].update = true;

            //don't mark OUT for any checkpoint <= start index. Otherwise you could
            //prematurely start your race
            if (near_idx > startIndex && (cps[near_idx].value_m - cps[near_idx - 1].value_m) < Const.shortSegmentThreshold && near_idx != finishIndex)
            {
                cps[near_idx].exit.state = PointHistory.PointHistoryState.cycled;
                cps[near_idx].exit.time = utc_in_time_ms;
                current.currentCycle = cps[near_idx].exit;
                current.isEntry = false;
            }
            else //entry only
            {
                current.currentCycle = cps[near_idx].enter;
                current.isEntry = true;
            }
            current.currentIndex = near_idx;
            current.autoCheckpointStatus = String.format("%s_%s", route.cps[near_idx].Name, current.isEntry ? "IN" : "OUT");
        }

        // checkpoint is between consecutive gps readings and entry has not been recorded.
        // We've cycled the cp and will look to the previous data point and then see if we can
        // estimate when we entered
        //            else if (valid_s0idx && (s1idx == s0idx + 1) && (cps[s1idx].enter.state == PointHistory.PointHistoryState.unknown))
        else if (valid_s0idx && (s1idx == s0idx + 1) && (cps[s1idx].enter.state == PointHistory.PointHistoryState.unknown))
        {
            // with prior racer state
            long utc_ms = CalcBestEntryTime(s1idx, pose, routeRelative, summary, s0, route, pose.utc_ms);

            cps[s1idx].enter.state = PointHistory.PointHistoryState.cycled;
            cps[s1idx].enter.time = utc_ms;
            cps[s1idx].update = true;

            //don't mark out for any checkpoint <= start index. Otherwise you could
            //accident start your race while waiting to start
            if (s1idx > startIndex && (cps[s1idx].value_m - cps[s1idx - 1].value_m) < Const.shortSegmentThreshold && s1idx != finishIndex)
            {
                cps[s1idx].exit.state = PointHistory.PointHistoryState.cycled;
                cps[s1idx].exit.time = utc_ms;
                current.currentCycle = cps[s1idx].exit;
                current.isEntry = false;
            }
            else
            {
                current.currentCycle = cps[s1idx].enter;
                current.isEntry = true;
            }
            current.currentIndex = s1idx;
            current.autoCheckpointStatus = String.format("%s_%s", route.cps[s1idx].Name, current.isEntry ? "IN" : "OUT");
        }

        // -----------------------------------------------------------------------------------------
        // check for exiting a checkpoint
        // checkpoint is behind us but has not been recorded
        if (!routeRelative.atCp
                && valid_s0idx
                && routeRelative.cpIndex > s1idx
                && (cps[s1idx].exit.state == PointHistory.PointHistoryState.unknown)
                && s1idx != cps.length - 1) //finish line
        {
            long utc_ms = CalcBestExitTime(s1idx, pose, routeRelative, summary, s0, route);
            if (utc_ms > 0) //we have a fix on speed
            {
                cps[s1idx].exit.state = PointHistory.PointHistoryState.cycled;
                cps[s1idx].exit.time = utc_ms;
                cps[s1idx].update = true;
                current.currentCycle = cps[s1idx].exit;
                current.isEntry = false;
                current.currentIndex = s1idx;
                current.autoCheckpointStatus = String.format("%s_%s", route.cps[s1idx].Name, "OUT");
            }
        }

        // variable race start and racer is at the start and exit has not been recorded.
        // we need a precise exit time
        if (isVariableStart
                && valid_s0idx
                && routeRelative.startState == RouteRelative.StartState.armed)
        {
            cps[startIndex].exit.state = PointHistory.PointHistoryState.armed;
        }

        // variable race start and racer is at the start and exit has not been recorded.
        // we need a precise exit time
        if (isVariableStart
                && valid_s0idx
                && routeRelative.cpIndex <= startIndex
                && cps[startIndex].exit.state == PointHistory.PointHistoryState.cycled)
        {
            cps[startIndex].exit.state = PointHistory.PointHistoryState.armed;
        }



        // variable race start and racer is at the start and exit has not been recorded.
        // we need a precise exit time
        if (isVariableStart
                && valid_s0idx
                && routeRelative.cpIndex > startIndex
                && ((cps[startIndex].exit.state == PointHistory.PointHistoryState.armed)
                || cps[startIndex].exit.time <= cps[0].exit.time))
        {
            long utc_ms = CalcBestExitTime(startIndex, pose, routeRelative, summary, s0, route);

            if (utc_ms > 0) //we have a good fix on speed
            {
                cps[startIndex].exit.state = PointHistory.PointHistoryState.cycled;
                cps[startIndex].exit.time = utc_ms;
            }
            else
            {
                cps[startIndex].exit.state = PointHistory.PointHistoryState.cycled;
                cps[startIndex].exit.time = cps[0].exit.time;
            }
            cps[startIndex].update = true;
            current.currentIndex = startIndex;
            current.isEntry = false;

            current.autoCheckpointStatus = String.format("%s_%s", route.cps[s1idx].Name, "OUT");

        }

        current.nextCheckpointIndex = GetNextCheckpointIndex(routeRelative, cps);
        return (cps);

    }

    static class EstimateScore
    {
        public long time_ms;
        public double cost;

    }

    private long CalcBestExitTime(int targetCPIndex, Pose pose1, RouteRelative routeRelative, StateSummary summary, RacerState s0, Route route)
    {
        long utcEstimate_ms = 0;
        double cpValue_m = route.cps[targetCPIndex].value_m;

        double bestSpeed_mps = 0.0;

        ArrayList<EstimateScore> estimates = new ArrayList<>();

        // most recent pose is after checkpoint
        if (routeRelative.value_m >= cpValue_m + Const.maxMeasurementError_m)
        {
            //bestSpeed_mps = summary.InitSpeed ? bestSpeed_mps : summary.avgSpeed_mps;
            bestSpeed_mps = summary.avgSpeed_mps > route.minSpeed_mps() ? summary.avgSpeed_mps : bestSpeed_mps;
            if (bestSpeed_mps > 0)
            {
                double scale = 1.0;
                long myEstimate = EstimateCheckpointTime(pose1, bestSpeed_mps, routeRelative, cpValue_m);
                EstimateScore estimateScore = new EstimateScore();
                estimateScore.time_ms = myEstimate;
                estimateScore.cost = scale * Math.abs(routeRelative.value_m - cpValue_m);
                estimates.add(estimateScore);
            }
        }

        // last pose is after checkpoint
        if (s0.routeRelative.value_m >= cpValue_m + Const.maxMeasurementError_m)
        {
            //bestSpeed_mps = s0.summary.InitSpeed ? bestSpeed_mps : s0.summary.avgSpeed_mps;
            bestSpeed_mps = s0.summary.avgSpeed_mps > route.minSpeed_mps() ? s0.summary.avgSpeed_mps : bestSpeed_mps;
            if (bestSpeed_mps > 0)
            {
                double scale = 1.0;
                EstimateScore estimateScore = new EstimateScore();
                estimateScore.time_ms = EstimateCheckpointTime(s0.pose1, bestSpeed_mps, s0.routeRelative, cpValue_m);
                estimateScore.cost = scale * Math.abs(s0.routeRelative.value_m - cpValue_m);
                estimates.add(estimateScore);
            }
        }

//        if (estimates.size() > 0)
//        {

            // set constraints
            // min time given that state cp index >= target
//            long minTime = 0;
//            var cpmins = this.checkPointHistories.Where((x, i) => i < targetCPIndex && x.exit.state == PointHistory.PointHistoryState.cycled).Select(y => y.exit.time);
//            if (cpmins.length > 0) minTime = cpmins.max();
//            minTime = pose1.utc_ms > minTime && routeRelative.cpIndex < targetCPIndex ? pose1.utc_ms : minTime;
//            minTime = s0.reported.utcTime_ms > minTime && s0.routeRelative.cpIndex < targetCPIndex ? s0.reported.utcTime_ms : minTime;
//
//            // max state time given that state cp index <= target
//            long maxTime = 0;
//            var cpmaxs = this.checkPointHistories.Where((x, i) => i > targetCPIndex && x.enter.state == PointHistory.PointHistoryState.cycled).Select(y => y.exit.time);
//            if (cpmaxs.length > 0) maxTime = cpmaxs.min();
//            maxTime = (pose1.utc_ms < maxTime || maxTime == 0) && routeRelative.cpIndex >= targetCPIndex ? pose1.utc_ms : maxTime;
//            maxTime = (s0.reported.utcTime_ms < maxTime || maxTime == 0) && s0.routeRelative.cpIndex >= targetCPIndex ? s0.reported.utcTime_ms : maxTime;
//
//            // down select for min/max time and order
//            estimates = estimates.Where(x => x.time_ms >= minTime && (x.time_ms <= maxTime || maxTime == 0)).OrderBy(y => y.cost).ToList();
//        }

        // make selection
        if (estimates.size() > 0)
        {
            //cannot be less than the entry
            utcEstimate_ms = Math.max(this.checkPointHistories[targetCPIndex].enter.time, estimates.get(0).time_ms);
        }

        return utcEstimate_ms;

    }


    private long CalcBestEntryTime(int targetCPIndex, Pose pose1, RouteRelative routeRelative, StateSummary summary, RacerState s0, Route route, long defaultTime_ms)
    {
        double cpValue_m = route.cps[targetCPIndex].value_m;

       // ArrayList<EstimateScore> estimates = new ArrayList<>();

        // most recent pose is prior to checkpoint
//        if (routeRelative.value_m < cpValue_m - Const.maxMeasurementError_m)
//        {
//            double scale = 1.0;
//            long myEstimate = EstimateCheckpointTime(pose1, summary.avgSpeed_mps, routeRelative, cpValue_m);
//            estimates.add(new EstimateScore() { time_ms = myEstimate, cost = scale * Math.abs(routeRelative.value_m - cpValue_m) });
//        }
//
//        // most recent pose is after checkpoint
//        if (routeRelative.value_m >= cpValue_m - Const.maxMeasurementError_m)
//        {
//            double scale = 2.0;
//            long myEstimate = EstimateCheckpointTime(pose1, summary.avgSpeed_mps, routeRelative, cpValue_m);
//            estimates.add(new EstimateScore() { time_ms = myEstimate, cost = scale * Math.abs(routeRelative.value_m - cpValue_m) });
//        }
//
//        // we have a previous state,
//        if (s0 != null && s0.routeRelative.value_m < cpValue_m - Const.maxMeasurementError_m)
//        {
//            double scale = 1.5;
//            long myEstimate = EstimateCheckpointTime(s0.pose1, s0.summary.avgSpeed_mps, s0.routeRelative, cpValue_m);
//            estimates.add(new EstimateScore() { time_ms = myEstimate, cost = scale * Math.abs(routeRelative.value_m - cpValue_m) });
//        }
//
//        if (estimates.size() > 0)
//        {
//
//            // set constraints
//            // min time given that state cp index >= target
//            long minTime = 0;
//            var cpmins = this.checkPointHistories.Where((x, i) => i < targetCPIndex && x.exit.state == PointHistory.PointHistoryState.cycled).Select(y => y.exit.time);
//            if (cpmins.length > 0) minTime = cpmins.max();
//            minTime = pose1.utc_ms > minTime && routeRelative.cpIndex < targetCPIndex ? pose1.utc_ms : minTime;
//            minTime = s0.reported.utcTime_ms > minTime && s0.routeRelative.cpIndex < targetCPIndex ? s0.reported.utcTime_ms : minTime;
//
//            // max state time given that state cp index <= target
//            long maxTime = 0;
//            var cpmaxs = this.checkPointHistories.Where((x, i) => i > targetCPIndex && x.enter.state == PointHistory.PointHistoryState.cycled).Select(y => y.exit.time);
//            if (cpmaxs.length > 0) maxTime = cpmaxs.min();
//            maxTime = (pose1.utc_ms < maxTime || maxTime == 0) && routeRelative.cpIndex >= targetCPIndex ? pose1.utc_ms : maxTime;
//            maxTime = (s0.reported.utcTime_ms < maxTime || maxTime == 0) && s0.routeRelative.cpIndex >= targetCPIndex ? s0.reported.utcTime_ms : maxTime;
//
//            // down select for min/max time and order
//            estimates = estimates.Where(x => x.time_ms >= minTime && (x.time_ms <= maxTime || maxTime == 0)).OrderBy(y => y.cost).ToList();
//        }

        // make selection
//        if (estimates.size() > 0)
//        {
//            utcEstimate_ms = estimates.get(0).time_ms;
//        }

        return defaultTime_ms;

    }

        // ---------------------------------------------------------------------------------------------
        // estimateCheckpointTime
        // return UTC time for estimate of when the racer enters or exits a checkpoint
        // NOTE: inputs are assumed defined
        // returns 0 if no estimate is possible
        // ---------------------------------------------------------------------------------------------
        private static long EstimateCheckpointTime(Pose pose, double avgSpeed_mps, RouteRelative routeRelative, double cp_value_m)
        {
            long utc_estimate_ms = 0;

            if (avgSpeed_mps > 0.0)
            {
                double dist_m = cp_value_m - routeRelative.value_m;
                double deltat_s = dist_m / avgSpeed_mps;
                utc_estimate_ms = pose.utc_ms + (int)(Math.round(deltat_s) * Const.sec_to_ms);

                utc_estimate_ms = (long) 0 > 0 ? Math.max(0, utc_estimate_ms) : utc_estimate_ms;
                utc_estimate_ms = (long) 0 > 0 ? Math.min(0, utc_estimate_ms) : utc_estimate_ms;
            }

            return (utc_estimate_ms);
        }

    // verifyAverageSpeed
    // ---------------------------------------------------------------------------------------------
    private static boolean VerifyAverageSpeed(double avgSpeed_mps)
    {
        boolean ret = true;

        if (avgSpeed_mps < Const.minSpeed_mps)
        {
            ret = false;
        }
        else if (avgSpeed_mps > Const.maxSpeed_mps)
        {
            ret = false;
        }
        return (ret);
    }

    // ---------------------------------------------------------------------------------------------
    // getNextCheckpointIndex
    // ---------------------------------------------------------------------------------------------
    private int GetNextCheckpointIndex(RouteRelative routeRelative, CheckPointHistory[] checkPointHistories)
    {
        int idx = Math.min((int)(routeRelative.cpIndex + 1), checkPointHistories.length - 1);
        return (int)(idx);
    }
}
