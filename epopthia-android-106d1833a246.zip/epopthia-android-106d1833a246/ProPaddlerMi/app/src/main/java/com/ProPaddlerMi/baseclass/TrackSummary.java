package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.UTCTime;

public class TrackSummary {
    public double avg_speed_mps;
    public double max_speed_mps;
    public final double total_dist_m;
    public TrackSegment own_path;
    public final long referenceUtcTime_ms; //UTC time used in calculation of elapsed time

    public TrackSummary()
    {
        avg_speed_mps = -1.0;
        max_speed_mps = -1.0;
        total_dist_m = 0.0;
        own_path = new TrackSegment();
        referenceUtcTime_ms = UTCTime.getCurrentUTC();
    }

    public TrackSummary(TrackSummary s0)
    {
        avg_speed_mps = s0.avg_speed_mps;
        max_speed_mps = s0.max_speed_mps;
        total_dist_m = s0.total_dist_m;
        own_path = new TrackSegment(s0.own_path);
        referenceUtcTime_ms = s0.referenceUtcTime_ms;
    }

    public TrackSummary(Pose s0)
    {
        this();
        avg_speed_mps = s0.gpsVel_mps;
        max_speed_mps = s0.gpsVel_mps;
        own_path = new TrackSegment(s0);
    }
}
