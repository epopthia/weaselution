package com.ProPaddlerMi;

import com.ProPaddlerMi.baseclass.LatLngRad;
import com.ProPaddlerMi.baseclass.LookupInfo;
import com.ProPaddlerMi.baseclass.RacerState;
import com.ProPaddlerMi.baseclass.RangeBearing;
import com.ProPaddlerMi.utility.Const;

import static java.lang.Math.max;

class ClassSimulation {
	private static final double accuracy_m = 30.0 * Const.ft_to_m;
	private double sim_last_elapsed_time_sec;
	private double simLastValue_m;
	private final Globals globals;

	private final WayPointMission wp;

	// ----------------------------------------------------------------------
	// simulation constructor
	// ----------------------------------------------------------------------
	ClassSimulation()
	{
		globals = Globals.getInstance();
		wp = ActivityMain.wp; // get wp from main activity
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(false);
		simLastValue_m = 0;
	}

	// ----------------------------------------------------------------------
	// init
	// ----------------------------------------------------------------------
	void init(float speed_mph, float initPercent)
	{
		int wpCount = globals.route.wps.length;
		double value_m = wpCount>0 ? initPercent / 100 * (globals.route.wps[wpCount-1].value_m - globals.route.wps[0].value_m) + globals.route.wps[0].value_m : 0;
	 	LookupInfo info = wp.estimateLocationFromValue(value_m);
		int curr_wp =  info.iUpper;
		wp.setWaypoint(curr_wp);

		double lat_deg = wp.getWaypointLatitude(curr_wp)*Const.rtd;
		double lon_deg = wp.getWaypointLongitude(curr_wp)*Const.rtd;
		double bearing_deg = wp.getWaypointBearing();
		double speed_mps = speed_mph * Const.mph_to_mps;

		wp.updateNav(lat_deg, lon_deg, speed_mps, bearing_deg, accuracy_m, System.currentTimeMillis());

		// update sim AppState
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(true);
		simLastValue_m = value_m;
	}

	// ----------------------------------------------------------------------
	// init - secondary init used for settings restore
	// ----------------------------------------------------------------------
	void init(float speed_mph, double lat_deg, double lon_deg, double bearing_deg, int curr_wp)
	{
		wp.setWaypoint(curr_wp);

		double speed_mps = speed_mph * Const.mph_to_mps;

		wp.updateNav(lat_deg, lon_deg, speed_mps, bearing_deg, accuracy_m, System.currentTimeMillis());

		// update simulation AppState
		sim_last_elapsed_time_sec = wp.getElapsedTimeSec(true);
		simLastValue_m = globals.route.wps[WayPointMission.curr_wp_index].value_m;
	}

	// ----------------------------------------------------------------------
	// cycle
	// ----------------------------------------------------------------------
	void cycle(double elapsed_time_s, double speed_mph)
	{
		double speed_mps = speed_mph * Const.mph_to_mps;

		double deltaT_s = elapsed_time_s - sim_last_elapsed_time_sec;
		deltaT_s = max(deltaT_s,0);  	//forbid going backwards in time.

		double wpDirection = globals.route.isAscending() ? 1.0:-1.0;

		double deltaDist_m = speed_mps * deltaT_s;

		double newValue_m = (deltaDist_m*wpDirection) + simLastValue_m;

		RacerState s0 = RacerStateManager.getRacerState();

		LatLngRad newLocation = RacerState.LookupPoint(newValue_m, globals.route);

		RangeBearing rb = new RangeBearing(s0.reported.pt, newLocation);

		wp.updateNav(newLocation.latitude_rad *Const.rtd, newLocation.longitude_rad *Const.rtd, speed_mps, rb.bearing_rad*Const.rtd, accuracy_m, System.currentTimeMillis());

		//update sim AppState
		sim_last_elapsed_time_sec = elapsed_time_s;
		simLastValue_m = newValue_m;

	}
}
