package com.ProPaddlerMi.fragments;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.ProPaddlerMi.ActivityMain;
import com.ProPaddlerMi.ClassFileIO;
import com.ProPaddlerMi.Location;
import com.ProPaddlerMi.RaceOwlAPI;
import com.ProPaddlerMi.RacerStateManager;
import com.ProPaddlerMi.utility.Const;
import com.ProPaddlerMi.Globals;
import com.ProPaddlerMi.R;
import com.ProPaddlerMi.RaceOwlClient;
import com.ProPaddlerMi.WayPointMission;
import com.ProPaddlerMi.utility.ClassUtility;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

public class Frag02_tracking extends Fragment
{
	private View v = null;
	private Handler mHandler;
	private Globals globals;
	private WayPointMission wp;
	private RaceOwlClient raceowl;


	private TextView textViewLat;
	private TextView textViewLon;
	private TextView tv_time_to_update;
	private TextView textViewLocQueue;

	private TextView tvTotalMiles;
	private TextView tvTotalLocations;



	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		setHasOptionsMenu(true);

		if (container == null)
		{
			return null;
		}
		super.onCreate(savedInstanceState);

		//get singleton objects
		wp = WayPointMission.getInstance();
		raceowl = RaceOwlClient.getInstance();

		//get view
		v = inflater.inflate(R.layout.frag02_tracking, container, false);

		initGui();

		// if fragment is visible then update
		if (getUserVisibleHint())
		{
			update();
		}
		return v;
	}

	@Override
	public void onAttach(Context context) {
		super.onAttach(context);
		globals = Globals.getInstance();
		globals.appState.ctx = context;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
		super.setUserVisibleHint(isVisibleToUser);
		if (isVisibleToUser && v!=null)
		{
			((ActivityMain)Objects.requireNonNull(getActivity())).manageScreenTransition();
			update();
		}
	}

	// graphicsRefresh for AppState screen
	private void graphicsRefresh()
	{
		int myColor = Color.RED;
		if (globals.settings.enable_high_contrast_color)
		{
			myColor = Color.WHITE;
		}
		//set text color
		setTextColor(myColor);
	}

	@Override
	public void onPause()
	{
		//unregisterReceiver();
		stopRepeatingTask();

		// set slow update rate if going to sleep
//		((ActivityMain)getActivity()).broadcastGPSRateUpdate(30*1000);
		super.onPause();
	}

	@Override
	public void onResume()
	{
		graphicsRefresh();

		//start timed activities
		if (mHandler==null)
		{
			mHandler = new Handler(); //setup for timed updates
		}
		startRepeatingTask();

		super.onResume();
	}


	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	private void startRepeatingTask()
	{
		runMainTimerEvent.run();
	}

	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
	private void stopRepeatingTask()
	{
		mHandler.removeCallbacks(runMainTimerEvent);
	}


	//---------------------------------------------------------------------------
	// runMainTimerEvent
	//---------------------------------------------------------------------------
	private final Runnable runMainTimerEvent = new Runnable()
	{
		@Override
		public void run()
		{
			update();
			mHandler.removeCallbacks(runMainTimerEvent);
			mHandler.postDelayed(runMainTimerEvent, Const.prime_deltat_ms);
		}
	};

	// ----------------------------------------------------------------------
	// initGui
	// ----------------------------------------------------------------------
	private void initGui()
	{

		textViewLat = v.findViewById(R.id.lat);
		textViewLon = v.findViewById(R.id.lon);
		tv_time_to_update = v.findViewById(R.id.time_to_update);
		textViewLocQueue = v.findViewById(R.id.loc_queue);
		tvTotalMiles =   v.findViewById(R.id.total_miles);
		tvTotalLocations =  v.findViewById(R.id.total_locs);


		//= (TextView) v.findViewById(R.id.update_status);
		TextView textViewUpdateStatus = v.findViewById(R.id.update_status);

		Button start_track = v.findViewById(R.id.start_track);
		Button stop_track = v.findViewById(R.id.stop_track);

		//enable and disable buttons
		start_track.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				globals.settings.trackingActive = true;
				raceowl.setTrackingState(RaceOwlClient.TrackingState.TRACKING);
				if (raceowl.getTrackingStatus()) {

					globals.settings.counterStateUpdate = (int) (raceowl.locationUpdatePeriod_min * globals.settings.triggersPerMinute);
					Location.addLocation(globals.locations, RacerStateManager.getRacerState());
					raceowl.sendLocation();
					update();
				}
			}
		});


		//enable and disable buttons
		stop_track.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				globals.settings.trackingActive = false;
				raceowl.setTrackingState(RaceOwlClient.TrackingState.STOPPED);
				update();
			}
		});

	}
	//---------------------------------------------------------------------------
	// setTextColor
	//---------------------------------------------------------------------------
	private void setTextColor(int color)
	{
		TextView t1 = v.findViewById(R.id.text_lon);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_lat);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_location_queue);
		t1.setTextColor(color);
		t1 = v.findViewById(R.id.text_next_update);
		t1.setTextColor(color);
	}

	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{

		if (textViewLat ==null) return;  //pop out of update if screen not drawn

		textViewLat.setText(String.format("%1.6f", wp.getLatitude() * Const.rtd));
		textViewLon.setText(String.format("%1.6f", wp.getLongitude()* Const.rtd));

		double tmp = globals.settings.counterLocationTracking * Const.prime_deltat_ms /1000.0;
		tv_time_to_update.setText(String.format("%s", ClassUtility.convertSecondsToMinutesSeconds(tmp)));

		int tmpInt = Location.getLocationsWaitingForSendCount(globals.locations);
		textViewLocQueue.setText(String.format("%d",tmpInt));

		tvTotalLocations.setText(String.format("%d",globals.locations.size()));
		tvTotalMiles.setText(String.format("%1.2f",wp.getTotalMiles()));


		set_status(raceowl.getTrackingStatus(), raceowl.getTrackingStatusMessage());

		graphicsRefresh();
	}

	private enum track_menu
	{
		exportLocations,
		deleteAllLocations,
	}

	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
	{
		menu.add(0,track_menu.exportLocations.ordinal(),0,"Export CSV");
		menu.add(0, track_menu.deleteAllLocations.ordinal(), 0, "Clear Location Queue");
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		track_menu value = track_menu.values()[item.getItemId()];

		boolean ret = true;
		switch (value)
		{
			case exportLocations:
				exportLocations();
				break;
			case deleteAllLocations:

				raceowl.clearLocations();

				if (globals.locations.size()>0) {
					AlertDialog.Builder builder;
					builder = new AlertDialog.Builder(getActivity());
					AlertDialog alertDialog = builder.setMessage(String.format("Remove %d locations from log. Are you sure?", globals.locations.size())).setPositiveButton("Yes", dialogClearLocations)
							.setNegativeButton("No", dialogClearLocations).show();
				}
				else
				{
					Toast.makeText(globals.appState.ctx, "no locations to delete", Toast.LENGTH_SHORT).show();
				}
				break;
			default:
				super.onOptionsItemSelected(item);
		}
		update();
		return true;
	}

	// ------------------------------------------------------------------------
	//	Are you sure dialog handler
	// ------------------------------------------------------------------------
	private final DialogInterface.OnClickListener dialogClearLocations = new DialogInterface.OnClickListener()
	{
		@Override
		public void onClick(DialogInterface dialog, int which)
		{
			switch (which)
			{
				case DialogInterface.BUTTON_POSITIVE:
					raceowl.clearLocations();
					break;

				case DialogInterface.BUTTON_NEGATIVE:
					break;
			}
		}
	};



	@TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
	private void set_status(boolean online, String msg) {

		TextView t4 = v.findViewById(R.id.update_status);
		t4.setText(msg);

		if (online) {
			t4.setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
		} else {
			t4.setBackgroundColor(getResources().getColor(android.R.color.holo_red_dark));
		}
		t4.setTextColor(getResources().getColor(android.R.color.white));
	}
	// ---------------------------------------------------------------------------------------------
	// exportRoute
	// ---------------------------------------------------------------------------------------------
	private void exportLocations()
	{
		boolean success = true;

		//verify there is something to write
		if (globals.locations.size() <= 0)
		{
			success = false;
			Toast.makeText(globals.appState.ctx, "nothing to export", Toast.LENGTH_SHORT).show();
		}

		if (success)
		{
			RaceOwlAPI.RaceEvent item = raceowl.getRaceItem(globals.settings.RaceEventID);
			String outFile = 	(String.format("%s_locations.csv", item.RaceCode));
			writeLocationCSV(outFile, globals.locations);
			Toast.makeText(globals.appState.ctx, String.format("%s exported", outFile), Toast.LENGTH_SHORT).show();
		}
	}

	// ------------------------------------------------------------------------
	//	writeLocationCSV - internal/external storage
	// ------------------------------------------------------------------------
    private void writeLocationCSV(String filename, ArrayList<Location> locations)
	{
		if (locations.size()>0)
		{
			ArrayList<String> lines = new ArrayList<>();

			lines.add("time,lat(deg),lon(deg)");

			for(Location item : locations)
			{
				Date locTime = ClassUtility.convertUTCtoDate(item.llt.utcTime_ms);
				lines.add(String.format("%s,%1.7f,%1.7f", locTime.toString(), item.llt.pt.latitude_rad * Const.rtd, item.llt.pt.longitude_rad * Const.rtd));
			}

			ClassFileIO.writeExternalFile(filename, lines);
		}
	}
}

