package com.ProPaddlerMi;

import android.util.Log;

import com.ProPaddlerMi.baseclass.GPSData;
import com.ProPaddlerMi.baseclass.LatLngRad;
import com.ProPaddlerMi.baseclass.RacerState;
import com.ProPaddlerMi.baseclass.Route;
import com.ProPaddlerMi.utility.Const;
import com.ProPaddlerMi.utility.UTCTime;

@SuppressWarnings("WeakerAccess")
public class RacerStateManager
{


    // ----------------------------------------------------------------------
    //  setRacerState
    //	Update the geo-position state of the racer
    // ----------------------------------------------------------------------
    public static void setRacerState(RacerState racerState)
    {
        pushRacerState(racerState); // add the racer state
    }


    // ----------------------------------------------------------------------
    //  setRacerState
    //	Update the geo-position state of the racer
    // ----------------------------------------------------------------------
    public static RacerState setRacerState(double lat_deg, double lon_deg, double speed_mps, double actual_bearing_deg, double accuracy_m, long time_ms)
    {

        Globals globals = Globals.getInstance();

        // verify that we have a route
        boolean isValidRoute = Route.verifyRoute(globals.route);

        // Update the racer state
        // get the current location
        GPSData loc = new GPSData(new LatLngRad(lat_deg * Const.dtr, lon_deg * Const.dtr), speed_mps, actual_bearing_deg * Const.dtr, accuracy_m, time_ms);

        RacerState s1;

        if (isValidRoute) {
            //update the state, get the last saved or init a new location
            RacerState s0 = globals.racerStates.size() > 0 ? getRacerState() : new RacerState(loc, globals.route);

            // update to the new state
            //s1 = new RacerState(loc, globals.route, s0);
            s1 = new RacerState(loc, globals.route);

            pushRacerState(s1); // add the racer state
        }
        else
        {
            s1 = new RacerState();
            Log.d(globals.appState.appName, "attempt to update racer state with invalid Route");
        }

        return (s1);

    }


    // ---------------------------------------------------------------------------------------------
    //     getRecentRacerState() - return the best estimate of the racer's state
    // ---------------------------------------------------------------------------------------------
    public static RacerState getRacerState()
    {
        Globals globals = Globals.getInstance();

        int count = globals.racerStates.size();
        RacerState ret;
        if (count > 0)
        {
            ret = new RacerState(globals.racerStates.get(count-1));
        }
        else
        {
            ret = new RacerState(new GPSData(globals.route.cps[0].pt,0.0,0.0,0.0,0), globals.route); //  (new LatLngRad(), 0.0, new Date(), globals.route, globals.settings.RaceEventID, globals.settings.boat_number);
        }
        return (ret);
    }

    public static void resetSpeeds() {
        RacerState s0 = getRacerState();
        s0.summary.avgSpeed_mps = s0.pose1.gpsVel_mps;
        s0.summary.maxSpeed_mps = s0.pose1.gpsVel_mps;
        pushRacerState(s0);
    }

    public static void resetTimeAndMiles() {
        RacerState s0 = getRacerState();
        s0.summary.totDist_m = 0.0;
        s0.checkPointStatus.checkPointHistories[0].exit.time = UTCTime.getCurrentUTC();
        pushRacerState(s0);
    }

    // ---------------------------------------------------------------------------------------------
    // pushRacerState
    // ---------------------------------------------------------------------------------------------
    public static  void pushRacerState(RacerState s0)
    {
        Globals globals = Globals.getInstance();

        globals.racerStates.add(s0);
        if (globals.racerStates.size() > globals.maxRacerState)
        {
            globals.racerStates.remove(0);
        }
    }
}
