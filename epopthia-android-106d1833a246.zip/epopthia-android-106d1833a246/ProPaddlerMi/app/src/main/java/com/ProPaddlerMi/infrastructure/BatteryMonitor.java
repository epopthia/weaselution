package com.ProPaddlerMi.infrastructure;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.util.Log;

public class BatteryMonitor extends BroadcastReceiver
{

    private boolean isCharging;
    public float batteryPercent;
    public boolean isLowBatteryWarning;

    private static BatteryMonitor objBatteryMonitor;

    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized BatteryMonitor getInstance()
    {
        if(objBatteryMonitor == null)
        {
            objBatteryMonitor = new BatteryMonitor();
        }
        return objBatteryMonitor;
    }

    private BatteryMonitor()
    {
        isCharging = false;
        batteryPercent = 50;
        isLowBatteryWarning = false;
    }

    public IntentFilter getIntentFilter()
    {
        IntentFilter  ifilter = new IntentFilter();
//        ifilter.addAction(Intent.ACTION_POWER_CONNECTED);
//        ifilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        ifilter.addAction(Intent.ACTION_BATTERY_CHANGED);

        return (ifilter);
    }


    @Override
    public void onReceive(Context context, Intent intent)
    {

        String action = intent.getAction();

        if (action != null) {
            //                case Intent.ACTION_POWER_CONNECTED:
            //                    isCharging = true;
            //                    //Toast.makeText(context, "The device is charging", Toast.LENGTH_SHORT).show();
            //                    Log.d("ProPaddlerMi", "battery: ACTION_POWER_CONNECTED");
            //                    break;
            //                case Intent.ACTION_POWER_DISCONNECTED:
            //                    isCharging = false;
            //                    //Toast.makeText(context, "The device is not charging", Toast.LENGTH_SHORT).show();
            //                    Log.d("ProPaddlerMi", "battery: ACTION_POWER_DISCONNECTED");
            //                    break;
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;

                if (level == -1 || scale == -1 || scale == 0) {
                    batteryPercent = 50.0f;
                } else {
                    batteryPercent = ((float) level / (float) scale) * 100.0f;
                }
                Log.d("ProPaddlerMi", "battery: ACTION_BATTERY_CHANGED");
            }
        }

        // set warning
        isLowBatteryWarning = !isCharging && batteryPercent < 15.0f;


    }


}