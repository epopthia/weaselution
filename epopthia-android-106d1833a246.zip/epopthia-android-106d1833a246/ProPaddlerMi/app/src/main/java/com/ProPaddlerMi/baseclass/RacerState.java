package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;
import com.ProPaddlerMi.utility.UTCTime;

import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;


@SuppressWarnings("WeakerAccess")
public class RacerState {

    public enum ErrorCode {
        normal,
        notInitialized
    }

    public enum RaceStatus {
        IN,
        OUT,
        DNF
    }

    public final int raceTeamId;                      // team identifier
    public LatLngTime reported;                 // current reported position (could be in error)
    public Pose pose0;                          // location and time of the previous location fix (validated)
    public Pose pose1;                          // location and time of the current location fix (validated)
    public Track track;                         // defined by self location history
    public RouteRelative routeRelative;         // defined by location history relative to the route
    public CheckPointStatus checkPointStatus;   // current status, eta and history of cycled checkpoints
    public StateSummary summary;                // state summary - include speeds, total distance, and elapsed time, timezone
    public ArrayList<StateError> errors;        // a compilation of state errors

    //constructors
    public RacerState() {
        raceTeamId = 0;
        reported = new LatLngTime();
        pose0 = new Pose();
        pose1 = new Pose();
        track = new Track(pose1);
        routeRelative = new RouteRelative();
        checkPointStatus = new CheckPointStatus();
        summary = new StateSummary();

        errors = new ArrayList<>();
        StateError err = new StateError();
        err.errorType = StateError.ErrorType.RacerState;
        err.code = ErrorCode.notInitialized.ordinal();
        errors.add(err);
    }

    /// <summary>
    /// Racer state copy
    /// </summary>
    public RacerState(RacerState s0) {
        raceTeamId = s0.raceTeamId;
        reported = new LatLngTime(s0.reported);
        pose0 = new Pose(s0.pose0);
        pose1 = new Pose(s0.pose1);
        track = new Track(s0.track);
        routeRelative = new RouteRelative(s0.routeRelative);
        checkPointStatus = new CheckPointStatus(s0.checkPointStatus);
        summary = new StateSummary(s0.summary);
        errors = new ArrayList<>(s0.errors);             // a compilation of state errors
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// Start of race RacerState. This constructor should be called as we start a race.
    /// </summary>
    /// <param name="loc1">GPS location of the racer</param>
    /// <param name="route">route information that contains checkpoint and waypoint data</param>
    /// <returns type="RacerState" />
    //----------------------------------------------------------------------------------------------
    public RacerState(GPSData loc1, Route route) {
        this();
        int idx = 0; // starting checkpoint
        pose0 = new Pose();
        pose1 = new Pose(loc1);
        reported = new LatLngTime(pose1.pt, pose1.utc_ms);
        track = new Track(pose1);
        routeRelative = new RouteRelative(pose1, route);
        summary = new StateSummary(this, route.routeTimeZone);
        checkPointStatus = new CheckPointStatus(route.cps, loc1.ptt.utcTime_ms, false);
        errors = CompileRacerStateErrors(this);
    }

    //----------------------------------------------------------------------------------------------
    /// The constructor for RacerState after you have a valid previous racerstate
    /// </summary>
    /// <param name="loc1">GPS data</param>
    /// <param name="route">route information that contains checkpoint and waypoint data</param>
    /// <param name="s0">prior racerState</param>
    /// <returns type="RacerState" />
    //----------------------------------------------------------------------------------------------
    public RacerState(GPSData loc1, Route route, RacerState s0) {
        this(s0);

        boolean success = true;

        reported = new LatLngTime(loc1); //always retain the reported GPS

        // clear any old errors
        errors = new ArrayList<>();

        // test position
        Pose testPose = new Pose(loc1, s0);
        if (testPose.errors.size() > 0) {
            this.pose1.errors = new ArrayList<>(testPose.errors); //save the errors but retain the prior location
            success = false;
        }

        // test own path
        Track testTrack = new Track(testPose, s0);
        if (success && testTrack.errors.size() > 0) {
            this.track.errors = new ArrayList<>(testTrack.errors); //save the errors but retain the prior track
            success = false;
        }

        // get position relative to the route
        RouteRelative testRouteRelative = new RouteRelative(reported, testPose, testTrack, route, s0);
        if (success && testRouteRelative.errors.size() > 0) {
            this.routeRelative.errors = new ArrayList<>(testRouteRelative.errors); //save the errors but retain the prior track
            success = false;
        }

        // we have valid data, update the state all at once with consistent values
        if (success) {
            pose0 = new Pose(s0.pose1);  // set last position
            pose1 = testPose;
            track = testTrack;
            routeRelative = testRouteRelative;
            summary = new StateSummary(this, s0, route);  // current speed update
            checkPointStatus = new CheckPointStatus(pose1, routeRelative, summary, route, s0); // update the checkpoint status/estimates

            FinalizeState();  // perform any go back calculations needed on the state (eg the race has ended so fix the avg speed for overall race
        }

        errors = CompileRacerStateErrors(this);
    }

    public void Reset(GPSData resetLocationAndTime, Route route) {
        long utc_ms = resetLocationAndTime.ptt.utcTime_ms;
        pose0 = new Pose(resetLocationAndTime);
        pose1 = new Pose(resetLocationAndTime);
        reported = new LatLngTime(resetLocationAndTime);
        track = new Track(pose0);
        routeRelative = new RouteRelative(pose1, route);

    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// CompileRacerStateErrors
    /// </summary>
    //----------------------------------------------------------------------------------------------
    private ArrayList<StateError> CompileRacerStateErrors(RacerState s1) {
        ArrayList<StateError> errors = new ArrayList<>();

        for (Pose.ErrorCode code : s1.pose1.errors) {
            StateError error = new StateError(StateError.ErrorType.Pose, code.ordinal(), Pose.ErrorCodeMessage(code.ordinal()));
            errors.add(error);
        }
        for (Track.ErrorCode code : s1.track.errors) {
            StateError error = new StateError(StateError.ErrorType.Track, code.ordinal(), Track.ErrorCodeMessage(code.ordinal()));
            errors.add(error);
        }
        for (RouteRelative.ErrorCode code : s1.routeRelative.errors) {
            StateError error = new StateError(StateError.ErrorType.RouteRelative, code.ordinal(), RouteRelative.ErrorCodeMessage(code.ordinal()));
            errors.add(error);
        }

        return (errors);
    }

    private ArrayList<StateError> ExpandMinStateErrors(ArrayList<MinStateError> minErrors) {
        ArrayList<StateError> errors = new ArrayList<>();

        for (MinStateError me : minErrors) {
            StateError error;
            switch (me.errorType) {
                case Pose:
                    error = new StateError(StateError.ErrorType.Pose, me.code, Pose.ErrorCodeMessage(me.code));
                    errors.add(error);
                    break;
                case Track:
                    error = new StateError(StateError.ErrorType.Track, me.code, Track.ErrorCodeMessage(me.code));
                    errors.add(error);
                    break;
                case RouteRelative:
                    error = new StateError(StateError.ErrorType.RouteRelative, me.code, RouteRelative.ErrorCodeMessage(me.code));
                    errors.add(error);
                    break;
                default:
                    error = new StateError();
                    error.errorType = me.errorType;
                    error.code = me.code;
                    errors.add(error);
                    break;
            }
        }
        return (errors);
    }

    public Date GetStateTime() {
        //TimeZone TimeZone = TimeZone.FindSystemTimeZoneById(summary.timeZone);
        return (UTCTime.getDateTimeFromUTC(reported.utcTime_ms, summary.timeZone));
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// GetRaceDistance in meters
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public double GetRaceDistance() // in m
    {
        double raceDistance_m;
        if (!checkPointStatus.RaceStarted()) {
            raceDistance_m = 0;
        } else if (checkPointStatus.RaceFinished()) {
            raceDistance_m = checkPointStatus.FinishValue() - checkPointStatus.StartValue();
        } else {
            raceDistance_m = routeRelative.value_m - checkPointStatus.StartValue();
        }
        return (raceDistance_m);
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// EstimateRouteDistance in meters
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public double EstimateRouteDistance(long curr_UTC_time_ms) {
        double estRouteDist_m;
        // difficulty here is what you assume is the latest data. the last reported time may be different that
        // the last accepted system pose.
        double distDelta_m = 0;
        //if there is a delta between reported and pose, then we are in an error state. don't make estimate assumptions
        boolean isNoError = errors.size() == 0;
        if (isNoError) {
            distDelta_m = ((curr_UTC_time_ms - pose1.utc_ms) * Const.ms_to_sec) * summary.avgSpeed_mps;
        }
        estRouteDist_m = routeRelative.value_m + distDelta_m;
        estRouteDist_m = Math.min(checkPointStatus.FinishValue(), estRouteDist_m);
        estRouteDist_m -= checkPointStatus.StartValue();
        return (estRouteDist_m);
    }

    // ---------------------------------------------------------------------------------------------
    // GetCheckPointDistance
    // estimate arrival in ms to the specified checkpoint. This function assumes you continue
    // at average speed - it does not take into account rest stops
    // todo: add a crosstrack offset, this now returns the channel location
    // ---------------------------------------------------------------------------------------------
    public double GetNextCheckPointDistance() {
        int checkPointIndex = checkPointStatus.current.nextCheckpointIndex;
        return (checkPointStatus.checkPointHistories.length > checkPointIndex ? checkPointStatus.checkPointHistories[checkPointIndex].value_m - routeRelative.value_m : 0.0);
    }

    // ---------------------------------------------------------------------------------------------
    // GetCheckPointDistance
    // estimate arrival in ms to the specified checkpoint. This function assumes you continue
    // at average speed - it does not take into account rest stops
    // todo: add a crosstrack offset, this now returns the channel location
    // ---------------------------------------------------------------------------------------------
    public double GetCheckPointDistance(int checkPointIndex) {
        return (checkPointStatus.checkPointHistories.length > checkPointIndex ? checkPointStatus.checkPointHistories[checkPointIndex].value_m - routeRelative.value_m : 0.0);
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// GetNextCheckPointName
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public String GetNextCheckPointName() {
        int checkPointIndex = checkPointStatus.current.nextCheckpointIndex;
        return (checkPointStatus.checkPointHistories.length > checkPointIndex ? checkPointStatus.checkPointHistories[checkPointIndex].CheckpointName : "NA");
    }


    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// return the split time for a selected checkpoint (as a String)
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public String GetSplitDateTimeString(int checkpointIndex, RaceStatus raceStatus) {
        Date myDate = GetSplitDateTime(checkpointIndex, raceStatus);
        return (myDate.toString());
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// return the split time for a selected checkpoint (as a String)
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public String GetDateTimeString(Date Date) {
        return (Date.toString());
    }


    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// Get the split time for a selected checkpoint
    /// </summary>
    /// <param name="checkpointIndex">information on the checkpoint we are cycling</param>
    /// <param name="raceStatus">route information that contains checkpoint and waypoint data</param>
    /// <returns type="Date" />
    //----------------------------------------------------------------------------------------------
    public Date GetSplitDateTime(int checkpointIndex, RaceStatus raceStatus) {
        Date ret = null;
        if (checkpointIndex >= 0 && checkpointIndex < checkPointStatus.checkPointHistories.length) {
            long testTime = 0;
            PointHistory.PointHistoryState testState;
            switch (raceStatus) {
                case IN:
                    testTime = checkPointStatus.checkPointHistories[checkpointIndex].enter.time;
                    break;
                case OUT:
                    testTime = checkPointStatus.checkPointHistories[checkpointIndex].exit.time;
                    break;
                case DNF:
                    testState = checkPointStatus.checkPointHistories[checkpointIndex].enter.state;
                    testTime = testState == PointHistory.PointHistoryState.dnf ? checkPointStatus.checkPointHistories[checkpointIndex].enter.time : 0;
                    break;
            }

            ret = testTime > 0 ? UTCTime.getDateTimeFromUTC(testTime, summary.timeZone) : null;
        }
        return (ret);
    }


    // ---------------------------------------------------------------------------------------------
    // estimateCheckpointArrival
    // estimate arrival in ms to the specified checkpoint. This function assumes you continue
    // at average speed - it does not take into account rest stops
    // todo: add a crosstrack offset, this now returns the channel location
    // ---------------------------------------------------------------------------------------------
    public Date EstimateCheckPointTime(int index) {
        long estUTC_ms = 0;
        if (checkPointStatus.checkPointHistories[index].enter.state == PointHistory.PointHistoryState.cycled) {
            estUTC_ms = checkPointStatus.checkPointHistories[index].enter.time;
        } else {

            double distDelta_m = GetCheckPointDistance(index);
            if (summary.avgSpeed_mps > Const.epsilon) {
                long deltaT_ms = (long) ((distDelta_m / summary.avgSpeed_mps) * Const.sec_to_ms);
                estUTC_ms = pose1.utc_ms + deltaT_ms;
            }
        }
        return (UTCTime.getDateTimeFromUTC(estUTC_ms, summary.timeZone));
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// estimate arrival in ms to the specified checkpoint.
    /// </summary>
    //----------------------------------------------------------------------------------------------
    public long EstimateCheckPointUtcTime(int index) {
        long estUTC_ms = 0;
        if (checkPointStatus.checkPointHistories[index].enter.state == PointHistory.PointHistoryState.cycled) {
            estUTC_ms = checkPointStatus.checkPointHistories[index].enter.time;
        } else {

            double distDelta_m = GetCheckPointDistance(index);
            if (summary.avgSpeed_mps > Const.epsilon) {
                long deltaT_ms = (long) ((distDelta_m / summary.avgSpeed_mps) * Const.sec_to_ms);
                estUTC_ms = pose1.utc_ms + deltaT_ms;
            }
        }
        return (estUTC_ms);
    }


    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// the the elapsed time from a reference
    /// </summary>
    /// <param name="timeToCalcElapsedTimeTo_ms"> typically the current time</param>
    /// <returns type="long" />
    //----------------------------------------------------------------------------------------------
    public long GetRaceElapsedTime(long timeToCalcElapsedTimeTo_ms) {
        long deltaTime_ms;

        if (!checkPointStatus.RaceStarted() || checkPointStatus.StartTime() == 0) {
            deltaTime_ms = 0;
        } else if (checkPointStatus.RaceFinished()) {
            deltaTime_ms = checkPointStatus.FinishTime() - checkPointStatus.StartTime();
        } else {
            deltaTime_ms = timeToCalcElapsedTimeTo_ms - checkPointStatus.StartTime();
        }

        // add penalty
        deltaTime_ms += summary.penaltyMinutes * Const.minute_to_msec;

        return (deltaTime_ms);
    }

    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// Get the split distance for a selected checkpoint
    /// </summary>
    /// <param name="checkpointIndex">information on the checkpoint we are cycling</param>
    /// <returns type="double" />
    //----------------------------------------------------------------------------------------------
    public double GetSplitDistance(int checkpointIndex) {
        double ret = 0.0;
        if (checkpointIndex > checkPointStatus.startIndex && checkpointIndex < checkPointStatus.checkPointHistories.length) {
            ret = checkPointStatus.checkPointHistories[checkpointIndex].value_m - checkPointStatus.checkPointHistories[checkpointIndex - 1].value_m;
        }
        return (ret);
    }


    // ---------------------------------------------------------------------------------------------
    // estimatePosition
    // estimate a future position along the route
    // todo: add a crosstrack offset, this now returns the channel location
    // ---------------------------------------------------------------------------------------------
    public double EstimatePosition(long utc_time_ms, Route route)
    {
        double est_value_m;
        // estimate the position. If we have cycled the last checkpoint then 
        // stop propagating the position
        if (routeRelative.atCp) // || cp_history.Last().exit.state == PointHistory.PointHistoryState.cycled)
        {
            int cpIdx = (int)Math.round(routeRelative.cpIndex);
            est_value_m = route.cps[cpIdx].value_m;
        }
        else
        {
            // get  average speed and time delta
            double deltaT_s = (utc_time_ms - pose1.utc_ms) * Const.ms_to_sec;
            est_value_m = routeRelative.value_m + (deltaT_s * summary.avgSpeed_mps);
        }

        return (est_value_m);
    }

    public static LatLngRad LookupPoint(double value, Route route)
    {
        LatLngRad ret = new LatLngRad();
        if (route.wps.length > 0)
        {
            InterpolateResult res = Interpolate.InterpolateIndex2D(value, route.ivs);
            ret.latitude_rad = (1.0 - res.alpha) * route.wps[res.iLower].pt.latitude_rad + res.alpha * route.wps[res.iUpper].pt.latitude_rad;
            ret.longitude_rad = (1.0 - res.alpha) * route.wps[res.iLower].pt.longitude_rad + res.alpha * route.wps[res.iUpper].pt.longitude_rad;
        }
        return (ret);
    }
    //----------------------------------------------------------------------------------------------
    /// <summary>
    /// perform any go back calculations needed on the state (eg the race has ended so fix the avg speed for overall race)
    /// </summary>
    //----------------------------------------------------------------------------------------------
    void FinalizeState() {
        //if the race is complete then finalize
        if (checkPointStatus.RaceFinished()) {
            // of we are done, then calc the final avg speed. total dist / total time
            summary.avgSpeed_mps = (GetRaceDistance() / (GetRaceElapsedTime(0) * Const.ms_to_sec));

            //// of we are done, then calc the final avg speed. total dist / total time
            //summary.avgSpeed_mps = (GetRaceDistance() / (GetRaceElapsedTime(0) * Const.ms_to_sec));

        }
    }


    static public ArrayList<RacerState> EvolveState(Route route, boolean isVariableStart, ArrayList<GPSData> locations) {
        ArrayList<RacerState> allStates = new ArrayList<>();
        TimeZone localTimeZone = TimeZone.getTimeZone(route.routeTimeZone);

        if (locations.size() > 0) {
            long raceStartUtc_ms = -1;
            long raceEndUtc_ms = -1;
            for (GPSData loc : locations) {
                raceStartUtc_ms = raceStartUtc_ms < 0 || loc.ptt.utcTime_ms < raceStartUtc_ms ? loc.ptt.utcTime_ms : raceStartUtc_ms;
                raceEndUtc_ms = raceEndUtc_ms < 0 || loc.ptt.utcTime_ms > raceEndUtc_ms ? loc.ptt.utcTime_ms : raceEndUtc_ms;
            }
//                raceStartUtc_ms-=Const.day_to_msec;
//                raceEndUtc_ms+=Const.day_to_msec;
            RacerState lastState = null;
            RacerState rs;
            for (int inx = 0; inx < locations.size(); inx++) {
                rs = new RacerState(locations.get(inx), route, lastState);
                allStates.add(rs);
                if (rs.errors.size() == 0 && rs.track.trackSegment.rb.range_m > 0) {
                    lastState = new RacerState(rs);
                    lastState.checkPointStatus.setUpdateCheckPoint(false);
                }
            }
        }
        return (allStates);
    }


    static public CheckPointCurrent GetCurrent(RacerState s1) {
        CheckPointCurrent current = new CheckPointCurrent();
        String status = "";

        // update the latest
        for (int inx = s1.checkPointStatus.checkPointHistories.length - 1; inx >= 0; inx--) {
            if (s1.checkPointStatus.checkPointHistories[inx].enter.state != PointHistory.PointHistoryState.unknown) {
                current.nextCheckpointIndex = Math.min(s1.checkPointStatus.checkPointHistories.length - 1, inx + 1);
                current.isEntry = true;
                current.currentIndex = inx;
                current.currentCycle.state = s1.checkPointStatus.checkPointHistories[inx].enter.state;
                current.currentCycle.time = s1.checkPointStatus.checkPointHistories[inx].enter.time;
                break;
            } else if (s1.checkPointStatus.checkPointHistories[inx].exit.state != PointHistory.PointHistoryState.unknown) {
                current.nextCheckpointIndex = Math.min(s1.checkPointStatus.checkPointHistories.length - 1, inx + 1);
                current.isEntry = false;
                current.currentIndex = inx;
                current.currentCycle.state = s1.checkPointStatus.checkPointHistories[inx].exit.state;
                current.currentCycle.time = s1.checkPointStatus.checkPointHistories[inx].exit.time;
                break;
            }
        }
        return (current);
    }
}

