package com.ProPaddlerMi.baseclass;

public class PointHistory
{
    public long time;
    public PointHistoryState state;

    public PointHistory()
    {
        time = 0;
        state = PointHistoryState.unknown;
    }

    public PointHistory(PointHistory s0)
    {
        time = s0.time;
        state = s0.state;
    }

    //private long getTime()
    //{
    //    long utc_ms = UTCTime.GetCurrentUTC();
    //    return (utc_ms);
    //}

    public enum PointHistoryState
    {
        unknown,
        cycled,
        dnf,
        armed,
        sent
    }
}
