package com.ProPaddlerMi;

public class ClassObj
{
	String rawobj;
	final float[] value_km;
	public double[] lat_rad;
	public double[] lon_rad;
	
	
	ClassObj()
	{
		rawobj = "";
		double[] lat_rad = new double[0];
		double[] lon_rad = new double[0];
		value_km = new float[2];
	}
}

