package com.ProPaddlerMi.baseclass;

public class CheckPointHistory {

        public String CheckpointName;
        public int SeqNbr;
        public double value_m;
        public PointHistory enter;
        public PointHistory exit;
        public boolean update;
        public CheckPointHistory()
        {
            CheckpointName = "";
            SeqNbr = 0;
            value_m = 0.0;
            enter = new PointHistory();
            exit = new PointHistory();
            update = false;
        }
        public CheckPointHistory(CheckPointHistory s0)
        {
            CheckpointName = s0.CheckpointName;
            SeqNbr = s0.SeqNbr;
            value_m = s0.value_m;
            enter = new PointHistory(s0.enter);
            exit = new PointHistory(s0.exit);
            update = s0.update;
        }
}
