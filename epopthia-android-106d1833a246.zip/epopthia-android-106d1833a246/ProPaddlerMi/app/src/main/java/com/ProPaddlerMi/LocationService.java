package com.ProPaddlerMi;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.widget.Toast;

import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import java.util.List;
import java.util.Objects;


public class LocationService extends Service {
    private static final String BROADCAST_ACTION = "Mi_LOCATION";
    private static final float LOCATION_REFRESH_DISTANCE = 0;
    private static final long LOCATION_REFRESH_TIME = 2000;
    private LocationManager locationManager;
    private MyLocationListener listener;
    private long current_update_rate_ms;


    private Intent intent;

    public LocationService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        int NOTIFICATION_ID = 9954;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForeground(NOTIFICATION_ID, getNotification());
        }
        intent = new Intent(BROADCAST_ACTION);
    }

    // ---------------------------------------------------------------------------------------------
    // notification must be setup for api > 26 for background use
    // ---------------------------------------------------------------------------------------------
    private Notification getNotification() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String chid = String.format("%s%d", Const.appPackage, 1);
            NotificationChannel channel = new NotificationChannel(chid,"ProPaddler Foreground Service", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            Notification.Builder builder = new Notification.Builder(getApplicationContext(),chid);
            return builder.build();
        }
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        //String bestProvider = getBestProvider();
        String bestProvider = "gps";  //workaround for Android 12 bug

        long refresh_time_ms = LOCATION_REFRESH_TIME;
        if (intent != null) {
            refresh_time_ms = intent.getLongExtra("update_rate_ms", LOCATION_REFRESH_TIME);
        }
        current_update_rate_ms = refresh_time_ms;
        lastLocTime_ms = ClassUtility.getDate().getTime();
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        listener = new MyLocationListener();

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED )
        {
            locationManager.requestLocationUpdates(bestProvider, refresh_time_ms, LOCATION_REFRESH_DISTANCE, listener);
        }

        registerBroadcastReceiver();

        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        unregisterBroadcastReceiver();
        if (locationManager != null) {
            locationManager.removeUpdates(listener);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            stopForeground(true);
            stopSelf();
        }

        Log.v("STOP_SERVICE", "DONE");
        super.onDestroy();
    }

    // ----------------------------------------------------------------------
    //  getBestProvider
    // ----------------------------------------------------------------------
    private String getBestProvider() {
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setSpeedAccuracy(Criteria.ACCURACY_HIGH);
        criteria.setBearingAccuracy(Criteria.ACCURACY_HIGH);
        criteria.setBearingRequired(true);
        criteria.setSpeedRequired(true);
        return locationManager.getBestProvider(criteria, false);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    private long lastLocTime_ms = 0;


    private class MyLocationListener implements LocationListener {

        public void onLocationChanged(final Location loc)
        {

            intent.putExtra("gpsDisabled", false);
            intent.putExtra("Latitude", loc.getLatitude());
            intent.putExtra("Longitude", loc.getLongitude());
            intent.putExtra("Provider", loc.getProvider());
            intent.putExtra("Speed", loc.getSpeed());
            intent.putExtra("Bearing", loc.getBearing());
            intent.putExtra("Time", loc.getTime());
            intent.putExtra("Accuracy", loc.getAccuracy());
            sendBroadcast(intent);

            //            long delta = curr - lastLocTime_ms;
            lastLocTime_ms = loc.getTime();

//            Log.d("ProPaddlerMi", String.format("GPS location change, time = %d",delta));

        }

        public void onProviderDisabled(String provider) {
            intent.putExtra("gpsDisabled", true);
            sendBroadcast(intent);
            Toast.makeText(getApplicationContext(), "Gps Disabled", Toast.LENGTH_SHORT).show();
        }

        public void onProviderEnabled(String provider)
        {
            Toast.makeText(getApplicationContext(), "Gps Enabled", Toast.LENGTH_SHORT).show();
        }

        public void onStatusChanged(String provider, int status, Bundle extras)
        {

        }

    }


    private static BroadcastReceiver mGPSControlReceiver;


    // ------------------------------------------------------------------------
    //      registerBroadcastReceiver
    // ------------------------------------------------------------------------
    private void registerBroadcastReceiver() {
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("Mi_GPS_CONTROL");
        mGPSControlReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String strAction = intent.getAction();

                assert strAction != null;
                if (Objects.requireNonNull(strAction).equals("Mi_GPS_CONTROL")) {
                    long update_rate_ms = intent.getLongExtra("update_rate_ms", LOCATION_REFRESH_TIME);
                    if (current_update_rate_ms != update_rate_ms)
                    {
                        current_update_rate_ms = update_rate_ms;
                        setLocationManagerUpdates(current_update_rate_ms);
                    }
                }
            }
        };
        this.registerReceiver(mGPSControlReceiver, theFilter);
    }

    //---------------------------------------------------------------------------
    // setLocationManagerUpdates
    //---------------------------------------------------------------------------
    private void setLocationManagerUpdates(long update_rate_ms)
    {
        //List<String> allProviders = locationManager.getAllProviders();
        //String bestProvider = getBestProvider();
        String bestProvider = "gps";  //Version 12 workaround

        Log.d("ProPaddlerMi", String.format("setLocationManagerUpdates (%1.0f sec)", (update_rate_ms / 1000.0)));
        locationManager.removeUpdates(listener);
        listener = new MyLocationListener();
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED )
        {
            locationManager.requestLocationUpdates(bestProvider, update_rate_ms, LOCATION_REFRESH_DISTANCE, listener);
        }
    }

    //---------------------------------------------------------------------------
    // unregisterReceiver
    //---------------------------------------------------------------------------
    private void unregisterBroadcastReceiver()
    {
        int apiLevel = Build.VERSION.SDK_INT;

        if (apiLevel >= 7)
        {
            try
            {
                this.unregisterReceiver(mGPSControlReceiver);
            }
            catch (IllegalArgumentException e)
            {
                mGPSControlReceiver = null;
            }
        }
        else
        {
            this.unregisterReceiver(mGPSControlReceiver);
            mGPSControlReceiver = null;
        }
    }
}