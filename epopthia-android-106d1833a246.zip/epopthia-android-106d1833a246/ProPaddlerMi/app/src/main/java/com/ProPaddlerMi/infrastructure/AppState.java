package com.ProPaddlerMi.infrastructure;

import android.content.Context;
import com.ProPaddlerMi.utility.ClassUtility;

@SuppressWarnings("WeakerAccess")
public class AppState {


    public enum QuickStartState
    {
        disabled,
        armed,
        displaying,
        displayed
    }

    public boolean isSoftStart;
    public boolean forceReset;
    public boolean gpsDisableWarningDisplayed;
    public final boolean gpsDisabled;
    public boolean isOnline;
    public QuickStartState quickStartState;
    public boolean racesInitializing;
    public boolean racesInitialized;
    public int racesInitializedRetryCount;
    public boolean screenOff;
    public boolean setRaceStartTime;
    public boolean enableSimulation;
    public boolean useDesiredFinishHr;
    public Context ctx;
//    public boolean appModeDiaglogDisplayed;
    public String appName;
    public String uid;  //unique device ID

    public AppState(){
        isSoftStart = false;
        appName = "";
        ctx =  null;
        forceReset = false;
        gpsDisableWarningDisplayed = false;
        gpsDisabled = false;
        isOnline = false;
        quickStartState = QuickStartState.armed;
        racesInitializing = false;
        racesInitialized = false;
        screenOff = false;
        setRaceStartTime = false;
        enableSimulation = false;
        uid = "";
        useDesiredFinishHr = true;
        racesInitializedRetryCount = 3;
    }
    public AppState(AppState src)
    {
        isSoftStart = src.isSoftStart;
        appName = src.appName;
        ctx =  src.ctx;
        forceReset = src.forceReset;
        gpsDisableWarningDisplayed = src.gpsDisableWarningDisplayed;
        gpsDisabled = src.gpsDisabled;
        isOnline = src.isOnline;
        quickStartState = src.quickStartState;
        racesInitializing = src.racesInitializing;
        racesInitialized = src.racesInitialized;
        screenOff = src.screenOff;
        setRaceStartTime = src.setRaceStartTime;
        enableSimulation = src.enableSimulation;
        uid = src.uid;
        useDesiredFinishHr = src.useDesiredFinishHr;
        racesInitializedRetryCount = src.racesInitializedRetryCount;
    }

    public AppState(Context mycontext){

        this();
        appName = ClassUtility.getApplicationName(mycontext);
        uid = ClassUtility.getUniqueID(mycontext);
        ctx = mycontext;
        isOnline = NetworkMonitor.isNetworkAvailable(ctx);
    }
}
