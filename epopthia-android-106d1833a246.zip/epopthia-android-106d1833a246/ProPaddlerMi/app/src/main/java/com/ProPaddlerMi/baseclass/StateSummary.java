package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.Const;

public class StateSummary {
    public double selSpeed_mps;                 // selected (best estimate) of the racer's current speed
    public double avgSpeed_mps;                 // average racer speed
    public double maxSpeed_mps;                 // max racer speed
    public double totRouteDist_m;               // total route distance traveled by the racer
    public double totDist_m;                    // total distance traveled by the racer
    public final String timeZone;                     // String that represents the race time zone
    public final int penaltyMinutes;                  // minutes added or subtraced from the total time
    public int stateCount;                      // racer state evolution count since init

    // set the init flag if needed
    // return true if the speed is initializing
    public boolean InitSpeed()
    {
        return (avgSpeed_mps < Const.minSpeed_mps ||
                avgSpeed_mps > Const.maxSpeed_mps ||
                stateCount < 2);
    }


    public StateSummary()
    {
        selSpeed_mps = -Const.epsilon;
        avgSpeed_mps = selSpeed_mps;
        maxSpeed_mps = selSpeed_mps;
        totRouteDist_m = 0.0;
        totDist_m = 0.0;
        timeZone = "Central Standard Time";
        penaltyMinutes = 0;
        stateCount = 0;
    }
    public StateSummary(StateSummary s0)
    {
        selSpeed_mps = s0.selSpeed_mps;
        avgSpeed_mps = s0.avgSpeed_mps;
        maxSpeed_mps = s0.maxSpeed_mps;
        totRouteDist_m = s0.totRouteDist_m;
        totDist_m = s0.totDist_m;
        timeZone = s0.timeZone;
        penaltyMinutes = s0.penaltyMinutes;
        stateCount = s0.stateCount;
    }

    public StateSummary(RacerState s1, String raceTimeZone)
    {
        selSpeed_mps = s1.pose1.gpsVel_mps;
        avgSpeed_mps = selSpeed_mps;
        maxSpeed_mps = selSpeed_mps;
        totRouteDist_m = 0.0;
        totDist_m = 0.0;
        timeZone = raceTimeZone;
        penaltyMinutes = s1.summary.penaltyMinutes;
        stateCount = 0;
    }


    public StateSummary(RacerState s1, RacerState s0)
    {
        this(s0.summary);
        // current speed update
        SelectCurrentSpeed(s1, s0);

        // average speed update
        CalcAvgSpeed(s1, s0, null);

        // max speed update
        CalcMaxSpeed(s0);

        // route distance
        CalcRouteRelativeDistance(s1, s0);

        // distance update
        totDist_m = s0.summary.totDist_m + s1.track.trackSegment.rb.range_m;

        // count (only count after a race has started, otherwise you may average in near 0 m/s)
        stateCount = s1.routeRelative.cpIndex < s0.checkPointStatus.startIndex ? 0 : s0.summary.stateCount + 1;
        stateCount = Math.min(stateCount, 10000);  // don't overflow
    }

    public StateSummary(RacerState s1, RacerState s0, Route route)
    {
        this(s0.summary);

        // current speed update
        SelectCurrentSpeed(s1,s0);

        // average speed update
        CalcAvgSpeed(s1, s0, route);

        // max speed update
        CalcMaxSpeed(s0);

        // route distance
        CalcRouteRelativeDistance(s1,s0);

        // distance update
        totDist_m = s0.summary.totDist_m + s1.track.trackSegment.rb.range_m;

        // count (only count after a race has started, otherwise you may average in near 0 m/s)
        stateCount = s1.routeRelative.cpIndex < s0.checkPointStatus.startIndex ? 0 : s0.summary.stateCount + 1;
        stateCount = Math.min(stateCount, 10000);  // don't overflow
    }

    // ----------------------------------------------------------------------
    //  selectCurrentSpeed - goes in route
    // ----------------------------------------------------------------------
    private void SelectCurrentSpeed(RacerState s1, RacerState s0)
    {
        //double trackSpeed_mps = track.  s1.track.speed_mps < Const.maxSpeedLimit_mps ? s1.track.speed_mps : -1.0;
        //double selSpeed_mps;

        // select GPS speed if available
        if (s1.pose1.gpsVel_mps > 0)  // TODO: 0 is a valid speed but is incorrectly pervasive in the DB, use GPS only if we are > 0
        {
            selSpeed_mps = s1.pose1.gpsVel_mps;
        }
        else
        {
            //calc route augmented position based speed
            double delta_m = Math.abs(s1.routeRelative.value_m - s0.routeRelative.value_m);
            if (delta_m > 0 && s1.track.trackSegment.dT_ms > 1)
            {
                selSpeed_mps = delta_m / (s1.track.trackSegment.dT_ms * Const.ms_to_sec);
            }
            else
            {
                //calc straight line position based speed, revert to avg speed if invalid
                selSpeed_mps = s1.track.trackSegment.dr_rad > 0 ? s1.track.trackSegment.posVel_mps : avgSpeed_mps;
            }
        }

        //revert to average speed if beyond the speed bound
        selSpeed_mps = selSpeed_mps >= Const.maxSpeed_mps ? avgSpeed_mps : selSpeed_mps;

    }

    //TODO: this is route only. Should also have a track based total
    // ----------------------------------------------------------------------
    //  calcTotalDistance
    // ----------------------------------------------------------------------
    private void CalcRouteRelativeDistance(RacerState s1, RacerState s0)
    {
        double delta_m = Math.abs(s1.routeRelative.value_m - s0.routeRelative.value_m);
        //delta_m = delta_m > track.trackSegment.rb.range_m ? delta_m : track.trackSegment.rb.range_m;
        totRouteDist_m = s0.summary.totRouteDist_m + delta_m;
    }

    //----------------------------------------------------------------------------------------------
    // calcMaxSpeed
    //----------------------------------------------------------------------------------------------
    private void CalcMaxSpeed(RacerState s0)
    {
        //retain last speed by default, overwrite if conditions warrant
        maxSpeed_mps = selSpeed_mps >= s0.summary.maxSpeed_mps ? selSpeed_mps : s0.summary.maxSpeed_mps;
    }

    //----------------------------------------------------------------------------------------------
    // calcAvgSpeed
    //----------------------------------------------------------------------------------------------
    private void CalcAvgSpeed(RacerState s1, RacerState s0, Route route)
    {
        double minSpeed;
        double maxSpeed;

        if (route == null)
        {
            minSpeed = Const.minSpeed_mps;
            maxSpeed = Const.maxSpeed_mps;
        }
        else
        {
            minSpeed = route.minSpeed_mps();
            maxSpeed = route.maxSpeed_mps();
        }

        // set initial condition 
        avgSpeed_mps = s0.summary.avgSpeed_mps;

        // select avg window
        final double avgLongDeltaTime_ms = 20 * Const.minute_to_msec; //time over which to average a speed (marathon route)
        final double avgShortDeltaTime_ms = 8 * Const.minute_to_msec; //time over which to average a speed (marathon route)
        final double marathonRoute_m = 20.0 * Const.mile_to_m;

        //retain last speed by default, overwrite if conditions warrant, use current speed if non initialized
        avgSpeed_mps = InitSpeed() ? selSpeed_mps : s0.summary.avgSpeed_mps;

        // if the speed is too slow, then we are going to assume that the racer is stopped and not
        // include the speed estimate enter the moving average.
        if (selSpeed_mps >= Const.minSpeed_mps && s1.track.trackSegment.dT_ms > 1)
        {
            double avgDeltaTime_ms = route.maxValue() > marathonRoute_m ? avgLongDeltaTime_ms : avgShortDeltaTime_ms;
            double tau = s1.track.trackSegment.dT_ms / avgDeltaTime_ms;
            tau = Math.max(0, tau);
            tau = Math.min(tau, 1.0);

            // speed is a moving average
            avgSpeed_mps = avgSpeed_mps + tau * (selSpeed_mps - avgSpeed_mps);
        }

        //bound the avgSpeed
        avgSpeed_mps = Math.min(Math.max(avgSpeed_mps, minSpeed), maxSpeed);
    }
}
