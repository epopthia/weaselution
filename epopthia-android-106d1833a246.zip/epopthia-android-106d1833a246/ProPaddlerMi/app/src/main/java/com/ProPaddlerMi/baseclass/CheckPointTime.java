package com.ProPaddlerMi.baseclass;

public class CheckPointTime
{
    public double actual_in_hr;  //elapsed time
    public double actual_out_hr;
    public double plan_rest_hr;
    public double rest_hr;
    public boolean text_out;


    public CheckPointTime()
    {
        actual_in_hr = -999;  //-999 is an invalid number indicating we've not been here yet
        actual_out_hr = -999;
        plan_rest_hr = 0.0;
        rest_hr = 0.0;
        text_out = false;
    }

    public CheckPointTime(CheckPointTime src)
    {
        actual_in_hr = src.actual_in_hr;
        actual_out_hr = src.actual_out_hr;
        plan_rest_hr = src.plan_rest_hr;
        rest_hr = src.rest_hr;
        text_out = src.text_out;
    }

}