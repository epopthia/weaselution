package com.ProPaddlerMi.baseclass;

public class CheckPointCurrent {
    public boolean isEntry;
    public int currentIndex;
    public PointHistory currentCycle;
    public String autoCheckpointStatus;
    public int nextCheckpointIndex;                     // index of the next expected checkpoint

    public CheckPointCurrent()
    {
        isEntry = false;
        currentIndex = 0;
        currentCycle = new PointHistory();
        autoCheckpointStatus = "DNS";
        nextCheckpointIndex = 1;                     // index of the next expected checkpoint
    }
    public CheckPointCurrent(CheckPointHistory[] cps)
    {
        this();

        isEntry = false;
        currentIndex = 0;
        currentCycle = new PointHistory();
        autoCheckpointStatus = "DNS";
        nextCheckpointIndex = 1;                     // index of the next expected checkpoint
    }


    public CheckPointCurrent(CheckPointCurrent s0)
    {
        isEntry = s0.isEntry;
        currentIndex = s0.currentIndex;
        currentCycle = new PointHistory(s0.currentCycle);
        autoCheckpointStatus = s0.autoCheckpointStatus;         //name of current checkpoint (TODO change this name)
        nextCheckpointIndex = s0.nextCheckpointIndex;                     // index of the next expected checkpoint
    }
}
