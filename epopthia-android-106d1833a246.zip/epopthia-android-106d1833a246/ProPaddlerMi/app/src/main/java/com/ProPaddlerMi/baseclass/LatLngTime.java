package com.ProPaddlerMi.baseclass;



//import com.google.android.gms.maps.model.LatLng;

import com.ProPaddlerMi.utility.UTCTime;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class LatLngTime
{
    public final LatLngRad pt;
    public final long utcTime_ms;  //the number of milliseconds between a specified date and midnight of January 1, 1970,

    public LatLngTime()
    {
        pt = new LatLngRad();
        utcTime_ms = 0;
    }

    public LatLngTime(GPSData gps)
    {
        pt = new LatLngRad(gps.ptt.pt);
        utcTime_ms = gps.ptt.utcTime_ms;
    }
    public LatLngTime(Pose pose)
    {
        pt = new LatLngRad(pose.pt);
        utcTime_ms = pose.utc_ms;
    }

    @SuppressWarnings("unused")
    public LatLngTime(double lat_rad, double lng_rad, long utc_time1_ms)
    {
        pt = new LatLngRad(lat_rad,lng_rad);
        utcTime_ms = utc_time1_ms;
    }

    public LatLngTime(LatLng pt0)
    {
        this(new LatLngRad(pt0));
    }

    public LatLngTime(LatLngRad pt0) {

        pt = new LatLngRad(pt0);
        Calendar c = Calendar.getInstance();
        int utcOffset = c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET);
        utcTime_ms = c.getTimeInMillis() + utcOffset;
    }

    public LatLngTime(LatLngRad pt0, long pt0_time_ms) {

        pt = new LatLngRad(pt0);
        utcTime_ms = pt0_time_ms;
    }

    public LatLngTime(LatLngTime pt0) {
        pt = new LatLngRad(pt0.pt);
        utcTime_ms = pt0.utcTime_ms;
    }

    public LatLngTime(LatLngRad pt0, Date dateTime, TimeZone timeZone)
    {
        pt = new LatLngRad(pt0);
        utcTime_ms = UTCTime.getUTCFromDateTime(dateTime);
    }

}
