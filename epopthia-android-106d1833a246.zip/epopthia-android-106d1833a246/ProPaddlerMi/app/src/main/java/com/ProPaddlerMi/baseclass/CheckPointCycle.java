package com.ProPaddlerMi.baseclass;

import com.ProPaddlerMi.utility.ClassUtility;
import com.ProPaddlerMi.utility.Const;

import java.util.ArrayList;
import java.util.Date;


// Race item fields
public  class CheckPointCycle
{

    public enum CheckPointCycleStatus
    {
        pending,
        sent,
        acknowledged,
        rejected,
        none
    }

    private Date entryTime;
    public Date lastAttemptToSend;
    public Date locationTime;
    public String BoatNumber;
    public int RaceEventID;
    public String Checkpoint;
    public String Status;
    public String TextLocationTime;
    public String NetLocationTime;
    public String Authorization;
    public CheckPointCycleStatus raceowl_status;
    public int MessageID;
    public int checkpoint_index;
    public boolean acknowledged;

    public CheckPointCycle()
    {
        BoatNumber = "";
        RaceEventID = -1;
        Checkpoint = "";
        Status = "";
        TextLocationTime = "";
        NetLocationTime = "";
        Authorization = "";
        lastAttemptToSend = ClassUtility.getDate(-10 * Const.hour_to_ms);  //move out of the way
        raceowl_status = CheckPointCycleStatus.none;
        MessageID = -1;
        checkpoint_index = -1;
        locationTime = new Date();
        entryTime = new Date();
        acknowledged = false;
    }


    public CheckPointCycle(CheckPointCycle s0)
    {
        this();
        BoatNumber = s0.BoatNumber;
        RaceEventID = s0.RaceEventID;
        Checkpoint = s0.Checkpoint;
        Status = s0.Status;
        TextLocationTime = s0.TextLocationTime;
        NetLocationTime = s0.NetLocationTime;
        Authorization = s0.Authorization;
        lastAttemptToSend = s0.lastAttemptToSend;
        raceowl_status = s0.raceowl_status;
        MessageID = s0.MessageID;
        checkpoint_index = s0.checkpoint_index;
        locationTime = s0.locationTime;
        acknowledged = s0.acknowledged;
        entryTime = s0.entryTime;
    }


    // ---------------------------------------------------------------------------------------------
    // addCheckPointCycle (CheckPointCycles are sent to RaceOwl)
    // ---------------------------------------------------------------------------------------------
    public static void addCheckPointCycle(ArrayList<CheckPointCycle> cpcs, CheckPointCycle cpc)
    {

        if (cpc != null && cpcs !=null)
        {
            CheckPointCycle item = new CheckPointCycle(cpc);
            item.MessageID = cpcs.size();
            cpcs.add(item);
        }
    }
    // ---------------------------------------------------------------------------------------------
    // getCheckPointCyclesWaitingForSend
    // ---------------------------------------------------------------------------------------------
    public static int getCheckPointCyclesWaitingForSendCount(ArrayList<CheckPointCycle> cpcs)
    {
        int count = 0;
        for (CheckPointCycle cpc : cpcs) {
            if (!cpc.acknowledged) {
                count++;
            }
        }
        return (count);
    }

    // ---------------------------------------------------------------------------------------------
    // getFirstCheckPointCyclesForSend
    // ---------------------------------------------------------------------------------------------
    public static CheckPointCycle getFirstCheckPointCyclesForSend(ArrayList<CheckPointCycle> cpcs)
    {
        for (CheckPointCycle cpc : cpcs) {
            if (!cpc.acknowledged) {
                return cpc;
            }
        }
        return(null);
    }

    // ---------------------------------------------------------------------------------------------
    // setCheckpointRaceOwlStatus
    // ---------------------------------------------------------------------------------------------
    public static void setCheckpointRaceOwlStatus(ArrayList<CheckPointCycle> cpcs, int messageID, CheckPointCycle.CheckPointCycleStatus status, boolean ack)
    {
        // for messageID not to be found in range, the cps would have to be cleared prior to
        // receipt of an ak. Could happen when no network
        if (messageID < cpcs.size()) {
            CheckPointCycle item = cpcs.get(messageID);
            item.raceowl_status = status;
            item.acknowledged = ack;
            cpcs.set(messageID, item);
        }
    }

    //---------------------------------------------------------------------------
    // getCheckpointCycleLatest
    //---------------------------------------------------------------------------
    static public CheckPointCycle getCheckpointCycleLatest(ArrayList<CheckPointCycle> cpcs)
    {
        CheckPointCycle latestItem = null;
        for (CheckPointCycle item:cpcs) {
            if (latestItem != null) {
                if (item.entryTime.after(latestItem.entryTime)) {
                    latestItem = item;
                }
            } else {
                latestItem = item;
            }
        }
        return (latestItem);
    }



//
//    //---------------------------------------------------------------------------
//    // filterCheckPointCycles
//    //---------------------------------------------------------------------------
//    public ArrayList<CheckPointCycle> filterCheckPointCycles(int eventid, String racerid)
//    {
//        ArrayList<CheckPointCycle> fcpcs = new ArrayList<>();
//
//        for (CheckPointCycle item:globals.checkPointCycles)
//        {
//            if (item.RaceEventID==eventid && item.BoatNumber.equalsIgnoreCase(racerid))
//            {
//                fcpcs.add(item);
//            }
//        }
//
//        return fcpcs;
//    }

}

