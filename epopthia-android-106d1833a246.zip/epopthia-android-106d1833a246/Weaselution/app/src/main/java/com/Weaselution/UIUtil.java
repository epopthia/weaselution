package com.Weaselution;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@SuppressWarnings("WeakerAccess")
class UIUtil {


	// ------------------------------------------------------------------------
	  //	addItemsOnSpinner (with init pos setting)
	  // ------------------------------------------------------------------------
	  // add upcoming_races into spinner dynamically
	  public static void addItemsOnSpinner(Context ctx, String[] items, Spinner spinner, int initpos) 
	  {
		  List<String> list = new ArrayList<>();
		  Collections.addAll(list, items);
		  ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(ctx, android.R.layout.simple_spinner_item, list);
		  dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		  spinner.setAdapter(dataAdapter);

		  if (initpos >0 && initpos<items.length)
		  {
			  spinner.setSelection(initpos,false);
		  }
	  }


}
