package com.Weaselution;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

//import android.R.menu;


@SuppressLint("DefaultLocale")
public class Frag02_weasel_settings extends Fragment
{
	private View v = null;
	private ClassAppSettings settings = null;
	private ClassHamlet hamlet = null;
	private boolean isVisible = false;

	Button btn_reset;
	Spinner spinner1;
	private final String[] complexity_modes = {"none","build_up(pos constrained)", "build_up(no pos constrained)", "whole word"};


//	EditText children_per_generation = null;
//	EditText target_string = null;
//	EditText minimum_complexity = null;
//	EditText years_per_generation = null;

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		//setHasOptionsMenu(true);
		if (container == null)
		{
	        return null;
	    }
		super.onCreate(savedInstanceState);
	    v=inflater.inflate(R.layout.frag_weasel_settings, container, false);
	    settings = ClassAppSettings.getInstance();
		hamlet = ClassHamlet.getInstance(null);


		spinner1 = v.findViewById(R.id.spinner_minimum_comlextity);
		UIUtil.addItemsOnSpinner(getActivity(), complexity_modes, spinner1, settings.app.complexity_mode);


		return v;
	}

	@Override
	public void setUserVisibleHint(boolean isVisibleToUser)
	{
	    super.setUserVisibleHint(isVisibleToUser);
		isVisible = isVisibleToUser;
		if (!isVisibleToUser) {
			applySettingsChanges();
			//Toast.makeText(getActivity(), String.format("Settings Update"), Toast.LENGTH_LONG).show();
		}
		update();
	}

    @Override
    public void onPause()
    {
		applySettingsChanges();
        super.onPause();

    }

    @Override
	public void onResume()
    {
    	update();
   	    super.onResume();
    }

	private void resetPhrase()
	{

		settings.app.hamlet_offset = 16454;
		settings.app.hamlet_length = 6;
		String mytarget = hamlet.getTarget(settings.app.hamlet_offset, settings.app.hamlet_length);
		TextView tx = v.findViewById(R.id.target_phrase);
		tx.setText(mytarget);
	}
	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{

		if (!(isVisible && v!=null)) return;

		// set items
		EditText et = v.findViewById(R.id.children_per_generation_val);
		et.setText(String.format("%d",settings.app.children_per_generation));

		et = v.findViewById(R.id.target_phrase);
		et.setText(settings.app.target_string);

		et = v.findViewById(R.id.years_per_gen);
		et.setText(String.format("%1.1f",settings.app.years_per_generation));

//		//seekBar_minimum_complexity
//		SeekBar seekBar_minimum_complexity = (SeekBar)v.findViewById(R.id.seekbar_minimum_comlextity);
//		TextView tx = (TextView)v.findViewById(R.id.minimum_comlextity);
//		String word_mode = getString(R.string.minimum_complexity) + "("+ (getString(R.string.word_mode))+")";
//
//		settings.app.word_mode = settings.app.minimum_complexity>=seekBar_minimum_complexity.getMax();
//		setSeekBarValue(seekBar_minimum_complexity, (float) (settings.app.minimum_complexity),settings.minimum_complexity_m, settings.minimum_complexity_b, tx, getString(R.string.minimum_complexity) + settings.minimum_complexity_format, word_mode, settings.app.word_mode);


//		seekBar_minimum_complexity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
//			@Override
//			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
//
//				float tmp = progress * settings.minimum_complexity_m + settings.minimum_complexity_b;
//				settings.app.minimum_complexity = (int) tmp;
//				String complex_string_update = String.format(getString(R.string.minimum_complexity) + settings.minimum_complexity_format, tmp);
//				settings.app.word_mode = settings.app.minimum_complexity >= seekBar.getMax();
//				if (settings.app.word_mode) {
//					complex_string_update =  getString(R.string.minimum_complexity) + "("+ (getString(R.string.word_mode))+")";
//				}
//				TextView tx = (TextView) v.findViewById(R.id.minimum_comlextity);
//				tx.setText(complex_string_update);
//			}
//
//			@Override
//			public void onStartTrackingTouch(SeekBar arg0) {
//			}
//
//			@Override
//			public void onStopTrackingTouch(SeekBar arg0) {
//			}
//		});
		
		

		// reset button
		if (btn_reset == null)
		{
			btn_reset = v.findViewById(R.id.btn_reset);
			if (btn_reset ==null) return;  //pop out of update if screen not drawn

			btn_reset.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v)
				{
					resetPhrase();
				}
			});
		}

		//seekbar_mutation_perc_per_child
		SeekBar seekBar_mutation_perc_per_child = v.findViewById(R.id.seekbar_mutation_perc_per_child);
        TextView tx = v.findViewById(R.id.mutation_perc_per_child);
		setSeekBarValue(seekBar_mutation_perc_per_child, settings.app.mutation_perc_per_child,settings.mutation_perc_per_child_m, settings.mutation_perc_per_child_b, tx, getString(R.string.mutation_perc_per_child) + settings.mutation_perc_per_child_format, null, false);
		seekBar_mutation_perc_per_child.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				settings.app.mutation_perc_per_child = progress * settings.mutation_perc_per_child_m + settings.mutation_perc_per_child_b;
				TextView tx = v.findViewById(R.id.mutation_perc_per_child);
                String tmp = getString(R.string.mutation_perc_per_child) + String.format(settings.mutation_perc_per_child_format,settings.app.mutation_perc_per_child);
				tx.setText(tmp);
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});


		//seekbar_mutation_perc_per_gen
		SeekBar seekBar_mutation_perc_per_gen = v.findViewById(R.id.seekbar_mutation_perc_per_gen);
		tx = v.findViewById(R.id.mutation_perc_per_gen);
		setSeekBarValue(seekBar_mutation_perc_per_gen, settings.app.mutation_perc_per_gen,settings.mutation_perc_per_gen_m, settings.mutation_perc_per_gen_b, tx,  getString(R.string.mutation_perc_per_gen) + settings.mutation_perc_per_gen_format, null, false);

		seekBar_mutation_perc_per_gen.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				settings.app.mutation_perc_per_gen = progress * settings.mutation_perc_per_gen_m + settings.mutation_perc_per_gen_b;
				TextView tx = v.findViewById(R.id.mutation_perc_per_gen);
                String tmp = getString(R.string.mutation_perc_per_gen) + String.format(settings.mutation_perc_per_gen_format, settings.app.mutation_perc_per_gen);
				tx.setText(tmp);
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});



		//seekbar_hamletoffset
		SeekBar seekBar_hamletoffset = v.findViewById(R.id.seekbar_hamletoffset);
		setSeekBarValue(seekBar_hamletoffset, (float) (settings.app.hamlet_offset),1, 0, null, "", "", true);
		seekBar_hamletoffset.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				settings.app.hamlet_offset = progress;

				String mytarget = hamlet.getTarget(settings.app.hamlet_offset, settings.app.hamlet_length);
				TextView tx = v.findViewById(R.id.target_phrase);
				tx.setText(mytarget);

				//convert to actual value from progress
				//float val = progress*settings.seekbar_hamletoffset_scale + settings.seekbar_hamletoffset_offset;
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

		//seekbar_hamlet_length
		SeekBar seekBar_hamlet_length = v.findViewById(R.id.seekbar_hamlelength);
		setSeekBarValue(seekBar_hamlet_length, (float) (settings.app.hamlet_length),1, 0, null, "", "", true);

		seekBar_hamlet_length.setOnSeekBarChangeListener( new SeekBar.OnSeekBarChangeListener()
		{
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
			{
				settings.app.hamlet_length = progress;
				String mytarget = hamlet.getTarget(settings.app.hamlet_offset, settings.app.hamlet_length);
				TextView tx = v.findViewById(R.id.target_phrase);
				tx.setText(mytarget);

			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {}
		});

	}

	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
	{
//        local_menu = menu.add(0,0,0,"Toggle High Contrast");
    }

   @Override
   public void onPrepareOptionsMenu(Menu menu)
   {
        super.onPrepareOptionsMenu(menu);
   }

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		boolean ret;

		int idx = item.getItemId();
	    switch (idx)
	    {
	        default:
	            ret = super.onOptionsItemSelected(item);
	    }
    	update();
    	return (ret);
	}

	// ----------------------------------------------------------------------
	// applySettingsChanges
	// ----------------------------------------------------------------------
	private void applySettingsChanges()
	{

		if (v==null) return;

		EditText et = v.findViewById(R.id.children_per_generation_val);


		String tmpstr = et.getText().toString();
		if (ClassUtility.isInteger(tmpstr))
		{
			settings.app.children_per_generation = Integer.parseInt(tmpstr);
		}

		//et = v.findViewById(R.id.target_phrase);


		//spinner1 = (Spinner) v.findViewById(R.id.spinner_minimum_comlextity);
		settings.app.complexity_mode =  spinner1.getSelectedItemPosition();



		et = v.findViewById(R.id.years_per_gen);
		tmpstr = et.getText().toString();
		if (ClassUtility.isNumeric(tmpstr))
		{
			settings.app.years_per_generation = Float.parseFloat(tmpstr);
		}


		et = v.findViewById(R.id.target_phrase);
		settings.app.target_string = et.getText().toString();


	}

	// ------------------------------------------------------------------------
	//	setSeekBarValue
	//	format like "base line width (%1.0f pixels)"
	//  TextView tx - text view to update
	//  String format - format string
	//  String static_string,
	//  boolean force_static_string
	// ------------------------------------------------------------------------
	private void setSeekBarValue(SeekBar seekbar, float val, float scale, float offset, TextView tx, String format, String static_string, boolean force_static_string)
	{
		int sval = (int) ((val-offset)/scale);
		seekbar.setProgress(sval);

		if (tx!=null)
		{
			if ((val<=0 && static_string!=null) || force_static_string)
			{
				tx.setText(static_string);
			}
			else
			{
				tx.setText(String.format(format, val));
			}
		}

	}

//	// ------------------------------------------------------------------------
//	//	getSeekBarValue
//	// ------------------------------------------------------------------------
//	private float getSeekBarValue(SeekBar seekbar, float scale, float offset)
//	{
//		return (((float) seekbar.getProgress() * scale + offset));
//	}


}
