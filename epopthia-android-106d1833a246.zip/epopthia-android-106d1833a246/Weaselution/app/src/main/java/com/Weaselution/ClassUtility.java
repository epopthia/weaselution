package com.Weaselution;

import java.util.ArrayList;

class ClassUtility
{

	static String ArrayListToString(ArrayList<String> tokens, String delimiter, int offset, int length)
	{
		String ret = "";
		int tot = tokens.size();

		//verify inputs
		if (tot <=0 || offset<0 || offset>=tot || length<=0 )
		{
			return(ret);
		}

		if (offset + length > tot)
		{
			length = tot-offset;
		}

		ret = tokens.get(offset);
		tot = offset + length;
		for (int inx=offset+1;inx<tot;inx++)
		{
			if (tokens.get(inx)!=null)
			{
				ret = String.format("%s%s%s", ret,delimiter,tokens.get(inx));
			}
		}
		return ret;
	}


	// ------------------------------------------------------------------------
	  //	isInteger
	  // ------------------------------------------------------------------------
	  static boolean isInteger(String str)
	  {
		  try
		  {
			  int tmp = Integer.parseInt(str);
			  return true;
		  } catch (NumberFormatException ignored) {}
		  return false;
	  }

	// ------------------------------------------------------------------------
	//	isNumeric
	// ------------------------------------------------------------------------
	static boolean isNumeric(String str)
	{
		try
		{
			float tmp = Float.parseFloat(str);
			return true;
		} catch (NumberFormatException ignored) {}
		return false;
	}
}
