package com.Weaselution;

import android.annotation.SuppressLint;


@SuppressLint("SimpleDateFormat")
class AppSettings {
	// following are soft start variables
	private boolean is_soft_start; // true if this is a soft kill of the app by the OS

	int children_per_generation;
	String target_string;
	String start_string;
	String current_string;
	boolean word_mode;
	float mutation_perc_per_gen;
	float mutation_perc_per_child;
	int complexity_mode;
	int sim_delay_ms;
	int hamlet_offset;
	int hamlet_length;
	int display_update_rate;
	float years_per_generation;

	AppSettings()
	{
		is_soft_start = false;
	}
	AppSettings(AppSettings ref)
	{
		CopySettings(ref, this);
	}

	void CopySettings(AppSettings src, AppSettings dst)
	{
		dst.children_per_generation = src.children_per_generation;
		dst.hamlet_offset = src.hamlet_offset;
		dst.hamlet_length = src.hamlet_length;
		dst.target_string = src.target_string;
		dst.current_string = src.current_string;
		dst.start_string = src.start_string;
		dst.mutation_perc_per_gen = src.mutation_perc_per_gen;
		dst.mutation_perc_per_child = src.mutation_perc_per_child;
		dst.sim_delay_ms = src.sim_delay_ms;
		dst.display_update_rate = src.display_update_rate;
		dst.years_per_generation = src.years_per_generation;
		dst.is_soft_start = src.is_soft_start;
		dst.word_mode = src.word_mode;

	}

}