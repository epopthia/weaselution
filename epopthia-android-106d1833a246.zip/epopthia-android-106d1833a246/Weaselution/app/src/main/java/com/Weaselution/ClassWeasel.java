package com.Weaselution;

// --------------------------------------------------

import java.util.ArrayList;
import java.util.Random;

// Created by sm403c on 9/3/2015.



// --------------------------------------------------
@SuppressWarnings("ALL")
public class ClassWeasel {
    private ClassAppSettings settings;

    boolean isConverged;
    private long generationNumber;
    private String startPhrase;
    String targetPhrase;
    private final String characterArray = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
    //ArrayList<String> Generations = null; //= new ArrayList<String>();
    Random rand = null;
    private static ClassWeasel objClassWeasel;
    private double last_score;
    private double last_year;
    private double last_conv_year;
    int[] score;// = new int[TargetString.length()];

    private String generation;
    private int current_score;

    private ClassHamlet hamlet;

    private ArrayList<String_with_int> subtokens;

    private final int mode_none = 0;
    private final int mode_buildup_pos = 1;
    private final int mode_buildup_nopos= 2;
    private final int mode_whole_word = 3;


    // Constructor
    // ----------------------------------------------------------------------
    public ClassWeasel()
    {

        hamlet = ClassHamlet.getInstance(null);

        settings = ClassAppSettings.getInstance();

        rand = new Random();

        subtokens = new ArrayList<String_with_int>();

        //maxGenerationListSize = 20;
        reset();
    }

    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized ClassWeasel getInstance()
    {
        if (objClassWeasel == null) {
            objClassWeasel = new ClassWeasel();
        }
        return objClassWeasel;
    }

    private String[] target_tokens;
    private int[] target_tokens_start;
    private int[] target_tokens_end;

    private int[] target_tokens_length;

    private int[] target_subtokens_start;
    private int[] target_subtokens_length;



    //---------------------------------------------------------------------------
    // reset
    //---------------------------------------------------------------------------
    void reset()
    {
        last_score = 0;
        last_year = 0;
        last_conv_year = 0;
        max_perc_converge = 0;

        isConverged = false;
        targetPhrase = settings.app.target_string.toUpperCase();
        startPhrase = generateStartPhrase();
        generation = startPhrase;
        generationNumber = 1;

        // parse target
        // target words
        target_tokens = targetPhrase.split(" ");
        target_tokens_start = new int[target_tokens.length];
        target_tokens_end = new int[target_tokens.length];
        target_tokens_length = new int[target_tokens.length];

        target_subtokens_start = new int[target_tokens.length];
        target_subtokens_length =new int[target_tokens.length];


        subtokens.clear();
        for (int inx = 0;inx<target_tokens.length;inx++)
        {
            subtokens.addAll(hamlet.getSubWords(target_tokens[inx],inx));
        }



        int fromIndex = 0;
        for (int j = 0; j < target_tokens.length; j++)
        {
            // get start position and length of token
            target_tokens_start[j] = targetPhrase.indexOf(target_tokens[j], fromIndex);
            target_tokens_length[j] = target_tokens[j].length();
            target_tokens_end[j] = (target_tokens_start[j]+ target_tokens_length[j])-1;
            fromIndex= target_tokens_end[j]+1;

            Boolean found = false;
            for (int inx = 0;inx<subtokens.size();inx++)
            {
                if (j==subtokens.get(inx).index)
                {
                    if (!found) {
                        target_subtokens_start[j] = inx;
                        found = true;
                    }
                    target_subtokens_length[j]++;
                }
                else
                {
                    if (found) break;
                }
            }
        }


        score = new int[targetPhrase.length()];

    }



    // ----------------------------------------------------------------------
    // stepWeasel
    // ----------------------------------------------------------------------
    String stepWeasel()
    {
        //Generate and Mutate Children
        String current = getCurrentWeasel();
        String test_nextgen;
        String nextgen = current;

        int highestSimilarity = 0;

        for (int i = 0; i < settings.app.children_per_generation; i++)
        {
            if (isMutate(settings.app.mutation_perc_per_gen))
            {
                test_nextgen = reproduceAndMutate(current);
            }
            else
            {
                test_nextgen = current;
            }

            int similarity_score = scoreChild(test_nextgen, targetPhrase, settings.app.complexity_mode);

            // record new best score if needed
            if (similarity_score>highestSimilarity)
            {
                nextgen = test_nextgen;
                highestSimilarity = similarity_score;
            }
            else if(similarity_score==highestSimilarity)
            {
                if (rand.nextInt(1)==1)
                {
                    nextgen = test_nextgen;
                    highestSimilarity = similarity_score;
                }
            }
        }

        if (highestSimilarity>=targetPhrase.length())
        {
            if (settings.app.complexity_mode == mode_buildup_nopos)
            {
                highestSimilarity = scoreChild(nextgen, targetPhrase, mode_buildup_pos);
                if (highestSimilarity>=targetPhrase.length())
                {
                    isConverged = true;
                }
            }
            else {

                isConverged = true;
            }
        }

        current_score = highestSimilarity;
        generation = nextgen;
        generationNumber++;
        return (nextgen);
    }

    //---------------------------------------------------------------------------
    // reproduceAndMutate
    //---------------------------------------------------------------------------
    private String reproduceAndMutate(String parent)
    {
        String child = parent;
        do
        {
            child = changeCharInPosition(rand.nextInt(child.length()), characterArray.charAt(rand.nextInt(characterArray.length())), child);
        }
        while (isMutate(settings.app.mutation_perc_per_child));
        return(child) ;
    }

    //---------------------------------------------------------------------------
    // changeCharInPosition
    //---------------------------------------------------------------------------
    private String changeCharInPosition(int position, char ch, String str)
    {
        char[] charArray = str.toCharArray();
        charArray[position] = ch;
        return new String(charArray);
    }

    //---------------------------------------------------------------------------
    // getCurrentGeneration
    //---------------------------------------------------------------------------
    long getCurrentGeneration() {
        return (generationNumber);
    }


    private float max_perc_converge;
    //---------------------------------------------------------------------------
    // generateStartPhrase
    //---------------------------------------------------------------------------
    double getConvergenceYear(float perc_converge)
    {
        double conv_year = 0;

        double current_year = getCurrentYear();

        if (!isConverged) {
            double dscore_per_year;

            if (current_year > last_year && perc_converge >= max_perc_converge)
            {
                dscore_per_year = (current_score - last_score) / (current_year - last_year);
                if (dscore_per_year > 0) {
                    conv_year = current_year + (targetPhrase.length() / dscore_per_year);
                }
            }
        }
        else
        {
            conv_year = current_year;
        }

        last_year = current_year;
        last_score = current_score;

        if (conv_year>0 || current_year>last_conv_year)
        {
            last_conv_year = conv_year;
        }

        if (perc_converge >= max_perc_converge)
        {
            max_perc_converge = perc_converge;
        }

        return last_conv_year;

    }


    //---------------------------------------------------------------------------
    // getCurrentWeasel
    //---------------------------------------------------------------------------
    String getCurrentWeasel()
    {
        return (generation);
    }

    //---------------------------------------------------------------------------
    // getCurrentConvergedPerc
    //---------------------------------------------------------------------------
    float getCurrentConvergedPerc()
    {
        float perc = 0;
        float target = targetPhrase.length();
        //float cs = current_score;

        int cs = scoreChild(generation, targetPhrase, mode_none);


        if (target>0)
        {
            perc =  (float) ( cs / target * 100.0);
        }
        return perc;
    }

    //---------------------------------------------------------------------------
    // getCurrentYear
    //---------------------------------------------------------------------------
    float getCurrentYear()
    {
        return (generationNumber*settings.app.years_per_generation);
    }



    //---------------------------------------------------------------------------
    // scoreChild
    //---------------------------------------------------------------------------
    private int scoreChild(String childString, String TargetString, int complexity_mode)
    {
        int similarity_score;

        char[] testc = childString.toCharArray();
        char[] targetc = TargetString.toCharArray();


        // step thru the string and set the score where ==
        int tot = TargetString.length();
        for (int j=0;j<tot;j++) {
            if (testc[j] == targetc[j]) {
                score[j] = 1;
            } else {
                score[j] = 0;
            }
        }

        //settings.app.complexity_mode
        // if there is any complexity, then the score may need to be adjusted
        if (complexity_mode!=mode_none)
        {
            for (int j = 0; j < target_tokens.length; j++) //each word
            {
                // for word mode integrate the score, it must be word length to mark as good
                if (complexity_mode==mode_whole_word)
                {
                    // step thru each of the words and score
                    for (int k = target_tokens_start[j]; k <= target_tokens_end[j]; k++)
                    {
                        // clear all matches if the word requirement is not satisfied
                        if (score[k] == 0)
                        {
                            for (int lnx = target_tokens_start[j]; lnx < target_tokens_start[j] + target_tokens_length[j]; lnx++)
                            {
                                score[lnx] = 0;
                            }
                            break; // break the for loop since there is no more to do here
                        }
                    }
                }
                else //buildup
                {
                    // extract strings for the given token
                    String substr = childString.substring(target_tokens_start[j], target_tokens_end[j]+1);
                    scoreSubChild(substr,j, complexity_mode);
                }
            }
        }

        // sum for total score
        similarity_score = 0;
        for (int aScore : score) {
            similarity_score += aScore;
        }

        return (similarity_score);

    }

    //---------------------------------------------------------------------------
    // scoreSubChild
    //---------------------------------------------------------------------------
    void scoreSubChild(String substr, int j, int complexity_mode)
    {

        char[] substrc = substr.toCharArray();
        char[] targetc = target_tokens[j].toCharArray();

        //clear the score
        int steps = target_tokens_end[j]-target_tokens_start[j]+1;
        for (int inx = target_tokens_start[j];inx<=target_tokens_end[j];inx++) {
            score[inx] = 0;
        }

        int jnx = 0;
        int tot = 0;
        if (complexity_mode==mode_buildup_pos) {
            for (int inx = target_tokens_start[j]; inx <= target_tokens_end[j]; inx++) {
                // remove any chars that don't match the target-this prevents buildup from favorable
                // scoring of strings that are out-of-position but match sub strings
                if (substrc[jnx] != targetc[jnx]) {
                    substrc[jnx] = '-';
                    tot++;
                }
                jnx++;
            }
            substr = String.valueOf(substrc);
        }

        if (tot<steps) {
            int totscore = 0;
            for (int inx = target_subtokens_start[j]; inx < (target_subtokens_start[j] + target_subtokens_length[j]); inx++) {
                String tmpstr = subtokens.get(inx).str;
                int tmplen = tmpstr.length();
                int start = substr.indexOf(tmpstr);
                if (start >= 0) {
                    for (jnx = start; jnx < start + tmplen; jnx++) {
                        score[target_tokens_start[j] + jnx] = 1;
                        totscore++;
                    }
                }
            }

            // if this is an unconstrained position buildup, then degrade the score by 1 so evolution does
            // not get stuck as we have satisfied the score but not the design criterion
            jnx = 0;
            if (complexity_mode != mode_buildup_pos && totscore==target_subtokens_length[j]) {
                for (int inx = target_tokens_start[j]; inx <= target_tokens_end[j]; inx++) {
                    // remove any chars that don't match the target-this prevents buildup from favorable
                    // scoring of strings that are out-of-position but match sub strings
                    if (substrc[jnx] != targetc[jnx]) {
                        for (int knx = target_tokens_start[j]; knx <= target_tokens_end[j]; knx++) {
                            score[knx] = 0;
                        }
                        break;
                    }
                    jnx++;
                }

            }
        }
    }

    //---------------------------------------------------------------------------
    // generateStartPhrase
    //---------------------------------------------------------------------------
    private String generateStartPhrase()
    {
        String parent = targetPhrase;
        StringBuilder sb = new StringBuilder();
        for (int inx=0;inx<parent.length();inx++)
        {
            sb.append(characterArray.charAt(rand.nextInt(characterArray.length())));
        }
        return (sb.toString());
    }

    //---------------------------------------------------------------------------
    // isMutate
    //---------------------------------------------------------------------------
    private boolean isMutate(float mutation_percent)
    {
        boolean ret = true;
        if (mutation_percent<100.0)
        {
            float rat = rand.nextFloat();
            if (mutation_percent<(rat*100))
            {
                ret = false;
            }
        }
        return ret;
    }

    
}
