package com.Weaselution;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.PowerManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.MenuItem;

import java.util.List;
import java.util.Vector;


public class ActivityMain extends FragmentActivity 
{

	private Handler mHandler;

	private static final int MY_CHILD_ACTIVITY = 10;
	private static ClassAppSettings settings = null; // application settings


    private static ClassWeasel weasel = null;


	private PowerManager.WakeLock mWakeLock;
	private AppSettings last_settings = null;


	@SuppressLint("WakelockTimeout")
    @Override
	protected void onCreate(Bundle savedInstanceState) 
	{

		// Get the one and only instance of settings
		settings = ClassAppSettings.getInstance(this);
        ClassHamlet.getInstance(this);
		weasel = ClassWeasel.getInstance();

		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewpager_layout);

		mHandler = new Handler(); //setup for timed updates


		//don't let the app go to sleep
		PowerManager pm = (PowerManager) this.getSystemService(Context.POWER_SERVICE);
        assert pm != null;
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Weaselution:wakelock");
        mWakeLock.acquire();
	   	initialisePaging();

		last_settings = new AppSettings(settings.app);

	}

	@Override
	public void onResume()
	{
		super.onResume();

	}

	@Override
	public void onPause()
	{
		super.onPause();
	}
	
	@Override
	protected void onDestroy() 
	{
		stopRepeatingTask();
		mWakeLock.release();
		settings.saveSettings(this);
		super.onDestroy();
	}
	
	private void initialisePaging() 
	{
		List<Fragment> fragments = new Vector<>();
		fragments.add(Fragment.instantiate(this,Frag01_weasel.class.getName()));
		fragments.add(Fragment.instantiate(this,Frag02_weasel_settings.class.getName()));

		PagerAdapter mPagerAdapter = new PagerAdapter(this.getSupportFragmentManager(), fragments);
		ViewPager pager = findViewById(R.id.viewpager);
		pager.setAdapter(mPagerAdapter);
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
	    switch (item.getItemId()) 
	    {

	    default:
	        return super.onOptionsItemSelected(item);
	    }
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		switch(requestCode) 
		{
	    	case (MY_CHILD_ACTIVITY) : 
	    	{
	    		if (resultCode == Activity.RESULT_OK) 
	    		{
	    			Bundle extras = data.getExtras();
					if (extras != null) 
					{	
						settings.app.CopySettings(settings.app, last_settings);
						processSettingsChanges();
					}
	    		}
	    		break;
		    } 
		}
	}

	// ------------------------------------------------------------------------
	//	processSettingsChanges
	// ------------------------------------------------------------------------
	private void processSettingsChanges()
	{	
		//write settings to non-volatile
		settings.saveSettings(this);
	}


	//---------------------------------------------------------------------------

	// onSaveInstanceState
	//---------------------------------------------------------------------------
	@Override
	public void onSaveInstanceState(Bundle savedInstanceState) 
	{
	  super.onSaveInstanceState(savedInstanceState);
	  settings.saveSettings(this);

	}
	public boolean mrunning;
	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	public void startRepeatingTask()
	{
		if (!mrunning) {
			if (!weasel.isConverged) {
				mrunning = true;
				mReproduce.run();
			}
		}
	}
	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
	public void stopRepeatingTask()
	{
		mHandler.removeCallbacks(mReproduce);
		mrunning = false;
	}

	//---------------------------------------------------------------------------
	// mReproduce
	//---------------------------------------------------------------------------
	private final Runnable mReproduce = new Runnable()
	{
		@Override
		public void run()
		{

			weasel.stepWeasel();
			if (!weasel.isConverged)
			{
				if (settings.app.sim_delay_ms<=0)
				{
					mHandler.post(mReproduce);
				}
				else
				{
					long ms = settings.app.sim_delay_ms;
					mHandler.postDelayed(mReproduce,ms);
				}
			}
			else
			{
				stopRepeatingTask();
			}
		}
	};

}
