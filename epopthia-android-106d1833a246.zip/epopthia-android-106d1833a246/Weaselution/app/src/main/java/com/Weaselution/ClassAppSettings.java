package com.Weaselution;


import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

class ClassAppSettings  {

	private static ClassAppSettings objClassAppSettings;

    private SharedPreferences preferences;

	// preferences
	final AppSettings app;

	final float  sim_gen_per_refhresh_m = 1;
	final float  sim_gen_per_refhresh_b = 1;

	final float mutation_perc_per_gen_m = 1;
	final float mutation_perc_per_gen_b = 0;
	final String mutation_perc_per_gen_format =  "("+"%02.1f" + ")";

	final float mutation_perc_per_child_m = 1;
	final float mutation_perc_per_child_b = 0;
	final String mutation_perc_per_child_format = "("+"%02.1f" + ")";


	// ----------------------------------------------------------------------
	// getInstance
	// ----------------------------------------------------------------------
	static synchronized ClassAppSettings getInstance()
	{
		return getInstance(null);
	}

	// ----------------------------------------------------------------------
	// getInstance
	// ----------------------------------------------------------------------
	static synchronized ClassAppSettings getInstance(Context context)
	{
		if(objClassAppSettings == null) // && context != null)
		{
			if (context == null) {
				objClassAppSettings = new ClassAppSettings();
			} else {

				objClassAppSettings = new ClassAppSettings(context);
			}
		}
		return objClassAppSettings;
	}

	// ----------------------------------------------------------------------
	// Constructor
	// ----------------------------------------------------------------------
	private ClassAppSettings()
	{
		app = new AppSettings();
	}

	// ----------------------------------------------------------------------
	// Constructor
	// ----------------------------------------------------------------------
    private ClassAppSettings(Context context) {
		app = new AppSettings();
		loadSettings(context);
	}

	private void loadSettings(Context context)
	{
		preferences = PreferenceManager.getDefaultSharedPreferences(context);

		app.children_per_generation = preferences.getInt("children_per_generation", 100);
		app.target_string = preferences.getString("target_string", "Methinks it is like a weasel");
		app.start_string = preferences.getString("start_string", "WDLTMNLT DTJBKWIRZREZLMQCO P");
		app.current_string = preferences.getString("current_string", "WDLTMNLT DTJBKWIRZREZLMQCO P");
		app.years_per_generation = preferences.getFloat("years_per_generation", (float) 1.0);
		app.display_update_rate = preferences.getInt("display_update_rate", 1);
		app.word_mode = preferences.getBoolean("word_mode", false);
		app.mutation_perc_per_gen = preferences.getFloat("mutation_perc_per_gen", (float) 100.0);
		app.hamlet_offset = preferences.getInt("hamlet_offset", 16454);
		app.hamlet_length = preferences.getInt("hamlet_length", 6);
		app.sim_delay_ms = preferences.getInt("sim_delay_ms",0);
		app.complexity_mode = preferences.getInt("complexity_mode",0);

	}

	void saveSettings(Context context)
	{
		preferences = PreferenceManager.getDefaultSharedPreferences(context);

		SharedPreferences.Editor editor = preferences.edit();
		editor.putInt("hamlet_offset", app.hamlet_offset);
		editor.putInt("hamlet_length", app.hamlet_length);
		editor.putInt("children_per_generation", app.children_per_generation);
		editor.putString("target_string", app.target_string);
		editor.putString("start_string", app.start_string);
		editor.putString("current_string", app.current_string);
		editor.putFloat("years_per_generation", app.years_per_generation);
		editor.putInt("display_update_rate", app.display_update_rate);
		editor.putBoolean("word_mode", app.word_mode);
		editor.putFloat("mutation_perc_per_gen", app.mutation_perc_per_gen);
		editor.putFloat("mutation_perc_per_child", app.mutation_perc_per_child);
		editor.putInt("sim_delay_ms",app.sim_delay_ms);
		editor.putInt("complexity_mode",app.complexity_mode);

		editor.apply();
	}

}
