package com.Weaselution;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.Objects;

//import android.R.menu;


@SuppressLint("DefaultLocale")
public class Frag01_weasel extends Fragment
{
	private View v = null;
	private Handler mHandler;
	//private boolean mrunning;

	//GUI objects
	Button reset_button;
	Button go_button;
	TextView text_current_generation;
	TextView text_current_weasel;
	TextView text_current_perc_converged;
	TextView text_current_years;
	TextView text_convergence;

	private boolean mrunning;

	private ClassWeasel weasel;


	//private int display_update_rate_count;
	ClassAppSettings settings = null;

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		//setHasOptionsMenu(true);
		if (container == null) return null;
		super.onCreate(savedInstanceState);
		//get settings
		settings = ClassAppSettings.getInstance();

		weasel = ClassWeasel.getInstance();
		
		mHandler = new Handler(); //setup for timed updates

		mrunning = false;

	    v=inflater.inflate(R.layout.frag_weasel_main, container, false);

		return v;
	}
	
	@Override
	public void setUserVisibleHint(boolean isVisibleToUser) 
	{
	    super.setUserVisibleHint(isVisibleToUser);
	    if (isVisibleToUser && v!=null) 
	    { 
			update();	
	    }
	}
    
    @Override
    public void onPause() 
    {
		stopRepeatingTask();
		super.onPause();
    }

 
    @Override
	public void onResume() 
    {
		update();
		if (((ActivityMain)Objects.requireNonNull(getActivity())).mrunning)
		{
			startRepeatingTask();
		}
		super.onResume();
    }


	//---------------------------------------------------------------------------
	// updateStatus
	//---------------------------------------------------------------------------
	private  void updateStatus()
	{
		DecimalFormat formatter = new DecimalFormat("###,###,###,###");

		text_current_generation.setText(formatter.format(weasel.getCurrentGeneration()));
		text_current_years.setText(formatter.format(weasel.getCurrentYear()));
		text_current_weasel.setText(weasel.getCurrentWeasel());

		float perc_conv = weasel.getCurrentConvergedPerc();

		text_current_perc_converged.setText(String.format("%1.1f%%", perc_conv));

		double cy = weasel.getConvergenceYear(perc_conv);
		if (cy>0) {
			text_convergence.setText(formatter.format(cy));
		}
		else {
			text_convergence.setText(R.string.infinite);
		}
	}
	// ----------------------------------------------------------------------
	// update
	// ----------------------------------------------------------------------
	private void update()
	{

		reset_button = v.findViewById(R.id.button_reset);
		if (reset_button ==null) return;  //pop out of update if screen not drawn

		go_button = v.findViewById(R.id.button_go);
		if (go_button ==null) return;  //pop out of update if screen not drawn

		text_current_generation = v.findViewById(R.id.current_generation);
		text_current_weasel = v.findViewById(R.id.current_weasel);
		text_current_years = v.findViewById(R.id.current_years);
		text_convergence = v.findViewById(R.id.converge_years);
		text_current_perc_converged = v.findViewById(R.id.percent_converged);

		//seekbar_sim_gen_per_refhresh
		SeekBar seekbar_sim_gen_per_refhresh = v.findViewById(R.id.seekbar_sim_gen_per_refresh);
		setSeekBarValue(seekbar_sim_gen_per_refhresh, (float) (settings.app.display_update_rate), settings.sim_gen_per_refhresh_m, settings.sim_gen_per_refhresh_b);
		seekbar_sim_gen_per_refhresh.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				settings.app.display_update_rate = (int) (progress * settings.sim_gen_per_refhresh_m + settings.sim_gen_per_refhresh_b);
				updateStatus();
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
			}

			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
			}
		});


		//seekbar_simulation speed
		SeekBar seekBar_sim_delay_ms = v.findViewById(R.id.seekbar_sim_delay_ms);
		setSeekBarValue(seekBar_sim_delay_ms, (float) (settings.app.sim_delay_ms),1, 0);

		seekBar_sim_delay_ms.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
				settings.app.sim_delay_ms = progress;
			}

			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
			}

			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
			}
		});


		updateStatus();

		reset_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v)
			{
				weasel.reset();
				updateStatus();
			}
		});

		go_button.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				if (weasel.targetPhrase.length()<=0)
				{
					return;
				}
				if (((ActivityMain)Objects.requireNonNull(getActivity())).mrunning)
				{
					stopRepeatingTask();
					((ActivityMain)getActivity()).stopRepeatingTask();
				}
				else
				{
					startRepeatingTask();
					((ActivityMain)getActivity()).startRepeatingTask();
				}
		}
		});
	}


	@Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) 
	{
//        local_menu = menu.add(0,0,0,"Toggle High Contrast");
    }
	
	@Override
	public void onPrepareOptionsMenu(Menu menu)
	{
		super.onPrepareOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		boolean ret;

		int idx = item.getItemId();
	    switch (idx) 
	    {
	        default:
	            ret = super.onOptionsItemSelected(item);
	    }   
    	update();
    	return (ret);
	}

	// ------------------------------------------------------------------------
	//	setSeekBarValue
	//	format like "base line width (%1.0f pixels)"
	// ------------------------------------------------------------------------
	private void setSeekBarValue(SeekBar seekbar, float val, float scale, float offset)
	{
		int sval = (int) ((val-offset)/scale);
		seekbar.setProgress(sval);

	}


	//---------------------------------------------------------------------------
	// startRepeatingTask
	//---------------------------------------------------------------------------
	public void startRepeatingTask()
	{
		if (!mrunning) {
			if (!weasel.isConverged) {
				mrunning = true;
				mReproduce.run();
				if (!((ActivityMain) Objects.requireNonNull(getActivity())).mrunning)
				{
					((ActivityMain) getActivity()).startRepeatingTask();
				}
			}
		}

		updateButton();

	}

	//---------------------------------------------------------------------------
	// updateButton
	//---------------------------------------------------------------------------
	private void updateButton()
	{

		if (mrunning) {
			go_button.setText(R.string.pause);
		}
		else {
			go_button.setText(R.string.Run);
		}
	}
	//---------------------------------------------------------------------------
	// stopRepeatingTask
	//---------------------------------------------------------------------------
	public void stopRepeatingTask()
	{
		mHandler.removeCallbacks(mReproduce);
		mrunning = false;
		updateButton();

	}

	//---------------------------------------------------------------------------
	// mReproduce
	//---------------------------------------------------------------------------
	private final Runnable mReproduce = new Runnable()
	{
		@Override
		public void run()
		{
			updateStatus();

			if (!weasel.isConverged)
			{
				long ms = settings.app.display_update_rate;
				ms = Math.max(ms,100);
				mHandler.postDelayed(mReproduce,ms);
			}
			else
			{
				updateStatus();
				stopRepeatingTask();
			}
		}
	};

}
