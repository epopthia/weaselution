package com.Weaselution;// --------------------------------------------------

import android.content.Context;
import android.content.res.AssetManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;

 class String_with_int
{
    String str;
    int index;
}

// Created by sm403c on 2/1/2016.
// --------------------------------------------------
public class ClassHamlet {

    private static ClassHamlet objClassHamlet;
    public ArrayList<String> hamlet;
    public ArrayList<String_with_int> hamlet_w_len;
    public int[] start_index = null;


    // ----------------------------------------------------------------------
    // getInstance
    // ----------------------------------------------------------------------
    public static synchronized ClassHamlet getInstance(Context context)
    {
        if(objClassHamlet == null) // && context != null)
        {
            objClassHamlet = new ClassHamlet(context);
        }
        return objClassHamlet;
    }


    public ArrayList<String_with_int> getSubWords(String target, int index)
    {
        ArrayList<String_with_int> ret = new ArrayList<String_with_int>();

        if (target.length()>0)
        {
            //start index
            int inx = 0;
            for (inx = target.length() - 1; inx >= 0; inx--) {
                if (start_index[inx] > 0) break;
            }

            for (int jnx = start_index[inx]; jnx >= 0; jnx--) {
                if (target.contains(hamlet_w_len.get(jnx).str)) {
                    String_with_int item = new String_with_int();
                    item.str = hamlet_w_len.get(jnx).str;
                    item.index = index;
                    ret.add(item);
                }
            }
        }
        return (ret);
    }

    // Constructor
    // ----------------------------------------------------------------------
    public ClassHamlet(Context context)
    {
        //read the file
        hamlet = new ArrayList<String>();
        readHamletFile("hamlet.txt", context);
        //int hamlet_len = hamlet.size();

        // remove duplicate strings from hamlet
        ArrayList<String> hamlet_no_repeat=new ArrayList<String>();
        HashSet<String> hashSet = new HashSet<String>();
        hashSet.addAll(hamlet);
        hamlet_no_repeat.clear();
        hamlet_no_repeat.addAll(hashSet);

        hamlet_w_len = new ArrayList<String_with_int>();

        //get hamlet_w_len
        for (String item:hamlet_no_repeat) {
            String_with_int newitem = new String_with_int();
            newitem.str = item;
            newitem.index = item.length();
            hamlet_w_len.add(newitem);
        }
        //sort
        Collections.sort(hamlet_w_len, new LenComparator());

        //find index where strings of the same size start
        String_with_int max = hamlet_w_len.get(hamlet_w_len.size()-1);
        start_index = new int[max.index];

        int jnx = start_index.length-1;
        int last_len = -1;
        for (int inx = hamlet_w_len.size()-1;inx>=0;inx--)
        {
            if (last_len!=hamlet_w_len.get(inx).index) {
                last_len = hamlet_w_len.get(inx).index;
                start_index[last_len-1] = inx;
            }
        }


//        jnx = 0;

    }

    public class LenComparator implements Comparator<String_with_int>
    {
        public int compare(String_with_int left, String_with_int right) {
            return left.index - right.index;
        }
    }
    // ----------------------------------------------------------------------
    // readTextFile
    // ----------------------------------------------------------------------
    private void readHamletFile(String text_file, Context context)
    {
        AssetManager assetManager = context.getAssets();
        try
        {
            InputStreamReader istrm;
            istrm = new InputStreamReader (assetManager.open(text_file));

            BufferedReader br = new BufferedReader(istrm);
            String strLine;

            while ((strLine = br.readLine()) != null)
            {
                hamlet.add(strLine);
            }
            istrm.close();

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    // ----------------------------------------------------------------------
    // readTextFile
    // ----------------------------------------------------------------------
    public String getTarget(int offset, int length)
    {
        return (ClassUtility.ArrayListToString(hamlet, " ", offset, length));
    }


}
